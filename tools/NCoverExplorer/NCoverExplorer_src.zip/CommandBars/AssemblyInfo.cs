using System.Reflection;

//
// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
//
[assembly: AssemblyTitle("CommandBars")]
[assembly: AssemblyDescription("Lutz Roeder's CommandBar code for menus and toolbars.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("CommandBar")]
[assembly: AssemblyCopyright("Copyright � 2006 Lutz Roeder.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		
[assembly: AssemblyVersion("1.0.0.0")]
