// ---------------------------------------------------------
// Windows Forms CommandBar Control
// Copyright (C) 2001-2003 Lutz Roeder. All rights reserved.
// http://www.aisto.com/roeder
// Grant Drake - changed to inherit from CommandBarButton instead of
// CommandBarButtonBase so it can have keyboard shortcuts
// ---------------------------------------------------------
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace System.Windows.Forms
{
	[DesignTimeVisible(false), ToolboxItem(false)]
	public class CommandBarCheckBox : CommandBarButton
	{
		private bool isChecked = false;

		public CommandBarCheckBox() : base("None")
		{
		}

		public CommandBarCheckBox(string text) : base(text)
		{
		}
	
		public CommandBarCheckBox(string text, EventHandler clickHandler) : base(text, clickHandler)
		{	
		}
	
		public CommandBarCheckBox(string text, EventHandler clickHandler, Keys shortcut) : base(text, clickHandler, shortcut)
		{	
		}
	
		public CommandBarCheckBox(Image image, string text) : base(image, text, null)
		{	
		}
	
		public CommandBarCheckBox(Image image, string text, EventHandler clickHandler) : base(image, text, clickHandler)
		{	
		}
	
		public CommandBarCheckBox(Image image, string text, EventHandler clickHandler, Keys shortcut) : base(image, text, clickHandler, shortcut)
		{	
		}

		public bool Checked
		{
			set
			{ 
				if (value != this.isChecked)
				{ 
					this.isChecked = value; 
					this.OnPropertyChanged(new PropertyChangedEventArgs("IsChecked")); 
				}
			}

			get { return this.isChecked; }
		}

		protected override void OnClick(EventArgs e)
		{
			this.Checked = !this.Checked;
			base.OnClick(e);
		}

		public override string ToString()
		{
			return "CheckBox(" + this.Text + "," + this.Checked + ")";
		}
	}
}
