// ---------------------------------------------------------
// Windows Forms CommandBar Control
// Copyright (C) 2001-2003 Lutz Roeder. All rights reserved.
// http://www.aisto.com/roeder
// Grant Drake - added support for .Parent relationship
// ---------------------------------------------------------
using System;
using System.ComponentModel;

namespace System.Windows.Forms
{
	[DesignTimeVisible(false), ToolboxItem(false)]
	public class CommandBarMenu : CommandBarItem
	{
		public event EventHandler DropDown;
		private CommandBarItemCollection items;

		public CommandBarMenu() : this("None")
		{
		}

		public CommandBarMenu(string text) : base(text)
		{
			items = new CommandBarItemCollection(this);
		}

		[TypeConverter(typeof(ExpandableObjectConverter)), DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
		public CommandBarItemCollection Items
		{
			get { return this.items; }
		}

		protected virtual void OnDropDown(EventArgs e)
		{
			if (this.DropDown != null)
			{
				this.DropDown(this, e);
			}
		}

		internal void PerformDropDown(EventArgs e)
		{
			this.OnDropDown(e);
		}
	}
}
