using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Tests.Core
{
	/// <summary>
	/// Summary description for TestCoverageTreeFactory.
	/// </summary>
	public class TestCoverageTreeFactory
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="TestCoverageTreeFactory"/> class.
		/// </summary>
		public TestCoverageTreeFactory(IExplorerConfiguration configuration)
		{
			_configuration = configuration;
		}

		#endregion Constructor

		public CoverageFileTreeNode CreateTree()
		{
			return new CoverageFileTreeNode(_configuration, "");
		}

		public void AddChildModuleTreeNode(CoverageFileTreeNode coverageFileTreeNode, string moduleName,
			string assemblyName, string namespaceName)
		{
			ModuleTreeNode moduleTreeNode = new ModuleTreeNode(_configuration, moduleName, assemblyName);
			coverageFileTreeNode.Nodes.Add(moduleTreeNode);
			AddChildNamespaceAndClassTreeNode(moduleTreeNode, namespaceName);
		}

		public void AddChildNamespaceNode(TreeNode parentTreeNode, string namespaceName)
		{
			NamespaceTreeNode namespaceTreeNode = new NamespaceTreeNode(_configuration, namespaceName, namespaceName);
			parentTreeNode.Nodes.Add(namespaceTreeNode);
		}

		public void AddChildNamespacesNestedTreeNode(TreeNode parentTreeNode, string namespaceName, string fullyQualifiedName, string namespace2)
		{
			NamespaceTreeNode namespaceTreeNode = new NamespaceTreeNode(_configuration, namespaceName, fullyQualifiedName);
			parentTreeNode.Nodes.Add(namespaceTreeNode);
			AddChildNamespaceAndClassTreeNode(namespaceTreeNode, namespace2);
		}

		public void AddChildNamespaceAndClassTreeNode(TreeNode parentTreeNode, string namespaceName)
		{
			NamespaceTreeNode namespaceTreeNode = new NamespaceTreeNode(_configuration, namespaceName, namespaceName);
			parentTreeNode.Nodes.Add(namespaceTreeNode);
			AddChildClassTreeNode(namespaceTreeNode,  "Test");
		}

		public ClassTreeNode AddChildClassTreeNode(TreeNode parentTreeNode, string className)
		{
			ClassTreeNode classTreeNode = new ClassTreeNode(_configuration, className, className);
			parentTreeNode.Nodes.Add(classTreeNode);
			MethodTreeNode methodTreeNode = new MethodTreeNode(_configuration, "TestMethod", className);
			classTreeNode.Nodes.Add(methodTreeNode);
			methodTreeNode.SequencePoints.Add(new SequencePoint("TestMethod",1,1,1,1,5,"Test.cs"));
			methodTreeNode.TotalSequencePoints = 1;
			return classTreeNode;
		}

	}
}
