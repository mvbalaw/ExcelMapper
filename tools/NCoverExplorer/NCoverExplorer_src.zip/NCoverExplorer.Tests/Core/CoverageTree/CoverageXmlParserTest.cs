using System;
using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Parser;
using NUnit.Framework;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Tests.Core.CoverageTree
{
	/// <summary>
	/// TestFixture class for the CoverageXmlParser class.
	/// </summary>
	[TestFixture]
	public class CoverageXmlParserTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageXmlParserTest"/> class.
		/// </summary>
		public CoverageXmlParserTest()
		{
		}

		#endregion Constructor

		#region Tests

		/// <summary>
		/// Test parsing of a large file - temporary test to be run manually.
		/// </summary>
		[Test(Description="Test parsing of a large file - temporary test to be run manually.")]
		[Explicit]
		public void ParseLargeFileOnce()
		{
			// TODO: Change or remove test - do we want a large file in source control or should we generate on fly?
			HighPerformanceTimer timer = new HighPerformanceTimer();
			timer.Start();
			CoverageXmlParser xmlParser = new CoverageXmlParser(new ExplorerConfiguration(null));
			xmlParser.LoadFile(@"E:\Dev\NCoverExplorer\CoverageXml\Coverage.Full.xml");
			timer.Stop();
			Console.WriteLine("Completed CoverageParser(old) in: " + timer.Duration.ToString());
		}

		/// <summary>
		/// Test parsing of a large file multiple times - temporary test to be run manually.
		/// </summary>
		[Test(Description="Test parsing of a large file multiple times - temporary test to be run manually.")]
		[Explicit]
		public void ParseLargeFileMultipleTimes()
		{
			// TODO: Change or remove test - do we want a large file in source control or should we generate on fly?
			HighPerformanceTimer timer = new HighPerformanceTimer();
			timer.Start();
			for	(int index=0; index < 5; index++)
			{
				CoverageXmlParser xmlParser = new CoverageXmlParser(new ExplorerConfiguration(null));
				xmlParser.LoadFile(@"E:\Dev\NCoverExplorer\CoverageXml\Coverage.Full.xml");
			}
			timer.Stop();
			Console.WriteLine("Completed CoverageParser(old) in: " + timer.Duration.ToString());
		}

		#endregion Tests
	}
}
