using System.Windows.Forms;
using NUnit.Framework;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Tests.Core.CoverageTree
{
	/// <summary>
	/// Test fixture for the TreeViewSorter class.
	/// </summary>
	[TestFixture]
	public class TreeViewSorterTest
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="TreeViewSorterTest"/> class.
		/// </summary>
		public TreeViewSorterTest()
		{
		}

		#endregion Constructor

		#region Test Setup / TearDown

		/// <summary>
		/// Test setup.
		/// </summary>
		[SetUp]
		public void Setup()
		{
			_configuration = new ExplorerConfiguration(null, null, null);
		}

		#endregion Test Setup / TearDown

		#region Tests

		/// <summary>
		///Test the treeview sort algorithm.
		/// </summary>
		[Test(Description="Test the treeview sort algorithm.")]
		public void SortTreeViewSimple()
		{
			TreeView treeView = new TreeView();
			treeView.Nodes.Add(new ModuleTreeNode(_configuration, "B", "TestB"));
			treeView.Nodes.Add(new ModuleTreeNode(_configuration, "A", "TestA"));

			Assert.AreEqual("TestB", treeView.Nodes[0].Text, "Before sort [0]");
			Assert.AreEqual("TestA", treeView.Nodes[1].Text, "Before sort [1]");

			TreeViewSorter.SortTreeView(treeView);

			Assert.AreEqual(2, treeView.Nodes.Count, "After sort count");
			Assert.AreEqual("TestA", treeView.Nodes[0].Text, "After sort [0]");
			Assert.AreEqual("TestB", treeView.Nodes[1].Text, "After sort [1]");
		}

		/// <summary>
		///Test the treeview sort algorithm.
		/// </summary>
		[Test(Description="Test the treeview sort algorithm.")]
		public void SortTreeViewNested()
		{
			TreeView treeView = new TreeView();
			CoverageFileTreeNode root = new CoverageFileTreeNode(_configuration, "Root");
			treeView.Nodes.Add(root);
			root.Nodes.Add(new ModuleTreeNode(_configuration, "C", "TestC"));
			root.Nodes.Add(new ModuleTreeNode(_configuration, "A", "TestA"));
			root.Nodes.Add(new ModuleTreeNode(_configuration, "D", "TestD"));
			root.Nodes.Add(new ModuleTreeNode(_configuration, "B", "TestB"));

			Assert.AreEqual("TestC", root.Nodes[0].Text, "Before sort [0]");
			Assert.AreEqual("TestA", root.Nodes[1].Text, "Before sort [1]");
			Assert.AreEqual("TestD", root.Nodes[2].Text, "Before sort [2]");
			Assert.AreEqual("TestB", root.Nodes[3].Text, "Before sort [3]");

			TreeViewSorter.SortTreeView(treeView);

			Assert.AreEqual(1, treeView.Nodes.Count, "After sort count");
			Assert.AreEqual(4, root.Nodes.Count, "After sort root count");
			Assert.AreEqual("TestA", root.Nodes[0].Text, "After sort [0]");
			Assert.AreEqual("TestB", root.Nodes[1].Text, "After sort [1]");
			Assert.AreEqual("TestC", root.Nodes[2].Text, "After sort [2]");
			Assert.AreEqual("TestD", root.Nodes[3].Text, "After sort [3]");
		}

		#endregion Tests
	}
}
