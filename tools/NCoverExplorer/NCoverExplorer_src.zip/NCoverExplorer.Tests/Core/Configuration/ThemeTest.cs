using System;
using System.ComponentModel;
using System.Drawing;
using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Utilities;
using NUnit.Framework;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// Test fixture for the Theme and ThemeCollection classes.
	/// </summary>
	[TestFixture]
	public class ThemeTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ThemeTest"/> class.
		/// </summary>
		public ThemeTest()
		{
		}

		#endregion Constructor

		#region Tests

		#region Theme Class

		/// <summary>
		/// Read default theme colours.
		/// </summary>
		[Test(Description="Read default theme colours.")]
		public void ConstructNewTheme()
		{
			Theme theme = new Theme();
			Assert.AreEqual(Theme.DefaultThemeName, theme.Name, "Name");
			Assert.AreEqual(HighlightVisitedCodeStyle.Block, theme.HighlightVisitedCodeStyle, "HighlightVisitedCodeStyle");
			Assert.AreEqual(HighlightUnvisitedCodeStyle.Block, theme.HighlightUnvisitedCodeStyle, "HighlightUnvisitedCodeStyle");
			Assert.AreEqual(HighlightVisitedCodeStyle.Block, theme.HighlightExcludedCodeStyle, "HighlightExcludedCodeStyle");
			Assert.AreEqual(Color.FromArgb(224, 237, 253).Name, theme.HighlightVisitedCodeColor.Name, "HighlightVisitedCodeColor");
			Assert.AreEqual(Color.FromArgb(230, 176, 165).Name, theme.HighlightUnvisitedCodeColor.Name, "HighlightUnvisitedCodeColor");
			Assert.AreEqual(Color.LightGray.Name, theme.HighlightExcludedCodeColor.Name, "HighlightExcludedCodeColor");
			Assert.AreEqual(Color.Black.Name, theme.TreeNodeFullCoverageColor.Name, "TreeNodeFullCoverageColor");
			Assert.AreEqual(Color.Blue.Name, theme.TreeNodeSatisfactoryCoverageColor.Name, "TreeNodeSatisfactoryCoverageColor");
			Assert.AreEqual(Color.Red.Name, theme.TreeNodePartiallyVisitedColor.Name, "TreeNodePartiallyVisitedColor");
			Assert.AreEqual(Color.Gray.Name, theme.TreeNodeUnvisitedColor.Name, "TreeNodeUnvisitedColor");
			Assert.AreEqual(Color.Gray.Name, theme.TreeNodeExcludedCoverageColor.Name, "TreeNodeExcludedCoverageColor");
			Assert.AreEqual(SystemColors.Window.Name, theme.CoverageTreeBackgroundColor.Name,  "CoverageTreeBackgroundColor");
			Assert.AreEqual(SystemColors.Window.Name, theme.StatisticsPaneBackgroundColor.Name,  "StatisticsPaneBackgroundColor");
			Assert.AreEqual(SystemColors.Window.Name, theme.SourceCodeBackgroundColor.Name,  "SourceCodeBackgroundColor");
			Assert.AreEqual(SystemColors.ControlDark.Name, theme.SourceCodeLineNumbersColor.Name,  "SourceCodeLineNumbers");
			Assert.AreEqual("Tahoma", theme.CoverageTreeFont.Name,  "CoverageTreeFont");
			Assert.AreEqual("Tahoma", theme.StatisticsPaneFont.Name,  "StatisticsPaneFont");
			Assert.AreEqual("Courier New", theme.SourceCodeFont.Name,  "SourceCodeFont");

			int[] customDialogColors = theme.GetDefaultCustomColorsForPicker();
			Assert.AreEqual(16, customDialogColors.Length, "CustomColors.Length");

			Assert.AreEqual(Theme.DefaultThemeName, theme.ToString(), "ToString()");
		}

		/// <summary>
		/// Test serializing and deserializing theme.
		/// </summary>
		[Test(Description="Test serializing and deserializing theme.")]
		public void SerializeTheme()
		{
			Theme theme = _CreateCustomTheme();
			string serializedTheme = SerializationUtilities.SerializeToXml(theme);
			Assert.IsNotNull(serializedTheme, "IsNotNull when serialized");
			Assert.IsTrue(serializedTheme.Length > 0, "Length when serialized");
			Theme themeCopy = (Theme)SerializationUtilities.DeserializeFromXml(serializedTheme, typeof(Theme));
			Assert.IsNotNull(themeCopy, "IsNotNull after deserialized");

			Assert.AreEqual("Grant", themeCopy.Name);
			Assert.AreEqual(HighlightVisitedCodeStyle.None, theme.HighlightVisitedCodeStyle, "HighlightVisitedCodeStyle");
			Assert.AreEqual(HighlightUnvisitedCodeStyle.Underlined, theme.HighlightUnvisitedCodeStyle, "HighlightUnvisitedCodeStyle");
			Assert.AreEqual(HighlightVisitedCodeStyle.None, theme.HighlightExcludedCodeStyle, "HighlightExcludedCodeStyle");
			Assert.AreEqual(Color.AliceBlue.Name, theme.CoverageTreeBackgroundColor.Name, "CoverageTreeBackgroundColor");
			Assert.AreEqual(Color.AntiqueWhite.Name, theme.HighlightUnvisitedCodeColor.Name, "HighlightUnvisitedCodeColor");
			Assert.AreEqual(Color.Aqua.Name, theme.HighlightVisitedCodeColor.Name, "HighlightVisitedCodeColor");
			Assert.AreEqual(Color.Red.Name, theme.HighlightExcludedCodeColor.Name, "HighlightExcludedCodeColor");
			Assert.AreEqual(Color.Aquamarine.Name, theme.SourceCodeBackgroundColor.Name, "SourceCodeBackgroundColor");
			Assert.AreEqual(Color.Azure.Name, theme.SourceCodeLineNumbersColor.Name, "SourceCodeLineNumbersColor");
			Assert.AreEqual(Color.Beige.Name, theme.StatisticsPaneBackgroundColor.Name, "StatisticsPaneBackgroundColor");
			Assert.AreEqual(Color.Bisque.Name, theme.TreeNodeFullCoverageColor.Name, "TreeNodeFullCoverageColor");
			Assert.AreEqual(Color.Black.Name, theme.TreeNodePartiallyVisitedColor.Name, "TreeNodePartiallyVisitedColor");
			Assert.AreEqual(Color.BlanchedAlmond.Name, theme.TreeNodeSatisfactoryCoverageColor.Name, "TreeNodeSatisfactoryCoverageColor");
			Assert.AreEqual(Color.FromArgb(1,2,3,4).Name, theme.TreeNodeUnvisitedColor.Name, "TreeNodeUnvisitedColor");
			Assert.AreEqual(Color.RosyBrown.Name, theme.TreeNodeExcludedCoverageColor.Name, "TreeNodeExcludedCoverageColor");
			Assert.AreEqual("Arial", theme.CoverageTreeFont.Name, "CoverageTreeFont");
			Assert.AreEqual("Arial", theme.SourceCodeFont.Name, "SourceCodeFont");
			Assert.AreEqual("Arial", theme.StatisticsPaneFont.Name, "StatisticsPaneFont");
		}

		/// <summary>
		/// Clone a theme.
		/// </summary>
		[Test(Description="Clone a theme.")]
		public void CloneTheme()
		{
			Theme theme = new Theme("Grant");
			theme.HighlightUnvisitedCodeStyle = HighlightUnvisitedCodeStyle.Underlined;
			Theme cloneTheme = theme.Clone();
			Assert.AreEqual(theme.Name, cloneTheme.Name, "Name");
			Assert.AreEqual(theme.HighlightUnvisitedCodeStyle, cloneTheme.HighlightUnvisitedCodeStyle, "HighlightUnvisitedCodeStyle");
			Assert.AreNotSame(theme, cloneTheme, "NotSame");
		}


		/// <summary>
		/// Test setting visited code style to an invalid value throws expected exception
		/// </summary>
		[Test(Description="Test setting visited code style to an invalid value throws expected exception.")]
		[ExpectedException(typeof(InvalidEnumArgumentException))]
		public void InvalidHighlightVisitedCodeStyle()
		{
			Theme theme = new Theme();
			theme.HighlightVisitedCodeStyle = (HighlightVisitedCodeStyle)(-1);
		}

		/// <summary>
		/// Test setting unvisited code style to an invalid value throws expected exception
		/// </summary>
		[Test(Description="Test setting unvisited code style to an invalid value throws expected exception.")]
		[ExpectedException(typeof(InvalidEnumArgumentException))]
		public void InvalidHighlightUnvisitedCodeStyle()
		{
			Theme theme = new Theme();
			theme.HighlightUnvisitedCodeStyle = (HighlightUnvisitedCodeStyle)(-1);
		}

		/// <summary>
		/// Test setting excluded code style to an invalid value throws expected exception
		/// </summary>
		[Test(Description="Test setting excluded code style to an invalid value throws expected exception.")]
		[ExpectedException(typeof(InvalidEnumArgumentException))]
		public void InvalidExcludedCodeStyle()
		{
			Theme theme = new Theme();
			theme.HighlightExcludedCodeStyle = (HighlightVisitedCodeStyle)(-1);
		}

		#endregion Theme Class

		#region ThemeCollection Class

		/// <summary>
		/// Test the ThemeCollection class methods and properties.
		/// </summary>
		[Test(Description="Test the ThemeCollection class methods and properties.")]
		public void ThemeCollectionMethodsAndProperties()
		{
			ThemeCollection themes = new ThemeCollection();
			Theme theme1 = new Theme("Theme1");
			Theme theme2 = new Theme("Theme2");
			Theme theme3 = new Theme("Theme3");

			themes.Add(theme1);
			themes.Add(theme2);
			themes.Insert(1, theme3);

			Assert.AreEqual(3, themes.Count, "Count");
			Assert.AreEqual(theme1, themes[0], "themes[0]");
			Assert.AreEqual(theme3, themes[1], "themes[1]");
			Assert.AreEqual(theme2, themes[2], "themes[2]");
			Assert.AreEqual(1, themes.IndexOf(theme3), "IndexOf(theme)");
			Assert.AreEqual(2, themes.IndexOf("Theme2"), "IndexOf(themeName)");
			Assert.AreEqual(-1, themes.IndexOf("NonExistentTheme"), "IndexOf(NonExistentTheme)");

			Assert.IsTrue(themes.Contains(theme1), "Contains true");

			Assert.IsNull(themes["NonExistentTheme"], "this[NonExistentTheme]");
			Assert.AreEqual(theme3, themes["Theme3"], "this[Theme3]");

			themes.Remove(theme3);
			Assert.AreEqual(2, themes.Count, "Count after Remove");
			Assert.IsFalse(themes.Contains(theme3), "Contains after remove");

			themes.RemoveAt(0);
			Assert.AreEqual(1, themes.Count, "Count after RemoveAt");
			Assert.AreEqual(theme2, themes[0], "Correct item removed");

			themes[0] = theme1;
			Assert.AreEqual(theme1, themes[0], "themes[0] after set[int]");
			themes["Theme1"] = theme3;
			Assert.AreEqual(theme3, themes[0], "themes[0] after set[string]");

			themes.Clear();
			Assert.AreEqual(0, themes.Count, "Count after Clear()");
		}

		/// <summary>
		/// Test accessing a string value out of range should throw exception.
		/// </summary>
		[Test(Description="Test accessing a string value out of range should throw exception.")]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void InvalidIndexerString()
		{
			ThemeCollection themes = new ThemeCollection();
			themes["DoesntExist"] = new Theme();
		}

		#endregion ThemeCollection Class

		#endregion Tests

		#region Private Helper Methods

		private static Theme _CreateCustomTheme()
		{
			Theme theme = new Theme();

			theme.Name = "Grant";
			theme.HighlightVisitedCodeStyle = HighlightVisitedCodeStyle.None;
			theme.HighlightUnvisitedCodeStyle = HighlightUnvisitedCodeStyle.Underlined;
			theme.HighlightExcludedCodeStyle = HighlightVisitedCodeStyle.None;
			theme.CoverageTreeBackgroundColor = Color.AliceBlue;
			theme.HighlightUnvisitedCodeColor = Color.AntiqueWhite;
			theme.HighlightVisitedCodeColor = Color.Aqua;
			theme.HighlightExcludedCodeColor = Color.Red;
			theme.SourceCodeBackgroundColor = Color.Aquamarine;
			theme.SourceCodeLineNumbersColor = Color.Azure;
			theme.StatisticsPaneBackgroundColor = Color.Beige;
			theme.TreeNodeFullCoverageColor = Color.Bisque;
			theme.TreeNodePartiallyVisitedColor = Color.Black;
			theme.TreeNodeSatisfactoryCoverageColor = Color.BlanchedAlmond;
			theme.TreeNodeUnvisitedColor = Color.FromArgb(1,2,3,4);
			theme.TreeNodeExcludedCoverageColor = Color.RosyBrown;
			theme.CoverageTreeFont = new Font("Arial", 20f);
			theme.SourceCodeFont = new Font("Arial", 21f);
			theme.StatisticsPaneFont = new Font("Arial", 22f);

			return theme;
		}

		#endregion Private Helper Methods
	}
}
