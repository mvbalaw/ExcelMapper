using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Utilities;

using NUnit.Framework;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// Test fixture for the CoverageExclusion and CoverageExclusionCollection classes.
	/// </summary>
	[TestFixture]
	public class CoverageExclusionTest
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private TestCoverageTreeFactory _coverageTreeFactory;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageExclusionTest"/> class.
		/// </summary>
		public CoverageExclusionTest()
		{
		}

		#endregion Constructor

		#region Test Setup / Teardown

		/// <summary>
		/// Test setup.
		/// </summary>
		[SetUp]
		public void Setup()
		{
			_configuration = new ExplorerConfiguration(null, null, null);
			_coverageTreeFactory = new TestCoverageTreeFactory(_configuration);
		}

		#endregion Test Setup / Teardown

		#region Tests

		#region CoverageExclusion Class

		/// <summary>
		/// Create a new coverage exclusion.
		/// </summary>
		[Test(Description="Read default exclusion colours.")]
		public void ConstructNewCoverageExclusion()
		{
			CoverageExclusion coverageExclusion = new CoverageExclusion(ExclusionType.Assembly, "Grant");
			Assert.AreEqual(ExclusionType.Assembly, coverageExclusion.ExclusionType, "ExclusionType");
			Assert.AreEqual("Grant", coverageExclusion.Pattern, "Pattern");
			Assert.AreEqual(true, coverageExclusion.Enabled, "Enabled");

			CoverageExclusion coverageExclusion2 = new CoverageExclusion(ExclusionType.Assembly, "Grant");
			Assert.IsTrue(coverageExclusion2.Equals(coverageExclusion), "Equals");
			Assert.AreEqual(coverageExclusion2.GetHashCode(), coverageExclusion.GetHashCode(), "GetHashCode");

			CoverageExclusion coverageExclusion3 = new CoverageExclusion(ExclusionType.Assembly, "Grant3");
			Assert.IsFalse(coverageExclusion3.Equals(coverageExclusion), "Equals Different");
			Assert.AreNotEqual(coverageExclusion3.GetHashCode(), coverageExclusion.GetHashCode(), "GetHashCode Different");
		}

		/// <summary>
		///Test the matching exclusion with exact match.
		/// </summary>
		[Test(Description="Test the matching exclusion with exact match.")]
		public void MatchingExclusionExact()
		{
			CoverageExclusion coverageExclusion = new CoverageExclusion(ExclusionType.Assembly, "Grant");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("Grant"), "Grant");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("Grant1"), "Grant1");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("grant"), "grant");
		}

		/// <summary>
		///Test the matching exclusion with starts with match.
		/// </summary>
		[Test(Description="Test whether the matching exclusion with starts with match.")]
		public void MatchingExclusionStartsWith()
		{
			CoverageExclusion coverageExclusion = new CoverageExclusion(ExclusionType.Assembly, "Grant*");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("Grant"), "Grant");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("Grant1"), "Grant1");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("grant"), "grant");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("SomeGrant"), "SomeGrant");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("SomethingGrant1"), "SomethingGrant1");
		}

		/// <summary>
		///Test the matching exclusion with ends with match.
		/// </summary>
		[Test(Description="Test whether the matching exclusion with ends with match.")]
		public void MatchingExclusionEndsWith()
		{
			CoverageExclusion coverageExclusion = new CoverageExclusion(ExclusionType.Assembly, "*Grant");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("Grant"), "Grant");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("Grant1"), "Grant1");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("grant"), "grant");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("SomeGrant"), "SomeGrant");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("SomethingGrant1"), "SomethingGrant1");
		}

		/// <summary>
		///Test the matching exclusion with contains match.
		/// </summary>
		[Test(Description="Test whether the matching exclusion with contains match.")]
		public void MatchingExclusionContains()
		{
			CoverageExclusion coverageExclusion = new CoverageExclusion(ExclusionType.Assembly, "*Grant*");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("Grant"), "Grant");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("Grant1"), "Grant1");
			Assert.AreEqual(false, coverageExclusion.IsMatchingExclusion("grant"), "grant");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("SomeGrant"), "SomeGrant");
			Assert.AreEqual(true, coverageExclusion.IsMatchingExclusion("SomethingGrant1"), "SomethingGrant1");
		}

		/// <summary>
		/// Test serializing and deserializing exclusion.
		/// </summary>
		[Test(Description="Test serializing and deserializing exclusion.")]
		public void SerializeCoverageExclusion()
		{
			CoverageExclusion coverageExclusion = new CoverageExclusion(ExclusionType.Assembly, "Grant");
			coverageExclusion.Enabled = false;

			string serializedCoverageExclusion = SerializationUtilities.SerializeToXml(coverageExclusion);
			Assert.IsNotNull(serializedCoverageExclusion, "IsNotNull when serialized");
			Assert.IsTrue(serializedCoverageExclusion.Length > 0, "Length when serialized");
			CoverageExclusion exclusionCopy = (CoverageExclusion)SerializationUtilities.DeserializeFromXml(serializedCoverageExclusion, typeof(CoverageExclusion));
			Assert.IsNotNull(exclusionCopy, "IsNotNull after deserialized");

			Assert.AreEqual(ExclusionType.Assembly, exclusionCopy.ExclusionType, "ExclusionType");
			Assert.AreEqual("Grant", exclusionCopy.Pattern, "Pattern");
			Assert.AreEqual(false, exclusionCopy.Enabled, "Enabled");
		}

		#endregion CoverageExclusion Class

		#region CoverageExclusionCollection Class

		/// <summary>
		/// Test the CoverageExclusionCollection class methods and properties.
		/// </summary>
		[Test(Description="Test the CoverageExclusionCollection class methods and properties.")]
		public void CoverageExclusionCollectionMethodsAndProperties()
		{
			CoverageExclusionCollection exclusions = new CoverageExclusionCollection();
			CoverageExclusion coverageExclusion1 = new CoverageExclusion(ExclusionType.Assembly, "Tests");
			CoverageExclusion coverageExclusion2 = new CoverageExclusion(ExclusionType.Namespace, "My");
			CoverageExclusion coverageExclusion3 = new CoverageExclusion(ExclusionType.Namespace, "My.Resources");

			Assert.AreEqual(false, exclusions.IsDirty, "IsDirty before add");

			exclusions.Add(coverageExclusion1);
			exclusions.Add(coverageExclusion2);
			Assert.AreEqual(true, exclusions.IsDirty, "IsDirty after add");
			exclusions.IsDirty = false;
			exclusions.Insert(1, coverageExclusion3);
			Assert.AreEqual(true, exclusions.IsDirty, "IsDirty after insert");

			Assert.AreEqual(3, exclusions.Count, "Count");
			Assert.AreEqual(coverageExclusion1, exclusions[0], "exclusions[0]");
			Assert.AreEqual(coverageExclusion3, exclusions[1], "exclusions[1]");
			Assert.AreEqual(coverageExclusion2, exclusions[2], "exclusions[2]");
			Assert.AreEqual(1, exclusions.IndexOf(coverageExclusion3), "IndexOf(exclusion)");

			Assert.IsTrue(exclusions.Contains(coverageExclusion1), "Contains true");

			exclusions.IsDirty = false;
			exclusions.Remove(coverageExclusion3);
			Assert.AreEqual(true, exclusions.IsDirty, "IsDirty after Remove");
			Assert.AreEqual(2, exclusions.Count, "Count after Remove");
			Assert.IsFalse(exclusions.Contains(coverageExclusion3), "Contains after remove");

			exclusions.IsDirty = false;
			exclusions.RemoveAt(0);
			Assert.AreEqual(true, exclusions.IsDirty, "IsDirty after RemoveAt");
			Assert.AreEqual(1, exclusions.Count, "Count after RemoveAt");
			Assert.AreEqual(coverageExclusion2, exclusions[0], "Correct item removed");

			exclusions.IsDirty = false;
			exclusions[0] = coverageExclusion1;
			Assert.AreEqual(true, exclusions.IsDirty, "IsDirty after set[int]");
			Assert.AreEqual(coverageExclusion1, exclusions[0], "exclusions[0] after set[int]");

			exclusions.Clear();
			Assert.AreEqual(0, exclusions.Count, "Count after Clear()");
		}

		/// <summary>
		/// Test cloning a CoverageExclusion collection.
		/// </summary>
		[Test(Description="Test cloning a CoverageExclusion collection.")]
		public void CloneCollection()
		{
			CoverageExclusionCollection exclusions = new CoverageExclusionCollection();
			CoverageExclusion coverageExclusion1 = new CoverageExclusion(ExclusionType.Assembly, "Tests");
			CoverageExclusion coverageExclusion2 = new CoverageExclusion(ExclusionType.Namespace, "My");
			CoverageExclusion coverageExclusion3 = new CoverageExclusion(ExclusionType.Namespace, "My.Resources");
			exclusions.Add(coverageExclusion1);
			exclusions.Add(coverageExclusion2);
			exclusions.Add(coverageExclusion3);

			CoverageExclusionCollection exclusionsClone = exclusions.Clone();
			Assert.AreEqual(exclusions.Count, exclusionsClone.Count, "Count");
			// Change one of the clone values and verify original is not changed.
			Assert.AreEqual(coverageExclusion1.Pattern, exclusionsClone[0].Pattern, "Pattern Before");
			Assert.AreNotSame(coverageExclusion1.Pattern, exclusionsClone[0].Pattern, "NotSame");
			exclusionsClone[0].Pattern = "AlteredValue";
			Assert.AreEqual("AlteredValue", exclusionsClone[0].Pattern, "Pattern Changed");
			Assert.AreNotEqual(coverageExclusion1.Pattern, exclusionsClone[0].Pattern, "Pattern After");
		}

		#endregion CoverageExclusionCollection Class

		#region CoverageManager Class

		#region Apply Exclusions For Assembly

		/// <summary>
		/// Test the assembly exclusions.
		/// </summary>
		[Test(Description="Test the assembly exclusions.")]
		public void ApplyExclusionsForAssembly()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();

			_coverageTreeFactory.AddChildModuleTreeNode(coverageFileTreeNode, "mymodule1.dll", "NoMatch", "TestNamespace");
			_coverageTreeFactory.AddChildModuleTreeNode(coverageFileTreeNode, "mymodule2.dll", "Grant", "TestNamespace");
			_coverageTreeFactory.AddChildModuleTreeNode(coverageFileTreeNode, "mymodule3.dll", "grant", "TestNamespace");
			_coverageTreeFactory.AddChildModuleTreeNode(coverageFileTreeNode, "mymodule4.dll", "Grant4", "TestNamespace");
			_coverageTreeFactory.AddChildModuleTreeNode(coverageFileTreeNode, "mymodule5.dll", "5Grant", "TestNamespace");
			_coverageTreeFactory.AddChildModuleTreeNode(coverageFileTreeNode, "mymodule6.dll", "6Grant6", "TestNamespace");

			Assert.AreEqual(6, coverageFileTreeNode.Nodes.Count, "Count Before Exclude");

			// Now apply the exclusions
			CoverageExclusionCollection coverageExclusions = new CoverageExclusionCollection();
			coverageExclusions.Add(new CoverageExclusion(ExclusionType.Assembly, "*Grant*"));
			ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(coverageExclusions);
			coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);

			Assert.AreEqual(3, coverageFileTreeNode.Nodes.Count, "Count After Exclude");
			Assert.AreEqual("NoMatch", coverageFileTreeNode.Nodes[0].Text, "Node[0]");
			Assert.AreEqual("grant", coverageFileTreeNode.Nodes[1].Text, "Node[1]");
			Assert.AreEqual("Excluded", ((TreeNodeBase)coverageFileTreeNode.Nodes[2]).NodeName, "[Excluded]");
		}

		#endregion Apply Exclusions For Assembly

		#region Apply Exclusions For Namespace

		/// <summary>
		/// Test the namespace exclusions with exact match.
		/// </summary>
		[Test(Description="Test the namespace exclusions with exact match.")]
		public void ApplyExclusionsForNamespaceExact()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			ModuleTreeNode moduleTreeNode = _BuildNamespaceTestData(coverageFileTreeNode);

			// Now apply the exclusions
			CoverageExclusionCollection coverageExclusions = new CoverageExclusionCollection();
			coverageExclusions.Add(new CoverageExclusion(ExclusionType.Namespace, "Grant"));
			ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(coverageExclusions);
			coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);

			Assert.AreEqual(6, moduleTreeNode.Nodes.Count, "Count After Exclude");
			Assert.AreEqual("Excluded", ((TreeNodeBase)moduleTreeNode.Nodes[5]).NodeName, "[Excluded]");
			Assert.AreEqual(1, ((TreeNodeBase)moduleTreeNode.Nodes[5]).Nodes.Count, "[Excluded] Count");
		}

		/// <summary>
		/// Test the namespace exclusions with contains match.
		/// </summary>
		[Test(Description="Test the namespace exclusions with contains match.")]
		public void ApplyExclusionsForNamespaceContains()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			ModuleTreeNode moduleTreeNode = _BuildNamespaceTestData(coverageFileTreeNode);

			// Now apply the exclusions
			CoverageExclusionCollection coverageExclusions = new CoverageExclusionCollection();
			coverageExclusions.Add(new CoverageExclusion(ExclusionType.Namespace, "*Grant*"));
			ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(coverageExclusions);
			coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);

			Assert.AreEqual(4, moduleTreeNode.Nodes.Count, "Count After Exclude");
			Assert.AreEqual("!NoMatch", moduleTreeNode.Nodes[0].Text, "Node[0]");
			Assert.AreEqual("!grant", moduleTreeNode.Nodes[1].Text, "Node[1]");
			Assert.AreEqual("!ParentOk", moduleTreeNode.Nodes[2].Text, "Node[2]");
			Assert.AreEqual("Excluded", ((TreeNodeBase)moduleTreeNode.Nodes[3]).NodeName, "[Excluded]");
			Assert.AreEqual(3, ((TreeNodeBase)moduleTreeNode.Nodes[3]).Nodes.Count, "[Excluded] Count");
		}

		/// <summary>
		/// Test the namespace exclusions with starts with match.
		/// </summary>
		[Test(Description="Test the namespace exclusions with starts with match.")]
		public void ApplyExclusionsForNamespaceStartsWith()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			ModuleTreeNode moduleTreeNode = _BuildNamespaceTestData(coverageFileTreeNode);

			// Now apply the exclusions
			CoverageExclusionCollection coverageExclusions = new CoverageExclusionCollection();
			coverageExclusions.Add(new CoverageExclusion(ExclusionType.Namespace, "Grant*"));
			ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(coverageExclusions);
			coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);

			Assert.AreEqual(5, moduleTreeNode.Nodes.Count, "Count After Exclude");
			Assert.AreEqual("!NoMatch", moduleTreeNode.Nodes[0].Text, "Node[0]");
			Assert.AreEqual("!grant", moduleTreeNode.Nodes[1].Text, "Node[1]");
			Assert.AreEqual("!5Grant", moduleTreeNode.Nodes[2].Text, "Node[2]");
			Assert.AreEqual("!ParentOk", moduleTreeNode.Nodes[3].Text, "Node[3]");
			Assert.AreEqual("Excluded", ((TreeNodeBase)moduleTreeNode.Nodes[4]).NodeName, "[Excluded]");
			Assert.AreEqual(2, ((TreeNodeBase)moduleTreeNode.Nodes[4]).Nodes.Count, "[Excluded] Count");
		}

		/// <summary>
		/// Test the namespace exclusions with ends with match.
		/// </summary>
		[Test(Description="Test the namespace exclusions with ends with match.")]
		public void ApplyExclusionsForNamespaceEndsWith()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			ModuleTreeNode moduleTreeNode = _BuildNamespaceTestData(coverageFileTreeNode);

			// Now apply the exclusions
			CoverageExclusionCollection coverageExclusions = new CoverageExclusionCollection();
			coverageExclusions.Add(new CoverageExclusion(ExclusionType.Namespace, "*Grant"));
			ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(coverageExclusions);
			coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);

			Assert.AreEqual(5, moduleTreeNode.Nodes.Count, "Count After Exclude");
			Assert.AreEqual("!NoMatch", moduleTreeNode.Nodes[0].Text, "Node[0]");
			Assert.AreEqual("!grant", moduleTreeNode.Nodes[1].Text, "Node[1]");
			Assert.AreEqual("!Grant4", moduleTreeNode.Nodes[2].Text, "Node[2]");
			Assert.AreEqual("!ParentOk", moduleTreeNode.Nodes[3].Text, "Node[3]");
			Assert.AreEqual("Excluded", ((TreeNodeBase)moduleTreeNode.Nodes[4]).NodeName, "[Excluded]");
			Assert.AreEqual(2, ((TreeNodeBase)moduleTreeNode.Nodes[4]).Nodes.Count, "[Excluded] Count");
		}

		/// <summary>
		/// Construct test data for the namespace tests.
		/// </summary>
		private ModuleTreeNode _BuildNamespaceTestData(CoverageFileTreeNode coverageFileTreeNode)
		{
			ModuleTreeNode moduleTreeNode = new ModuleTreeNode(_configuration, "mymodule2.dll", "Grant");
			coverageFileTreeNode.Nodes.Add(moduleTreeNode);
	
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode, "NoMatch", "NoMatch", "SubNamespace");
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode, "Grant", "Grant", "SubNamespace");
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode, "grant", "grant", "SubNamespace");
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode, "Grant4", "Grant4", "SubNamespace");
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode, "5Grant", "5Grant", "SubNamespace");
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode, "ParentOk", "ParentOk", "GrantToRemove");
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode.Nodes[5].Nodes[0], "WillRemove", "ParentOk.GrantToRemove.WillRemove", "ChildNode");
			_coverageTreeFactory.AddChildNamespacesNestedTreeNode(moduleTreeNode.Nodes[5], "DontRemove", "ParentOk.DontRemove", "NoRemoval");

			Assert.AreEqual(6, moduleTreeNode.Nodes.Count, "Count Before Exclude");
			Assert.AreEqual(2, moduleTreeNode.Nodes[5].Nodes.Count, "ParentOk Count Before Exclude");

			return moduleTreeNode;
		}

		#endregion Apply Exclusions For Namespace

		#region Apply Exclusions For Class

		/// <summary>
		/// Test the class exclusions.
		/// </summary>
		[Test(Description="Test the class exclusions.")]
		public void ApplyExclusionsForClasses()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			ModuleTreeNode moduleTreeNode = new ModuleTreeNode(_configuration, "mymodule2.dll", "Grant");
			NamespaceTreeNode namespaceTreeNode = new NamespaceTreeNode(_configuration, "MyNamespace", "MyNamespace");
			coverageFileTreeNode.Nodes.Add(moduleTreeNode);
			moduleTreeNode.Nodes.Add(namespaceTreeNode);

			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode, "NoMatch");
			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode, "Grant");
			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode, "grant");
			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode, "Grant4");
			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode, "5Grant");
			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode, "ParentOk");
			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode.Nodes[5], "GrantToRemove");
			_coverageTreeFactory.AddChildClassTreeNode(namespaceTreeNode.Nodes[5], "DontRemove");

			Assert.AreEqual(6, namespaceTreeNode.Nodes.Count, "Count Before Exclude");
			Assert.AreEqual(3, namespaceTreeNode.Nodes[5].Nodes.Count, "ParentOk Count Before Exclude");

			// Now apply the exclusions
			CoverageExclusionCollection coverageExclusions = new CoverageExclusionCollection();
			coverageExclusions.Add(new CoverageExclusion(ExclusionType.Class, "*Grant*"));
			ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(coverageExclusions);
			coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);

			Assert.AreEqual(4, namespaceTreeNode.Nodes.Count, "Count After Exclude");
			Assert.AreEqual("NoMatch", namespaceTreeNode.Nodes[0].Text, "Node[0]");
			Assert.AreEqual("grant", namespaceTreeNode.Nodes[1].Text, "Node[1]");
			Assert.AreEqual("ParentOk", namespaceTreeNode.Nodes[2].Text, "Node[2]");
			Assert.AreEqual(3, namespaceTreeNode.Nodes[2].Nodes.Count, "ParentOk Count After Exclude");
			Assert.AreEqual("Excluded", ((TreeNodeBase)namespaceTreeNode.Nodes[3]).NodeName, "[Excluded]");
			Assert.AreEqual(3, namespaceTreeNode.Nodes[3].Nodes.Count, "[Excluded] Top Count");
			Assert.AreEqual("Excluded", ((TreeNodeBase)namespaceTreeNode.Nodes[2].Nodes[2]).NodeName, "[Excluded] Inner");
			Assert.AreEqual(1, namespaceTreeNode.Nodes[2].Nodes[2].Nodes.Count, "[Excluded] Inner Count");
		}

		#endregion Apply Exclusions For Class

		#endregion CoverageManager Class

		#endregion Tests
	}
}
