using System.IO;
using System.Xml.Serialization;

using NCoverExplorer.Core.Configuration;
using NUnit.Framework;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// Test fixture for the PersistentConfiguration class.
	/// </summary>
	[TestFixture]
	public class PersistentConfigurationTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="PersistentConfigurationTest"/> class.
		/// </summary>
		public PersistentConfigurationTest()
		{
		}

		#endregion Constructor

		#region Tests

		/// <summary>
		///Read config file to verify deserialization. Currently needs .config file in bin\debug folder.
		/// </summary>
		[Test(Description="Read config file to verify deserialization. Currently needs .config file in bin\\debug folder.")]
		[Explicit]
		public void ReadToVerifyDeserialization()
		{
			// TODO: Change test to copy embedded resource to location for test to run.
			XmlSerializer serializer = new XmlSerializer(typeof (PersistentConfiguration));
			PersistentConfiguration persistentConfiguration;
			using (StreamReader configFile = File.OpenText("NCoverExplorer.Config"))
			{
				persistentConfiguration = (PersistentConfiguration) serializer.Deserialize(configFile);
			}
			Assert.AreEqual(2, persistentConfiguration.FormStates.Count, "FormStates");
			Assert.AreEqual(1, persistentConfiguration.MruStates.Count, "MruStates");
		}

		#endregion Tests
	}
}
