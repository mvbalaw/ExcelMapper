using System;
using NUnit.Framework;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// TestFixture for the MruState class.
	/// </summary>
	[TestFixture]
	public class MruStateTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MruStateTest"/> class.
		/// </summary>
		public MruStateTest()
		{
		}

		#endregion Constructor

		#region	Tests

		#region Xml Serialization

		/// <summary>
		/// Check the custom xml serialization of the MruState class for single entity.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the MruState class for single entity.")]
		public void CheckXMLSerializationSingleForSingleEntity()
		{
			const string SerializedValue = @"<MruState MenuId=""MyMenuId""><Items><Item Name=""C:\Test1.txt"" /><Item Name=""C:\Test2.txt"" /></Items></MruState>";

			MruState mruState = new MruState("MyMenuId");
			mruState.Add(@"C:\Test1.txt");
			mruState.Add(@"C:\Test2.txt");

			string xml = SerializationUtilities.SerializeToXml(mruState);
			Assert.AreEqual(SerializedValue, xml, "SerializedValue");

			mruState = (MruState)SerializationUtilities.DeserializeFromXml(xml, typeof(MruState));
			Assert.IsNotNull(mruState, "IsNotNull");
			Assert.AreEqual("MyMenuId", mruState.MenuId, "MenuId");
			Assert.AreEqual(2, mruState.Count, "Count");
			Assert.AreEqual(@"C:\Test1.txt", mruState[0], "[0]");
			Assert.AreEqual(@"C:\Test2.txt", mruState[1], "[1]");
		}

		/// <summary>
		/// Check the custom xml serialization of the MruState class with no settings specified.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the MruState class with no settings specified.")]
		public void CheckXMLSerializationWithEmptyItems()
		{
			const string SerializedValue = @"<MruState MenuId=""MyMenuId""><Items /></MruState>";

			MruState mruState = new MruState("MyMenuId");

			string xml = SerializationUtilities.SerializeToXml(mruState);
			Assert.AreEqual(SerializedValue, xml, "SerializedValue");

			mruState = (MruState)SerializationUtilities.DeserializeFromXml(xml, typeof(MruState));
			Assert.IsNotNull(mruState, "IsNotNull");
			Assert.AreEqual("MyMenuId", mruState.MenuId, "MenuId");
			Assert.AreEqual(0, mruState.Count, "Count");
		}

		/// <summary>
		/// Check the custom xml serialization of the MruState class for multiple entities.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the MruState class for multiple entities.")]
		public void CheckXMLSerializationSingleForMultipleEntities()
		{
			MruState mruState1 = new MruState("MyMenuId1");

			MruState mruState2 = new MruState("MyMenuId2");
			mruState2.Add(@"C:\Test1.txt");
			mruState2.Add(@"C:\Test2.txt");

			MruState mruState3 = new MruState("MyMenuId3");

			MruState[] mruStateArray = new MruState[3] { mruState1, mruState2, mruState3 };

			string xml = SerializationUtilities.SerializeToXml(mruStateArray);
			//Console.WriteLine(xml);

			mruStateArray = (MruState[])SerializationUtilities.DeserializeFromXml(xml, typeof(MruState[]));
			Assert.IsNotNull(mruStateArray, "IsNotNull");
			Assert.AreEqual(3, mruStateArray.Length, "Count");
			Assert.AreEqual("MyMenuId1", mruStateArray[0].MenuId, "[0]MenuId");
			Assert.AreEqual(0, mruStateArray[0].Count, "[0]Count");
			Assert.AreEqual("MyMenuId2", mruStateArray[1].MenuId, "[1]MenuId");
			Assert.AreEqual(@"C:\Test1.txt", mruStateArray[1][0], "[1] Item [0]");
			Assert.AreEqual(@"C:\Test2.txt", mruStateArray[1][1], "[1] Item [1]");
		}

		/// <summary>
		/// Check the custom xml serialization of the MruStateCollection class.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the MruStateCollection class.")]
		public void CheckXMLSerializationForMruStateCollection()
		{
			MruState mruState1 = new MruState("MyMenuId1");

			MruState mruState2 = new MruState("MyMenuId2");
			mruState2.Add(@"C:\Test1.txt");
			mruState2.Add(@"C:\Test2.txt");

			MruState mruState3 = new MruState("MyMenuId3");

			MruStateCollection mruStates = new MruStateCollection();
			mruStates.Add(mruState1);
			mruStates.Add(mruState2);
			mruStates.Add(mruState3);

			string xml = SerializationUtilities.SerializeToXml(mruStates);
			//Console.WriteLine(xml);

			mruStates = null;
			mruStates = (MruStateCollection)SerializationUtilities.DeserializeFromXml(xml, typeof(MruStateCollection));
			Assert.IsNotNull(mruStates, "IsNotNull");
			Assert.AreEqual(3, mruStates.Count, "Count");
			Assert.AreEqual("MyMenuId1", mruStates[0].MenuId, "[0]MenuId");
			Assert.AreEqual(0, mruStates[0].Count, "[0]Count");
			Assert.AreEqual("MyMenuId2", mruStates[1].MenuId, "[1]MenuId");
			Assert.AreEqual(@"C:\Test1.txt", mruStates[1][0], "[1] Item [0]");
			Assert.AreEqual(@"C:\Test2.txt", mruStates[1][1], "[1] Item [1]");
		}

		#endregion Xml Serialization

		#region MruStateCollection

		/// <summary>
		/// Test the MruStateCollection class methods and properties.
		/// </summary>
		[Test(Description="Test the MruStateCollection class methods and properties.")]
		public void MruStateCollectionMethodsAndProperties()
		{
			MruStateCollection mruStates = new MruStateCollection();
			MruState mruState1 = new MruState("MyMenu1");
			MruState mruState2 = new MruState("MyMenu2");
			MruState mruState3 = new MruState("MyMenu3");

			mruStates.Add(mruState1);
			mruStates.Add(mruState2);
			mruStates.Insert(1, mruState3);

			Assert.AreEqual(3, mruStates.Count, "Count");
			Assert.AreEqual(mruState1, mruStates[0], "mruStates[0]");
			Assert.AreEqual(mruState3, mruStates[1], "mruStates[1]");
			Assert.AreEqual(mruState2, mruStates[2], "mruStates[2]");
			Assert.AreEqual(1, mruStates.IndexOf(mruState3), "IndexOf(mruState)");
			Assert.AreEqual(2, mruStates.IndexOf("MyMenu2"), "IndexOf(formName)");
			Assert.AreEqual(-1, mruStates.IndexOf("MyNonExistentMenu"), "IndexOf(MyNonExistentMenu)");

			Assert.IsTrue(mruStates.Contains(mruState1), "Contains true");

			Assert.IsNull(mruStates["NonExistentMenu"], "this[nonExistentMenuName]");
			Assert.AreEqual(mruState3, mruStates["MyMenu3"], "this[MyMenu3]");

			mruStates.Remove(mruState3);
			Assert.AreEqual(2, mruStates.Count, "Count after Remove");
			Assert.IsFalse(mruStates.Contains(mruState3), "Contains after remove");

			mruStates.RemoveAt(0);
			Assert.AreEqual(1, mruStates.Count, "Count after RemoveAt");
			Assert.AreEqual(mruState2, mruStates[0], "Correct item removed");

			mruStates[0] = mruState1;
			Assert.AreEqual(mruState1, mruStates[0], "mruStates[0] after set[int]");
			mruStates["MyMenu1"] = mruState3;
			Assert.AreEqual(mruState3, mruStates[0], "mruStates[0] after set[string]");

			mruStates.Clear();
			Assert.AreEqual(0, mruStates.Count, "Count after Clear()");
		}

		/// <summary>
		///Test accessing a string value out of range should throw exception.
		/// </summary>
		[Test(Description="Test accessing a string value out of range should throw exception.")]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void InvalidIndexerString()
		{
			MruStateCollection mruStates = new MruStateCollection();
			mruStates["DoesntExist"] = new MruState("NotGoingToHappen");
		}

		/// <summary>
		///Test accessing a numeric value out of range should throw exception.
		/// </summary>
		[Test(Description="Test accessing a numeric value out of range should throw exception.")]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void InvalidIndexerNumeric()
		{
			MruStateCollection mruStates = new MruStateCollection();
			mruStates[20] = new MruState("NotGoingToHappen");
		}

		#endregion MruStateCollection

		#endregion Tests
	}
}
