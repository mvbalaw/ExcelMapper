using System.IO;

using NUnit.Framework;

using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// TestFixture for the ExplorerConfiguration class.
	/// </summary>
	[TestFixture]
	public class ExplorerConfigurationTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ExplorerConfigurationTest"/> class.
		/// </summary>
		public ExplorerConfigurationTest()
		{
		}

		#endregion Constructor

		#region Tests

		/// <summary>
		/// Verify the default configuration settings are initialised correctly.
		/// </summary>
		[Test(Description="Verify the default configuration settings are initialised correctly.")]
		public void DefaultConfigurationSettings()
		{
			string tmpFileName = @"C:\~NonExistentFile.xml";
			IExplorerConfiguration configuration = new ExplorerConfiguration(null, new FileThemeManager(null), @tmpFileName);

			Assert.AreEqual(95, configuration.SatisfactoryCoverageThreshold, "SatisfactoryCoverageThreshold");
			Assert.AreEqual(0, configuration.SatisfactoryUnvisitedSequencePoints, "SatisfactoryUnvisitedLines");
			Assert.AreEqual(true, configuration.GroupByModule, "GroupByModule");
			Assert.AreEqual(true, configuration.FlattenNamespaces, "FlattenNamespaces");
			Assert.AreEqual(true, configuration.RestoreSelectionOnReload, "RestoreSelectionOnReload");
			Assert.AreEqual(10, configuration.NumberOfRecentFiles, "NumRecentFiles");
			Assert.AreEqual(CoverageTreeReportStyle.SequencePointCoveragePercentage, configuration.CoverageTreeReportStyle, "CoverageTreeReportStyle");
			Assert.AreEqual(TreeSortStyle.Name, configuration.TreeSortStyle, "TreeSortStyle");
			Assert.AreEqual(TreeFilterStyle.None, configuration.TreeFilterStyle, "TreeFilterStyle");

			Assert.AreEqual(0, configuration.FormStates.Count, "FormStates");
			Assert.AreEqual(0, configuration.MruStates.Count, "MruStates");
			Assert.IsNull(configuration.CommandLineOptions, "CommandLineOptions");
			Assert.AreEqual(2, configuration.CoverageExclusions.Count, "CoverageExclusions");
			Assert.AreEqual(0, configuration.ModuleThresholds.Count, "ModuleThresholds");

			Assert.IsNotNull(configuration.Themes, "Themes");
			Assert.IsTrue(configuration.Themes.Count >= 2, "Themes Count");
			Assert.IsNotNull(configuration.Theme, "Theme");
			Assert.AreEqual(Theme.DefaultThemeName, configuration.Theme.Name, "Theme.Name");

			Assert.AreEqual("", configuration.ProjectName, "ProjectName");
		}

		/// <summary>
		/// Persist and load a configuration.
		/// </summary>
		[Test(Description="Persist and load a configuration.")]
		public void PersistAndLoadConfiguration()
		{
			string tmpFileName = Path.GetTempFileName();
			string tmpThemeFileName = Path.GetTempFileName();
			// Have to delete this file since .Net creates one - annoying!
			File.Delete(tmpFileName);
			IExplorerConfiguration configuration = new ExplorerConfiguration(null, new FileThemeManager(tmpThemeFileName), @tmpFileName);

			// Adjust all the property values
			configuration.SatisfactoryCoverageThreshold = 50;
			configuration.SatisfactoryUnvisitedSequencePoints = 5;
			configuration.GroupByModule = false;
			configuration.FlattenNamespaces = false;
			configuration.RestoreSelectionOnReload = false;
			configuration.NumberOfRecentFiles = 5;
			configuration.CoverageTreeReportStyle = CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints;
			configuration.TreeSortStyle = TreeSortStyle.CoveragePercentageDescending;
			configuration.TreeFilterStyle = TreeFilterStyle.HideUnvisited;
			configuration.CoverageTreeReportStyle = CoverageTreeReportStyle.FunctionCoverage;
			configuration.ProjectName = "Test";

			try
			{
				configuration.Persist();

				IExplorerConfiguration newConfiguration = new ExplorerConfiguration(null, new FileThemeManager(tmpThemeFileName), @tmpFileName);
				// Verify we have the properties changed we assigned.
				Assert.AreEqual(50, newConfiguration.SatisfactoryCoverageThreshold, "SatisfactoryCoverageThreshold");
				Assert.AreEqual(5, newConfiguration.SatisfactoryUnvisitedSequencePoints, "SatisfactoryUnvisitedLines");
				Assert.AreEqual(false, newConfiguration.GroupByModule, "GroupByModule");
				Assert.AreEqual(false, newConfiguration.FlattenNamespaces, "FlattenNamespaces");
				Assert.AreEqual(false, newConfiguration.RestoreSelectionOnReload, "RestoreSelectionOnReload");
				Assert.AreEqual(5, newConfiguration.NumberOfRecentFiles, "NumberOfRecentFiles");
				Assert.AreEqual(CoverageTreeReportStyle.FunctionCoverage, newConfiguration.CoverageTreeReportStyle, "CoverageTreeReportStyle");
				// Grant: Current tree sort style is not persisted so will always be at default of "Name"
				Assert.AreEqual(TreeSortStyle.Name, newConfiguration.TreeSortStyle, "TreeSortStyle");
				Assert.AreEqual(TreeFilterStyle.HideUnvisited, configuration.TreeFilterStyle, "TreeFilterStyle");
				Assert.AreEqual("Test", newConfiguration.ProjectName, "ProjectName");

				// Now also check the cloning.
				IExplorerConfiguration cloneConfiguration = newConfiguration.Clone();
				Assert.AreEqual(newConfiguration.SatisfactoryCoverageThreshold, cloneConfiguration.SatisfactoryCoverageThreshold, "Clone SatisfactoryCoverageThreshold");
				Assert.AreEqual(newConfiguration.GroupByModule, cloneConfiguration.GroupByModule, "Clone GroupByModule");
				Assert.AreEqual(newConfiguration.FlattenNamespaces, cloneConfiguration.FlattenNamespaces, "Clone FlattenNamespaces");
				Assert.AreEqual(newConfiguration.RestoreSelectionOnReload, cloneConfiguration.RestoreSelectionOnReload, "Clone RestoreSelectionOnReload");
				Assert.AreEqual(newConfiguration.NumberOfRecentFiles, cloneConfiguration.NumberOfRecentFiles, "Clone NumberOfRecentFiles");
				Assert.AreEqual(newConfiguration.CoverageTreeReportStyle, newConfiguration.CoverageTreeReportStyle, "Clone CoverageTreeReportStyle");
				Assert.AreEqual(newConfiguration.TreeSortStyle, newConfiguration.TreeSortStyle, "Clone TreeSortStyle");
				Assert.AreEqual(newConfiguration.TreeFilterStyle, newConfiguration.TreeFilterStyle, "Clone TreeFilterStyle");
				Assert.AreEqual(newConfiguration.Theme.Name, cloneConfiguration.Theme.Name, "Clone Name");
				Assert.AreEqual(CoverageTreeReportStyle.FunctionCoverage, configuration.CoverageTreeReportStyle, "CoverageTreeReportStyle");
				Assert.AreEqual(newConfiguration.ProjectName, cloneConfiguration.ProjectName, "Clone ProjectName");
			}
			finally
			{
				if (File.Exists(tmpFileName))
				{
					File.Delete(tmpFileName);
				}
				if (File.Exists(tmpThemeFileName))
				{
					File.Delete(tmpThemeFileName);
				}
			}
		}

		/// <summary>
		/// Reload a configuration after modifying a value.
		/// </summary>
		[Test(Description="Reload a configuration after modifying a value.")]
		public void ReloadConfiguration()
		{
			string tmpFileName = Path.GetTempFileName();
			// Have to delete this file since .Net creates one - annoying!
			File.Delete(tmpFileName);
			IExplorerConfiguration configuration = new ExplorerConfiguration(null, null, @tmpFileName);
			Assert.AreEqual(10, configuration.NumberOfRecentFiles, "Default NumRecentFiles");

			try
			{
				configuration.Persist();

				// Adjust a property value
				configuration.NumberOfRecentFiles = 5;
				Assert.AreEqual(5, configuration.NumberOfRecentFiles, "Before Reload NumRecentFiles");

				// Reload the configuration
				configuration.Reload();
				Assert.AreEqual(10, configuration.NumberOfRecentFiles, "After Reload NumRecentFiles");
			}
			finally
			{
				if (File.Exists(tmpFileName))
				{
					File.Delete(tmpFileName);
				}
			}
		}

		/// <summary>
		/// Persist and load a configuration.
		/// </summary>
		[Test(Description="Persist and load a configuration along with some themes.")]
		public void PersistWithThemes()
		{
			string tmpFileName = Path.GetTempFileName();
			string tmpThemesFileName = Path.GetTempFileName();
			// Have to delete this file since .Net creates one - annoying!
			File.Delete(tmpFileName);
			File.Delete(tmpThemesFileName);

			FileThemeManager themeManager = new FileThemeManager(tmpThemesFileName);
			IExplorerConfiguration configuration = new ExplorerConfiguration(null, themeManager, @tmpFileName);
			configuration.Themes.Add(new Theme("Grant"));

			try
			{
				configuration.Persist();

				Assert.IsTrue(File.Exists(tmpThemesFileName), "Themes exist");
				ThemeCollection themes = themeManager.Load();
				Assert.IsNotNull(themes, "IsNotNull After loading");
				Assert.IsTrue(themes.Count >= 2, "Count");
				Assert.IsNotNull(themes["Grant"], "themes[Grant]");
			}
			finally
			{
				if (File.Exists(tmpFileName))
				{
					File.Delete(tmpFileName);
				}
				if (File.Exists(tmpThemesFileName))
				{
					File.Delete(tmpThemesFileName);
				}
			}
		}

		#endregion Tests
	}
}
