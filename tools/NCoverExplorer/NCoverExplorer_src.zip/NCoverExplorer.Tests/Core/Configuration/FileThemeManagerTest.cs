using System;
using System.Drawing;
using System.IO;
using NCoverExplorer.Core.Configuration;
using NUnit.Framework;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// Test fixture for the FileThemeManager class.
	/// </summary>
	[TestFixture]
	public class FileThemeManagerTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="FileThemeManagerTest"/> class.
		/// </summary>
		public FileThemeManagerTest()
		{
		}

		#endregion Constructor

		#region Tests

		/// <summary>
		/// Read embedded themes file.
		/// </summary>
		[Test(Description="Load embedded default themes file.")]
		public void LoadDefaultThemes()
		{
			IThemeManager themeManager = new FileThemeManager();
			ThemeCollection themes = themeManager.LoadDefaultThemes();
			Assert.IsNotNull(themes, "IsNotNull");
			Assert.IsTrue(themes.Count >= 3, "Count");

			Theme theme = themes["Neutral"];
			Assert.IsNotNull(theme, "IsNotNull themes[Khaki]");
			Assert.AreEqual(SystemColors.ControlDark.Name, theme.SourceCodeLineNumbersColor.Name,  "SourceCodeLineNumbers");
		}

		/// <summary>
		/// Write a theme and read it in again.
		/// </summary>
		[Test(Description="Write a theme and read it in again.")]
		public void WriteTheme()
		{
			string tmpFileName = Path.GetTempFileName();
			// Have to delete this file since .Net creates one - annoying!
			File.Delete(tmpFileName);

			try
			{
				IThemeManager themeManager = new FileThemeManager(tmpFileName);
				ThemeCollection themes = new ThemeCollection();
				themes.Add(new Theme("Grant"));
				themes.Add(new Theme("Testing"));
				themeManager.Persist(themes);

				// Verify we can read it again
				themes = themeManager.Load();
				Assert.IsNotNull(themes);
				Assert.AreEqual(2, themes.Count, "Count");
				Theme theme = themes["Grant"];
				Assert.IsNotNull(theme, "IsNotNull themes[Grant]");
				Assert.AreEqual(SystemColors.ControlDark.Name, theme.SourceCodeLineNumbersColor.Name,  "SourceCodeLineNumbers");
			}
			finally
			{
				if (File.Exists(tmpFileName))
				{
					File.Delete(tmpFileName);
				}
			}
		}

		/// <summary>
		/// Throw exception when trying to write theme to null filename.
		/// </summary>
		[Test(Description="Throw exception when trying to write theme to null filename.")]
		[ExpectedException(typeof(ArgumentNullException))]
		public void WriteThemeExceptionFromNullFileName()
		{
			IThemeManager themeManager = new FileThemeManager(null);
			ThemeCollection themes = new ThemeCollection();
			themeManager.Persist(themes);
		}

		/// <summary>
		/// Throw exception when trying to write null themes collection.
		/// </summary>
		[Test(Description="Throw exception when trying to write null themes collection.")]
		[ExpectedException(typeof(ArgumentNullException))]
		public void WriteThemeExceptionFromNullThemes()
		{
			IThemeManager themeManager = new FileThemeManager("Blah.xml");
			themeManager.Persist(null);
		}

		#endregion Tests
	}
}
