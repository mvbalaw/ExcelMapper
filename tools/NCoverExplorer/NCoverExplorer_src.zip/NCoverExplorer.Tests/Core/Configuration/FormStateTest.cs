using System;
using NUnit.Framework;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// TestFixture for the FormState and related classes.
	/// </summary>
	[TestFixture]
	public class FormStateTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="FormStateTest"/> class.
		/// </summary>
		public FormStateTest()
		{
		}

		#endregion Constructor

		#region	Tests

		#region FormState

		/// <summary>
		/// Test the properties and methods of the FormState class.
		/// </summary>
		[Test(Description="Test the properties and methods of the FormState class.")]
		public void FormStatePropertiesAndMethods()
		{
			FormState formState = new FormState("MyFormId");
			Assert.AreEqual("MyFormId", formState.FormId, "FormId");

			formState.SetValue("MyStringKey1", "MyValue1");
			Assert.AreEqual("MyValue1", formState.GetString("MyStringKey1"), "MyStringKey1");
			Assert.AreEqual("", formState.GetString("MyStringNotThere"), "MyStringNotThere");
			Assert.AreEqual("Test", formState.GetString("MyStringNotThereDefault", "Test"), "MyStringNotThereDefault");

			formState.SetValue("MyBoolTrue", true);
			Assert.AreEqual(true, formState.GetBoolean("MyBoolTrue"), "MyBoolTrue");
			formState.SetValue("MyBoolFalse", false);
			Assert.AreEqual(false, formState.GetBoolean("MyBoolFalse"), "MyBoolFalse");
			Assert.AreEqual(false, formState.GetBoolean("MyBoolNotThere"), "MyBoolNotThere");
			Assert.AreEqual(true, formState.GetBoolean("MyBoolNotThereDefault", true), "MyBoolNotThereDefault");

			formState.SetValue("MyInt32", 10);
			Assert.AreEqual(10, formState.GetInt32("MyInt32"), "MyInt32");
			Assert.AreEqual(0, formState.GetInt32("MyInt32NotThere"), "MyInt32NotThere");
			Assert.AreEqual(10, formState.GetInt32("MyInt32NotThereDefault", 10), "MyInt32NotThereDefault");

			formState.SetValue("MySingle", 10.1f);
			Assert.AreEqual(10.1f, formState.GetSingle("MySingle"), "MySingle");
			Assert.AreEqual(0f, formState.GetSingle("MySingleNotThere"), "MySingleNotThere");
			Assert.AreEqual(10.2f, formState.GetSingle("MySingleNotThereDefault", 10.2f), "MySingleNotThereDefault");

			formState.SetValue("MyDouble", 10.1);
			Assert.AreEqual(10.1, formState.GetDouble("MyDouble"), "MyDouble");
			Assert.AreEqual(0, formState.GetDouble("MyDoubleNotThere"), "MyDoubleNotThere");
			Assert.AreEqual(10.2, formState.GetDouble("MyDoubleNotThereDefault", 10.2), "MyDoubleNotThereDefault");

			formState.SetValue("MyDecimal", 10.1M);
			Assert.AreEqual(10.1M, formState.GetDecimal("MyDecimal"), "MyDecimal");
			Assert.AreEqual(0M, formState.GetDecimal("MyDecimalNotThere"), "MyDecimalNotThere");
			Assert.AreEqual(10.2M, formState.GetDecimal("MyDecimalNotThereDefault", 10.2M), "MyDecimalNotThereThereDefault");

			Assert.AreEqual(7, formState.Count, "Count initialisation");

			Assert.AreEqual(true, formState.ContainsKey("MyDecimal"), "ContainsKeyTrue");
			Assert.AreEqual(false, formState.ContainsKey("MyDecimalNotThere"), "ContainsKeyNotThere");

			Assert.AreEqual(true, formState.ContainsValue("MyValue1"), "ContainsValueTrue");
			Assert.AreEqual(false, formState.ContainsValue("MyValue1There"), "ContainsValueNotThere");

			formState.Clear();
			Assert.AreEqual(0, formState.Count, "Count after Clear()");
		}

		#endregion FormState

		#region Xml Serialization

		/// <summary>
		/// Check the custom xml serialization of the FormState class for single entity.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the FormState class for single entity.")]
		public void CheckXMLSerializationSingleForSingleEntity()
		{
			const string SerializedValue = @"<FormState FormId=""MyFormId""><Settings><Setting Key=""mykey2"" Value=""MyValue2"" /><Setting Key=""mykey1"" Value=""MyValue1"" /></Settings></FormState>";

			FormState formState = new FormState("MyFormId");
			formState.SetValue("MyKey1", "MyValue1");
			formState.SetValue("MyKey2", "MyValue2");

			string xml = SerializationUtilities.SerializeToXml(formState);
			Assert.AreEqual(SerializedValue, xml, "SerializedValue");

			formState = (FormState)SerializationUtilities.DeserializeFromXml(xml, typeof(FormState));
			Assert.IsNotNull(formState, "IsNotNull");
			Assert.AreEqual("MyFormId", formState.FormId, "FormId");
			Assert.AreEqual(2, formState.Count, "Count");
			Assert.AreEqual("MyValue1", formState.GetString("MyKey1"), "MyKey1");
			Assert.AreEqual("MyValue2", formState.GetString("MyKey2"), "MyKey2");
		}

		/// <summary>
		/// Check the custom xml serialization of the FormState class with no settings specified.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the FormState class with no settings specified.")]
		public void CheckXMLSerializationWithEmptySettings()
		{
			const string SerializedValue = @"<FormState FormId=""MyFormId""><Settings /></FormState>";

			FormState formState = new FormState("MyFormId");

			string xml = SerializationUtilities.SerializeToXml(formState);
			Assert.AreEqual(SerializedValue, xml, "SerializedValue");

			formState = (FormState)SerializationUtilities.DeserializeFromXml(xml, typeof(FormState));
			Assert.IsNotNull(formState, "IsNotNull");
			Assert.AreEqual("MyFormId", formState.FormId, "FormId");
			Assert.AreEqual(0, formState.Count, "Count");
		}

		/// <summary>
		/// Check the custom xml serialization of the FormState class for multiple entities.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the FormState class for multiple entities.")]
		public void CheckXMLSerializationSingleForMultipleEntities()
		{
			FormState formState1 = new FormState("MyFormId1");

			FormState formState2 = new FormState("MyFormId2");
			formState2.SetValue("MyKey1", "MyValue1");
			formState2.SetValue("MyKey2", "MyValue2");

			FormState formState3 = new FormState("MyFormId3");

			FormState[] formStateArray = new FormState[3] { formState1, formState2, formState3 };

			string xml = SerializationUtilities.SerializeToXml(formStateArray);
			//Console.WriteLine(xml);

			formStateArray = (FormState[])SerializationUtilities.DeserializeFromXml(xml, typeof(FormState[]));
			Assert.IsNotNull(formStateArray, "IsNotNull");
			Assert.AreEqual(3, formStateArray.Length, "Count");
			Assert.AreEqual("MyFormId1", formStateArray[0].FormId, "[0]FormId");
			Assert.AreEqual(0, formStateArray[0].Count, "[0]Count");
			Assert.AreEqual("MyFormId2", formStateArray[1].FormId, "[1]FormId");
			Assert.AreEqual("MyValue1", formStateArray[1].GetString("MyKey1"), "[1]MyKey1");
			Assert.AreEqual("MyValue2", formStateArray[1].GetString("MyKey2"), "[1]MyKey2");
		}

		/// <summary>
		/// Check the custom xml serialization of the FormStateCollection class.
		/// </summary>
		[Test(Description="Check the custom xml serialization of the FormStateCollection class.")]
		public void CheckXMLSerializationForFormStateCollection()
		{
			FormState formState1 = new FormState("MyFormId1");

			FormState formState2 = new FormState("MyFormId2");
			formState2.SetValue("MyKey1", "MyValue1");
			formState2.SetValue("MyKey2", "MyValue2");

			FormState formState3 = new FormState("MyFormId3");

			FormStateCollection formStates = new FormStateCollection();
			formStates.Add(formState1);
			formStates.Add(formState2);
			formStates.Add(formState3);

			string xml = SerializationUtilities.SerializeToXml(formStates);
			//Console.WriteLine(xml);

			formStates = null;
			formStates = (FormStateCollection)SerializationUtilities.DeserializeFromXml(xml, typeof(FormStateCollection));
			Assert.IsNotNull(formStates, "IsNotNull");
			Assert.AreEqual(3, formStates.Count, "Count");
			Assert.AreEqual("MyFormId1", formStates[0].FormId, "[0]FormId");
			Assert.AreEqual(0, formStates[0].Count, "[0]Count");
			Assert.AreEqual("MyFormId2", formStates[1].FormId, "[1]FormId");
			Assert.AreEqual("MyValue1", formStates[1].GetString("MyKey1"), "[1]MyKey1");
			Assert.AreEqual("MyValue2", formStates[1].GetString("MyKey2"), "[1]MyKey2");
		}

		#endregion Xml Serialization

		#region FormStateCollection

		/// <summary>
		/// Test the FormStateCollection class methods and properties.
		/// </summary>
		[Test(Description="Test the FormStateCollection class methods and properties.")]
		public void FormStateCollectionMethodsAndProperties()
		{
			FormStateCollection formStates = new FormStateCollection();
			FormState formState1 = new FormState("MyForm1");
			FormState formState2 = new FormState("MyForm2");
			FormState formState3 = new FormState("MyForm3");

			formStates.Add(formState1);
			formStates.Add(formState2);
			formStates.Insert(1, formState3);

			Assert.AreEqual(3, formStates.Count, "Count");
			Assert.AreEqual(formState1, formStates[0], "formStates[0]");
			Assert.AreEqual(formState3, formStates[1], "formStates[1]");
			Assert.AreEqual(formState2, formStates[2], "formStates[2]");
			Assert.AreEqual(1, formStates.IndexOf(formState3), "IndexOf(formState)");
			Assert.AreEqual(2, formStates.IndexOf("MyForm2"), "IndexOf(formName)");
			Assert.AreEqual(-1, formStates.IndexOf("MyNonExistentForm"), "IndexOf(MyNonExistentForm)");

			Assert.IsTrue(formStates.Contains(formState1), "Contains true");

			Assert.IsNull(formStates["NonExistentForm"], "this[nonExistentFormName]");
			Assert.AreEqual(formState3, formStates["MyForm3"], "this[MyForm3]");

			formStates.Remove(formState3);
			Assert.AreEqual(2, formStates.Count, "Count after Remove");
			Assert.IsFalse(formStates.Contains(formState3), "Contains after remove");

			formStates.RemoveAt(0);
			Assert.AreEqual(1, formStates.Count, "Count after RemoveAt");
			Assert.AreEqual(formState2, formStates[0], "Correct item removed");

			formStates[0] = formState1;
			Assert.AreEqual(formState1, formStates[0], "formStates[0] after set[int]");
			formStates["MyForm1"] = formState3;
			Assert.AreEqual(formState3, formStates[0], "formStates[0] after set[string]");

			formStates.Clear();
			Assert.AreEqual(0, formStates.Count, "Count after Clear()");
		}

		/// <summary>
		///Test accessing a string value out of range should throw exception.
		/// </summary>
		[Test(Description="Test accessing a string value out of range should throw exception.")]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void InvalidIndexerString()
		{
			FormStateCollection formStates = new FormStateCollection();
			formStates["DoesntExist"] = new FormState("NotGoingToHappen");
		}

		/// <summary>
		///Test accessing a numeric value out of range should throw exception.
		/// </summary>
		[Test(Description="Test accessing a numeric value out of range should throw exception.")]
		[ExpectedException(typeof(ArgumentOutOfRangeException))]
		public void InvalidIndexerNumeric()
		{
			FormStateCollection formStates = new FormStateCollection();
			formStates[20] = new FormState("NotGoingToHappen");
		}

		#endregion FormStateCollection

		#region FormStateEventArgs

		/// <summary>
		/// Test the FormStateEventArgs class.
		/// </summary>
		[Test(Description="Test the FormStateEventArgs class.")]
		public void FormStateEventArgsProperties()
		{
			FormStateEventArgs e = new FormStateEventArgs(null);
			Assert.IsNull(e.FormState, "null args");

			FormState formState = new FormState("Test");
			e = new FormStateEventArgs(formState);
			Assert.AreEqual(formState, e.FormState, "With args");
		}

		#endregion FormStateEventArgs

		#endregion Tests
	}
}
