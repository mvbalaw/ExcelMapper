using NUnit.Framework;

using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Tests.Core.Configuration
{
	/// <summary>
	/// TestFixture for the CommandLineOptions class.
	/// </summary>
	[TestFixture]
	public class CommandLineOptionsTest
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CommandLineOptionsTest"/> class.
		/// </summary>
		public CommandLineOptionsTest()
		{
		}

		#endregion Constructor

		#region Tests

		/// <summary>
		/// Verify correct behaviour when no command line arguments passed into application.
		/// </summary>
		[Test(Description="Verify correct behaviour when no command line arguments passed into application.")]
		public void NoCommandLineArgs()
		{
			string[] args = new string[0];

			CommandLineOptions commandLineOptions = new CommandLineOptions(args);
			Assert.AreEqual(0, commandLineOptions.CoverageFileNames.Length, "CoverageFileName");
			Assert.AreEqual(false, commandLineOptions.HasCoverageFileName, "HasCoverageFileName");
		}

		/// <summary>
		/// Verify correct behaviour when a single command line argument passed into application.
		/// </summary>
		[Test(Description="Verify correct behaviour when a single command line argument passed into application.")]
		public void ValidSingleCommandLineArg()
		{
			const string FILENAME = @"C:\coverage.xml";
			string[] args = new string[] { FILENAME };

			CommandLineOptions commandLineOptions = new CommandLineOptions(args);
			Assert.AreEqual(1, commandLineOptions.CoverageFileNames.Length, "Filename count");
			Assert.AreEqual(FILENAME, commandLineOptions.CoverageFileNames[0], "CoverageFileName");
			Assert.AreEqual(true, commandLineOptions.HasCoverageFileName, "HasCoverageFileName");
		}

		/// <summary>
		/// Verify correct behaviour for multiple filenames in the command line.
		/// </summary>
		[Test(Description="Verify correct behaviour for multiple filenames in the command line.")]
		public void ValidMultipleFileArguments()
		{
			const string FILENAME1 = @"C:\coverage1.xml";
			const string FILENAME2 = @"C:\coverage2.xml";
			string[] args = new string[] { FILENAME1, FILENAME2 };

			CommandLineOptions commandLineOptions = new CommandLineOptions(args);
			Assert.AreEqual(2, commandLineOptions.CoverageFileNames.Length, "Filename count");
			Assert.AreEqual(FILENAME1, commandLineOptions.CoverageFileNames[0], "CoverageFileName1");
			Assert.AreEqual(FILENAME2, commandLineOptions.CoverageFileNames[1], "CoverageFileName2");
			Assert.AreEqual(true, commandLineOptions.HasCoverageFileName, "HasCoverageFileName");
		}

		/// <summary>
		/// Pass unknown arguments in the command arguments.
		/// </summary>
		[Test(Description="Pass unknown arguments in the command arguments.")]
		public void UnknownArguments()
		{
			string[] args = new string[] { "/unused:" };
			CommandLineOptions commandLineOptions = new CommandLineOptions(args);
			Assert.AreEqual(1, commandLineOptions.CoverageFileNames.Length, "Filename count");
			Assert.AreEqual("/unused:", commandLineOptions.CoverageFileNames[0], "Filename[0]");

			args = new string[] { "/unused2:true" };
			commandLineOptions = new CommandLineOptions(args);
			Assert.AreEqual(0, commandLineOptions.CoverageFileNames.Length, "Filename count");
		}

		/// <summary>
		/// Pass a parameter switch argument.
		/// </summary>
		[Test(Description="Pass a parameter switch argument.")]
		public void ParameterSwitchArgumentsSimple()
		{
			string[] args = new string[] { "/parameter:test" };
			SampleCommandLineOptions commandLineOptions = new SampleCommandLineOptions(args);
			Assert.AreEqual(0, commandLineOptions.CoverageFileNames.Length, "Filename count");
			Assert.AreEqual("test", commandLineOptions.Parameter, ".Parameter");
		}

		/// <summary>
		/// Pass a parameter switch argument where includes a path
		/// </summary>
		[Test(Description="Pass a parameter switch argument where includes a path.")]
		public void ParameterSwitchArgumentsComplex()
		{
			string[] args = new string[] { @"/parameter:C:\Test.txt" };
			SampleCommandLineOptions commandLineOptions = new SampleCommandLineOptions(args);
			Assert.AreEqual(0, commandLineOptions.CoverageFileNames.Length, "Filename count");
			Assert.AreEqual(@"C:\Test.txt", commandLineOptions.Parameter, ".Parameter");
		}

		/// <summary>
		/// Pass a parameter switch argument where nothing specified after the colon.
		/// </summary>
		[Test(Description="Pass a parameter switch argument where nothing specified after the colon.")]
		public void ParameterSwitchArgumentsNoColon()
		{
			string[] args = new string[] { @"" };
			SampleCommandLineOptions commandLineOptions = new SampleCommandLineOptions(args);
			Assert.AreEqual(false, commandLineOptions.IsXml, ".IsXml No Param");
			Assert.AreEqual(string.Empty, commandLineOptions.XmlFileName, ".XmlFileName No Param");

			args = new string[] { @"/xml" };
			commandLineOptions = new SampleCommandLineOptions(args);
			Assert.AreEqual(true, commandLineOptions.IsXml, ".IsXml /xml");
			Assert.AreEqual("Default.xml", commandLineOptions.XmlFileName, ".XmlFileName /xml");

			args = new string[] { @"/xml:C:\Test.xml" };
			commandLineOptions = new SampleCommandLineOptions(args);
			Assert.AreEqual(true, commandLineOptions.IsXml, ".IsXml Specified");
			Assert.AreEqual(@"C:\Test.xml", commandLineOptions.XmlFileName, ".XmlFileName Specified");
		}

		#endregion Tests

		#region SampleCommandLineOptions Class

		/// <summary>
		/// Test class used to verify complex arguments are working correctly.
		/// </summary>
		public class SampleCommandLineOptions : CommandLineOptions
		{
			public string Parameter = string.Empty;
			public string XmlFileName = string.Empty;
			public bool IsXml = false;

			public SampleCommandLineOptions(string[] args)
				: base(args)
			{
			}

			protected override void ValidateAndAssignArgument(string name, string value)
			{
				switch (name.ToLower())
				{
					case "parameter":
						Parameter = value;
						break;

					case "xml":
						IsXml = true;
						if (value.Length == 0)
						{
							XmlFileName = "Default.xml";
						}
						else
						{
							XmlFileName = value;
						}
						break;

					default:
						base.ValidateAndAssignArgument(name, value);
						break;
				}
			}

		}

		#endregion
	}
}
