using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using Microsoft.Win32;

using NCoverExplorer.Core.Utilities;

using NUnit.Framework;

namespace NCoverExplorer.Tests.Core.Utilities
{
	/// <summary>
	/// Test fixture for the RemoteController class to simulate receiving messages from TestDriven.Net.
	/// </summary>
	[TestFixture]
	public class RemoteControllerTest
	{
		#region Private Variables

		private string _coverageFile1 = string.Empty;
		private string _coverageFile2 = string.Empty;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="RemoteControllerTest"/> class.
		/// </summary>
		public RemoteControllerTest()
		{
		}

		#endregion Constructor

		#region NUnit Setup / TearDown

		/// <summary>
		/// Test setup.
		/// </summary>
		[SetUp]
		public void Setup()
		{
			_coverageFile1 = Path.GetTempFileName();
			_coverageFile2 = Path.GetTempFileName();
			File.Delete(_coverageFile1);
			File.Delete(_coverageFile2);

			_WriteResourceToFile("CoverageFile1.xml", _coverageFile1);
			_WriteResourceToFile("CoverageFile2.xml", _coverageFile2);
		}

		/// <summary>
		/// Test setup.
		/// </summary>
		[TearDown]
		public void TearDown()
		{
//			File.Delete(_coverageFile1);
//			File.Delete(_coverageFile2);
		}

		#endregion NUnit Setup / TearDown

		#region Tests

		/// <summary>
		/// Send a single file open message to NCoverExplorer.
		/// </summary>
		[Test(Description="Send a single file open message to NCoverExplorer.")]
		[Explicit]
		public void SendSingleFileMessage()
		{
			Process ncoverExplorerProcess = NCoverExplorerApplication.GetNCoverExplorerProcess();
			NCoverExplorerApplication.SendOpenMessage(ncoverExplorerProcess, _coverageFile1);
		}

		/// <summary>
		/// Send a multiple file open message to NCoverExplorer.
		/// </summary>
		[Test(Description="Send a multiple file open message to NCoverExplorer.")]
		[Explicit]
		public void SendMultipleFileMessage()
		{
			Process ncoverExplorerProcess = NCoverExplorerApplication.GetNCoverExplorerProcess();
			string combinedMessage = _coverageFile1 + ";" + _coverageFile2;
			NCoverExplorerApplication.SendOpenMessage(ncoverExplorerProcess, combinedMessage);
			Thread.Sleep(1000); // To give time to load the coverage file
		}

		#endregion Tests

		#region Private Methods
		
		private void _WriteResourceToFile(string resourceName, string fileName)
		{
			Assembly assembly = Assembly.GetExecutingAssembly();
			string fullName = "NCoverExplorer.Tests.Core.Utilities." + resourceName;
			using (Stream stream = assembly.GetManifestResourceStream(fullName))
			{
				string text = string.Empty;
				using (StreamReader streamReader = new StreamReader(stream))
				{
					text = streamReader.ReadToEnd();
				}
				using (StreamWriter writer = File.CreateText(fileName))
				{
					writer.Write(text);
					writer.Flush();
				}
			}
		}

		#endregion Private Methods

		#region NCoverExplorerApplication Class (Private)

		private class NCoverExplorerApplication
		{
			public static Process GetNCoverExplorerProcess()
			{
				Process ncoverExplorerProcess = null;

				Process[] processes = Process.GetProcessesByName("NCoverExplorer");
				foreach (Process process in processes)
				{
					if (process.ProcessName.StartsWith("NCoverExplorer"))
					{
						ncoverExplorerProcess = Process.GetProcessesByName("NCoverExplorer")[0];
						break;
					}
				}

				if (ncoverExplorerProcess == null || ncoverExplorerProcess.HasExited)
				{
					string application = _FindNCoverExplorerApplication();
					ncoverExplorerProcess = Process.Start(application);
					Thread.Sleep(1000); // Time for it to load
					Trace.WriteLine("NCoverExplorer application loaded.");
				}
				else
				{
					Trace.WriteLine("NCoverExplorer process found.");
				}
				return ncoverExplorerProcess;
			}

			public static void SendOpenMessage(Process process, string file)
			{
				Trace.WriteLine("Send open '" + file + "' message to HWnd " + process.MainWindowHandle);
				RemoteController.Send(process.MainWindowHandle, file);
			}

			private static string _FindNCoverExplorerApplication()
			{
				string exeFile = _FindNCoverExplorerApplication(Registry.CurrentUser);
				if (exeFile == null)
				{
					exeFile = _FindNCoverExplorerApplication(Registry.LocalMachine);
				}

				return exeFile;
			}

			private static string _FindNCoverExplorerApplication(RegistryKey root)
			{
				string name = @"Software\KiwiDevelopment\NCoverExplorer";
				using (RegistryKey key = root.OpenSubKey(name, false))
				{
					if (key == null)
					{
						return null;
					}

					return (string)key.GetValue("Application");
				}
			}
		}

		#endregion NCoverExplorerApplication Class (Private)
	}
}
