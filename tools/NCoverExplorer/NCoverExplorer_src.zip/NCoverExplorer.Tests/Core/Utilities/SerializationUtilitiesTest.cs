using NUnit.Framework;

using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Tests.Core.Utilities
{
	/// <summary>
	/// TestFixture for the SerializationUtilities class.
	/// </summary>
	[TestFixture]
	public class SerializationUtilitiesTest
	{
		#region Constants

		private const string SerializedXml = @"<MyTestClass><FirstName>Grant</FirstName><LastName>Drake</LastName></MyTestClass>";

		#endregion Constants

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SerializationUtilitiesTest"/> class.
		/// </summary>
		public SerializationUtilitiesTest()
		{
		}

		#endregion Constructor

		#region	Tests

		/// <summary>
		/// Test the SerializeToXml method.
		/// </summary>
		[Test(Description="Test the SerializeToXml method.")]
		public void SerializeToXml()
		{
			MyTestClass myTestClass = new MyTestClass();
			myTestClass.FirstName = "Grant";
			myTestClass.LastName = "Drake";
			
			string xml = SerializationUtilities.SerializeToXml(myTestClass);

			Assert.AreEqual(SerializedXml, xml);
		}

		/// <summary>
		/// Test the DeserializeFromXml method.
		/// </summary>
		[Test(Description="Test the DeserializeFromXml method.")]
		public void DeserializeFromXml()
		{
			MyTestClass myTestClass = (MyTestClass)SerializationUtilities.DeserializeFromXml(SerializedXml, typeof(MyTestClass));

			Assert.IsNotNull(myTestClass, "IsNotNull");
			Assert.AreEqual("Grant", myTestClass.FirstName, "FirstName");
			Assert.AreEqual("Drake", myTestClass.LastName, "LastName");
		}

		#endregion Tests

		#region MyTestClass Class

		/// <summary>
		/// Test class used for serialization tests.
		/// </summary>
		public class MyTestClass
		{
			/// <summary>
			/// Initializes a new instance of the <see cref="MyTestClass"/> class.
			/// </summary>
			public MyTestClass()
			{
				FirstName = "";
				LastName = "";
			}

			public string FirstName;
			public string LastName;
		}

		#endregion MyTestClass Class
	}
}
