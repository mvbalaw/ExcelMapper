using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Visitors;

using NUnit.Framework;

namespace NCoverExplorer.Tests.Core.Visitors
{
	/// <summary>
	/// Unit tests for the various visitors.
	/// </summary>
	[TestFixture]
	public class VisitorsTest
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private TestCoverageTreeFactory _coverageTreeFactory;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="VisitorsTest"/> class.
		/// </summary>
		public VisitorsTest()
		{
		}

		#endregion Constructor

		#region Test Setup / TearDown

		/// <summary>
		/// Test setup.
		/// </summary>
		[SetUp]
		public void Setup()
		{
			_configuration = new ExplorerConfiguration(null, null, null);
			_coverageTreeFactory = new TestCoverageTreeFactory(_configuration);
		}

		#endregion Test Setup / TearDown

		#region Tests

		#region ExcludedTreeNodeVisitor

		/// <summary>
		/// Test ExcludedTreeNodeVisitor iterating over a coverage tree.
		/// </summary>
		[Test(Description="Test ExcludedTreeNodeVisitor iterating over a coverage tree.")]
		public void ExcludedTreeNodeVisitorHappyPath()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			_BuildNamespaceTestData(coverageFileTreeNode);

			ExcludedTreeNodeVisitor visitor = new ExcludedTreeNodeVisitor();
			coverageFileTreeNode.AcceptVisitor(visitor);

			Assert.AreEqual(1, visitor.ExcludedNodesSummary.ExcludedModules.Count, "Excluded Modules");
			Assert.AreEqual("MyModuleExcluded.dll", visitor.ExcludedNodesSummary.ExcludedModules[0].ToString(), "Modules[0]");
			Assert.AreEqual(1, visitor.ExcludedNodesSummary.ExcludedNamespaces.Count, "Excluded Namespaces");
			Assert.AreEqual("ExcludedNamespace1", visitor.ExcludedNodesSummary.ExcludedNamespaces[0].ToString(), "Namespaces[0]");
			Assert.AreEqual(1, visitor.ExcludedNodesSummary.ExcludedClasses.Count, "Excluded Classes");
			Assert.AreEqual("ExcludedClass", visitor.ExcludedNodesSummary.ExcludedClasses[0].ToString(), "Classes[0]");
			Assert.AreEqual(1, visitor.ExcludedNodesSummary.ExcludedMethods.Count, "Excluded Methods");
			Assert.AreEqual("NoNamespaceClass.ExcludedMethod", visitor.ExcludedNodesSummary.ExcludedMethods[0].ToString(), "Methods[0]");
		}

		#endregion ExcludedTreeNodeVisitor

		#region StatisticsTreeNodeVisitor

		/// <summary>
		/// Test StatisticsTreeNodeVisitor iterating over a coverage tree.
		/// </summary>
		[Test(Description="Test StatisticsTreeNodeVisitor iterating over a coverage tree.")]
		public void StatisticsTreeNodeVisitorHappyPath()
		{
			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			_BuildNamespaceTestData(coverageFileTreeNode);

			StatisticsTreeNodeVisitor visitor = new StatisticsTreeNodeVisitor();
			coverageFileTreeNode.AcceptVisitor(visitor);

			Assert.AreEqual(_configuration.SatisfactoryCoverageThreshold, visitor.StatisticsSummary.AcceptablePercentage, "Acceptable%");
			Assert.AreEqual(coverageFileTreeNode.CoveragePercentage, visitor.StatisticsSummary.CoveragePercentage, "Coverage%");
			Assert.AreEqual(4, visitor.StatisticsSummary.NumberOfClasses, "NumberOfClasses");
			Assert.AreEqual(1, visitor.StatisticsSummary.NumberOfFiles, "NumberOfFiles");
			Assert.AreEqual(4, visitor.StatisticsSummary.NumberOfMembers, "NumberOfMembers");
			Assert.AreEqual(4, visitor.StatisticsSummary.NumberOfNonCommentLines, "NumberOfNonCommentLines");
			Assert.AreEqual(0, visitor.StatisticsSummary.NumberOfSequencePoints, "NumberOfSequencePoints");
			Assert.AreEqual(-1, visitor.StatisticsSummary.NumberOfUnvisitedSequencePoints, "NumberOfUnvisitedSequencePoints");
			Assert.AreEqual(_configuration.ProjectName, visitor.StatisticsSummary.ProjectName, "ProjectName");
		}

		#endregion ExcludedTreeNodeVisitor

		#endregion Tests

		#region Private Methods

		/// <summary>
		/// Construct test data.
		/// </summary>
		private ModuleTreeNode _BuildNamespaceTestData(CoverageFileTreeNode coverageFileTreeNode)
		{
			ModuleTreeNode moduleTreeNode1 = new ModuleTreeNode(_configuration, "mymodule1.dll", "MyModule1");
			coverageFileTreeNode.Nodes.Add(moduleTreeNode1);
	
			_coverageTreeFactory.AddChildClassTreeNode(moduleTreeNode1, "NoNamespaceClass");
			ClassTreeNode classTreeNode = _coverageTreeFactory.AddChildClassTreeNode(moduleTreeNode1, "NoNamespaceClass");
			MethodTreeNode excludedMethod = new MethodTreeNode(_configuration, "ExcludedMethod", "NoNamespaceClass");
			classTreeNode.ExcludedNode.Nodes.Add(excludedMethod);
			excludedMethod.IsExcluded = true;
			_coverageTreeFactory.AddChildNamespaceNode(moduleTreeNode1, "NamespaceX");
			_coverageTreeFactory.AddChildNamespaceNode(moduleTreeNode1, "NamespaceY");
			ClassTreeNode excludedClass = _coverageTreeFactory.AddChildClassTreeNode(moduleTreeNode1.ExcludedNode, "ExcludedClass");
			excludedClass.IsExcluded = true;

			ModuleTreeNode moduleTreeNode2 = new ModuleTreeNode(_configuration, "mymodule2.dll", "MyModule2");
			coverageFileTreeNode.Nodes.Add(moduleTreeNode2);
			_coverageTreeFactory.AddChildNamespaceNode(moduleTreeNode2, "NamespaceA");

			ModuleTreeNode moduleTreeNode3 = new ModuleTreeNode(_configuration, "mymodule3.dll", "FilteredModule");
			coverageFileTreeNode.FilteredNode.Nodes.Add(moduleTreeNode3);
			_coverageTreeFactory.AddChildNamespaceAndClassTreeNode(moduleTreeNode3.FilteredNode, "FilteredNamespace");
			_coverageTreeFactory.AddChildClassTreeNode(moduleTreeNode3.FilteredNode, "FilteredClass");
			_coverageTreeFactory.AddChildNamespaceNode(moduleTreeNode3.ExcludedNode, "ExcludedNamespace1");
			((NamespaceTreeNode)moduleTreeNode3.ExcludedNode.Nodes[0]).IsExcluded = true;

			ModuleTreeNode excludedModule = new ModuleTreeNode(_configuration, "mymodule4.dll", "MyModuleExcluded");
			excludedModule.IsExcluded = true;
			coverageFileTreeNode.ExcludedNode.Nodes.Add(excludedModule);
			_coverageTreeFactory.AddChildNamespaceAndClassTreeNode(excludedModule, "ExcludedNamespace2");
			((NamespaceTreeNode)excludedModule.Nodes[0]).IsExcluded = true;

			return moduleTreeNode1;
		}

		#endregion Private Methods
	}
}
