using System;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Iterators;
using NUnit.Framework;

namespace NCoverExplorer.Tests.Core.Iterators
{
	/// <summary>
	/// Unit tests for the various coverage tree iterators.
	/// </summary>
	[TestFixture]
	public class TreeIteratorsTest
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private TestCoverageTreeFactory _coverageTreeFactory;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="TreeIteratorsTest"/> class.
		/// </summary>
		public TreeIteratorsTest()
		{
		}

		#endregion Constructor

		#region Test Setup / TearDown

		/// <summary>
		/// Test setup.
		/// </summary>
		[SetUp]
		public void Setup()
		{
			_configuration = new ExplorerConfiguration(null, null, null);
			_coverageTreeFactory = new TestCoverageTreeFactory(_configuration);
		}

		#endregion Test Setup / TearDown

		#region Tests

		#region ModuleTreeIterator

		/// <summary>
		/// Test ModuleTreeIterator iterating over some modules.
		/// </summary>
		[Test(Description="Test ModuleTreeIterator iterating over some modules.")]
		public void ModuleTreeIteratorHappyPath()
		{
			_configuration.GroupByModule = true;

			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			_BuildNamespaceTestData(coverageFileTreeNode);

			ModuleTreeIterator iterator = new ModuleTreeIterator(coverageFileTreeNode);
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 1");
			Assert.AreEqual("MyModule1", ((TreeNodeBase)iterator.Current).NodeName, "Current 1");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 2");
			Assert.AreEqual("MyModule2", ((TreeNodeBase)iterator.Current).NodeName, "Current 2");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 3");
			Assert.AreEqual("FilteredModule", ((TreeNodeBase)iterator.Current).NodeName, "Current 3");
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 4");
		}

		/// <summary>
		/// Test ModuleTreeIterator iterating with no modules.
		/// </summary>
		[Test(Description="Test ModuleTreeIterator iterating with no module nodes.")]
		public void ModuleTreeIteratorNoModules()
		{
			_configuration.GroupByModule = false;

			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			_coverageTreeFactory.AddChildNamespaceNode(coverageFileTreeNode, "NamespaceX");
			_coverageTreeFactory.AddChildNamespaceNode(coverageFileTreeNode, "NamespaceY");

			ModuleTreeIterator iterator = new ModuleTreeIterator(coverageFileTreeNode);
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 1");
		}

		#endregion ModuleTreeIterator

		#region ModuleNamespaceTreeIterator

		/// <summary>
		/// Test ModuleNamespaceTreeIterator iterating over some modules.
		/// </summary>
		[Test(Description="Test ModuleNamespaceTreeIterator iterating over some modules.")]
		public void ModuleNamespaceTreeIteratorHappyPath()
		{
			_configuration.GroupByModule = true;

			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			ModuleTreeNode moduleTreeNode = _BuildNamespaceTestData(coverageFileTreeNode);

			ModuleNamespaceTreeIterator iterator = new ModuleNamespaceTreeIterator(moduleTreeNode);
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 1");
			Assert.AreEqual("NamespaceX", ((TreeNodeBase)iterator.Current).NodeName, "Current 1");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 2");
			Assert.AreEqual("NamespaceY", ((TreeNodeBase)iterator.Current).NodeName, "Current 2");
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 3");
	
			iterator = new ModuleNamespaceTreeIterator(null);
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext Unparented");
		}

		#endregion ModuleNamespaceTreeIterator

		#region ModuleClassTreeIterator

		/// <summary>
		/// Test ModuleClassTreeIterator iterating over some modules.
		/// </summary>
		[Test(Description="Test ModuleClassTreeIterator iterating over some modules.")]
		public void ModuleClassTreeIteratorHappyPath()
		{
			_configuration.GroupByModule = true;

			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			ModuleTreeNode moduleTreeNode = _BuildNamespaceTestData(coverageFileTreeNode);

			ModuleClassTreeIterator iterator = new ModuleClassTreeIterator(moduleTreeNode);
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 1");
			Assert.AreEqual("NoNamespaceClass", ((TreeNodeBase)iterator.Current).NodeName, "Current 1");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 2");
			Assert.AreEqual("NestedClass", ((TreeNodeBase)iterator.Current).NodeName, "Current 2");
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 3");

			iterator = new ModuleClassTreeIterator((ModuleTreeNode)coverageFileTreeNode.Nodes[1]);
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 4");
			Assert.AreEqual("Test", ((TreeNodeBase)iterator.Current).NodeName, "Current 3");
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 5");

			iterator = new ModuleClassTreeIterator((ModuleTreeNode)coverageFileTreeNode.Nodes[2].Nodes[0]);
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 6");
			Assert.AreEqual("Test", ((TreeNodeBase)iterator.Current).NodeName, "Current 4");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 7");
			Assert.AreEqual("FilteredClass", ((TreeNodeBase)iterator.Current).NodeName, "Current 5");
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 8");
	
			iterator = new ModuleClassTreeIterator(null);
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext Unparented");
		}

		#endregion ModuleTreeIterator

		#region NamespaceTreeIterator

		/// <summary>
		/// Test NamespaceTreeIterator iterating over some namespaces.
		/// </summary>
		[Test(Description="Test NamespaceTreeIterator iterating over some namespaces.")]
		public void NamespaceTreeIteratorHappyPath()
		{
			_configuration.GroupByModule = true;

			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			_BuildNamespaceTestData(coverageFileTreeNode);

			NamespaceTreeIterator iterator = new NamespaceTreeIterator(coverageFileTreeNode);
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 1");
			Assert.AreEqual("NamespaceX", ((TreeNodeBase)iterator.Current).NodeName, "Current 1");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 2");
			Assert.AreEqual("NamespaceY", ((TreeNodeBase)iterator.Current).NodeName, "Current 2");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 3");
			Assert.AreEqual("NamespaceA", ((TreeNodeBase)iterator.Current).NodeName, "Current 3");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 4");
			Assert.AreEqual("FilteredNamespace", ((TreeNodeBase)iterator.Current).NodeName, "Current 4");
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 5");
		}

		#endregion NamespaceTreeIterator

		#region SortedNamespaceTreeIterator

		/// <summary>
		/// Test SortedNamespaceTreeIterator iterating over some namespaces.
		/// </summary>
		[Test(Description="Test SortedNamespaceTreeIterator iterating over some namespaces.")]
		public void SortedNamespaceTreeIteratorHappyPath()
		{
			_configuration.GroupByModule = true;

			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			_BuildNamespaceTestData(coverageFileTreeNode);

			SortedNamespaceTreeIterator iterator = new SortedNamespaceTreeIterator(coverageFileTreeNode);
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 1");
			Assert.AreEqual("FilteredNamespace", ((TreeNodeBase)iterator.Current).NodeName, "Current 1");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 2");
			Assert.AreEqual("NamespaceA", ((TreeNodeBase)iterator.Current).NodeName, "Current 2");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 3");
			Assert.AreEqual("NamespaceX", ((TreeNodeBase)iterator.Current).NodeName, "Current 3");
			Assert.AreEqual(true, iterator.MoveNext(), "MoveNext 4");
			Assert.AreEqual("NamespaceY", ((TreeNodeBase)iterator.Current).NodeName, "Current 4");
			Assert.AreEqual(false, iterator.MoveNext(), "MoveNext 5");
		}

		/// <summary>
		/// Test SortedNamespaceTreeIterator retrieving when iterator not set.
		/// </summary>
		[Test(Description="Test SortedNamespaceTreeIterator retrieving when iterator not set.")]
		[ExpectedException(typeof(InvalidOperationException))]
		public void SortedNamespaceTreeIteratorNoCurrentPosition()
		{
			_configuration.GroupByModule = true;

			CoverageFileTreeNode coverageFileTreeNode = _coverageTreeFactory.CreateTree();
			_BuildNamespaceTestData(coverageFileTreeNode);

			SortedNamespaceTreeIterator iterator = new SortedNamespaceTreeIterator(coverageFileTreeNode);
			Assert.IsNull(iterator.Current, "Current");
		}

		#endregion SortedNamespaceTreeIterator

		#endregion Tests

		#region Private Methods

		/// <summary>
		/// Construct test data.
		/// </summary>
		private ModuleTreeNode _BuildNamespaceTestData(CoverageFileTreeNode coverageFileTreeNode)
		{
			ModuleTreeNode moduleTreeNode1 = new ModuleTreeNode(_configuration, "mymodule1.dll", "MyModule1");
			coverageFileTreeNode.Nodes.Add(moduleTreeNode1);
	
			ClassTreeNode parentClassNode = _coverageTreeFactory.AddChildClassTreeNode(moduleTreeNode1, "NoNamespaceClass");
			_coverageTreeFactory.AddChildClassTreeNode(parentClassNode, "NestedClass");
			_coverageTreeFactory.AddChildNamespaceNode(moduleTreeNode1, "NamespaceX");
			_coverageTreeFactory.AddChildNamespaceNode(moduleTreeNode1, "NamespaceY");

			ModuleTreeNode moduleTreeNode2 = new ModuleTreeNode(_configuration, "mymodule2.dll", "MyModule2");
			coverageFileTreeNode.Nodes.Add(moduleTreeNode2);
			_coverageTreeFactory.AddChildNamespaceAndClassTreeNode(moduleTreeNode2, "NamespaceA");

			ModuleTreeNode moduleTreeNode3 = new ModuleTreeNode(_configuration, "mymodule3.dll", "FilteredModule");
			coverageFileTreeNode.FilteredNode.Nodes.Add(moduleTreeNode3);
			_coverageTreeFactory.AddChildNamespaceAndClassTreeNode(moduleTreeNode3.FilteredNode, "FilteredNamespace");
			_coverageTreeFactory.AddChildClassTreeNode(moduleTreeNode3.FilteredNode, "FilteredClass");
			_coverageTreeFactory.AddChildNamespaceAndClassTreeNode(moduleTreeNode3.ExcludedNode, "ExcludedNamespace1");

			ModuleTreeNode excludedModule = new ModuleTreeNode(_configuration, "mymodule4.dll", "MyModuleExcluded");
			excludedModule.IsExcluded = true;
			coverageFileTreeNode.ExcludedNode.Nodes.Add(excludedModule);
			_coverageTreeFactory.AddChildNamespaceAndClassTreeNode(excludedModule, "ExcludedNamespace2");
			((NamespaceTreeNode)excludedModule.Nodes[0]).IsExcluded = true;

			return moduleTreeNode1;
		}

		#endregion Private Methods
	}
}
