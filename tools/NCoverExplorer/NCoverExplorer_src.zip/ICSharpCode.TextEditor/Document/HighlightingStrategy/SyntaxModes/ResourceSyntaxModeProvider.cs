// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Mike Krüger" email="mike@icsharpcode.net"/>
//     <version value="$version"/>
// </file>

using System;
using System.Collections;
using System.Reflection;
using System.Xml;
using System.IO;

namespace ICSharpCode.TextEditor.Document
{
	public class ResourceSyntaxModeProvider : ISyntaxModeFileProvider
	{
		ArrayList syntaxModes = null;

		/// <summary>
		/// Gets the syntax modes.
		/// </summary>
		/// <value>The syntax modes.</value>
		public ArrayList SyntaxModes
		{
			get { return syntaxModes; }
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ResourceSyntaxModeProvider"/> class.
		/// </summary>
		public ResourceSyntaxModeProvider()
		{
			Assembly assembly = typeof(SyntaxMode).Assembly;
			Stream syntaxModeStream = assembly.GetManifestResourceStream("ICSharpCode.TextEditor.Data.SyntaxModes.SyntaxModes.xml");
			if (syntaxModeStream == null)
			{
				throw new ApplicationException();
			}
			syntaxModes = SyntaxMode.GetSyntaxModes(syntaxModeStream);
		}

		/// <summary>
		/// Gets the syntax mode file.
		/// </summary>
		/// <param name="syntaxMode">The syntax mode.</param>
		/// <returns></returns>
		public XmlTextReader GetSyntaxModeFile(SyntaxMode syntaxMode)
		{
			Assembly assembly = typeof(SyntaxMode).Assembly;
			string[] names= assembly.GetManifestResourceNames();
			return new XmlTextReader(assembly.GetManifestResourceStream("ICSharpCode.TextEditor.Data.SyntaxModes." + syntaxMode.FileName));
		}
	}
}