// <file>
//     <copyright see="prj:///doc/copyright.txt"/>
//     <license see="prj:///doc/license.txt"/>
//     <owner name="Mike Krüger" email="mike@icsharpcode.net"/>
//     <version value="$version"/>
// </file>

using System;
using System.Collections;
using System.IO;

namespace ICSharpCode.TextEditor.Document
{
	public class HighlightingManager
	{
		ArrayList syntaxModeFileProviders = new ArrayList();
		static HighlightingManager highlightingManager;

		Hashtable highlightingDefs = new Hashtable();
		Hashtable extensionsToName = new Hashtable();

		/// <summary>
		/// Gets the highlighting definitions.
		/// </summary>
		/// <value>The highlighting definitions.</value>
		public Hashtable HighlightingDefinitions
		{
			get { return highlightingDefs; }
		}

		/// <summary>
		/// Gets the manager.
		/// </summary>
		/// <value>The manager.</value>
		public static HighlightingManager Manager
		{
			get { return highlightingManager; }
		}

		/// <summary>
		/// Initializes the <see cref="HighlightingManager"/> class.
		/// </summary>
		static HighlightingManager()
		{
			highlightingManager = new HighlightingManager();
			highlightingManager.AddSyntaxModeFileProvider(new ResourceSyntaxModeProvider());
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="HighlightingManager"/> class.
		/// </summary>
		public HighlightingManager()
		{
			_CreateDefaultHighlightingStrategy();
		}

		/// <summary>
		/// Adds the syntax mode file provider.
		/// </summary>
		/// <param name="syntaxModeFileProvider">The syntax mode file provider.</param>
		public void AddSyntaxModeFileProvider(ISyntaxModeFileProvider syntaxModeFileProvider)
		{
			foreach (SyntaxMode syntaxMode in syntaxModeFileProvider.SyntaxModes)
			{
				highlightingDefs[syntaxMode.Name] = new DictionaryEntry(syntaxMode, syntaxModeFileProvider);
				foreach (string extension in syntaxMode.Extensions)
				{
					extensionsToName[extension.ToUpper()] = syntaxMode.Name;
				}
			}
			if (!syntaxModeFileProviders.Contains(syntaxModeFileProvider))
			{
				syntaxModeFileProviders.Add(syntaxModeFileProvider);
			}
		}

		/// <summary>
		/// Reloads the syntax modes.
		/// </summary>
		public void ReloadSyntaxModes()
		{
			highlightingDefs.Clear();
			extensionsToName.Clear();
			_CreateDefaultHighlightingStrategy();
			foreach (ISyntaxModeFileProvider provider in syntaxModeFileProviders)
			{
				AddSyntaxModeFileProvider(provider);
			}
			OnReloadSyntaxHighlighting(EventArgs.Empty);
		}

		/// <summary>
		/// Creates the default highlighting strategy.
		/// </summary>
		private void _CreateDefaultHighlightingStrategy()
		{
			DefaultHighlightingStrategy defaultHighlightingStrategy = new DefaultHighlightingStrategy();
			defaultHighlightingStrategy.Extensions = new string[] {};
			defaultHighlightingStrategy.Rules.Add(new HighlightRuleSet());
			highlightingDefs["Default"] = defaultHighlightingStrategy;
		}

		/// <summary>
		/// Loads the definition.
		/// </summary>
		/// <param name="entry">The entry.</param>
		/// <returns></returns>
		private IHighlightingStrategy _LoadDefinition(DictionaryEntry entry)
		{
			SyntaxMode syntaxMode = (SyntaxMode) entry.Key;
			ISyntaxModeFileProvider syntaxModeFileProvider = (ISyntaxModeFileProvider) entry.Value;

			DefaultHighlightingStrategy highlightingStrategy = HighlightingDefinitionParser.Parse(syntaxMode, syntaxModeFileProvider.GetSyntaxModeFile(syntaxMode));
			highlightingDefs[syntaxMode.Name] = highlightingStrategy;
			highlightingStrategy.ResolveReferences();

			return highlightingStrategy;
		}

		/// <summary>
		/// Finds the highlighter.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <returns></returns>
		public IHighlightingStrategy FindHighlighter(string name)
		{
			object def = highlightingDefs[name];
			if (def is DictionaryEntry)
			{
				return _LoadDefinition((DictionaryEntry) def);
			}
			return (IHighlightingStrategy) (def == null ? highlightingDefs["Default"] : def);
		}

		/// <summary>
		/// Finds the highlighter for file.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <returns></returns>
		public IHighlightingStrategy FindHighlighterForFile(string fileName)
		{
			string highlighterName = (string) extensionsToName[Path.GetExtension(fileName).ToUpper()];
			if (highlighterName != null)
			{
				object def = highlightingDefs[highlighterName];
				if (def is DictionaryEntry)
				{
					return _LoadDefinition((DictionaryEntry) def);
				}
				return (IHighlightingStrategy) (def == null ? highlightingDefs["Default"] : def);
			}
			else
			{
				return (IHighlightingStrategy) highlightingDefs["Default"];
			}
		}

		/// <summary>
		/// Raises the reload syntax highlighting event.
		/// </summary>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		protected virtual void OnReloadSyntaxHighlighting(EventArgs e)
		{
			if (ReloadSyntaxHighlighting != null)
			{
				ReloadSyntaxHighlighting(this, e);
			}
		}

		public event EventHandler ReloadSyntaxHighlighting;
	}
}