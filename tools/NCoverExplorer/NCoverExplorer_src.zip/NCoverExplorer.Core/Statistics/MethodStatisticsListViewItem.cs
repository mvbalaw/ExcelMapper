using System.IO;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.Statistics
{
	/// <summary>
	/// Represents a ListViewItem in the statistics listview for representing detail of a method tree node. Self-populates itself from the
	/// supplied SequencePoint object.
	/// </summary>
	public class MethodStatisticsListViewItem : StatisticsListViewItem
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="MethodStatisticsListViewItem"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="methodTreeNode">The method tree node these sequence points belong to.</param>
		/// <param name="sequencePoint">The sequence point.</param>
		public MethodStatisticsListViewItem(IExplorerConfiguration configuration, MethodTreeNode methodTreeNode, SequencePoint sequencePoint)
			: base(configuration, methodTreeNode, sequencePoint)
		{
			// Display the { get; } or { set; } after the property name to make it look prettier.
			if (methodTreeNode.IsParentProperty)
			{
				this.Text += " { " + sequencePoint.MethodName.Substring(0,3) + "; }";
			}
			if (sequencePoint.IsExcluded)
			{
				this.Text += AppearanceHelper.ExcludedNodeSuffix;
			}
			else if (sequencePoint.IsFiltered)
			{
				this.Text += AppearanceHelper.FilteredNodeSuffix;
			}

			this.SubItems.Add(SequencePoint.VisitCount.ToString());
			this.SubItems.Add(SequencePoint.StartLine.ToString());
			this.SubItems.Add(SequencePoint.StartColumn.ToString());
			this.SubItems.Add(SequencePoint.EndLine.ToString());
			this.SubItems.Add(SequencePoint.EndColumn.ToString());
			this.SubItems.Add(Path.GetFileName(SequencePoint.FileName));

			// We know that for method clicks the tree must have been expanded already so icon is good to go.
			this.ImageIndex = methodTreeNode.ImageIndex;
		}

		/// <summary>
		/// Initialises the item for display by assigning the text color.
		/// </summary>
		public override void InitialiseForDisplay()
		{
			if (this.SequencePoint.IsExcluded)
			{
				this.ForeColor = this.Configuration.Theme.TreeNodeExcludedCoverageColor;
			}
			else if (this.SequencePoint.VisitCount == 0)
			{
				this.ForeColor = this.Configuration.Theme.TreeNodePartiallyVisitedColor;
			}
			else
			{
				this.ForeColor = this.Configuration.Theme.TreeNodeFullCoverageColor;
			}

		}
	}
}
