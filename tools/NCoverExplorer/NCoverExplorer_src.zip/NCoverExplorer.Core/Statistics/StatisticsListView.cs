using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Statistics
{
	/// <summary>
	/// ListView for showing the summary statistics for a class or method.
	/// </summary>
	public class StatisticsListView : ListView
	{
		#region DisplayMode Enum

		private enum DisplayMode
		{
			ClassStatistics = 0,
			MethodStatistics = 1
		}

		#endregion DisplayMode Enum

		#region Private Variables

		private ColumnHeader _lvcMethodName;
		private ColumnHeader _lvcVisitCount;
		private ColumnHeader _lvcCoveragePercentage;
		private ColumnHeader _lvcUnvisitedSequencePoints;
		private ColumnHeader _lvcVisitedSequencePoints;
		private ColumnHeader _lvcStartLine;
		private ColumnHeader _lvcStartColumn;
		private ColumnHeader _lvcEndLine;
		private ColumnHeader _lvcEndColumn;
		private ColumnHeader _lvcFileName;

		private IExplorerConfiguration _configuration;
		private DisplayMode _currentDisplayMode;

		private StatisticsListViewItemComparer _classItemComparer;
		private StatisticsListViewItemComparer _methodItemComparer;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsListView"/> class.
		/// </summary>
		public StatisticsListView()
		{
			_configuration = null;

			_lvcMethodName = _CreateColumnHeader("Method", 180);
			_lvcVisitCount = _CreateColumnHeader("Visit Count", 75);
			_lvcCoveragePercentage = _CreateColumnHeader("Coverage %", 80);
			_lvcUnvisitedSequencePoints = _CreateColumnHeader("Unvisited Points", 90);
			_lvcVisitedSequencePoints = _CreateColumnHeader("Visited Points", 80);
			_lvcFileName = _CreateColumnHeader("FileName", 75);
			_lvcVisitCount = _CreateColumnHeader("Visit Count", 75);
			_lvcStartLine = _CreateColumnHeader("Line", 75);
			_lvcStartColumn = _CreateColumnHeader("Column", 75);
			_lvcEndLine = _CreateColumnHeader("End Line", 75);
			_lvcEndColumn = _CreateColumnHeader("End Column", 75);
			_lvcFileName = _CreateColumnHeader("FileName", 75);

			// Want to maintain the separate sorting for class and method views.
			_classItemComparer = new StatisticsListViewItemComparer(0, true);
			_methodItemComparer = new StatisticsListViewItemComparer(0, true);

			// Set the class statistics columns to be populated by forcing a "toggle" of view.
			_currentDisplayMode = DisplayMode.MethodStatistics;
			_EnsureClassStatisticsColumnsVisible();
		}

		#endregion Constructor

		#region Public Methods

		#region Initialisation

		/// <summary>
		/// Initialises the listview with configuration and display column information.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		public void Initialise(IExplorerConfiguration configuration)
		{
			_configuration = configuration;

			// Ensure the listview is sorted by method name by default.
			SortByDefault();
		}

		#endregion Initialisation

		#region Column Width Persistence

		/// <summary>
		/// Loads the column widths.
		/// </summary>
		/// <param name="formState">State of the form.</param>
		public void LoadColumnWidths(FormState formState)
		{
			_lvcMethodName.Width = formState.GetInt32("StatisticsColumnWidthMethodName", 180);
			_lvcVisitCount.Width = formState.GetInt32("StatisticsColumnWidthVisitCount", 70);
			_lvcCoveragePercentage.Width = formState.GetInt32("StatisticsColumnWidthCoveragePercentage", 70);
			_lvcUnvisitedSequencePoints.Width = formState.GetInt32("StatisticsColumnWidthUnvisitedPointsCount", 70);
			_lvcVisitedSequencePoints.Width = formState.GetInt32("StatisticsColumnWidthVisitedPointsCount", 70);
			_lvcStartLine.Width = formState.GetInt32("StatisticsColumnWidthStartLine", 70);
			_lvcStartColumn.Width = formState.GetInt32("StatisticsColumnWidthStartColumn", 50);
			_lvcEndLine.Width = formState.GetInt32("StatisticsColumnWidthEndLine", 55);
			_lvcEndColumn.Width = formState.GetInt32("StatisticsColumnWidthEndColumn", 75);
			_lvcFileName.Width = formState.GetInt32("StatisticsColumnWidthFileName", 70);
		}

		/// <summary>
		/// Saves the column widths.
		/// </summary>
		/// <param name="formState">State of the form.</param>
		public void SaveColumnWidths(FormState formState)
		{
			formState.SetValue("StatisticsColumnWidthMethodName", _lvcMethodName.Width);
			formState.SetValue("StatisticsColumnWidthVisitCount", _lvcVisitCount.Width);
			formState.SetValue("StatisticsColumnWidthCoveragePercentage", _lvcCoveragePercentage.Width);
			formState.SetValue("StatisticsColumnWidthUnvisitedPointsCount", _lvcUnvisitedSequencePoints.Width);
			formState.SetValue("StatisticsColumnWidthVisitedPointsCount", _lvcVisitedSequencePoints.Width);
			formState.SetValue("StatisticsColumnWidthStartLine", _lvcStartLine.Width);
			formState.SetValue("StatisticsColumnWidthStartColumn", _lvcStartColumn.Width);
			formState.SetValue("StatisticsColumnWidthEndLine", _lvcEndLine.Width);
			formState.SetValue("StatisticsColumnWidthEndColumn", _lvcEndColumn.Width);
			formState.SetValue("StatisticsColumnWidthFileName", _lvcFileName.Width);
		}

		#endregion Column Width Persistence

		#region Population

		/// <summary>
		/// Populates the visit count list view with all the lines within the method.
		/// </summary>
		/// <param name="methodTreeNode">The method tree node to have it's sequence points populated.</param>
		public void PopulateStatisticsListViewForMethod(MethodTreeNode methodTreeNode)
		{
			BeginUpdate();
			try
			{
				Items.Clear();

				// Ensure we have the correct columns for method statistics
				_EnsureMethodStatisticsColumnsVisible();

				foreach (SequencePoint sequencePoint in methodTreeNode.SequencePoints)
				{
					MethodStatisticsListViewItem methodStatisticsListViewItem = new MethodStatisticsListViewItem(
						_configuration, methodTreeNode, sequencePoint);
					methodStatisticsListViewItem.InitialiseForDisplay();
					Items.Add(methodStatisticsListViewItem);
				}
			}
			finally
			{
				EndUpdate();
				Sort();
			}
		}

		/// <summary>
		/// Populates the visit count list view with all the lines within the method.
		/// </summary>
		/// <param name="classTreeNode">The class tree node to have it's methods populated.</param>
		public void PopulateStatisticsListViewForClass(ClassTreeNode classTreeNode)
		{
			BeginUpdate();
			try
			{
				Items.Clear();

				_EnsureClassStatisticsColumnsVisible();

				foreach (TreeNodeBase childNode in classTreeNode.Nodes)
				{
					if (childNode is MethodTreeNode)
					{
						MethodTreeNode methodTreeNode = (MethodTreeNode) childNode;
						ClassStatisticsListViewItem classStatisticsListViewItem = new ClassStatisticsListViewItem(
							_configuration, methodTreeNode);
						classStatisticsListViewItem.InitialiseForDisplay();
						Items.Add(classStatisticsListViewItem);
					}
				}
			}
			finally
			{
				EndUpdate();
				Sort();
			}
		}

		#endregion Population

		#region Selection

		/// <summary>
		/// Select the first visitcount listview item which has a visit count of 0 if any.
		/// If we don't find any just go to the first line in the visit count window.
		/// </summary>
		public void SelectFirstZeroCoverageItem()
		{
			foreach (StatisticsListViewItem statisticsListViewItem in Items)
			{
				if (statisticsListViewItem.SequencePoint.VisitCount == 0)
				{
					statisticsListViewItem.Selected = true;
					statisticsListViewItem.EnsureVisible();
					break;
				}
			}
			if (SelectedItems.Count == 0)
			{
				Items[0].Selected = true;
			}
		}

		/// <summary>
		/// Select the first visitcount listview item which has a visit count of 0 if any.
		/// If we don't find any just go to the first line in the visit count window.
		/// </summary>
		public void SelectLastZeroCoverageItem()
		{
			for (int index = Items.Count - 1; index >= 0; index--)
			{
				StatisticsListViewItem statisticsListViewItem = (StatisticsListViewItem)Items[index];
				if (statisticsListViewItem.SequencePoint.VisitCount == 0)
				{
					statisticsListViewItem.Selected = true;
					statisticsListViewItem.EnsureVisible();
					break;
				}
			}
		}

		#endregion Selection

		#region Sorting

		/// <summary>
		/// Sorts by the default column.
		/// </summary>
		public void SortByDefault()
		{
			OnColumnClick(new ColumnClickEventArgs(0));
		}

		#endregion Sorting

		#region ApplyTheme

		/// <summary>
		/// Applies the theme to the appearance of this control.
		/// </summary>
		/// <param name="theme">The theme.</param>
		public void ApplyTheme(Theme theme)
		{
			BackColor = theme.StatisticsPaneBackgroundColor;
			Font = theme.StatisticsPaneFont;
		}

		#endregion ApplyTheme

		#region Refresh

		/// <summary>
		/// Refreshes all items after some visual appearance decision has been changed like a new theme.
		/// </summary>
		public void RefreshAllItems()
		{
			foreach (StatisticsListViewItem statisticsListViewItem in Items)
			{
				statisticsListViewItem.InitialiseForDisplay();
			}
		}

		#endregion Refresh

		#region Navigation

		/// <summary>
		/// Navigates to the previous unvisited line within this class if there is one.
		/// </summary>
		/// <returns><c>true</c> if it found a sequence point to navigate to, otherwise <c>false</c>.</returns>
		public bool NavigateToPreviousUnvisitedLineInMethod()
		{
			int currentIndex = this.Items.Count;
			int currentLine = -1;
			if (this.SelectedItems.Count > 0)
			{
				currentIndex = this.SelectedIndices[0];
				currentLine = ((MethodStatisticsListViewItem)SelectedItems[0]).SequencePoint.StartLine;
			}

			MethodStatisticsListViewItem methodStatisticsListViewItem = null;
			for (int index = currentIndex - 1; index >= 0; index--)
			{
				methodStatisticsListViewItem = (MethodStatisticsListViewItem)this.Items[index];
				if (methodStatisticsListViewItem.SequencePoint.VisitCount == 0
					&& currentLine != methodStatisticsListViewItem.SequencePoint.StartLine)
				{
					methodStatisticsListViewItem.Selected = true;
					methodStatisticsListViewItem.EnsureVisible();
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Navigates to the next unvisited line within this class if there is one.
		/// </summary>
		/// <returns><c>true</c> if it found a sequence point to navigate to, otherwise <c>false</c>.</returns>
		public bool NavigateToNextUnvisitedLineInMethod()
		{
			int currentIndex = -1;
			int currentLine = -1;
			if (this.SelectedItems.Count > 0)
			{
				currentIndex = this.SelectedIndices[0];
				currentLine = ((MethodStatisticsListViewItem)SelectedItems[0]).SequencePoint.StartLine;
			}


			MethodStatisticsListViewItem methodStatisticsListViewItem = null;
			// Currently navigating within a method for this class rather than the class itself.
			for (int index = currentIndex + 1; index < this.Items.Count; index++)
			{
				methodStatisticsListViewItem = (MethodStatisticsListViewItem)this.Items[index];
				if (methodStatisticsListViewItem.SequencePoint.VisitCount == 0 
					&& currentLine != methodStatisticsListViewItem.SequencePoint.StartLine)
				{
					methodStatisticsListViewItem.Selected = true;
					methodStatisticsListViewItem.EnsureVisible();
					return true;
				}
			}
			return false;
		}

		#endregion Navigation

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Handles the ColumnClick event of the statistics listview control.
		/// </summary>
		/// <param name="e">The <see cref="System.Windows.Forms.ColumnClickEventArgs"/> instance containing the event data.</param>
		protected override void OnColumnClick(ColumnClickEventArgs e)
		{
			// Set the ListViewItemSorter as appropriate.
			StatisticsListViewItemComparer comparer = ListViewItemSorter as StatisticsListViewItemComparer;

			if (comparer == null)
			{
				ListViewItemSorter = new StatisticsListViewItemComparer(e.Column, true);
			}
			else
			{
				if (comparer.SortColumn == e.Column)
				{
					// Sort on same column, just the opposite direction.
					comparer.SortAscending = !comparer.SortAscending;
				}
				else
				{
					comparer.SortAscending = true;
					comparer.SortColumn = e.Column;
				}
			}

			Sort();

			base.OnColumnClick(e);
		}

		#endregion Protected Methods

		#region Private Methods
		
		/// <summary>
		/// Factory method to create a column header.
		/// </summary>
		/// <param name="columnName">Name of the column.</param>
		/// <param name="initialWidth">The initial width.</param>
		/// <returns></returns>
		private ColumnHeader _CreateColumnHeader(string columnName, int initialWidth)
		{
			ColumnHeader columnHeader = new ColumnHeader();
			columnHeader.Text = columnName;
			columnHeader.Width = initialWidth;
			return columnHeader;
		}

		/// <summary>
		/// Add/remove columns as required to display method statistics.
		/// </summary>
		private void _EnsureMethodStatisticsColumnsVisible()
		{
			if (_currentDisplayMode != DisplayMode.MethodStatistics)
			{
				ListViewItemSorter = _methodItemComparer;
				Columns.Clear();
				Columns.AddRange(new ColumnHeader[] {
														_lvcMethodName,
														_lvcVisitCount,
														_lvcStartLine,
														_lvcStartColumn, 
														_lvcEndLine, 
														_lvcEndColumn, 
														_lvcFileName
													});

				_currentDisplayMode = DisplayMode.MethodStatistics;
			}
		}

		/// <summary>
		/// Add/remove columns as required to display class statistics.
		/// </summary>
		private void _EnsureClassStatisticsColumnsVisible()
		{
			if (_currentDisplayMode != DisplayMode.ClassStatistics)
			{
				ListViewItemSorter = _classItemComparer;
				Columns.Clear();
				Columns.AddRange(new ColumnHeader[] {
														_lvcMethodName,
														_lvcVisitCount,
														_lvcCoveragePercentage,
														_lvcUnvisitedSequencePoints,
														_lvcVisitedSequencePoints,
														_lvcStartLine
													});

				_currentDisplayMode = DisplayMode.ClassStatistics;
			}
		}

		#endregion Private Methods
	}
}