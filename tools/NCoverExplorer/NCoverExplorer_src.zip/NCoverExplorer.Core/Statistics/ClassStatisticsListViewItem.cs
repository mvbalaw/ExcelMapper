using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.Statistics
{
	/// <summary>
	/// Represents a ListViewItem in the statistics listview summarising a method for a class tree node. 
	/// Self-populates itself from the supplied method tree node.
	/// </summary>
	public class ClassStatisticsListViewItem : StatisticsListViewItem
	{
		/// <summary>
		/// Initializes a new instance of the <see cref="ClassStatisticsListViewItem"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="methodTreeNode">The method tree node these sequence points belong to.</param>
		public ClassStatisticsListViewItem(IExplorerConfiguration configuration, MethodTreeNode methodTreeNode)
			: base(configuration, methodTreeNode, methodTreeNode.SequencePoints[0])
		{
			// Display the { get; } or { set; } after the property name to make it look prettier.
			if (methodTreeNode.IsExcluded)
			{
				this.Text += AppearanceHelper.ExcludedNodeSuffix;
			}
			else if (methodTreeNode.IsFiltered)
			{
				this.Text += AppearanceHelper.FilteredNodeSuffix;
			}

			this.SubItems.Add(SequencePoint.VisitCount.ToString());
			this.SubItems.Add(AppearanceHelper.GetCoveragePercentText(methodTreeNode.CoveragePercentage));
			this.SubItems.Add(methodTreeNode.UnvisitedSequencePoints.ToString());
			this.SubItems.Add(methodTreeNode.VisitedSequencePoints.ToString());
			this.SubItems.Add(SequencePoint.StartLine.ToString());

			if (methodTreeNode.HasBeenLoaded)
			{
				this.ImageIndex = methodTreeNode.ImageIndex;
			}
			else
			{
				this.ImageIndex = AppearanceHelper.GetImageIndexForMethod(methodTreeNode);
			}
		}

		/// <summary>
		/// Initialises the item for display by assigning the text color.
		/// </summary>
		public override void InitialiseForDisplay()
		{
			this.ForeColor = AppearanceHelper.GetNodeColor(
				this.Configuration, 
				this.MethodTreeNode.CoveragePercentage, 
				this.MethodTreeNode.UnvisitedSequencePoints, 
				this.MethodTreeNode.TotalSequencePoints, 
				this.MethodTreeNode.IsExcluded,
				this.MethodTreeNode.IsFiltered);

		}
	}
}
