
namespace NCoverExplorer.Core.Statistics
{
	/// <summary>
	/// Statistics data container for use with reporting and presentation of total project statistics.
	/// </summary>
	public class StatisticsSummary
	{
		#region Private Variables

		private string _projectName;
		private int _numberOfClasses;
		private int _numberOfMembers;
		private int _numberOfNonCommentLines;
		private int _numberOfFiles;
		private int _numberOfSequencePoints;
		private int _numberOfUnvisitedSequencePoints;
		private float _coveragePercentage;
		private float _acceptablePercentage;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsSummary"/> class.
		/// </summary>
		public StatisticsSummary()
		{
			_projectName = "";
			_numberOfClasses = 0;
			_numberOfMembers = 0;
			_numberOfNonCommentLines = 0;
			_numberOfFiles = 0;
			_numberOfSequencePoints = 0;
			_numberOfUnvisitedSequencePoints = 0;
			_coveragePercentage = 0;
			_acceptablePercentage = 100;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the name of the project.
		/// </summary>
		/// <value>The name of the project.</value>
		public string ProjectName
		{
			get { return _projectName; }
			set { _projectName = value; }
		}

		/// <summary>
		/// Gets or sets the number of classes.
		/// </summary>
		/// <value>The number of classes.</value>
		public int NumberOfClasses
		{
			get { return _numberOfClasses; }
			set { _numberOfClasses = value; }
		}

		/// <summary>
		/// Gets or sets the number of members.
		/// </summary>
		/// <value>The number of members.</value>
		public int NumberOfMembers
		{
			get { return _numberOfMembers; }
			set { _numberOfMembers = value; }
		}

		/// <summary>
		/// Gets or sets the number of NCLOC (non-commented lines of code).
		/// </summary>
		/// <value>The number of NCLOC.</value>
		public int NumberOfNonCommentLines
		{
			get { return _numberOfNonCommentLines; }
			set { _numberOfNonCommentLines = value; }
		}

		/// <summary>
		/// Gets or sets the number of files.
		/// </summary>
		/// <value>The number of files.</value>
		public int NumberOfFiles
		{
			get { return _numberOfFiles; }
			set { _numberOfFiles = value; }
		}

		/// <summary>
		/// Gets or sets the number of sequence points.
		/// </summary>
		/// <value>The number of sequence points.</value>
		public int NumberOfSequencePoints
		{
			get { return _numberOfSequencePoints; }
			set { _numberOfSequencePoints = value; }
		}

		/// <summary>
		/// Gets or sets the number of unvisited sequence points.
		/// </summary>
		/// <value>The number of unvisited sequence points.</value>
		public int NumberOfUnvisitedSequencePoints
		{
			get { return _numberOfUnvisitedSequencePoints; }
			set { _numberOfUnvisitedSequencePoints = value; }
		}

		/// <summary>
		/// Gets or sets the overall coverage percentage.
		/// </summary>
		/// <value>The overall coverage percentage.</value>
		public float CoveragePercentage
		{
			get { return _coveragePercentage; }
			set { _coveragePercentage = value; }
		}

		/// <summary>
		/// Gets or sets the acceptable coverage percentage.
		/// </summary>
		/// <value>The acceptable coverage percentage.</value>
		public float AcceptablePercentage
		{
			get { return _acceptablePercentage; }
			set { _acceptablePercentage = value; }
		}

		#endregion Public Properties
	}
}
