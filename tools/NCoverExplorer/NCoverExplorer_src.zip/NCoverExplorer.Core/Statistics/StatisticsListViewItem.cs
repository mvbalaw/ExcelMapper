using System.Windows.Forms;
using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Statistics
{
	/// <summary>
	/// Represents a base ListViewItem in the statistics listview for a method tree node. Self-populates itself from the
	/// supplied SequencePoint object.
	/// </summary>
	public abstract class StatisticsListViewItem : ListViewItem
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private MethodTreeNode _methodTreeNode;

		private SequencePoint _sequencePoint;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsListViewItem"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="methodTreeNode">The method tree node these sequence points belong to.</param>
		/// <param name="sequencePoint">The sequence point.</param>
		protected StatisticsListViewItem(IExplorerConfiguration configuration, MethodTreeNode methodTreeNode, SequencePoint sequencePoint)
		{
			_configuration = configuration;
			_methodTreeNode = methodTreeNode;
			_sequencePoint = sequencePoint;
			this.Text = methodTreeNode.NodeName;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the configuration.
		/// </summary>
		/// <value>The configuration.</value>
		public IExplorerConfiguration Configuration
		{
			get { return _configuration; }
		}

		/// <summary>
		/// Gets the method tree node.
		/// </summary>
		/// <value>The method tree node.</value>
		public MethodTreeNode MethodTreeNode
		{
			get { return _methodTreeNode; }
		}

		/// <summary>
		/// Gets the name of the method as displayed on this listview item.
		/// Note this may vary from the underlying sequence point name for nested properties.
		/// </summary>
		/// <value>The name of the method.</value>
		public string MethodName
		{
			get { return this.Text; }
		}

		/// <summary>
		/// Gets the NCover sequence point object details associated with this section of code.
		/// </summary>
		public SequencePoint SequencePoint
		{
			get { return _sequencePoint; }
			set { _sequencePoint = value; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Initialises the item for display by assigning the text color.
		/// </summary>
		public abstract void InitialiseForDisplay();

		#endregion Public Methods
	}
}
