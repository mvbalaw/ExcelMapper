using System.Collections;

using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Statistics
{
	/// <summary>
	/// ListView item comparer for the Statistics listview.
	/// </summary>
	public class StatisticsListViewItemComparer : IComparer
	{
		#region Private Variables

		private const int LineNumberColumnIndex = 5;
		private const int FileNameColumnIndex = 6;

		private int _sortColumn;
		private bool _isAscendingOrder;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsListViewItemComparer"/> class.
		/// </summary>
		public StatisticsListViewItemComparer() 
			: this(0, true)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsListViewItemComparer"/> class.
		/// </summary>
		/// <param name="column">The column.</param>
		public StatisticsListViewItemComparer(int column) 
			: this(column, true)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsListViewItemComparer"/> class.
		/// </summary>
		/// <param name="column">The column.</param>
		/// <param name="isAscendingOrder">if set to <c>true</c> sort ascending.</param>
		public StatisticsListViewItemComparer(int column, bool isAscendingOrder)
		{
			_sortColumn = column;
			_isAscendingOrder = isAscendingOrder;
		}

		#endregion Constructors

		#region Public Properties

		/// <summary>
		/// Gets or sets the sort column.
		/// </summary>
		/// <value>The sort column.</value>
		public int SortColumn
		{
			get { return _sortColumn; }
			set { _sortColumn = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether [sort ascending].
		/// </summary>
		/// <value><c>true</c> if [sort ascending]; otherwise, <c>false</c>.</value>
		public bool SortAscending
		{
			get { return _isAscendingOrder; }
			set { _isAscendingOrder = value; }
		}

		#endregion Public Properties

		#region IComparer Members

		/// <summary>
		/// Compares two objects and returns a value indicating whether one
		/// is less than, equal to or greater than the other.
		/// </summary>
		/// <param name="x">First object to compare.</param>
		/// <param name="y">Second object to compare.</param>
		public virtual int Compare(object x, object y)
		{
			int compare = 0;

			if (x is MethodStatisticsListViewItem)
			{
				compare = _CompareMethodStatisticsItems((MethodStatisticsListViewItem)x, (MethodStatisticsListViewItem)y);
			}
			else
			{
				compare = _CompareClassStatisticsItems((ClassStatisticsListViewItem)x, (ClassStatisticsListViewItem)y);
			}

			return compare;
		}

		#endregion IComparer Members

		#region Private Methods

		/// <summary>
		/// Perform comparison on items in the class statistics listview.
		/// </summary>
		/// <param name="firstListViewItem">The first list view item.</param>
		/// <param name="secondListViewItem">The second list view item.</param>
		/// <returns></returns>
		private int _CompareClassStatisticsItems(ClassStatisticsListViewItem firstListViewItem, ClassStatisticsListViewItem secondListViewItem)
		{
			int compare = 0;
			string columnName = firstListViewItem.ListView.Columns[SortColumn].Text;
	
			switch (columnName)
			{
				case "Method":
					compare = string.Compare(firstListViewItem.MethodName, secondListViewItem.MethodName);
					if (compare == 0)
					{
						compare = _CompareIntegers(firstListViewItem.SubItems[LineNumberColumnIndex].Text, secondListViewItem.SubItems[LineNumberColumnIndex].Text);
					}
					else if (!_isAscendingOrder)
					{
						compare = -compare;
					}
					break;

				case "Visit Count":
					compare = _CompareLongs(firstListViewItem.SequencePoint.VisitCount, secondListViewItem.SequencePoint.VisitCount);
					if (compare == 0)
					{
						compare = string.Compare(firstListViewItem.MethodName, secondListViewItem.MethodName);
					}
					break;

				case "Coverage %":
				case "Unvisited Points":
				case "Visited Points":
					compare = _CompareIntegers(firstListViewItem.SubItems[SortColumn].Text, secondListViewItem.SubItems[SortColumn].Text);
					if (compare == 0)
					{
						compare = string.Compare(firstListViewItem.MethodName, secondListViewItem.MethodName);
					}
					break;

				case "Line":
					compare = _CompareIntegers(firstListViewItem.SubItems[SortColumn].Text, secondListViewItem.SubItems[SortColumn].Text);
					break;
			}
			if (!_isAscendingOrder)
			{
				compare = -compare;
			}
			return compare;
		}

		/// <summary>
		/// Perform comparison on items in the method statistics listview.
		/// </summary>
		/// <param name="firstListViewItem">The first list view item.</param>
		/// <param name="secondListViewItem">The second list view item.</param>
		/// <returns></returns>
		private int _CompareMethodStatisticsItems(MethodStatisticsListViewItem firstListViewItem, MethodStatisticsListViewItem secondListViewItem)
		{
			int compare = 0;
	
			SequencePoint firstSequencePoint = firstListViewItem.SequencePoint;
			SequencePoint secondSequencePoint = secondListViewItem.SequencePoint;
			string columnName = firstListViewItem.ListView.Columns[SortColumn].Text;
	
			switch (columnName)
			{
				case "Method":
					compare = string.Compare(firstListViewItem.MethodName, secondListViewItem.MethodName);
					if (compare == 0)
					{
						compare = _CompareSequencePointsByLine(firstSequencePoint, secondSequencePoint);
					}
					else if (!_isAscendingOrder)
					{
						compare = -compare;
					}
					break;

				case "Visit Count":
					compare = _CompareLongs(firstSequencePoint.VisitCount, secondSequencePoint.VisitCount);
					if (compare == 0)
					{
						compare = _CompareSequencePointsByLine(firstSequencePoint, secondSequencePoint);
					}
					else if (!_isAscendingOrder)
					{
						compare = -compare;
					}
					break;

				case "Line":
				case "End Line":
				case "Column":
				case "End Column":
					compare = string.Compare(firstListViewItem.SubItems[FileNameColumnIndex].Text, secondListViewItem.SubItems[FileNameColumnIndex].Text);
					if (compare == 0)
					{
						compare = _CompareSequencePointsByLine(firstSequencePoint, secondSequencePoint);
						if (!_isAscendingOrder)
						{
							compare = -compare;
						}
					}
					break;

				case "FileName":
					compare = _CompareMethodNodesByFileName(firstListViewItem.SubItems[SortColumn].Text, secondListViewItem.SubItems[SortColumn].Text,
						firstSequencePoint, secondSequencePoint);
					break;
			}
			return compare;
		}

		/// <summary>
		/// Compares two integer column text strings (maybe containing trailing "%") and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstIntegerText">The first integer.</param>
		/// <param name="secondIntegerText">The second integer.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareIntegers(string firstIntegerText, string secondIntegerText)
		{
			int trailingPercentIndex = firstIntegerText.IndexOf("%");
			if (trailingPercentIndex > 0)
			{
				firstIntegerText = firstIntegerText.Substring(0, trailingPercentIndex);
				secondIntegerText = secondIntegerText.Substring(0, secondIntegerText.IndexOf("%"));
			}

			return _CompareIntegers(int.Parse(firstIntegerText), int.Parse(secondIntegerText));
		}

		/// <summary>
		/// Compares two integer columns and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstInteger">The first integer.</param>
		/// <param name="secondInteger">The second integer.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareIntegers(int firstInteger, int secondInteger)
		{
			if (firstInteger < secondInteger)
			{
				return -1;
			}
			else if (firstInteger == secondInteger)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}

		/// <summary>
		/// Compares two long columns and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstLong">The first long.</param>
		/// <param name="secondLong">The second long.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareLongs(long firstLong, long secondLong)
		{
			if (firstLong < secondLong)
			{
				return -1;
			}
			else if (firstLong == secondLong)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}

		/// <summary>
		/// Compares two sequence points positions and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstSequencePoint">The first sequence point.</param>
		/// <param name="secondSequencePoint">The second sequence point.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareSequencePointsByLine(SequencePoint firstSequencePoint, SequencePoint secondSequencePoint)
		{
			if (firstSequencePoint.StartLine != secondSequencePoint.StartLine)
			{
				return _CompareIntegers(firstSequencePoint.StartLine, secondSequencePoint.StartLine);
			}
			else
			{
				// Since on the same line compare the columns.
				return _CompareIntegers(firstSequencePoint.StartColumn, secondSequencePoint.StartColumn);
			}
		}

		/// <summary>
		/// Compares two method node positions by filename and returns appropriate value for IComparer.
		/// If filenames are the same sorts by method name (always ascending).
		/// If method name is the same, sorts by sequence point position (always ascending).
		/// </summary>
		/// <param name="firstFileName">The first filename.</param>
		/// <param name="secondFileName">The second filename.</param>
		/// <param name="firstSequencePoint">The first sequence point.</param>
		/// <param name="secondSequencePoint">The second sequence point.</param>
		/// <returns>
		/// 0 if the same, -1 if first is less than second, 1 otherwise.
		/// </returns>
		private int _CompareMethodNodesByFileName(string firstFileName, string secondFileName, 
			SequencePoint firstSequencePoint, SequencePoint secondSequencePoint)
		{
			if (firstFileName != secondFileName)
			{
				int compare = string.Compare(firstFileName, secondFileName);
				if (!_isAscendingOrder)
				{
					compare = -compare;
				}
				return compare;
			}
			else
			{
				// Since the same filename compare the method names
				if (firstSequencePoint.MethodName != secondSequencePoint.MethodName)
				{
					return string.Compare(firstFileName, secondFileName);
				}
				else
				{
					// Since the same filename and method name compare the line positions.
					return _CompareSequencePointsByLine(firstSequencePoint, secondSequencePoint);
				}
			}
		}

		#endregion Private Methods
	}
}
