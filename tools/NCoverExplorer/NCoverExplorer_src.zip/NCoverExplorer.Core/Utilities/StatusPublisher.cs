using System;

namespace NCoverExplorer.Core.Utilities
{
	/// <summary>
	/// Publish status messages to the GUI.
	/// </summary>
	public sealed class StatusPublisher
	{
		#region Private Static Variables

		private static IStatusMessageRecipient _statusMessageRecipient;

		#endregion Private Static Variables

		#region Private Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="StatusPublisher"/> class.
		/// </summary>
		[CoverageExclude]
		private StatusPublisher()
		{
		}

		#endregion Private Constructor

		#region Public Static Methods

		/// <summary>
		/// Initialises the specified status bar.
		/// </summary>
		/// <param name="statusMessageRecipient">The status bar.</param>
		public static void Initialise(IStatusMessageRecipient statusMessageRecipient)
		{
			_statusMessageRecipient = statusMessageRecipient;
		}

		/// <summary>
		/// Displays the specified message.
		/// </summary>
		/// <param name="message">The message.</param>
		public static void Display(string message)
		{
			if (_statusMessageRecipient == null)
			{
				Console.WriteLine("StatusPublisher: " + message);
			}
			else
			{
				_statusMessageRecipient.Publish(message);
			}
		}

		/// <summary>
		/// Displays the specified exception.
		/// </summary>
		/// <param name="ex">The exception to display.</param>
		public static void DisplayException(Exception ex)
		{
			// Display summary on status bar if it has been initialised.
			if (_statusMessageRecipient == null)
			{
				Console.WriteLine("StatusPublisher Exception: " + ex.ToString());
			}
			else
			{
				_statusMessageRecipient.Publish(ex);
			}
		}

		#endregion Public Static Methods
	}
}
