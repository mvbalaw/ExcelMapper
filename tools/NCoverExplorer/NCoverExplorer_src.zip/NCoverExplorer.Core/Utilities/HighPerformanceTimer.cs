using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Threading;

namespace NCoverExplorer.Core.Utilities
{
	/// <summary>
	/// High resolution timer using the windows API.
	/// </summary>
	public class HighPerformanceTimer
	{
		#region WinAPI

		[DllImport("Kernel32.dll")]
		private static extern short QueryPerformanceCounter(ref long lpPerformanceCount);

		[DllImport("Kernel32.dll")]
		private static extern short QueryPerformanceFrequency(ref long lpFrequency);

		#endregion WinAPI

		#region Private Variables

		private long _startTime;
		private long _duration;
		private long _frequency;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="HighPerformanceTimer"/> class.
		/// </summary>
		public HighPerformanceTimer()
		{
			_startTime = 0;
			_frequency = 0;

			if (QueryPerformanceFrequency(ref _startTime) != 0L)
			{
				QueryPerformanceFrequency(ref _frequency);
			}
			else
			{
				// high-performance counter not supported
				throw new Win32Exception();
			}
			
			// Ensure the methods have been 'jitted' for first call
			Start();
			Stop();

			_duration = 0;
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Starts the timer.
		/// </summary>
		public void Start()
		{
			// lets do the waiting threads there work
			Thread.Sleep(0);

			QueryPerformanceCounter(ref _startTime);
		}

		/// <summary>
		/// Stops the timer.
		/// </summary>
		public void Stop()
		{
			QueryPerformanceCounter(ref _duration);
			_duration -= _startTime;
		}

		/// <summary>
		/// Returns the duration of the timer (in seconds)
		/// </summary>
		/// <value>The duration.</value>
		public decimal Duration
		{
			get { return (decimal)(_duration) / (decimal) _frequency; }
		}

		#endregion Public Methods
	}	
}
