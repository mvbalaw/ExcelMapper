using System;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace NCoverExplorer.Core.Utilities
{
	/// <summary>
	/// Utility functions to Send and Receive messages to another running process.
	/// Used for receiving messages from TestDriven.Net to open a file in the currently running instance.
	/// </summary>
	public sealed class RemoteController
	{
		#region WinAPI

		private const short WM_COPYDATA = 74;

		[DllImport("user32.dll")]
		private static extern bool SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, ref CopyDataStruct lParam);

		[StructLayout(LayoutKind.Sequential)]
		private struct CopyDataStruct
		{
			public IntPtr Padding;
			public int Size;
			public IntPtr Buffer;
		}

		#endregion WinAPI

		#region Private Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="RemoteController"/> class.
		/// </summary>
		[CoverageExclude]
		private RemoteController()
		{
		}

		#endregion Private Constructor

		#region Public Static Methods

		/// <summary>
		/// Receives a string message from the WM_COPYDATA message type and decodes it.
		/// </summary>
		/// <param name="m">The windows message.</param>
		/// <returns></returns>
		public static string Receive(Message m)
		{
			CopyDataStruct copyDataStruct = (CopyDataStruct)m.GetLParam(typeof(CopyDataStruct));
			byte[] dataArray = new byte[copyDataStruct.Size];
			Marshal.Copy(copyDataStruct.Buffer, dataArray, 0, copyDataStruct.Size);
			return Encoding.Unicode.GetString(dataArray);
		}

		/// <summary>
		/// Sends the a string message to the window with specified IntPtr.
		/// </summary>
		/// <param name="intPtr">The IntPtr.</param>
		/// <param name="message">The message.</param>
		/// <returns></returns>
		public static bool Send(IntPtr intPtr, string message)
		{
			if (intPtr != IntPtr.Zero)
			{
				char[] dataArray = message.ToCharArray();

				CopyDataStruct copyDataStruct = new CopyDataStruct();
				copyDataStruct.Padding = IntPtr.Zero;
				copyDataStruct.Size = dataArray.Length * 2;
				copyDataStruct.Buffer = Marshal.AllocHGlobal(copyDataStruct.Size);
				Marshal.Copy(dataArray, 0, copyDataStruct.Buffer, dataArray.Length);

				bool isSent = RemoteController.SendMessage(intPtr, WM_COPYDATA, IntPtr.Zero, ref copyDataStruct);
				Marshal.FreeHGlobal(copyDataStruct.Buffer);
				return isSent;
			}
			return false;
		}

		#endregion Public Static Methods
	}
}
