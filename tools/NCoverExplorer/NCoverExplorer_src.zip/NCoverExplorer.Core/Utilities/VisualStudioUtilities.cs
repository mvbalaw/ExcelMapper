using System;
using System.IO;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Reflection;
using EnvDTE;

namespace NCoverExplorer.Core.Utilities
{
	/// <summary>
	/// Utility functions for automating the VS.Net IDE from an external application.
	/// </summary>
	public sealed class VisualStudioUtilities
	{
		#region Constructors

		/// <summary>
		/// Initializes the <see cref="VisualStudioUtilities"/> class - static constructor to hook
		/// up the assembly resolver.
		/// </summary>
        static VisualStudioUtilities()
        {
            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(_CurrentDomain_AssemblyResolve);
        }

		/// <summary>
		/// Initializes a new instance of the <see cref="VisualStudioUtilities"/> class.
		/// Private for FxCop requirements as class contains only static methods.
		/// </summary>
		[CoverageExclude]
		private VisualStudioUtilities()
		{
		}
		
		#endregion Constructors

		#region WinAPI

		[DllImport("ole32.dll")]		
		private static extern int GetRunningObjectTable(int reserved, out UCOMIRunningObjectTable prot);

		[DllImport("ole32.dll")]  
		private static extern int CreateBindCtx(int reserved, out UCOMIBindCtx ppbc);

		[DllImport("user32.dll")] 
		private static extern bool SetForegroundWindow(IntPtr hWnd);

		private const int SW_RESTORE = 9;
		[DllImport("user32.dll")] 
		private static extern bool ShowWindowAsync(IntPtr hWnd,int nCmdShow);

		[DllImport("user32.dll")] 
		private static extern bool IsIconic(IntPtr hWnd);       

		#endregion WinAPI

		#region Public Static Methods

		/// <summary>
		/// Find an instance of VS.Net open with the specified file, open the file and navigate to the specified line and offset.
		/// </summary>
		/// <param name="fileName">The file to find a match for.</param>
		/// <param name="line">The line of code within the file.</param>
		/// <param name="offset">The offset within the line.</param>
		public static void MoveToLineAndOffset(string fileName, int line, int offset)
		{
			Solution solution = _GuessSolutionForFile(fileName);
			if (solution != null)
			{
				DTE dte = solution.DTE;
				_MoveToLineAndOffset(dte, fileName, line, offset);

				_BringDTEInstanceToFront(dte);
			}
			else
			{
				try
				{
					System.Diagnostics.Process.Start(fileName);
				}
				catch (Exception ex)
				{
					MessageBox.Show("There was an error while starting the file:" + Environment.NewLine + ex.Message, "NCoverExplorer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
				}
			}
		}

		#endregion Public Static Methods

		#region Private Static Methods

		/// <summary>
		/// In situation where this app is installed on a machine with only VS2005 we need to
		/// remap the EnvDTE assembly.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="args">The <see cref="System.ResolveEventArgs"/> instance containing the event data.</param>
		/// <returns></returns>
		private static Assembly _CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
		{
			if (args.Name == "EnvDTE, Version=7.0.3300.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
			{
				return Assembly.Load("EnvDTE, Version=8.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a");
			}

			return null;
		}

		/// <summary>
		/// Guess the VS.Net solution object instance for a specified filename.
		/// </summary>
		/// <param name="file">The filename.</param>
		/// <returns>Solution object; null if file not found in any open solutions.</returns>
		private static Solution _GuessSolutionForFile(string file)
		{
			string lowerFile = file.ToLower();
			ArrayList solutionList = _GetIDESolutions(true);

			foreach (Solution solution in solutionList)
			{
				string solutionFile = solution.FileName;
				if (solutionFile == null || solutionFile.Length == 0)
				{
					continue;
				}

				string solutionDir = Path.GetDirectoryName(solutionFile);
				string prefix = solutionDir.ToLower() + Path.DirectorySeparatorChar;
				if (lowerFile.StartsWith(prefix))
				{
					return solution;
				}
			}

			return null;
		}

		/// <summary>
		/// Get a snapshot of the running object table (ROT).
		/// </summary>
		/// <returns>A hashtable mapping the name of the object in the ROT to the corresponding object.</returns>
		private static Hashtable _GetRunningObjectTable()
		{
			Hashtable result = new Hashtable();

			int numFetched;
			UCOMIRunningObjectTable runningObjectTable;   
			UCOMIEnumMoniker monikerEnumerator;
			UCOMIMoniker[] monikers = new UCOMIMoniker[1];

			GetRunningObjectTable(0, out runningObjectTable);    
			runningObjectTable.EnumRunning(out monikerEnumerator);
			monikerEnumerator.Reset();          
    
			while (monikerEnumerator.Next(1, monikers, out numFetched) == 0)
			{     
				UCOMIBindCtx ctx;
				CreateBindCtx(0, out ctx);     
            
				string runningObjectName;
				monikers[0].GetDisplayName(ctx, null, out runningObjectName);

				object runningObjectVal;  
				runningObjectTable.GetObject( monikers[0], out runningObjectVal); 

				result[ runningObjectName ] = runningObjectVal;
			} 

			return result;
		}

		/// <summary>
		/// Get a table of the currently running instances of the Visual Studio .NET IDE.
		/// </summary>
		/// <param name="openSolutionsOnly">Only return instances that have opened a solution</param>
		/// <returns>
		/// A hashtable mapping the name of the IDE in the running object table
		/// to the corresponding DTE object
		/// </returns>
		private static ArrayList _GetIDESolutions( bool openSolutionsOnly )
		{
			ArrayList solutions = new ArrayList();
			Hashtable runningObjects = _GetRunningObjectTable();

			IDictionaryEnumerator rotEnumerator = runningObjects.GetEnumerator();
			while ( rotEnumerator.MoveNext() )
			{
                Solution solution = rotEnumerator.Value as Solution;
                if (solution == null)
                {
                    continue;
                }

				_DTE ide = solution.DTE;
				if (openSolutionsOnly)
				{
					try
					{
						string solutionFile = ide.Solution.FullName;
						if (solutionFile != String.Empty)
						{
							solutions.Add(ide.Solution);
						}
					} 
					catch {}
				}
				else
				{
					solutions.Add(ide.Solution);
				}                       
			}
			return solutions;
		}

		/// <summary>
		/// Given a DTE object, open the specified file and move to a line and offset.
		/// </summary>
		private static void _MoveToLineAndOffset(DTE dte, string file, int line, int offset)
		{
			Window window = dte.ItemOperations.OpenFile(file, Constants.vsViewKindTextView);
			TextWindow textWindow = (TextWindow)window.Object;
			if (line == 1)
			{
				// VS.Net will blow up if you try the "MoveToLineAndOffset" method with
				// a line number of 1 - so we can just use the offset.
				textWindow.ActivePane.Selection.MoveToAbsoluteOffset(offset, false);
			}
			else
			{
				textWindow.ActivePane.Selection.MoveToLineAndOffset(line, offset, false);
			}
		}

		/// <summary>
		/// Brings the Visual Studio IDE with the DTE to the foreground.
		/// </summary>
		/// <param name="dte">The DTE.</param>
		private static void _BringDTEInstanceToFront(DTE dte)
		{
			System.IntPtr hWnd = (System.IntPtr)dte.MainWindow.HWnd;
			if (IsIconic(hWnd))
			{
				ShowWindowAsync(hWnd,SW_RESTORE);
			}
			SetForegroundWindow(hWnd);
			dte.MainWindow.Visible = true;
		}

		#endregion Private Static Methods
	}
}



