using System;

namespace NCoverExplorer.Core.Utilities
{
	/// <summary>
	/// Interface for callbacks to display status messages.
	/// </summary>
	public interface IStatusMessageRecipient
	{
		/// <summary>
		/// Publishes the specified message.
		/// </summary>
		/// <param name="message">The message.</param>
		void Publish(string message);
		/// <summary>
		/// Publishes the specified exception.
		/// </summary>
		/// <param name="ex">The exception.</param>
		void Publish(Exception ex);
	}
}
