using System;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace NCoverExplorer.Core.Utilities
{
	/// <summary>
	/// Utility functions for xml serialization.
	/// </summary>
	public class SerializationUtilities
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SerializationUtilities"/> class - private
		/// as class contains only static methods.
		/// </summary>
		[CoverageExclude]
		private SerializationUtilities()
		{
		}

		#endregion Constructor

		#region Public Static Methods

		/// <summary>
		/// Takes an XML string and returns the deserialized object using the XmlSerializer and ASCII.
		/// </summary>
		/// <param name="serialisedObject">A string representation of the instance of the object to return.</param>
		/// <param name="objectType">Only required for XML serialization (use null for other types). 
		/// The type of the object to return (see .GetType() or typeof()).</param>
		/// <returns>Returns the object the XML represents.</returns>
		public static object DeserializeFromXml(string serialisedObject, Type objectType)
		{
            using (MemoryStream stream = new MemoryStream(Encoding.ASCII.GetBytes(serialisedObject)))
			{
				XmlSerializer xs = new XmlSerializer(objectType);
				// HACK: Grant - due to a bug in XmlSerializer 1.1 we need to wrap the stream
				// in a new reader which has Normalization set to false.
				// http://66.102.9.104/search?q=cache:bBRe8_nipqEJ:www.hutteman.com/weblog/2003/12/18-149.html+xmlserializer+invalid+characters&hl=en
				return xs.Deserialize(new XmlTextReader(stream));
			}
		}

		/// <summary>
		/// Serializes an object using the XmlSerializer and ASCII encoding and returns the object as a string.
		/// Provided as a convenience overload for users of XmlSerializer.
		/// </summary>
		/// <param name="data">The object to get the XML serialization of using XmlSerializer and ASCII.</param>
		/// <returns>Returns a ASCII xml string representation of an object.</returns>
		public static string SerializeToXml(object data)
		{
			using (MemoryStream memoryStream = new MemoryStream())
			{
				XmlSerializer xs = new XmlSerializer(data.GetType());
				XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.ASCII);

				// Grant - added some optimisations to minimise the xml size.
				// http://markallanson.net/archives/000179.html
				// Remove the xml processing instruction.
				xmlTextWriter.Formatting = Formatting.None;
				xmlTextWriter.WriteRaw(string.Empty);

				// Ensure we do not serialize the "xsd" and "xsi" namespace declarations.
				XmlSerializerNamespaces xsn = new XmlSerializerNamespaces();
				xsn.Add(String.Empty, String.Empty);

				xs.Serialize(xmlTextWriter, data, xsn);

				byte[] contents = new byte[memoryStream.Length];
				memoryStream.Position = 0;
				memoryStream.Read(contents, 0, (int) memoryStream.Length);
                string xml = Encoding.ASCII.GetString(contents);

				return xml;
			}
		}

		#endregion Public Static Methods
	}
}
