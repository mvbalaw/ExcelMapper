using System;
using System.Text;
using System.Xml;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Parser
{
	/// <summary>
	/// Responsible for serialising current tree contents to a coverage.xml file.
	/// </summary>
	public sealed class CoverageFileWriter
	{
		#region Private Methods

		private IExplorerConfiguration _configuration;

		#endregion Private Methods

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageFileWriter"/> class.
		/// </summary>
		public CoverageFileWriter(IExplorerConfiguration configuration)
		{
			_configuration = configuration;
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Writes the coverage xml file. Note that any nodes marked as "excluded" will not be written out to the file.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		public void WriteCoverageXmlFile(string fileName, CoverageFileTreeNode coverageFileTreeNode)
		{
			if (!_configuration.GroupByModule)
			{
				// Not so easy. Need to find all the method nodes and sort them by module. Problem is do not
				// even store the "module" assembly information in this mode since the ModuleTreeNode does not exist.
				// For now just disable the functionality (although menus being disabled should prevent getting here).
				throw new InvalidOperationException("File save functionality disabled unless grouping by module.");
			}

			XmlTextWriter xmlTextWriter = new XmlTextWriter(fileName, Encoding.UTF8);
			xmlTextWriter.Indentation = 2;
			xmlTextWriter.Formatting = Formatting.Indented;

			xmlTextWriter.WriteStartDocument();

			string stylesheet = "href='coverage.xsl' type='text/xsl'";
			xmlTextWriter.WriteProcessingInstruction("xml-stylesheet", stylesheet);
			xmlTextWriter.WriteComment(" re-saved from NCover by NCoverExplorer url=http://www.kiwidude.com/blog/ ");

			// Now walk the coverage tree outputting the necessary nodes xml.
			_WriteCoverageTreeNode(xmlTextWriter, coverageFileTreeNode);

			xmlTextWriter.WriteEndDocument();
			xmlTextWriter.Flush();
			xmlTextWriter.Close();
		}

		#endregion Public Methods

		#region Private Methods
		
		/// <summary>
		/// Writes the node contents out to an xml stream.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		private void _WriteCoverageTreeNode(XmlTextWriter xmlTextWriter, CoverageFileTreeNode coverageFileTreeNode)
		{
			xmlTextWriter.WriteStartElement("coverage");
			
			foreach (TreeNodeBase childTreeNode in coverageFileTreeNode.Nodes)
			{
				if (childTreeNode is ModuleTreeNode)
				{
					_WriteModuleTreeNode(xmlTextWriter, (ModuleTreeNode)childTreeNode);
				}
			}
			
			xmlTextWriter.WriteEndElement();
		}
		
		/// <summary>
		/// Writes the node contents out to an xml stream.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="moduleTreeNode">The module tree node.</param>
		private void _WriteModuleTreeNode(XmlTextWriter xmlTextWriter, ModuleTreeNode moduleTreeNode)
		{
			xmlTextWriter.WriteStartElement("module");

			xmlTextWriter.WriteAttributeString("name", moduleTreeNode.ModuleName);
			xmlTextWriter.WriteAttributeString("assembly", moduleTreeNode.AssemblyName);

			// Want to recurse down each child node to get at the methods and write them out to the file.
			foreach (TreeNodeBase childTreeNode in moduleTreeNode.Nodes)
			{
				_RecurseToWriteMethodNode(xmlTextWriter, childTreeNode);
			}
			
			xmlTextWriter.WriteEndElement();
		}

		/// <summary>
		/// Recurses down through the child nodes of the node finding the method nodes.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="treeNode">The tree node.</param>
		private void _RecurseToWriteMethodNode(XmlTextWriter xmlTextWriter, TreeNodeBase treeNode)
		{
			if (treeNode is MethodTreeNode && !((MethodTreeNode)treeNode).IsParentProperty)
			{
				_WriteMethodTreeNode(xmlTextWriter, (MethodTreeNode)treeNode);
			}
			else if (!treeNode.IsExcluded)
			{
				foreach (TreeNodeBase childTreeNode in treeNode.Nodes)
				{
					_RecurseToWriteMethodNode(xmlTextWriter, childTreeNode);
				}
			}
		}
		
		/// <summary>
		/// Writes the node contents out to an xml stream.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="methodTreeNode">The method tree node.</param>
		private void _WriteMethodTreeNode(XmlTextWriter xmlTextWriter, MethodTreeNode methodTreeNode)
		{
			xmlTextWriter.WriteStartElement("method");

			xmlTextWriter.WriteAttributeString("name", methodTreeNode.NodeName);
			xmlTextWriter.WriteAttributeString("class", methodTreeNode.ClassNamespace);

			// Want to recurse down each child node to get at the methods and write them out to the file.
			foreach (SequencePoint sequencePoint in methodTreeNode.SequencePoints)
			{
				_WriteSequencePoint(xmlTextWriter, sequencePoint);
			}
			
			xmlTextWriter.WriteEndElement();
		}
		
		/// <summary>
		/// Writes the sequence point contents out to an xml stream.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="sequencePoint">The sequence point.</param>
		private void _WriteSequencePoint(XmlTextWriter xmlTextWriter, SequencePoint sequencePoint)
		{
			xmlTextWriter.WriteStartElement("seqpnt");

			xmlTextWriter.WriteAttributeString("visitcount", sequencePoint.VisitCount.ToString());
			xmlTextWriter.WriteAttributeString("line", sequencePoint.StartLine.ToString());
			xmlTextWriter.WriteAttributeString("column", sequencePoint.StartColumn.ToString());
			xmlTextWriter.WriteAttributeString("endline", sequencePoint.EndLine.ToString());
			xmlTextWriter.WriteAttributeString("endcolumn", sequencePoint.EndColumn.ToString());
			if (sequencePoint.HasExcludedAttribute)
			{
				// Note that this will always be false as any excluded nodes have been moved to the exclusions 
				// bin and not written out to the file.
				xmlTextWriter.WriteAttributeString("excluded", sequencePoint.IsExcluded.ToString().ToLower());
			}
			xmlTextWriter.WriteAttributeString("document", sequencePoint.FileName);
			
			xmlTextWriter.WriteEndElement();
		}

		#endregion Private Methods
	}
}
