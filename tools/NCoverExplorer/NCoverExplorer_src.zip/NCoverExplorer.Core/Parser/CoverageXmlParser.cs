using System.Collections;
using System.IO;
using System.Xml;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Parser
{
	/// <summary>
	/// Load a coverage xml file into a hierarchy of nodes in preparation for display in a CoverageTreeView control.
	/// </summary>
	public class CoverageXmlParser
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private IDictionary _methodTreeNodeCache;

		private ModuleTreeNode _lastModuleTreeNode;
		private string _lastAssemblyName;

		private bool _groupByModule;
		private bool _flattenNamespaces;
		private bool _isMergingCoverageFiles;

		private string _lastClassNamespace = null;
		private string _lastPropertyName = null;
		private bool _lastPropertyWasGetter = false;
		private MethodTreeNode _lastParentPropertyNode = null;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageXmlParser"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		public CoverageXmlParser(IExplorerConfiguration configuration)
		{
			_configuration = configuration;
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Loads the coverage file and buids a result tree.
		/// </summary>
		/// <param name="fileName">Name of the coverage xml file.</param>
		/// <returns>Rot node of the parsed file.</returns>
		public CoverageFileTreeNode LoadFile(string fileName)
		{
			if (!Path.IsPathRooted(fileName))
			{
				fileName = Path.GetFullPath(fileName);
			}
			if (!File.Exists(fileName))
			{
				string errorMessage = "The following file cannot be loaded because it doesn't exist:\n\n" + fileName;
				throw new FileNotFoundException(errorMessage, fileName);
			}
			else
			{
				_methodTreeNodeCache = new Hashtable();
				CoverageFileTreeNode coverageFileTreeNode = new CoverageFileTreeNode(_configuration, fileName);

				// Optimise performance by grabbing these configuration options into variables
				_groupByModule = _configuration.GroupByModule;
				_flattenNamespaces = _configuration.FlattenNamespaces;
				_isMergingCoverageFiles = false;

				_LoadAndParseCoverageFile(coverageFileTreeNode, fileName);

				return coverageFileTreeNode;
			}
		}

		/// <summary>
		/// Merges the coverage file into this coverage tree node.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="fileName">Name of the file.</param>
		public void MergeFile(CoverageFileTreeNode coverageFileTreeNode, string fileName)
		{
			if (!Path.IsPathRooted(fileName))
			{
				fileName = Path.GetFullPath(fileName);
			}
			if (!File.Exists(fileName))
			{
				string errorMessage = "The following file cannot be merged because it doesn't exist:\n\n" + fileName;
				throw new FileNotFoundException(errorMessage, fileName);
			}
			else
			{
				_isMergingCoverageFiles = true;
				_LoadAndParseCoverageFile(coverageFileTreeNode, fileName);
			}
		}

		#endregion Public Methods

		#region Private Methods

		#region _LoadAndParseCoverageFile

		/// <summary>
		/// Merges the coverage file into this coverage tree node.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="fileName">Name of the file.</param>
		private void _LoadAndParseCoverageFile(CoverageFileTreeNode coverageFileTreeNode, string fileName)
		{
			_lastModuleTreeNode = null;
			_lastAssemblyName = string.Empty;

			using (StreamReader sr = new StreamReader(fileName))
			{
				XmlTextReader reader = new XmlTextReader(sr);
				reader.MoveToContent();
				reader.Read();
				string moduleName = null;

				while (!reader.EOF)
				{
					if (reader.NodeType == XmlNodeType.Element)
					{
						switch (reader.Name)
						{
							case "module":
								moduleName = _ParseModuleXmlNode(coverageFileTreeNode, reader);
								break;
							case "method":
								_ParseMethodXmlNode(coverageFileTreeNode, reader, moduleName);
								break;
							default:
								reader.Read();
								break;
						}
					}
					else
					{
						reader.Read();
					}
				}
				reader.Close();
			}
		}

		#endregion _LoadAndParseCoverageFile

		#region _ParseModuleXmlNode

		/// <summary>
		/// Parses the module node in the xml. We may be grouping by module in which case need to add a new node to the tree.
		/// </summary>
		/// <param name="coverageFileTreeNode">The root coverage node.</param>
		/// <param name="reader">The reader.</param>
		/// <returns>The name of the module</returns>
		private string _ParseModuleXmlNode(CoverageFileTreeNode coverageFileTreeNode, XmlTextReader reader)
		{
			string moduleName = reader.GetAttribute("name");
			string assemblyName = reader.GetAttribute("assembly");
			// Bugfix for NCover sometimes dumping out invalid modules with an empty assembly name.
			if (assemblyName.Length == 0)
			{
				assemblyName = Path.GetFileNameWithoutExtension(moduleName);
			}
			reader.Read();

			if (assemblyName != _lastAssemblyName)
			{
				// We are parsing a different assembly/module
				_lastAssemblyName = assemblyName;
				if (_groupByModule)
				{
					// We may need to add a new module node for the child nodes to sit within.
					// If we are doing a merge we first need to check for an existing module with this name
					ModuleTreeNode moduleTreeNode = null;
					foreach (TreeNodeBase childModuleNode in coverageFileTreeNode.Nodes)
					{
						if (childModuleNode is ModuleTreeNode) // Might otherwise be the excluded bin
						{
							if (((ModuleTreeNode)childModuleNode).AssemblyName == _lastAssemblyName)
							{
								moduleTreeNode = (ModuleTreeNode)childModuleNode;
								break;
							}
						}
						else if (_isMergingCoverageFiles && childModuleNode is ExcludedTreeNode)
						{
							foreach (ModuleTreeNode excludedModuleNode in childModuleNode.Nodes)
							{
								if (excludedModuleNode.AssemblyName == _lastAssemblyName)
								{
									moduleTreeNode = excludedModuleNode;
									break;
								}
							}
						}
					}

					if (moduleTreeNode == null)
					{
						moduleTreeNode = new ModuleTreeNode(_configuration, moduleName, assemblyName);
						coverageFileTreeNode.Nodes.Add(moduleTreeNode);
					}
					_lastModuleTreeNode = moduleTreeNode;
				}
			}
			else if (_groupByModule)
			{
				_lastModuleTreeNode.AssemblyName = assemblyName;
			}
			return _lastAssemblyName;
		}

		#endregion _ParseModuleXmlNode

		#region _ParseMethodXmlNode

		/// <summary>
		/// Recursively creates a method tree node for this xml element.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree root node.</param>
		/// <param name="reader">The xml reader.</param>
		/// <param name="moduleName">Name of the module.</param>
		private void _ParseMethodXmlNode(CoverageFileTreeNode coverageFileTreeNode, XmlTextReader reader, 
		                                 string moduleName)
		{
			string[] methodNameWords = reader.GetAttribute("name").Split('.');
			// Perform this substitution here so the tree is sorted correctly with
			// constructors at the top.
			string methodName = methodNameWords[methodNameWords.Length - 1];
			if (methodName == "ctor")
			{
				methodName = ".ctor";
			}
			else if (methodName == "cctor")
			{
				methodName = ".cctor";
			}

			string classNamespace = reader.GetAttribute("class");
			if (classNamespace != _lastClassNamespace)
			{
				// On a different class so reset the memory of the last property processed used later on below
				// for handling overloaded indexed properties.
				_lastPropertyName = null;
			}
			_lastClassNamespace = classNamespace;

			string[] classNamespaceWords = classNamespace.Split('.');
			TreeNodeBase searchRootElement = _groupByModule ? _lastModuleTreeNode : (TreeNodeBase)coverageFileTreeNode;

			// Create or find the top-level namespace node.
			TreeNodeBase namespaceNode;
			if (_flattenNamespaces)
			{
				namespaceNode = _GetNamespaceNodeFlattened(searchRootElement, classNamespaceWords, classNamespace);
			}
			else
			{
				namespaceNode = _GetNamespaceNodeUsingNesting(searchRootElement, classNamespaceWords);
			}

			// Find or create the class node.
			ClassTreeNode classTreeNode = _GetClassNodeCheckingForNesting(namespaceNode, classNamespaceWords, classNamespace);

			// Create a node for the method/top-level property if required.
			_AddMethodTreeNodeWithSequencePoints(moduleName, methodName, classTreeNode, reader);
		}

		#endregion _ParseMethodXmlNode

		#region _GetNamespaceNodeUsingNesting

		/// <summary>
		/// In this approach, the namespace nodes are created as a tree for each component
		/// of their name ie.
		/// +NCoverExplorer
		///   +Core
		///     +Presentation
		/// </summary>
		/// <param name="searchRootElement">The search root element.</param>
		/// <param name="classNamespaceWords">The class namespace words.</param>
		/// <returns>The parent namespace node the class will be stored under.</returns>
		private TreeNodeBase _GetNamespaceNodeUsingNesting(TreeNodeBase searchRootElement, string[] classNamespaceWords)
		{
			string fullyQualifiedNamespace = "";
			TreeNodeBase namespaceNode = null;

			if (classNamespaceWords.Length == 1)
			{
				// This is a class without a namespace - place it under a "-" element
				fullyQualifiedNamespace = "-";
			}
			else
			{
				fullyQualifiedNamespace = classNamespaceWords[0];
				if (fullyQualifiedNamespace.IndexOf('+') > 0)
				{
					fullyQualifiedNamespace = fullyQualifiedNamespace.Split('+')[0];
				}
			}

			foreach (TreeNodeBase existingNamespaceNode in searchRootElement.Nodes)
			{
				if (existingNamespaceNode.NodeName == fullyQualifiedNamespace)
				{
					namespaceNode = existingNamespaceNode;
					break;
				}
				else if (_isMergingCoverageFiles && existingNamespaceNode is ExcludedTreeNode)
				{
					foreach (TreeNodeBase excludedNamespaceNode in existingNamespaceNode.Nodes)
					{
						if (excludedNamespaceNode.NodeName == fullyQualifiedNamespace)
						{
							namespaceNode = excludedNamespaceNode;
							break;
						}
					}
				}
			}
			if (namespaceNode == null)
			{
				if (classNamespaceWords.Length == 1)
				{
					// This is a class without a namespace so creating a root node of "-"
					namespaceNode = new NamespaceTreeNode(_configuration, fullyQualifiedNamespace, fullyQualifiedNamespace);
				}
				else
				{
					namespaceNode = new NamespaceTreeNode(_configuration, classNamespaceWords[0], fullyQualifiedNamespace);
				}
				searchRootElement.Nodes.Add(namespaceNode);
			}
	
			// If namespace has more then one level recurse through creating/finding namespace nodes.
			if (classNamespaceWords.Length > 1)
			{
				for (int wordIndex = 1; wordIndex < (classNamespaceWords.Length - 1); wordIndex++)
				{
					fullyQualifiedNamespace += "." + classNamespaceWords[wordIndex];
					TreeNodeBase childNamespaceNode = null;
					foreach (TreeNodeBase existingChildNamespaceNode in namespaceNode.Nodes)
					{
						if (existingChildNamespaceNode.NodeName == classNamespaceWords[wordIndex])
						{
							childNamespaceNode = existingChildNamespaceNode;
							break;
						}
						else if (_isMergingCoverageFiles && existingChildNamespaceNode is ExcludedTreeNode)
						{
							foreach (TreeNodeBase excludedChildNamespaceNode in existingChildNamespaceNode.Nodes)
							{
								if (excludedChildNamespaceNode.NodeName == classNamespaceWords[wordIndex])
								{
									childNamespaceNode = excludedChildNamespaceNode;
									break;
								}
							}
						}
					}
					if (childNamespaceNode == null)
					{
						TreeNodeBase namespaceTreeNode = new NamespaceTreeNode(_configuration, classNamespaceWords[wordIndex], fullyQualifiedNamespace);
						namespaceNode.Nodes.Add(namespaceTreeNode);
						namespaceNode = namespaceTreeNode;
					}
					else
					{
						namespaceNode = childNamespaceNode;
					}
				}
			}
			return namespaceNode;
		}

		#endregion _GetNamespaceNodeUsingNesting

		#region _GetNamespaceNodeFlattened

		/// <summary>
		/// In this approach, the namespace nodes are created as a single child node for each namespace
		/// under a single parent. ie.
		/// +NCoverExplorer
		/// +NCoverExplorer.Core
		/// +NCoverExplorer.Core.Presentation
		/// </summary>
		/// <param name="searchRootElement">The search root element.</param>
		/// <param name="classNamespaceWords">The class namespace words.</param>
		/// <param name="classNamespace">The class namespace.</param>
		/// <returns>The parent namespace node the class will be stored under.</returns>
		private TreeNodeBase _GetNamespaceNodeFlattened(TreeNodeBase searchRootElement, string[] classNamespaceWords, string classNamespace)
		{
			string namespaceWithoutClassName = "";
			if (classNamespaceWords.Length == 1)
			{
				// This is a class without a namespace - place it under a "-" root element
				namespaceWithoutClassName = "-";
			}
			else
			{
				namespaceWithoutClassName = classNamespace.Substring(
					0, classNamespace.Length - classNamespaceWords[classNamespaceWords.Length - 1].Length -1);
			}

			TreeNodeBase namespaceNode = null;
			foreach (TreeNodeBase existingNamespaceNode in searchRootElement.Nodes)
			{
				if (existingNamespaceNode.NodeName == namespaceWithoutClassName)
				{
					namespaceNode = existingNamespaceNode;
					break;
				}
				else if (_isMergingCoverageFiles && existingNamespaceNode is ExcludedTreeNode)
				{
					foreach (TreeNodeBase excludedNamespaceNode in existingNamespaceNode.Nodes)
					{
						if (excludedNamespaceNode.NodeName == namespaceWithoutClassName)
						{
							namespaceNode = excludedNamespaceNode;
							break;
						}
					}
				}
			}
			if (namespaceNode == null)
			{
				TreeNodeBase namespaceTreeNode = new NamespaceTreeNode(_configuration, namespaceWithoutClassName, namespaceWithoutClassName);
				searchRootElement.Nodes.Add(namespaceTreeNode);
				namespaceNode = namespaceTreeNode;
			}
			return namespaceNode;
		}

		#endregion _GetNamespaceNodeFlattened

		#region _GetClassNodeCheckingForNesting

		/// <summary>
		/// Finds or creates the class tree node that the method will be nested under. If it detectes this is a nested
		/// class then it recurses down through the nesting tree.
		/// </summary>
		/// <param name="namespaceNode">The namespace node.</param>
		/// <param name="classNamespaceWords">The class namespace words.</param>
		/// <param name="classNamespace">The class namespace.</param>
		/// <returns>Class tree node.</returns>
		private ClassTreeNode _GetClassNodeCheckingForNesting(TreeNodeBase namespaceNode, string[] classNamespaceWords, string classNamespace)
		{
			ClassTreeNode classTreeNode = null;
			string className = classNamespaceWords[classNamespaceWords.Length - 1];
			if (className.IndexOf('+') > 0)
			{
				// This is an inner nested class. Let's figure out the class name and use that
				string[] nestedClassNames = className.Split('+');
				TreeNodeBase parentNode = namespaceNode;
				if (classNamespaceWords.Length == 1)
				{
					// This is a nested class of a class without a namespace.
					classNamespace = "";
				}
				else
				{
					// Strip off all the trailing concatenated class names
					classNamespace = classNamespace.Substring(0, classNamespace.Length - className.Length - 1);
				}
				for (int index = 0; index < nestedClassNames.Length; index++)
				{
					// Put it back together again using + so that we preserve things correctly if user chooses to Save.
					// We will do a string replacement in the GUI events for displaying in the status bar.
					if (classNamespace.Length == 0)
					{
						classNamespace = nestedClassNames[index];
					}
					else
					{
						classNamespace += "+" + nestedClassNames[index];
					}
					classTreeNode = _GetClassNodeForMethod(parentNode, nestedClassNames[index], classNamespace, true);
					parentNode = classTreeNode;
				}
				return classTreeNode;
			}
			else
			{
				return _GetClassNodeForMethod(namespaceNode, className, classNamespace, false);
			}
		}

		#endregion _GetClassNodeCheckingForNesting

		#region _GetClassNodeForMethod

		/// <summary>
		/// Finds or creates the class tree node that the method will be nested under.
		/// </summary>
		/// <param name="parentNode">The parent node node.</param>
		/// <param name="className">Name of the class.</param>
		/// <param name="classNamespace">The class namespace.</param>
		/// <param name="isNested">if set to <c>true</c> is a nested.</param>
		/// <returns>Class tree node.</returns>
		private ClassTreeNode _GetClassNodeForMethod(TreeNodeBase parentNode, string className, string classNamespace, bool isNested)
		{
			ClassTreeNode classTreeNode = null;
			foreach (TreeNodeBase existingClassTreeNode in parentNode.Nodes)
			{
				if (existingClassTreeNode.NodeName == className)
				{
					classTreeNode = (ClassTreeNode)existingClassTreeNode;
					break;
				}
				else if (_isMergingCoverageFiles && existingClassTreeNode is ExcludedTreeNode)
				{
					foreach (TreeNodeBase excludedClassTreeNode in existingClassTreeNode.Nodes)
					{
						if (excludedClassTreeNode.NodeName == className)
						{
							classTreeNode = (ClassTreeNode)excludedClassTreeNode;
							break;
						}
					}
				}
			}
			if (classTreeNode == null)
			{
				if (isNested)
				{
					// Make sure that we prefix the class name so it is sorted correctly in the tree.
					classTreeNode = new ClassTreeNode(_configuration, className, classNamespace, true);
				}
				else
				{
					// Add it as a normal class.
					classTreeNode = new ClassTreeNode(_configuration, className, classNamespace);
				}
				parentNode.Nodes.Add(classTreeNode);
			}
			return classTreeNode;
		}

		#endregion _GetClassNodeForMethod

		#region _AddMethodTreeNodeWithSequencePoints
		
		/// <summary>
		/// Adds the method tree node and reads the sequence points.
		/// </summary>
		/// <param name="moduleName">Name of the module.</param>
		/// <param name="methodName">Name of the method.</param>
		/// <param name="classTreeNode">The class tree node.</param>
		/// <param name="reader">The reader.</param>
		private void _AddMethodTreeNodeWithSequencePoints(string moduleName, string methodName, ClassTreeNode classTreeNode, 
			XmlTextReader reader)
		{
			MethodTreeNode propertyTreeNode = null;
			string propertyName = null;
			bool needToAddParentProperty = false;
			bool needToAddMethod = false;
			bool isNestedProperty = false;
			bool isNewProperty = false;

			SequencePointCollection sequencePoints = _ReadSequencePoints(methodName, reader);
	
			string key = sequencePoints.FirstLineNumber + methodName + classTreeNode.FullyQualifiedName + methodName + moduleName;
			MethodTreeNode methodTreeNode = (MethodTreeNode)_methodTreeNodeCache[key];
	
			if (methodTreeNode == null)
			{
				needToAddMethod = true;
				if (methodName.StartsWith("get_") || methodName.StartsWith("set_"))
				{
					isNestedProperty = true;
					bool isGetter = methodName.StartsWith("get_");
					propertyName = methodName.Substring(4);
					if (classTreeNode.PropertyNodes.ContainsKey(key))
					{
						// We have seen this property before at this line number so we are doing a merge operation
						needToAddParentProperty = false;
						propertyTreeNode = (MethodTreeNode)classTreeNode.PropertyNodes[key];
						// We know we have the parent - see if we already have the nested method (i.e. merging seqpts)
						foreach (MethodTreeNode existingChildMethodNode in propertyTreeNode.Nodes)
						{
							if (existingChildMethodNode.NodeName == methodName)
							{
								needToAddMethod = false;
								methodTreeNode = existingChildMethodNode;
								break;
							}
						}
					}
					else if (propertyName != _lastPropertyName)
					{
						// Since this is a get or set for a different property name lets add a new node to the tree.
						needToAddParentProperty = true;
					}
					else if ((isGetter && _lastPropertyWasGetter) || (!isGetter && !_lastPropertyWasGetter))
					{
						// This is the same type of operation (get/set) as last processed.
						// Must be an overload of the this[] method
						needToAddParentProperty = true;
					}
					else
					{
						// We know it is the same property name as last processed but a different type of get/set
						// Need to identify whether it is for the same parent property that we last processed or
						// for a new parent property node.
						// Default assumption is that this is the opposite getter/setter for the same property.
						needToAddParentProperty = false;
						propertyTreeNode = _lastParentPropertyNode;
						foreach (MethodTreeNode existingChildMethodNode in propertyTreeNode.Nodes)
						{
							if (existingChildMethodNode.NodeName == methodName)
							{
								// We already have a matching getter or setter for this method
								// Are we merging into this or need to create a new property?
								if (existingChildMethodNode.FirstCodeLineNumber == sequencePoints.FirstLineNumber)
								{
									// Merging
									needToAddMethod = false;
									methodTreeNode = existingChildMethodNode;
									break;
								}
								else
								{
									// Already have a get/set on this but with different line number so must be overload.
									needToAddParentProperty = true;
									break;
								}
							}
						}
					}
					// Ensure we are set for the next node we process around the loop
					_lastPropertyWasGetter = isGetter;
					_lastPropertyName = propertyName;
				}
				if (needToAddParentProperty)
				{
					// Never seen it before so genuinely creating for the first time.
					propertyTreeNode = new MethodTreeNode(_configuration, propertyName, classTreeNode.FullyQualifiedName);
					propertyTreeNode.IsParentProperty = true;
					isNewProperty = true;
					_lastParentPropertyNode = propertyTreeNode;
				}
				if (needToAddMethod)
				{
					methodTreeNode = new MethodTreeNode(_configuration, methodName, classTreeNode.FullyQualifiedName);
				}
			}
			else if (_isMergingCoverageFiles && methodTreeNode.OriginalSortName != methodName)
			{
				throw new MergeCoverageException("Different source code between coverage files means these cannot be merged.");
			}
	
			methodTreeNode.PopulateSequencePoints(sequencePoints);
	
			if (methodTreeNode.SequencePoints.Count > 0)
			{
				if (needToAddMethod)
				{
					if (isNestedProperty)
					{
						if (isNewProperty)
						{
							classTreeNode.Nodes.Add(propertyTreeNode);
							// Store it in the hashtable under the key of the first getter/setter found for the method.
							classTreeNode.PropertyNodes[key] = propertyTreeNode;
						}
						methodTreeNode.IsNestedProperty = true;
						propertyTreeNode.Nodes.Add(methodTreeNode);
					}
					else
					{
						classTreeNode.Nodes.Add(methodTreeNode);
					}
					_methodTreeNodeCache[key] = methodTreeNode;
				}
			}
		}

		#endregion _AddMethodTreeNodeWithSequencePoints

		#region _ReadSequencePoints

		/// <summary>
		/// Populates a sequence points collection for this method node from the xml file.
		/// </summary>
		/// <param name="nodeName">Name of the node.</param>
		/// <param name="reader">The xml reader.</param>
		/// <returns></returns>
		private SequencePointCollection _ReadSequencePoints(string nodeName, XmlTextReader reader)
		{
			SequencePointCollection sequencePoints = new SequencePointCollection();
			SequencePoint sequencePoint = null;

			while (reader.Read())
			{
				if (reader.NodeType == XmlNodeType.Element)
				{
					if (reader.Name.Equals("seqpnt"))
					{
						sequencePoint = new SequencePoint(nodeName, reader);
						if (!sequencePoint.IsGarbageRow)
						{
							sequencePoints.Add(sequencePoint);
						}
					}
					else
					{
						break;
					}
				}
			}

			return sequencePoints;
		}

		#endregion _ReadSequencePoints

		#endregion Private Methods
	}
}
