using System;

namespace NCoverExplorer.Core.Parser
{
	/// <summary>
	/// Exception thrown when a problem occurs while trying to merge coverage files.
	/// </summary>
	public class MergeCoverageException : Exception
	{
		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="MergeCoverageException"/> class.
		/// </summary>
		public MergeCoverageException()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MergeCoverageException"/> class.
		/// </summary>
		/// <param name="message">The message.</param>
		public MergeCoverageException(string message) : base(message)
		{
		}

		#endregion Constructors
	}
}
