
namespace NCoverExplorer.Core.Visitors
{
	/// <summary>
	/// Interface for accepting a visitor.
	/// </summary>
	public interface IVisitableNode
	{		
		/// <summary>
		/// Accept the visitor.
		/// </summary>
		/// <param name="visitor">The visitor to accept.</param>
		/// <returns>The value the visitor returns after the visit.</returns>
		void AcceptVisitor(ITreeNodeVisitor visitor);
	}
}
