using System;
using System.Collections;
using System.Reflection;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Visitors
{
	/// <summary>
	/// Summary description for TreeNodeVisitorBase.
	/// </summary>
	public abstract class TreeNodeVisitorBase : ITreeNodeVisitor
	{
		#region Private Variables

		private MethodInfo _lastmethod = null;
		private object _lastvisitable = null;
		private Hashtable _cachedMethodInfos;

		#endregion Private Variables

		#region Constructor
		
		/// <summary>
		/// Initializes a new instance of the <see cref="TreeNodeVisitorBase"/> class.
		/// </summary>
		protected TreeNodeVisitorBase()
		{
			MethodInfo[] methodInfos = this.GetType().GetMethods(BindingFlags.Public | BindingFlags.Instance);
			_cachedMethodInfos = new Hashtable();
			foreach (MethodInfo methodInfo in methodInfos)
			{
				if (methodInfo.Name == "Visit")
				{
					_cachedMethodInfos.Add(methodInfo.GetParameters()[0].ParameterType, methodInfo);
				}
			}
		}

		#endregion Constructor

		#region ITreeNodeVisitor Members

		/// <summary>
		/// Use reflection to see if the Visitor has a method
		/// named Visit with the appropriate parameter type
		/// (i.e. a specific tree node type such as ClassTreeNode). If so, invoke it.
		/// </summary>
		/// <param name="visitableNode">The visitable node.</param>
		public void Visit(IVisitableNode visitableNode)
		{
			try
			{
				MethodInfo method = (MethodInfo)_cachedMethodInfos[visitableNode.GetType()];
				if (method != null)
					// Avoid StackOverflow exceptions by executing only if the method and visitable  
					// are different from the last parameters used.
					if (method != _lastmethod || visitableNode != _lastvisitable)
					{
						_lastmethod = method;
						_lastvisitable = visitableNode;
						method.Invoke(this, new object[] { visitableNode });
					}
			}
			catch (Exception ex)
			{
				if (ex.InnerException != null)
					throw ex.InnerException;
				throw ex;
			}
		}

		/// <summary>
		/// Visits the specified coverage file tree node.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		public virtual void Visit(CoverageFileTreeNode coverageFileTreeNode)
		{
			foreach (TreeNodeBase treeNodeBase in coverageFileTreeNode.Nodes)
			{
				treeNodeBase.AcceptVisitor(this);
			}
		}

		/// <summary>
		/// Visits the specified module tree node.
		/// </summary>
		/// <param name="moduleTreeNode">The module tree node.</param>
		public virtual void Visit(ModuleTreeNode moduleTreeNode)
		{
			foreach (TreeNodeBase treeNodeBase in moduleTreeNode.Nodes)
			{
				treeNodeBase.AcceptVisitor(this);
			}
		}

		/// <summary>
		/// Visits the specified namespace tree node.
		/// </summary>
		/// <param name="namespaceTreeNode">The namespace tree node.</param>
		public virtual void Visit(NamespaceTreeNode namespaceTreeNode)
		{
			foreach (TreeNodeBase treeNodeBase in namespaceTreeNode.Nodes)
			{
				treeNodeBase.AcceptVisitor(this);
			}
		}

		/// <summary>
		/// Visits the specified class tree node.
		/// </summary>
		/// <param name="classTreeNode">The class tree node.</param>
		public virtual void Visit(ClassTreeNode classTreeNode)
		{
			foreach (TreeNodeBase treeNodeBase in classTreeNode.Nodes)
			{
				treeNodeBase.AcceptVisitor(this);
			}
		}

		/// <summary>
		/// Visits the specified method tree node.
		/// </summary>
		/// <param name="methodTreeNode">The method tree node.</param>
		public virtual void Visit(MethodTreeNode methodTreeNode)
		{
			if (methodTreeNode.IsParentProperty)
			{
				foreach (TreeNodeBase treeNodeBase in methodTreeNode.Nodes)
				{
					treeNodeBase.AcceptVisitor(this);
				}
			}
		}

		/// <summary>
		/// Visits the specified excluded tree node.
		/// </summary>
		/// <param name="excludedTreeNode">The excluded tree node.</param>
		public virtual void Visit(ExcludedTreeNode excludedTreeNode)
		{
			foreach (TreeNodeBase treeNodeBase in excludedTreeNode.Nodes)
			{
				treeNodeBase.AcceptVisitor(this);
			}
		}

		/// <summary>
		/// Visits the specified filtered tree node.
		/// </summary>
		/// <param name="filteredTreeNode">The filtered tree node.</param>
		public virtual void Visit(FilteredTreeNode filteredTreeNode)
		{
			foreach (TreeNodeBase treeNodeBase in filteredTreeNode.Nodes)
			{
				treeNodeBase.AcceptVisitor(this);
			}
		}

		#endregion ITreeNodeVisitor Members
	}
}
