using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Reporting;
using NCoverExplorer.Core.Visitors;

namespace NCoverExplorer.Core.Visitors
{
	/// <summary>
	/// Visitor responsible for recursing into an Excluded tree node to iterate across its immediate children only
	/// and gather information on their names and types.
	/// </summary>
	public class ExcludedTreeNodeVisitor : TreeNodeVisitorBase
	{
		#region Private Variables

		private ExcludedNodesSummary _excludedNodesSummary;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ExcludedTreeNodeVisitor"/> class.
		/// </summary>
		public ExcludedTreeNodeVisitor()
		{
			_excludedNodesSummary = new ExcludedNodesSummary();
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the excluded nodes summary.
		/// </summary>
		/// <value>The excluded nodes summary.</value>
		public ExcludedNodesSummary ExcludedNodesSummary
		{
			get { return _excludedNodesSummary; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Visits the specified module tree node.
		/// </summary>
		/// <param name="moduleTreeNode">The module tree node.</param>
		public override void Visit(ModuleTreeNode moduleTreeNode)
		{
			if (moduleTreeNode.IsExcluded)
			{
				_excludedNodesSummary.ExcludedModules.Add(moduleTreeNode.AssemblyPathWithExtension);
			}
			else
			{
				base.Visit(moduleTreeNode);
			}
		}

		/// <summary>
		/// Visits the specified namespace tree node.
		/// </summary>
		/// <param name="namespaceTreeNode">The namespace tree node.</param>
		public override void Visit(NamespaceTreeNode namespaceTreeNode)
		{
			if (namespaceTreeNode.IsExcluded)
			{
				_excludedNodesSummary.ExcludedNamespaces.Add(namespaceTreeNode.FullyQualifiedName);
			}
			else
			{
				base.Visit(namespaceTreeNode);
			}
		}

		/// <summary>
		/// Visits the specified class tree node.
		/// </summary>
		/// <param name="classTreeNode">The class tree node.</param>
		public override void Visit(ClassTreeNode classTreeNode)
		{
			if (classTreeNode.IsExcluded)
			{
				_excludedNodesSummary.ExcludedClasses.Add(classTreeNode.FullyQualifiedName);
			}
			else
			{
				base.Visit(classTreeNode);
			}
		}

		/// <summary>
		/// Visits the specified method tree node.
		/// </summary>
		/// <param name="methodTreeNode">The method tree node.</param>
		public override void Visit(MethodTreeNode methodTreeNode)
		{
			if (methodTreeNode.IsExcluded)
			{
				_excludedNodesSummary.ExcludedMethods.Add(methodTreeNode.FullyQualifiedName);
			}
		}

		#endregion Public Methods
	}
}
