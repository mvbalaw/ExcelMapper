
namespace NCoverExplorer.Core.Visitors
{
	/// <summary>
	/// Interface for all visitors to implement.
	/// </summary>
	public interface ITreeNodeVisitor
	{
		/// <summary>
		/// Use reflection to see if the Visitor has a method 
		/// named Visit with the appropriate parameter type 
		/// (i.e. a specific tree node type such as ClassTreeNode). If so, invoke it.
		/// </summary>
		/// <param name="visitableNode">The visitable node.</param>
		void Visit(IVisitableNode visitableNode);
	}
}
