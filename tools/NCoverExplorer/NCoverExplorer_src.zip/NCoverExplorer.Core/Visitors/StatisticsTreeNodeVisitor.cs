using System.Collections.Specialized;

using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Statistics;
using NCoverExplorer.Core.Visitors;

namespace NCoverExplorer.Core.Visitors
{
	/// <summary>
	/// Visitor responsible for calculating code metric statistics for the loaded coverage tree.
	/// </summary>
	public class StatisticsTreeNodeVisitor : TreeNodeVisitorBase
	{
		#region Private Variables

		private StatisticsSummary _statisticsSummary;
		private StringCollection _fileNames;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsTreeNodeVisitor"/> class.
		/// </summary>
		public StatisticsTreeNodeVisitor()
		{
			_statisticsSummary = new StatisticsSummary();
			_fileNames = new StringCollection();
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the statistics summary.
		/// </summary>
		/// <value>The statistics summary.</value>
		public StatisticsSummary StatisticsSummary
		{
			get { return _statisticsSummary; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Visits the specified coverage file tree node.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		public override void Visit(CoverageFileTreeNode coverageFileTreeNode)
		{
			_statisticsSummary.ProjectName = coverageFileTreeNode.Configuration.ProjectName;
			_statisticsSummary.NumberOfSequencePoints = coverageFileTreeNode.TotalSequencePoints;
			_statisticsSummary.NumberOfUnvisitedSequencePoints = coverageFileTreeNode.UnvisitedSequencePoints;
			_statisticsSummary.CoveragePercentage = coverageFileTreeNode.CoveragePercentage;
			_statisticsSummary.AcceptablePercentage = coverageFileTreeNode.Configuration.SatisfactoryCoverageThreshold;

			base.Visit(coverageFileTreeNode);
		}

		/// <summary>
		/// Visits the specified class tree node.
		/// </summary>
		/// <param name="classTreeNode">The class tree node.</param>
		public override void Visit(ClassTreeNode classTreeNode)
		{
			_statisticsSummary.NumberOfClasses++;

			base.Visit(classTreeNode);
		}

		/// <summary>
		/// Visits the specified method tree node.
		/// </summary>
		/// <param name="methodTreeNode">The method tree node.</param>
		public override void Visit(MethodTreeNode methodTreeNode)
		{
			if (!methodTreeNode.IsParentProperty)
			{
				_statisticsSummary.NumberOfMembers++;
				int lastLine = 0;
				foreach (SequencePoint sequencePoint in methodTreeNode.SequencePoints)
				{
					if (!_fileNames.Contains(sequencePoint.FileName))
					{
						_statisticsSummary.NumberOfFiles++;
						_fileNames.Add(sequencePoint.FileName);
					}
					if (sequencePoint.StartLine != lastLine)
					{
						_statisticsSummary.NumberOfNonCommentLines += sequencePoint.EndLine - sequencePoint.StartLine + 1;
						lastLine = sequencePoint.EndLine;
					}
				}
			}

			base.Visit(methodTreeNode);
		}

		/// <summary>
		/// Visits the specified excluded tree node.
		/// </summary>
		/// <param name="excludedTreeNode">The excluded tree node.</param>
		public override void Visit(ExcludedTreeNode excludedTreeNode)
		{
			// Do nothing as excluded nodes are not included in statistics
			// Do not call the base method as do not want to recurse into the children.
		}

		#endregion Public Methods
	}
}
