using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Parser;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Controller class for the MainForm GUI form.
	/// </summary>
	public class MainFormController
	{
		#region Events

		/// <summary>
		/// Event raised when a coverage file has been loaded into the application.
		/// </summary>
		public event CoverageFilesEventHandler CoverageFileLoaded;
		/// <summary>
		/// Event raised when an attempt to load a coverage file failed.
		/// </summary>
		public event CoverageFileLoadFailedEventHandler CoverageFileLoadFailed;
		/// <summary>
		/// Event raised when a coverage file has been saved.
		/// </summary>
		public event CoverageFilesEventHandler CoverageFileSaved;
		/// <summary>
		/// Event raised when the configuration options have been changed.
		/// </summary>
		public event ConfigurationChangedEventHandler ConfigurationChanged;
		/// <summary>
		/// Event raised when the coverage file is closed.
		/// </summary>
		public event EventHandler CoverageFileClosed;

		#endregion Events

		#region Private Constants

		private const string FAQFileName = "NCoverExplorerFAQ.html";
		private const string ReleaseNotesFileName = "NCoverExplorerReleaseNotes.html";
		private const string NCoverExplorerWebSite = "http://www.kiwidude.com/dotnet/";
		private const string NCoverExplorerHomePage = "http://ncoverexplorer.org/";
		private const string NCoverExplorerBlogUrl = "http://www.kiwidude.com/blog/";
		private const string NCoverExplorerDonationUrl = "http://www.kiwidude.com/blog/PaypalPaymentPage.html";

		#endregion Private Constants

		#region Private Variables

		private IExplorerConfiguration _configuration;
		private CoverageFileTreeNode _coverageFileTreeNode;
		private CoverageXmlParser _coverageXmlParser;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MainFormController"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		public MainFormController(IExplorerConfiguration configuration)
		{
			_configuration = configuration;
			_coverageXmlParser = new CoverageXmlParser(_configuration);
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets a value indicating whether a coverage xml file is currently loaded.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has a coverage file loaded; otherwise, <c>false</c>.
		/// </value>
		public bool IsCoverageFileLoaded
		{
			get { return _coverageFileTreeNode != null; }
		}

		/// <summary>
		/// Gets the names of the coverage files currently loaded.
		/// </summary>
		/// <value>The name of the coverage files.</value>
		public string[] CoverageFileNames
		{
			get 
			{
				if (_coverageFileTreeNode == null)
				{
					return new string[]{};
				}
				return _coverageFileTreeNode.CoverageFileNames; 
			}
		}

		#endregion Public Properties

		#region Public Methods

		#region Open Coverage File

		/// <summary>
		/// Ask user to select a coverage file(s) to open, and then open it.
		/// </summary>
		public void OpenCoverageXmlFile()
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog())
			{
				openFileDialog.Multiselect = true;
				openFileDialog.Title = "Open Coverage File";
				openFileDialog.Filter = "NCover Reports|*.xml";
				openFileDialog.FilterIndex = 0;

				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					LoadCoverageXmlFiles(openFileDialog.FileNames);
				}
			}
		}

		/// <summary>
		/// Opens the specified NCover coverage XML file.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		public void LoadCoverageXmlFile(string fileName)
		{
			LoadCoverageXmlFiles(new string[] { fileName });
		}

		/// <summary>
		/// Opens the specified NCover coverage XML file.
		/// </summary>
		/// <param name="fileNames">Name of the files.</param>
		public void LoadCoverageXmlFiles(string[] fileNames)
		{
			HighPerformanceTimer timer = new HighPerformanceTimer();
			string firstFileName = fileNames[0];
			try
			{
				timer.Start();
				Cursor.Current = Cursors.WaitCursor;

				// Not merging with existing coverage tree for first file - instead are completely replacing it.
				StatusPublisher.Display(string.Format("Loading file: {0} ...", firstFileName));
				CoverageFileTreeNode coverageFileTreeNode = _coverageXmlParser.LoadFile(firstFileName);
				coverageFileTreeNode.CoverageFileNames = new string[] {firstFileName};

				bool isLoadedOk = _MergeCoverageXmlFiles(coverageFileTreeNode, fileNames, 1);

				timer.Stop();
				if (isLoadedOk)
				{
					_coverageFileTreeNode = coverageFileTreeNode;
					CoverageFilesEventArgs e = new CoverageFilesEventArgs(_coverageFileTreeNode, timer.Duration, true);
					OnCoverageFilesLoaded(e);
				}
			}
			catch(Exception ex)
			{
				OnCoverageFileLoadFailed(new CoverageFileLoadFailedEventArgs(firstFileName, ex));
				StatusPublisher.DisplayException(ex);
			}
			finally
			{
				timer.Stop();
				Cursor.Current = Cursors.Default;
			}
		}

		#endregion Open Coverage File

		#region Merge Coverage File

		/// <summary>
		/// Ask user to select a coverage file(s) to open and merge into results, and then open it.
		/// </summary>
		public void MergeCoverageXmlFile()
		{
			using (OpenFileDialog openFileDialog = new OpenFileDialog())
			{
				openFileDialog.Multiselect = true;
				openFileDialog.Title = "Add & Merge Coverage File";
				openFileDialog.Filter = "NCover Reports|*.xml";
				openFileDialog.FilterIndex = 0;

				if (openFileDialog.ShowDialog() == DialogResult.OK)
				{
					MergeCoverageXmlFiles(openFileDialog.FileNames);
				}
			}
		}

		/// <summary>
		/// Merging all the files passed into the specified NCover coverage XML file.
		/// </summary>
		/// <param name="fileNames">Name of the file.</param>
		public void MergeCoverageXmlFiles(string[] fileNames)
		{
			HighPerformanceTimer timer = new HighPerformanceTimer();
			try
			{
				timer.Start();
				Cursor.Current = Cursors.WaitCursor;

				for (int index = 0; index < fileNames.Length; index++)
				{
					if (_coverageFileTreeNode.HasFileLoaded(fileNames[index]))
					{
						StatusPublisher.Display("File already loaded. Add aborted.");
						return;
					}
				}

				_coverageFileTreeNode.CollapseRecursive();

				bool isLoadedOk = _MergeCoverageXmlFiles(_coverageFileTreeNode, fileNames, 0);

				timer.Stop();

				if (isLoadedOk)
				{
					_coverageFileTreeNode.Expand();
					CoverageFilesEventArgs e = new CoverageFilesEventArgs(_coverageFileTreeNode, timer.Duration, false);
					OnCoverageFilesLoaded(e);
				}
			}
			finally
			{
				timer.Stop();
				Cursor.Current = Cursors.Default;
			}
		}

		#endregion Merge Coverage File

		#region Close Coverage File

		/// <summary>
		/// Closes the coverage file.
		/// </summary>
		public void CloseCoverageFile()
		{
			_coverageFileTreeNode = null;
			OnCoverageFileClosed(EventArgs.Empty);
		}

		#endregion Close Coverage File

		#region Reload Coverage File

		/// <summary>
		/// Reloads the coverage XML file.
		/// </summary>
		public void ReloadCoverageXmlFile()
		{
			LoadCoverageXmlFiles(_coverageFileTreeNode.CoverageFileNames);
		}

		#endregion Reload Coverage File

		#region Save Coverage File

		/// <summary>
		/// Saves the coverage file over the top of itself.
		/// </summary>
		public void SaveCoverageFile()
		{
			if (_coverageFileTreeNode.CoverageFileNames.Length == 0)
			{
				return;
			}
			else if (_coverageFileTreeNode.CoverageFileNames.Length > 1)
			{
				SaveAsCoverageFile();
			}
			else
			{
				SaveCoverageFile(_coverageFileTreeNode.CoverageFileNames[0]);
			}
		}

		/// <summary>
		/// Asks user to specify a new file name before saving the coverage file.
		/// </summary>
		public void SaveAsCoverageFile()
		{
			using (SaveFileDialog saveFileDialog = new SaveFileDialog())
			{
				saveFileDialog.Title = "Save coverage xml file";
				if (_coverageFileTreeNode.CoverageFileNames.Length > 1)
				{
					saveFileDialog.FileName = "coverage.merged.xml";
				}
				else
				{
					saveFileDialog.FileName = _coverageFileTreeNode.CoverageFileNames[0];
				}
				saveFileDialog.DefaultExt = "xml";
				saveFileDialog.AddExtension = true;
				saveFileDialog.InitialDirectory = Path.GetDirectoryName(_coverageFileTreeNode.CoverageFileNames[0]);
				saveFileDialog.Filter = "XML Document|*.xml|All Files (*.*)|*.*";
				saveFileDialog.FilterIndex = 0;

				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					SaveCoverageFile(saveFileDialog.FileName);
				}
				else
				{
					StatusPublisher.Display("Save operation cancelled by user.");
				}
			}
		}

		/// <summary>
		/// Saves the coverage file under the specified file name.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		public void SaveCoverageFile(string fileName)
		{
			StatusPublisher.Display("Writing coverage file: " + fileName + " ...");
			HighPerformanceTimer timer = new HighPerformanceTimer();
			try
			{
				timer.Start();
				Cursor.Current = Cursors.WaitCursor;

				CoverageFileWriter writer = new CoverageFileWriter(_configuration);
				writer.WriteCoverageXmlFile(fileName, _coverageFileTreeNode);

				timer.Stop();
				_coverageFileTreeNode.CoverageFileNames = new string[] { fileName };
				OnCoverageFileSaved(new CoverageFilesEventArgs(_coverageFileTreeNode, timer.Duration, false));
			}
			finally
			{
				timer.Stop();
				Cursor.Current = Cursors.Default;
			}
		}

		#endregion Save Coverage File

		#region Change Source Code Path

		/// <summary>
		/// Changes the source code path in the loaded coverage tree to allow for moved source code.
		/// </summary>
		/// <returns><c>true</c> if the user changed the path, otherwise <c>false</c>.</returns>
		public bool ChangeSourceCodePath(string fileName)
		{
			using (ChangeSourcePathDialog changeSourcePathDialog = new ChangeSourcePathDialog(_configuration, _coverageFileTreeNode, fileName))
			{
				return (changeSourcePathDialog.ShowDialog() != DialogResult.Cancel);
			}
		}

		#endregion Change Source Code Path

		#region Show Dialogs

		/// <summary>
		/// Shows the statistics summary dialog.
		/// </summary>
		public void ShowStatisticsSummaryDialog()
		{
			using (StatisticsSummaryDialog statisticsDialog = new StatisticsSummaryDialog(_coverageFileTreeNode))
			{
				statisticsDialog.ShowDialog();
			}
		}

		/// <summary>
		/// Shows the reports dialog.
		/// </summary>
		public void ShowReportsDialog()
		{
			using (ReportsDialog reportsDialog = new ReportsDialog(_configuration, _coverageFileTreeNode))
			{
				reportsDialog.ShowDialog();
			}
		}

		/// <summary>
		/// Shows the configuration options dialog.
		/// </summary>
		public void ShowOptionsDialog()
		{
			using (OptionsDialog optionsDialog = new OptionsDialog(_configuration))
			{
				if (optionsDialog.ShowDialog() == DialogResult.OK)
				{
					ConfigurationChangedEventArgs e = new ConfigurationChangedEventArgs(optionsDialog.IsReloadRequired);
					OnConfigurationChanged(e);
				}
			}
		}
	
		/// <summary>
		/// Shows the about dialog.
		/// </summary>
		public void ShowAboutDialog()
		{
			using (AboutDialog aboutDialog = new AboutDialog())
			{
				aboutDialog.ShowDialog();
			}
		}

		#endregion Show Dialogs

		#region Show Web Pages

		/// <summary>
		/// Shows the FAQ file - off website if it does not exist locally.
		/// </summary>
		public void ShowFAQPage()
		{
			string localFaqFileName = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), FAQFileName);

			if (File.Exists(localFaqFileName))
			{
				Process.Start(localFaqFileName);
			}
			else
			{
				Process.Start(NCoverExplorerWebSite + FAQFileName);
			}
		}
	
		/// <summary>
		/// Shows the release notes - off website if it does not exist locally.
		/// </summary>
		public void ShowReleaseNotesPage()
		{
			string localReleaseFileName = Path.Combine(Path.GetDirectoryName(Application.ExecutablePath), ReleaseNotesFileName);
			
			if (File.Exists(localReleaseFileName))
			{
				Process.Start(localReleaseFileName);
			}
			else
			{
				Process.Start(NCoverExplorerWebSite + ReleaseNotesFileName);
			}
		}
	
		/// <summary>
		/// Shows the website home page for NCoverExplorer.
		/// </summary>
		public void ShowHomePage()
		{
			Process.Start(NCoverExplorerHomePage);
		}
	
		/// <summary>
		/// Shows the blog page for NCoverExplorer.
		/// </summary>
		public void ShowBlogPage()
		{
			Process.Start(NCoverExplorerBlogUrl);
		}
	
		/// <summary>
		/// Shows the PayPal donation page for NCoverExplorer.
		/// </summary>
		public void ShowDonationPage()
		{
			Process.Start(NCoverExplorerDonationUrl);
		}

		#endregion Show Web Pages

		#region Request Feedback

		/// <summary>
		/// Request feedback by e-mail.
		/// </summary>
		public void RequestFeedback()
		{
			Process.Start("mailto:support@ncoverexplorer.org");
		}

		#endregion Request Feedback

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Raises the CoverageFileLoaded event.
		/// </summary>
		/// <param name="e">The <see cref="CoverageFilesEventArgs"/> instance containing the event data.</param>
		protected void OnCoverageFilesLoaded(CoverageFilesEventArgs e)
		{
			if (this.CoverageFileLoaded != null)
			{
				CoverageFileLoaded(this, e);
			}
		}

		/// <summary>
		/// Raises the CoverageFileLoadFailed event.
		/// </summary>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Presentation.CoverageFileLoadFailedEventArgs"/> instance containing the event data.</param>
		protected void OnCoverageFileLoadFailed(CoverageFileLoadFailedEventArgs e)
		{
			if (this.CoverageFileLoadFailed != null)
			{
				CoverageFileLoadFailed(this, e);
			}
		}

		/// <summary>
		/// Raises the CoverageFileSaved event.
		/// </summary>
		/// <param name="e">The <see cref="CoverageFilesEventArgs"/> instance containing the event data.</param>
		protected void OnCoverageFileSaved(CoverageFilesEventArgs e)
		{
			if (this.CoverageFileSaved != null)
			{
				CoverageFileSaved(this, e);
			}
		}

		/// <summary>
		/// Raises the CoverageFileClosed event.
		/// </summary>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		protected void OnCoverageFileClosed(EventArgs e)
		{
			if (this.CoverageFileClosed != null)
			{
				CoverageFileClosed(this, e);
			}
		}

		/// <summary>
		/// Raises the ConfigurationChanged event.
		/// </summary>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		protected void OnConfigurationChanged(ConfigurationChangedEventArgs e)
		{
			if (this.ConfigurationChanged != null)
			{
				ConfigurationChanged(this, e);
			}
		}

		#endregion Protected Methods

		#region Private Methods

		/// <summary>
		/// Merging all the files with the current loaded coverage tree.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="fileNames">Array of files to be merged.</param>
		/// <param name="startIndex">The first file index in the array to start at.</param>
		private bool _MergeCoverageXmlFiles(CoverageFileTreeNode coverageFileTreeNode, string[] fileNames, int startIndex)
		{
			string currentFileName = string.Empty;
			try
			{
				for (int index = startIndex; index < fileNames.Length; index++)
				{
					currentFileName = fileNames[index];
					coverageFileTreeNode.AddFileName(currentFileName);
					StatusPublisher.Display(string.Format("Loading file: {0} ...", currentFileName));
					_coverageXmlParser.MergeFile(coverageFileTreeNode, currentFileName);
				}

				StatusPublisher.Display("Calculating coverage and applying exclusions...");
				ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(_configuration.CoverageExclusions);
				coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);
				return true;
			}
			catch(Exception ex)
			{
				coverageFileTreeNode = null;
				OnCoverageFileLoadFailed(new CoverageFileLoadFailedEventArgs(currentFileName, ex));
				StatusPublisher.DisplayException(ex);
				return false;
			}
		}

		#endregion Private Methods
	}

	#region Delegates

	public delegate void CoverageFilesEventHandler(object sender, CoverageFilesEventArgs e);
	public delegate void CoverageFileLoadFailedEventHandler(object sender, CoverageFileLoadFailedEventArgs e);
	public delegate void ConfigurationChangedEventHandler(object sender, ConfigurationChangedEventArgs e);

	#endregion Delegates

	#region CoverageFilesEventArgs Class

	/// <summary>
	/// EventArgs passed with the CoverageFilesLoaded and CoverageFilesSaved events.
	/// </summary>
	public class CoverageFilesEventArgs : EventArgs
	{
		private CoverageFileTreeNode _coverageFileTreeNode;
		private Decimal _duration;
		private bool _isNewCoverageTree;

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageFilesEventArgs"/> class.
		/// </summary>
		/// <param name="coverageFileTreeNode">The root coverage element.</param>
		/// <param name="duration">The duration.</param>
		/// <param name="isNewCoverageTree">if set to <c>true</c> [is new coverage tree].</param>
		public CoverageFilesEventArgs(CoverageFileTreeNode coverageFileTreeNode, Decimal duration, bool isNewCoverageTree)
		{
			_coverageFileTreeNode = coverageFileTreeNode;
			_duration = duration;
			_isNewCoverageTree = isNewCoverageTree;
		}

		/// <summary>
		/// Gets the coverage filenames opened.
		/// </summary>
		/// <value>Name of the file.</value>
		public string[] FileNames
		{
			get { return _coverageFileTreeNode.CoverageFileNames; }
		}

		/// <summary>
		/// Gets the root coverage element.
		/// </summary>
		/// <value>The root coverage element.</value>
		public CoverageFileTreeNode CoverageFileTreeNode
		{
			get { return _coverageFileTreeNode; }
		}

		/// <summary>
		/// Gets the time taken to load in milliseconds.
		/// </summary>
		/// <value>The time taken in milliseconds.</value>
		public Decimal Duration
		{
			get { return _duration; }
		}

		/// <summary>
		/// Gets a value indicating whether this is a new coverage tree loaded.
		/// </summary>
		/// <value><c>true</c> if this is a new tree loaded; otherwise, <c>false</c> for a merge into existing.</value>
		public bool IsNewCoverageTree
		{
			get { return _isNewCoverageTree; }
		}
	}

	#endregion CoverageFilesEventArgs Class

	#region CoverageFileLoadFailedEventArgs Class

	/// <summary>
	/// EventArgs passed with the CoverageFileLoadFailed event.
	/// </summary>
	public class CoverageFileLoadFailedEventArgs : EventArgs
	{
		private string _fileName;
		private Exception _exception;

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageFileLoadFailedEventArgs"/> class.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <param name="exception">The root coverage element.</param>
		public CoverageFileLoadFailedEventArgs(string fileName, Exception exception)
		{
			_fileName= fileName;
			_exception = exception;
		}

		/// <summary>
		/// Gets the coverage filename opened.
		/// </summary>
		/// <value>Name of the file.</value>
		public string FileName
		{
			get { return _fileName; }
		}

		/// <summary>
		/// Gets the exception thrown.
		/// </summary>
		/// <value>The exception thrown.</value>
		public Exception Exception
		{
			get { return _exception; }
		}

		/// <summary>
		/// Gets a value indicating whether this failed due to the file already being loaded.
		/// </summary>
		public bool IsFileAlreadyLoaded
		{
			get { return _exception is System.Data.DuplicateNameException; }
		}

		/// <summary>
		/// Gets a value indicating whether this problem means we need to reload the file.
		/// </summary>
		public bool IsMergeDifferenceProblem
		{
			get { return _exception is MergeCoverageException; }
		}
	}

	#endregion CoverageFileLoadFailedEventArgs Class

	#region ConfigurationChangedEventArgs Class

	/// <summary>
	/// EventArgs passed with the ConfigurationChanged event.
	/// </summary>
	public class ConfigurationChangedEventArgs : EventArgs
	{
		private bool _isReloadRequired;

		/// <summary>
		/// Initializes a new instance of the <see cref="ConfigurationChangedEventArgs"/> class.
		/// </summary>
		public ConfigurationChangedEventArgs(bool isReloadRequired)
		{
			_isReloadRequired = isReloadRequired;
		}

		/// <summary>
		/// Gets whether a complete reload of the coverage file is required.
		/// </summary>
		public bool IsReloadRequired
		{
			get { return _isReloadRequired; }
		}
	}

	#endregion ConfigurationChangedEventArgs Class
}
