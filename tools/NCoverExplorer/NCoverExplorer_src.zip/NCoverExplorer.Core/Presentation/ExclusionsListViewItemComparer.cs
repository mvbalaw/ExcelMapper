using System.Collections;
using System.Windows.Forms;
using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// ListView item comparer for the Exclusions listview within the Options dialog.
	/// </summary>
	public class ExclusionsListViewItemComparer : IComparer
	{
		#region Private Variables

		private int _sortColumn;
		private bool _isAscendingOrder;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="ExclusionsListViewItemComparer"/> class.
		/// </summary>
		public ExclusionsListViewItemComparer() 
			: this(0, true)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ExclusionsListViewItemComparer"/> class.
		/// </summary>
		/// <param name="column">The column.</param>
		public ExclusionsListViewItemComparer(int column) 
			: this(column, true)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ExclusionsListViewItemComparer"/> class.
		/// </summary>
		/// <param name="column">The column.</param>
		/// <param name="isAscendingOrder">if set to <c>true</c> sort ascending.</param>
		public ExclusionsListViewItemComparer(int column, bool isAscendingOrder)
		{
			_sortColumn = column;
			_isAscendingOrder = isAscendingOrder;
		}

		#endregion Constructors

		#region Public Properties

		/// <summary>
		/// Gets or sets the sort column.
		/// </summary>
		/// <value>The sort column.</value>
		public int SortColumn
		{
			get { return _sortColumn; }
			set { _sortColumn = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether [sort ascending].
		/// </summary>
		/// <value><c>true</c> if [sort ascending]; otherwise, <c>false</c>.</value>
		public bool SortAscending
		{
			get { return _isAscendingOrder; }
			set { _isAscendingOrder = value; }
		}

		#endregion Public Properties

		#region IComparer Members

		/// <summary>
		/// Compares two objects and returns a value indicating whether one
		/// is less than, equal to or greater than the other.
		/// </summary>
		/// <param name="x">First object to compare.</param>
		/// <param name="y">Second object to compare.</param>
		public virtual int Compare(object x, object y)
		{
			int compare = 0;
	
			ListViewItem firstListViewItem = (ListViewItem)x;
			ListViewItem secondListViewItem = (ListViewItem)y;
			CoverageExclusion firstCoverageExclusion = (CoverageExclusion)firstListViewItem.Tag;
			CoverageExclusion secondCoverageExclusion = (CoverageExclusion)secondListViewItem.Tag;
			string columnName = firstListViewItem.ListView.Columns[SortColumn].Text;
	
			switch (columnName)
			{
				case "Exclusion Type":
					compare = _CompareIntegers((int)firstCoverageExclusion.ExclusionType, (int)secondCoverageExclusion.ExclusionType);
					break;
				case "Pattern":
					compare = string.Compare(firstCoverageExclusion.Pattern, secondCoverageExclusion.Pattern);
					break;
				case "Enabled":
					compare = string.Compare(firstCoverageExclusion.Enabled.ToString(), secondCoverageExclusion.Enabled.ToString());
					break;
			}
			if (!_isAscendingOrder)
			{
				compare = -compare;
			}
			return compare;
		}

		#endregion IComparer Members

		#region Private Methods

		/// <summary>
		/// Compares two integer columns and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstInteger">The first integer.</param>
		/// <param name="secondInteger">The second integer.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareIntegers(int firstInteger, int secondInteger)
		{
			if (firstInteger < secondInteger)
			{
				return -1;
			}
			else if (firstInteger == secondInteger)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}

		#endregion Private Methods
	}
}
