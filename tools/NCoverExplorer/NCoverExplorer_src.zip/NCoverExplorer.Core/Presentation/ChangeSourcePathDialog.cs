using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;
using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Iterators;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Dialog offering the user the opportunity to perform a replacement of source code file paths.
	/// </summary>
	public class ChangeSourcePathDialog : System.Windows.Forms.Form
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private FormStatePersister _formStatePersister;
		private CoverageFileTreeNode _coverageFileTreeNode;
		private System.ComponentModel.IContainer components;

		#endregion Private Variables

		#region Designer Variables

		private System.Windows.Forms.GroupBox grpPath;
		private System.Windows.Forms.Button btnReplace;
		private System.Windows.Forms.TextBox txtFind;
		private System.Windows.Forms.Label lblFind;
		private System.Windows.Forms.ComboBox cboReplace;
		private System.Windows.Forms.Button btnChooseFolder;
		private System.Windows.Forms.Label lblMissingFile;
		private System.Windows.Forms.Button btnSkip;
		private System.Windows.Forms.TreeView tvwOriginalFolder;
		private System.Windows.Forms.CheckBox chkDoNotAskNextTime;
		private System.Windows.Forms.ImageList imlFolders;
		private System.Windows.Forms.ErrorProvider errorProvider;
		private System.Windows.Forms.Label lblReplace;

		#endregion Designer Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="ChangeSourcePathDialog"/> class.
		/// </summary>
		protected ChangeSourcePathDialog()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ChangeSourcePathDialog"/> class.
		/// </summary>
		public ChangeSourcePathDialog(IExplorerConfiguration configuration, CoverageFileTreeNode coverageFileTreeNode,
			string missingFileName)
			: this()
		{
			_configuration = configuration;
			_coverageFileTreeNode = coverageFileTreeNode;

			_HookPersistentFormState();
			_BindConfiguration(missingFileName);
		}

		#endregion Constructor

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ChangeSourcePathDialog));
			this.grpPath = new System.Windows.Forms.GroupBox();
			this.chkDoNotAskNextTime = new System.Windows.Forms.CheckBox();
			this.tvwOriginalFolder = new System.Windows.Forms.TreeView();
			this.imlFolders = new System.Windows.Forms.ImageList(this.components);
			this.btnChooseFolder = new System.Windows.Forms.Button();
			this.cboReplace = new System.Windows.Forms.ComboBox();
			this.lblReplace = new System.Windows.Forms.Label();
			this.lblFind = new System.Windows.Forms.Label();
			this.txtFind = new System.Windows.Forms.TextBox();
			this.lblMissingFile = new System.Windows.Forms.Label();
			this.btnSkip = new System.Windows.Forms.Button();
			this.btnReplace = new System.Windows.Forms.Button();
			this.errorProvider = new System.Windows.Forms.ErrorProvider();
			this.grpPath.SuspendLayout();
			this.SuspendLayout();
			// 
			// grpPath
			// 
			this.grpPath.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpPath.Controls.Add(this.chkDoNotAskNextTime);
			this.grpPath.Controls.Add(this.tvwOriginalFolder);
			this.grpPath.Controls.Add(this.btnChooseFolder);
			this.grpPath.Controls.Add(this.cboReplace);
			this.grpPath.Controls.Add(this.lblReplace);
			this.grpPath.Controls.Add(this.lblFind);
			this.grpPath.Controls.Add(this.txtFind);
			this.grpPath.Controls.Add(this.lblMissingFile);
			this.grpPath.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpPath.Location = new System.Drawing.Point(8, 8);
			this.grpPath.Name = "grpPath";
			this.grpPath.Size = new System.Drawing.Size(426, 418);
			this.grpPath.TabIndex = 0;
			this.grpPath.TabStop = false;
			this.grpPath.Text = "&Folder Path Replacement";
			// 
			// chkDoNotAskNextTime
			// 
			this.chkDoNotAskNextTime.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.chkDoNotAskNextTime.ForeColor = System.Drawing.SystemColors.ControlText;
			this.chkDoNotAskNextTime.Location = new System.Drawing.Point(12, 380);
			this.chkDoNotAskNextTime.Name = "chkDoNotAskNextTime";
			this.chkDoNotAskNextTime.Size = new System.Drawing.Size(280, 24);
			this.chkDoNotAskNextTime.TabIndex = 7;
			this.chkDoNotAskNextTime.Text = "&Do not ask about missing source code again.";
			// 
			// tvwOriginalFolder
			// 
			this.tvwOriginalFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tvwOriginalFolder.HideSelection = false;
			this.tvwOriginalFolder.ImageList = this.imlFolders;
			this.tvwOriginalFolder.Location = new System.Drawing.Point(100, 78);
			this.tvwOriginalFolder.Name = "tvwOriginalFolder";
			this.tvwOriginalFolder.ShowRootLines = false;
			this.tvwOriginalFolder.Size = new System.Drawing.Size(316, 218);
			this.tvwOriginalFolder.TabIndex = 2;
			this.tvwOriginalFolder.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvwOriginalFolder_AfterSelect);
			// 
			// imlFolders
			// 
			this.imlFolders.ImageSize = new System.Drawing.Size(16, 16);
			this.imlFolders.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlFolders.ImageStream")));
			this.imlFolders.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// btnChooseFolder
			// 
			this.btnChooseFolder.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChooseFolder.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChooseFolder.Image = ((System.Drawing.Image)(resources.GetObject("btnChooseFolder.Image")));
			this.btnChooseFolder.Location = new System.Drawing.Point(392, 332);
			this.btnChooseFolder.Name = "btnChooseFolder";
			this.btnChooseFolder.Size = new System.Drawing.Size(24, 23);
			this.btnChooseFolder.TabIndex = 6;
			this.btnChooseFolder.Click += new System.EventHandler(this.btnChooseFolder_Click);
			// 
			// cboReplace
			// 
			this.cboReplace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cboReplace.Location = new System.Drawing.Point(100, 332);
			this.cboReplace.Name = "cboReplace";
			this.cboReplace.Size = new System.Drawing.Size(288, 21);
			this.cboReplace.TabIndex = 5;
			// 
			// lblReplace
			// 
			this.lblReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.lblReplace.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblReplace.Location = new System.Drawing.Point(12, 336);
			this.lblReplace.Name = "lblReplace";
			this.lblReplace.Size = new System.Drawing.Size(72, 16);
			this.lblReplace.TabIndex = 4;
			this.lblReplace.Text = "R&eplace with:";
			// 
			// lblFind
			// 
			this.lblFind.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblFind.Location = new System.Drawing.Point(12, 80);
			this.lblFind.Name = "lblFind";
			this.lblFind.Size = new System.Drawing.Size(80, 16);
			this.lblFind.TabIndex = 1;
			this.lblFind.Text = "R&oot folder:";
			// 
			// txtFind
			// 
			this.txtFind.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtFind.Location = new System.Drawing.Point(100, 304);
			this.txtFind.MaxLength = 50;
			this.txtFind.Name = "txtFind";
			this.txtFind.Size = new System.Drawing.Size(312, 21);
			this.txtFind.TabIndex = 3;
			this.txtFind.Text = "";
			// 
			// lblMissingFile
			// 
			this.lblMissingFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblMissingFile.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblMissingFile.Location = new System.Drawing.Point(12, 26);
			this.lblMissingFile.Name = "lblMissingFile";
			this.lblMissingFile.Size = new System.Drawing.Size(402, 48);
			this.lblMissingFile.TabIndex = 0;
			this.lblMissingFile.Text = "";
			// 
			// btnSkip
			// 
			this.btnSkip.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnSkip.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnSkip.Location = new System.Drawing.Point(358, 434);
			this.btnSkip.Name = "btnSkip";
			this.btnSkip.TabIndex = 2;
			this.btnSkip.Text = "Skip";
			// 
			// btnReplace
			// 
			this.btnReplace.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnReplace.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnReplace.Location = new System.Drawing.Point(274, 434);
			this.btnReplace.Name = "btnReplace";
			this.btnReplace.TabIndex = 1;
			this.btnReplace.Text = "&Replace";
			this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
			// 
			// errorProvider
			// 
			this.errorProvider.ContainerControl = this;
			// 
			// ChangeSourcePathDialog
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.CancelButton = this.btnSkip;
			this.ClientSize = new System.Drawing.Size(442, 468);
			this.Controls.Add(this.btnSkip);
			this.Controls.Add(this.btnReplace);
			this.Controls.Add(this.grpPath);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ChangeSourcePathDialog";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Resolve Missing Source Code File";
			this.grpPath.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Protected Methods

		/// <summary>
		/// Overridden to store checkbox value about asking next time.
		/// </summary>
		protected override void OnClosing(CancelEventArgs e)
		{
			_configuration.WarnAboutMissingSourceCode = !chkDoNotAskNextTime.Checked;
			base.OnClosing (e);
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion Protected Methods

		#region Private Methods

		#region Form Persistence

		/// <summary>
		/// Creates and hooks event handlers for persistent window state of position and size.
		/// </summary>
		private void _HookPersistentFormState()
		{
			_formStatePersister = new FormStatePersister(this, "ChangeSourcePathDialog", _configuration.FormStates);

			_formStatePersister.LoadState += new FormStateEventHandler(_OnLoadState);
			_formStatePersister.SaveState += new FormStateEventHandler(_OnSaveState);
		}

		/// <summary>
		/// Handles the LoadState event of the form persistence object.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Configuration.FormStateEventArgs"/> instance containing the event data.</param>
		private void _OnLoadState(object sender, FormStateEventArgs e)
		{
			cboReplace.Items.Clear();
			cboReplace.Text = "";
			_AddToComboIfNewValue(e.FormState.GetString("LastReplaceText1", ""));
			_AddToComboIfNewValue(e.FormState.GetString("LastReplaceText2", ""));
			_AddToComboIfNewValue(e.FormState.GetString("LastReplaceText3", ""));
			_AddToComboIfNewValue(e.FormState.GetString("LastReplaceText4", ""));
			_AddToComboIfNewValue(e.FormState.GetString("LastReplaceText5", ""));
		}

		/// <summary>
		/// Handles the SaveState event of the form persistence object.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Configuration.FormStateEventArgs"/> instance containing the event data.</param>
		private void _OnSaveState(object sender, FormStateEventArgs e)
		{
			e.FormState.SetValue("LastReplaceText1", cboReplace.Text);
			int maxItemCount = cboReplace.Items.Count < 4 ? cboReplace.Items.Count : 4;
			for (int index = 0; index < maxItemCount; index++)
			{
				e.FormState.SetValue("LastReplaceText" + (index + 2).ToString(), cboReplace.Items[index].ToString());
			}
		}

		#endregion Form Persistence

		#region Initialisation

		/// <summary>
		/// Build combo of paths as a recent folder dropdown.
		/// </summary>
		/// <param name="text">The text.</param>
		private void _AddToComboIfNewValue(string text)
		{
			if (text.Length > 0)
			{
				for (int index = 0; index < cboReplace.Items.Count; index++)
				{
					if (cboReplace.Items[index].ToString().ToLower() == text.ToLower())
					{
						return;
					}
				}
				cboReplace.Items.Add(text);
			}
		}

		/// <summary>
		/// Binds the controls to the current configuration information.
		/// </summary>
		private void _BindConfiguration(string missingFileName)
		{
			lblMissingFile.Text = string.Format("The file \'{0}\' cannot be found in the folder shown below. Specify an alternative " +
				"root source code folder on your machine by performing a global find/replace with" +
				"in the document paths.", Path.GetFileName(missingFileName));

			_PopulateFolderTree(Path.GetDirectoryName(missingFileName));
		}

		/// <summary>
		/// Populates the original file folder tree.
		/// </summary>
		/// <param name="folderPath">The folder path.</param>
		private void _PopulateFolderTree(string folderPath)
		{
			string[] pathFolders = folderPath.Split(new char[]{'\\'});
			TreeNode lastNode = tvwOriginalFolder.Nodes.Add(pathFolders[0] + '\\');
			lastNode.ImageIndex = 0;
			lastNode.SelectedImageIndex = 0;
			for (int index = 1; index < pathFolders.Length; index++)
			{
				TreeNode newNode = lastNode.Nodes.Add(pathFolders[index]);
				newNode.ImageIndex = 1;
				newNode.SelectedImageIndex = 1;
				lastNode = newNode;
			}
			tvwOriginalFolder.ExpandAll();
			tvwOriginalFolder.SelectedNode = tvwOriginalFolder.Nodes[0];
		}

		#endregion Initialisation

		#region Replace

		/// <summary>
		/// Handles the Click event of the btnReplace control.
		/// </summary>
		private void btnReplace_Click(object sender, EventArgs e)
		{
			bool isError = _IsValidDataEntry();
			if (isError)
			{
				this.DialogResult = DialogResult.None;
				return;
			}
			try
			{
				Cursor.Current = Cursors.WaitCursor;

				IEnumerator enumerator = new MethodTreeIterator(_coverageFileTreeNode);
				string toFind = txtFind.Text;
				string replaceWith = cboReplace.Text;
				int numNodesReplaced = 0;
				int totalNodes = 0;
				while (enumerator.MoveNext())
				{
					MethodTreeNode methodTreeNode = (MethodTreeNode)enumerator.Current;
					string existingName = methodTreeNode.FileName;
					totalNodes++;
					if (existingName.IndexOf(toFind) != -1)
					{
						numNodesReplaced++;
						methodTreeNode.FileName = existingName.Replace(toFind, replaceWith);
					}
				}

				MessageBox.Show("Updated " + numNodesReplaced + " of " + totalNodes + " file paths.", "NCoverExplorer", 
				                MessageBoxButtons.OK, MessageBoxIcon.Information);
				this.Close();
				this.DialogResult = DialogResult.OK;
			}
			finally
			{
				Cursor.Current = Cursors.Default;
			}
		}

		private bool _IsValidDataEntry()
		{
			bool isError = false;
			if (txtFind.Text.Length == 0)
			{
				errorProvider.SetError(txtFind, "Cannot be blank");
				errorProvider.SetIconAlignment(txtFind, ErrorIconAlignment.MiddleLeft);
				isError = true;
			}
			if (cboReplace.Text.Length == 0)
			{
				errorProvider.SetError(cboReplace, "Cannot be blank");
				errorProvider.SetIconAlignment(cboReplace, ErrorIconAlignment.MiddleLeft);
				isError = true;
			}
			if (txtFind.Text.EndsWith("\\") && (cboReplace.Text.Length > 0 && !cboReplace.Text.EndsWith("\\")))
			{
				errorProvider.SetError(cboReplace, "Should have matching closing slash when replacing paths.");
				errorProvider.SetIconAlignment(cboReplace, ErrorIconAlignment.MiddleLeft);
				isError = true;
			}
			if (cboReplace.Text.EndsWith("\\") && (txtFind.Text.Length > 0 && !txtFind.Text.EndsWith("\\")))
			{
				errorProvider.SetError(txtFind, "Should have matching closing slash when replacing paths.");
				errorProvider.SetIconAlignment(txtFind, ErrorIconAlignment.MiddleLeft);
				isError = true;
			}
			if (txtFind.Text.StartsWith("\\") && (cboReplace.Text.Length > 0 && !cboReplace.Text.StartsWith("\\")))
			{
				errorProvider.SetError(cboReplace, "Should have matching opening slash when replacing paths.");
				errorProvider.SetIconAlignment(cboReplace, ErrorIconAlignment.MiddleLeft);
				isError = true;
			}
			if (cboReplace.Text.StartsWith("\\") && (txtFind.Text.Length > 0 && !txtFind.Text.StartsWith("\\")))
			{
				errorProvider.SetError(txtFind, "Should have matching opening slash when replacing paths.");
				errorProvider.SetIconAlignment(txtFind, ErrorIconAlignment.MiddleLeft);
				isError = true;
			}
			if (!isError)
			{
				errorProvider.SetError(txtFind,"");
				errorProvider.SetError(cboReplace,"");
			}

			return isError;
		}

		#endregion Replace

		#region ChooseFolder

		/// <summary>
		/// Handles the Click event of the btnChooseFolder control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnChooseFolder_Click(object sender, EventArgs e)
		{
			using (FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog())
			{
				folderBrowserDialog.SelectedPath = cboReplace.Text;

				folderBrowserDialog.ShowNewFolderButton = false;
				folderBrowserDialog.Description = "Select source code folder:";
				folderBrowserDialog.ShowDialog();

				string directory = folderBrowserDialog.SelectedPath;
				if (directory != null && directory.Length > 0) 
				{
					cboReplace.Text = directory;
				}
			}
		}

		#endregion ChooseFolder

		#region Treeview Events

		private void tvwOriginalFolder_AfterSelect(object sender, TreeViewEventArgs e)
		{
			txtFind.Text = e.Node.FullPath.Replace(@"\\",@"\");
		}

		#endregion Treeview Events

		#endregion Private Methods
	}
}
