using System;
using System.Drawing;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation.Controls;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Configuration options dialog for NCoverExplorer.
	/// </summary>
	public class OptionsDialog : Form
	{
		#region Class Variables

		private IExplorerConfiguration _configuration;
		private FormStatePersister _formStatePersister;
		private bool _isReloadRequired;
		private CoverageExclusionCollection _coverageExclusions;

		private CommandBarContextMenu _contextMenuExclusions;
		private CommandBarButton _ctxExclusionDelete;
		private CommandBarButton _ctxExclusionEnableItem;
		private CommandBarButton _ctxExclusionDisableItem;

		#endregion Class Variables

		#region Designer Variables

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private Button btnOk;
		private Button btnCancel;
		private System.Windows.Forms.ErrorProvider errorProvider;
		private System.Windows.Forms.TabControl tabControl;
		private System.Windows.Forms.TabPage tabPageCoverageTree;
		private System.Windows.Forms.GroupBox grpTreeViewOptions;
		private NCoverExplorer.Core.Presentation.Controls.MultipleChoice mulFlattenNamespaces;
		private NCoverExplorer.Core.Presentation.Controls.MultipleChoice mulTreeGrouping;
		private System.Windows.Forms.Label lblNamespaceAppearance;
		private System.Windows.Forms.Label lblGroupBy;
		private NCoverExplorer.Core.Presentation.Controls.NumericTextBox ntxtSatisfactoryThreshold;
		private System.Windows.Forms.Label lblThreshold;
		private System.Windows.Forms.GroupBox grpHighlightingOptions;
		private NCoverExplorer.Core.Presentation.Controls.MultipleChoice mulHighlightUnvisitedCode;
		private NCoverExplorer.Core.Presentation.Controls.MultipleChoice mulHighlightVisitedCode;
		private System.Windows.Forms.TabPage tabPageOther;
		private System.Windows.Forms.GroupBox grpOtherOptions;
		private NCoverExplorer.Core.Presentation.Controls.NumericTextBox ntxtRecentFileMenuItems;
		private System.Windows.Forms.Label lblRecentFileMenuItems;
		private System.Windows.Forms.GroupBox grpCoverageTolerance;
		private System.Windows.Forms.Label lblUnvisitedSeqPnts;
		private NCoverExplorer.Core.Presentation.Controls.NumericTextBox ntxtSatisfactorySeqPts;
		private System.Windows.Forms.ToolTip toolTip;
		private System.Windows.Forms.TrackBar trackSatisfactoryThreshold;
		private System.Windows.Forms.TrackBar trackSatisfactorySeqPts;
		private System.Windows.Forms.GroupBox grpSourceCodeColors;
		private System.Windows.Forms.Label lblColorSourceVisited;
		private System.Windows.Forms.Label lblColorSourceUnvisited;
		private System.Windows.Forms.Button btnChangeColorSourceVisited;
		private System.Windows.Forms.Button btnChangeColorSourceUnvisited;
		private System.Windows.Forms.GroupBox grpCoverageTreeColors;
		private System.Windows.Forms.Label lblColorTreeSatisfactoryCoverage;
		private System.Windows.Forms.Label lblColorTreeFullCoverage;
		private System.Windows.Forms.Label lblColorTreePartialCoverage;
		private System.Windows.Forms.Label lblColorTreeNoCoverage;
		private System.Windows.Forms.Button btnChangeColorTreeSatisfactoryCoverage;
		private System.Windows.Forms.Button btnChangeColorTreeFullCoverage;
		private System.Windows.Forms.Button btnChangeColorTreePartialCoverage;
		private System.Windows.Forms.Button btnChangeColorTreeNoCoverage;
		private System.Windows.Forms.Label lblDisplayColorSourceVisited;
		private System.Windows.Forms.Label lblDisplayColorSourceUnvisited;
		private System.Windows.Forms.Label lblDisplayColorTreeFullCoverage;
		private System.Windows.Forms.Label lblDisplayColorTreeSatisfactoryCoverage;
		private System.Windows.Forms.Label lblDisplayColorTreePartialCoverage;
		private System.Windows.Forms.Label lblDisplayColorTreeNoCoverage;
		private System.Windows.Forms.GroupBox grpStartupOptions;
		private System.Windows.Forms.Label lblRestoreSelectionOnReload;
		private System.Windows.Forms.CheckBox chkRestoreSelectionOnReload;
		private System.Windows.Forms.Label lblHelpSatisfactoryUnvisitedLines;
		private System.Windows.Forms.Label lblHelpSatisfactoryPercentage;
		private System.Windows.Forms.Label lblHelpRestoreSelectionOnReload;
		private System.Windows.Forms.Label lblColorTreeBackground;
		private System.Windows.Forms.TabPage tabPageTreeColors;
		private System.Windows.Forms.Button btnChangeColorTreeBackground;
		private System.Windows.Forms.Button btnChangeFontTree;
		private System.Windows.Forms.Label lblDisplayFontTree;
		private System.Windows.Forms.Button btnChangeFontSource;
		private System.Windows.Forms.Label lblDisplayFontSource;
		private System.Windows.Forms.GroupBox grpStatisticsListViewOptions;
		private System.Windows.Forms.Label lblDisplayFontStatistics;
		private System.Windows.Forms.Button btnChangeFontStatistics;
		private System.Windows.Forms.Button btnChangeColorStatisticsBackground;
		private System.Windows.Forms.Label lblStatisticsBackground;
		private System.Windows.Forms.TabPage tabPageThemes;
		private System.Windows.Forms.GroupBox grpThemeOptions;
		private System.Windows.Forms.TabPage tabPageSourceCodeColors;
		private System.Windows.Forms.Label lblThemeDescription;
		private System.Windows.Forms.ComboBox cboThemes;
		private System.Windows.Forms.Button btnThemeSaveAs;
		private System.Windows.Forms.Button btnThemeDelete;
		private System.Windows.Forms.Label lblTheme;
		private System.Windows.Forms.Label lblThemeReset;
		private System.Windows.Forms.TabPage tabPageStatisticsColors;
		private System.Windows.Forms.Button btnThemeResetDefaults;
		private System.Windows.Forms.Label lblColorSourceLineNumbers;
		private System.Windows.Forms.Label lblDisplayColorSourceLineNumbers;
		private System.Windows.Forms.Button btnChangeColorSourceLineNumbers;
		private System.Windows.Forms.Button btnChangeColorSourceBackground;
		private System.Windows.Forms.Label lblColorSourceBackgroundColor;
		private System.Windows.Forms.Label lblThemePreview;
		private System.Windows.Forms.Panel pnlPreview;
		private System.Windows.Forms.Panel pnlPreviewTree;
		private System.Windows.Forms.Panel pnlPreviewStatistics;
		private System.Windows.Forms.Panel pnlPreviewSource;
		private System.Windows.Forms.TabPage tabPageExclusions;
		private System.Windows.Forms.GroupBox grpExclusionAdd;
		private System.Windows.Forms.Label lblExclusionType;
		private System.Windows.Forms.ListView exclusionsListView;
		private System.Windows.Forms.ColumnHeader lvcExclusionType;
		private System.Windows.Forms.ColumnHeader lvcExclusionPattern;
		private System.Windows.Forms.ImageList imlExclusions;
		private System.Windows.Forms.ColumnHeader lvcExclusionEnabled;
		private System.Windows.Forms.ComboBox cboExclusionTypes;
		private System.Windows.Forms.Label lblExclusionPattern;
		private System.Windows.Forms.TextBox txtExclusionPattern;
		private System.Windows.Forms.Button btnExclusionAdd;
		private System.Windows.Forms.Label lblPatternDescription;
		private System.Windows.Forms.Label lblDisplayColorTreeExcludedCoverage;
		private System.Windows.Forms.Button btnChangeColorTreeExcludedCoverage;
		private System.Windows.Forms.Label lblColorTreeExcludedCoverage;
		private System.Windows.Forms.Label lblHighlightUncoveredCode;
		private System.Windows.Forms.Label lblHighlightVisitedCode;
		private System.Windows.Forms.Label lblHighlightExcludedCode;
		private System.Windows.Forms.Button btnChangeColorSourceExcluded;
		private System.Windows.Forms.Label lblDisplayColorSourceExcluded;
		private System.Windows.Forms.Label lblColorSourceExcluded;
		private NCoverExplorer.Core.Presentation.Controls.MultipleChoice mulHighlightExcludedCode;

		#endregion Designer Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="OptionsDialog"/> class, for use by designer.
		/// </summary>
		protected OptionsDialog()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="OptionsDialog"/> class, for use by application.
		/// </summary>
		public OptionsDialog(IExplorerConfiguration configuration) : this()
		{
			_configuration = configuration;
			_HookPersistentFormState();

			_CreateExclusionsContextMenu();
			_BindConfiguration();
			_isReloadRequired = false;
		}

		#endregion Constructors

		private void _CreateExclusionsContextMenu()
		{
			_ctxExclusionEnableItem = new CommandBarButton("&Enable Item", new EventHandler(ctxExclusionEnableItem_Click));
			_ctxExclusionDisableItem = new CommandBarButton("D&isable Item", new EventHandler(ctxExclusionDisableItem_Click));
			_ctxExclusionDelete = new CommandBarButton("&Delete", new EventHandler(ctxExclusionDelete_Click));

			_contextMenuExclusions = new CommandBarContextMenu();
			_contextMenuExclusions.Popup += new EventHandler(contextMenuExclusions_Popup);
			_contextMenuExclusions.Items.Add(_ctxExclusionEnableItem);
			_contextMenuExclusions.Items.Add(_ctxExclusionDisableItem);
			_contextMenuExclusions.Items.AddSeparator();
			_contextMenuExclusions.Items.Add(_ctxExclusionDelete);
			
			exclusionsListView.ContextMenu = _contextMenuExclusions;
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(OptionsDialog));
			this.btnOk = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.errorProvider = new System.Windows.Forms.ErrorProvider();
			this.ntxtSatisfactoryThreshold = new NCoverExplorer.Core.Presentation.Controls.NumericTextBox();
			this.ntxtRecentFileMenuItems = new NCoverExplorer.Core.Presentation.Controls.NumericTextBox();
			this.ntxtSatisfactorySeqPts = new NCoverExplorer.Core.Presentation.Controls.NumericTextBox();
			this.txtExclusionPattern = new System.Windows.Forms.TextBox();
			this.tabControl = new System.Windows.Forms.TabControl();
			this.tabPageCoverageTree = new System.Windows.Forms.TabPage();
			this.grpCoverageTolerance = new System.Windows.Forms.GroupBox();
			this.lblHelpSatisfactoryUnvisitedLines = new System.Windows.Forms.Label();
			this.lblHelpSatisfactoryPercentage = new System.Windows.Forms.Label();
			this.lblUnvisitedSeqPnts = new System.Windows.Forms.Label();
			this.lblThreshold = new System.Windows.Forms.Label();
			this.trackSatisfactorySeqPts = new System.Windows.Forms.TrackBar();
			this.trackSatisfactoryThreshold = new System.Windows.Forms.TrackBar();
			this.grpTreeViewOptions = new System.Windows.Forms.GroupBox();
			this.mulFlattenNamespaces = new NCoverExplorer.Core.Presentation.Controls.MultipleChoice();
			this.mulTreeGrouping = new NCoverExplorer.Core.Presentation.Controls.MultipleChoice();
			this.lblNamespaceAppearance = new System.Windows.Forms.Label();
			this.lblGroupBy = new System.Windows.Forms.Label();
			this.tabPageExclusions = new System.Windows.Forms.TabPage();
			this.exclusionsListView = new System.Windows.Forms.ListView();
			this.lvcExclusionType = new System.Windows.Forms.ColumnHeader();
			this.lvcExclusionPattern = new System.Windows.Forms.ColumnHeader();
			this.lvcExclusionEnabled = new System.Windows.Forms.ColumnHeader();
			this.imlExclusions = new System.Windows.Forms.ImageList(this.components);
			this.grpExclusionAdd = new System.Windows.Forms.GroupBox();
			this.lblPatternDescription = new System.Windows.Forms.Label();
			this.btnExclusionAdd = new System.Windows.Forms.Button();
			this.lblExclusionPattern = new System.Windows.Forms.Label();
			this.cboExclusionTypes = new System.Windows.Forms.ComboBox();
			this.lblExclusionType = new System.Windows.Forms.Label();
			this.tabPageOther = new System.Windows.Forms.TabPage();
			this.grpStartupOptions = new System.Windows.Forms.GroupBox();
			this.lblHelpRestoreSelectionOnReload = new System.Windows.Forms.Label();
			this.chkRestoreSelectionOnReload = new System.Windows.Forms.CheckBox();
			this.lblRestoreSelectionOnReload = new System.Windows.Forms.Label();
			this.grpOtherOptions = new System.Windows.Forms.GroupBox();
			this.lblRecentFileMenuItems = new System.Windows.Forms.Label();
			this.tabPageStatisticsColors = new System.Windows.Forms.TabPage();
			this.grpStatisticsListViewOptions = new System.Windows.Forms.GroupBox();
			this.lblDisplayFontStatistics = new System.Windows.Forms.Label();
			this.btnChangeFontStatistics = new System.Windows.Forms.Button();
			this.btnChangeColorStatisticsBackground = new System.Windows.Forms.Button();
			this.lblStatisticsBackground = new System.Windows.Forms.Label();
			this.tabPageTreeColors = new System.Windows.Forms.TabPage();
			this.grpCoverageTreeColors = new System.Windows.Forms.GroupBox();
			this.lblDisplayColorTreeExcludedCoverage = new System.Windows.Forms.Label();
			this.btnChangeColorTreeExcludedCoverage = new System.Windows.Forms.Button();
			this.lblColorTreeExcludedCoverage = new System.Windows.Forms.Label();
			this.lblDisplayFontTree = new System.Windows.Forms.Label();
			this.btnChangeFontTree = new System.Windows.Forms.Button();
			this.btnChangeColorTreeBackground = new System.Windows.Forms.Button();
			this.lblColorTreeBackground = new System.Windows.Forms.Label();
			this.lblDisplayColorTreeNoCoverage = new System.Windows.Forms.Label();
			this.lblDisplayColorTreePartialCoverage = new System.Windows.Forms.Label();
			this.lblDisplayColorTreeSatisfactoryCoverage = new System.Windows.Forms.Label();
			this.lblDisplayColorTreeFullCoverage = new System.Windows.Forms.Label();
			this.btnChangeColorTreeNoCoverage = new System.Windows.Forms.Button();
			this.lblColorTreeNoCoverage = new System.Windows.Forms.Label();
			this.btnChangeColorTreePartialCoverage = new System.Windows.Forms.Button();
			this.lblColorTreePartialCoverage = new System.Windows.Forms.Label();
			this.btnChangeColorTreeSatisfactoryCoverage = new System.Windows.Forms.Button();
			this.btnChangeColorTreeFullCoverage = new System.Windows.Forms.Button();
			this.lblColorTreeSatisfactoryCoverage = new System.Windows.Forms.Label();
			this.lblColorTreeFullCoverage = new System.Windows.Forms.Label();
			this.tabPageThemes = new System.Windows.Forms.TabPage();
			this.grpThemeOptions = new System.Windows.Forms.GroupBox();
			this.pnlPreview = new System.Windows.Forms.Panel();
			this.pnlPreviewSource = new System.Windows.Forms.Panel();
			this.pnlPreviewStatistics = new System.Windows.Forms.Panel();
			this.pnlPreviewTree = new System.Windows.Forms.Panel();
			this.lblThemePreview = new System.Windows.Forms.Label();
			this.lblThemeReset = new System.Windows.Forms.Label();
			this.btnThemeResetDefaults = new System.Windows.Forms.Button();
			this.lblTheme = new System.Windows.Forms.Label();
			this.btnThemeDelete = new System.Windows.Forms.Button();
			this.btnThemeSaveAs = new System.Windows.Forms.Button();
			this.cboThemes = new System.Windows.Forms.ComboBox();
			this.lblThemeDescription = new System.Windows.Forms.Label();
			this.tabPageSourceCodeColors = new System.Windows.Forms.TabPage();
			this.grpSourceCodeColors = new System.Windows.Forms.GroupBox();
			this.lblColorSourceExcluded = new System.Windows.Forms.Label();
			this.lblDisplayColorSourceExcluded = new System.Windows.Forms.Label();
			this.btnChangeColorSourceExcluded = new System.Windows.Forms.Button();
			this.btnChangeColorSourceBackground = new System.Windows.Forms.Button();
			this.btnChangeColorSourceLineNumbers = new System.Windows.Forms.Button();
			this.lblDisplayColorSourceLineNumbers = new System.Windows.Forms.Label();
			this.lblColorSourceLineNumbers = new System.Windows.Forms.Label();
			this.lblDisplayFontSource = new System.Windows.Forms.Label();
			this.btnChangeFontSource = new System.Windows.Forms.Button();
			this.lblDisplayColorSourceUnvisited = new System.Windows.Forms.Label();
			this.lblDisplayColorSourceVisited = new System.Windows.Forms.Label();
			this.btnChangeColorSourceUnvisited = new System.Windows.Forms.Button();
			this.btnChangeColorSourceVisited = new System.Windows.Forms.Button();
			this.lblColorSourceUnvisited = new System.Windows.Forms.Label();
			this.lblColorSourceVisited = new System.Windows.Forms.Label();
			this.lblColorSourceBackgroundColor = new System.Windows.Forms.Label();
			this.grpHighlightingOptions = new System.Windows.Forms.GroupBox();
			this.mulHighlightExcludedCode = new NCoverExplorer.Core.Presentation.Controls.MultipleChoice();
			this.lblHighlightExcludedCode = new System.Windows.Forms.Label();
			this.mulHighlightUnvisitedCode = new NCoverExplorer.Core.Presentation.Controls.MultipleChoice();
			this.mulHighlightVisitedCode = new NCoverExplorer.Core.Presentation.Controls.MultipleChoice();
			this.lblHighlightUncoveredCode = new System.Windows.Forms.Label();
			this.lblHighlightVisitedCode = new System.Windows.Forms.Label();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.tabControl.SuspendLayout();
			this.tabPageCoverageTree.SuspendLayout();
			this.grpCoverageTolerance.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.trackSatisfactorySeqPts)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trackSatisfactoryThreshold)).BeginInit();
			this.grpTreeViewOptions.SuspendLayout();
			this.tabPageExclusions.SuspendLayout();
			this.grpExclusionAdd.SuspendLayout();
			this.tabPageOther.SuspendLayout();
			this.grpStartupOptions.SuspendLayout();
			this.grpOtherOptions.SuspendLayout();
			this.tabPageStatisticsColors.SuspendLayout();
			this.grpStatisticsListViewOptions.SuspendLayout();
			this.tabPageTreeColors.SuspendLayout();
			this.grpCoverageTreeColors.SuspendLayout();
			this.tabPageThemes.SuspendLayout();
			this.grpThemeOptions.SuspendLayout();
			this.pnlPreview.SuspendLayout();
			this.tabPageSourceCodeColors.SuspendLayout();
			this.grpSourceCodeColors.SuspendLayout();
			this.grpHighlightingOptions.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnOk
			// 
			this.btnOk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOk.Location = new System.Drawing.Point(230, 407);
			this.btnOk.Name = "btnOk";
			this.btnOk.TabIndex = 3;
			this.btnOk.Text = "Ok";
			this.btnOk.Click += new System.EventHandler(this._OnOkButtonClicked);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(311, 407);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 4;
			this.btnCancel.Text = "Cancel";
			// 
			// errorProvider
			// 
			this.errorProvider.ContainerControl = this;
			// 
			// ntxtSatisfactoryThreshold
			// 
			this.errorProvider.SetIconAlignment(this.ntxtSatisfactoryThreshold, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.ntxtSatisfactoryThreshold.Location = new System.Drawing.Point(284, 20);
			this.ntxtSatisfactoryThreshold.MaxLength = 5;
			this.ntxtSatisfactoryThreshold.Name = "ntxtSatisfactoryThreshold";
			this.ntxtSatisfactoryThreshold.Size = new System.Drawing.Size(32, 21);
			this.ntxtSatisfactoryThreshold.TabIndex = 2;
			this.ntxtSatisfactoryThreshold.Text = "0";
			this.ntxtSatisfactoryThreshold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.ntxtSatisfactoryThreshold.Leave += new System.EventHandler(this.ntxtSatisfactoryThreshold_Leave);
			// 
			// ntxtRecentFileMenuItems
			// 
			this.errorProvider.SetIconAlignment(this.ntxtRecentFileMenuItems, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.ntxtRecentFileMenuItems.Location = new System.Drawing.Point(192, 20);
			this.ntxtRecentFileMenuItems.MaxLength = 5;
			this.ntxtRecentFileMenuItems.Name = "ntxtRecentFileMenuItems";
			this.ntxtRecentFileMenuItems.Size = new System.Drawing.Size(39, 21);
			this.ntxtRecentFileMenuItems.TabIndex = 1;
			this.ntxtRecentFileMenuItems.Text = "0";
			this.ntxtRecentFileMenuItems.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// ntxtSatisfactorySeqPts
			// 
			this.errorProvider.SetIconAlignment(this.ntxtSatisfactorySeqPts, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.ntxtSatisfactorySeqPts.Location = new System.Drawing.Point(284, 60);
			this.ntxtSatisfactorySeqPts.MaxLength = 5;
			this.ntxtSatisfactorySeqPts.Name = "ntxtSatisfactorySeqPts";
			this.ntxtSatisfactorySeqPts.Size = new System.Drawing.Size(32, 21);
			this.ntxtSatisfactorySeqPts.TabIndex = 6;
			this.ntxtSatisfactorySeqPts.Text = "0";
			this.ntxtSatisfactorySeqPts.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.ntxtSatisfactorySeqPts.Leave += new System.EventHandler(this.ntxtSatisfactoryLines_Leave);
			// 
			// txtExclusionPattern
			// 
			this.errorProvider.SetIconAlignment(this.txtExclusionPattern, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtExclusionPattern.Location = new System.Drawing.Point(112, 48);
			this.txtExclusionPattern.MaxLength = 100;
			this.txtExclusionPattern.Name = "txtExclusionPattern";
			this.txtExclusionPattern.Size = new System.Drawing.Size(148, 21);
			this.txtExclusionPattern.TabIndex = 3;
			this.txtExclusionPattern.Text = "";
			// 
			// tabControl
			// 
			this.tabControl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl.Controls.Add(this.tabPageCoverageTree);
			this.tabControl.Controls.Add(this.tabPageExclusions);
			this.tabControl.Controls.Add(this.tabPageOther);
			this.tabControl.Controls.Add(this.tabPageThemes);
			this.tabControl.Controls.Add(this.tabPageTreeColors);
			this.tabControl.Controls.Add(this.tabPageSourceCodeColors);
			this.tabControl.Controls.Add(this.tabPageStatisticsColors);
			this.tabControl.Location = new System.Drawing.Point(12, 8);
			this.tabControl.Multiline = true;
			this.tabControl.Name = "tabControl";
			this.tabControl.SelectedIndex = 0;
			this.tabControl.Size = new System.Drawing.Size(376, 388);
			this.tabControl.SizeMode = System.Windows.Forms.TabSizeMode.FillToRight;
			this.tabControl.TabIndex = 0;
			// 
			// tabPageCoverageTree
			// 
			this.tabPageCoverageTree.Controls.Add(this.grpCoverageTolerance);
			this.tabPageCoverageTree.Controls.Add(this.grpTreeViewOptions);
			this.tabPageCoverageTree.Location = new System.Drawing.Point(4, 40);
			this.tabPageCoverageTree.Name = "tabPageCoverageTree";
			this.tabPageCoverageTree.Size = new System.Drawing.Size(368, 344);
			this.tabPageCoverageTree.TabIndex = 0;
			this.tabPageCoverageTree.Text = "Coverage Options";
			// 
			// grpCoverageTolerance
			// 
			this.grpCoverageTolerance.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpCoverageTolerance.Controls.Add(this.lblHelpSatisfactoryUnvisitedLines);
			this.grpCoverageTolerance.Controls.Add(this.lblHelpSatisfactoryPercentage);
			this.grpCoverageTolerance.Controls.Add(this.ntxtSatisfactorySeqPts);
			this.grpCoverageTolerance.Controls.Add(this.lblUnvisitedSeqPnts);
			this.grpCoverageTolerance.Controls.Add(this.lblThreshold);
			this.grpCoverageTolerance.Controls.Add(this.ntxtSatisfactoryThreshold);
			this.grpCoverageTolerance.Controls.Add(this.trackSatisfactorySeqPts);
			this.grpCoverageTolerance.Controls.Add(this.trackSatisfactoryThreshold);
			this.grpCoverageTolerance.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpCoverageTolerance.Location = new System.Drawing.Point(8, 96);
			this.grpCoverageTolerance.Name = "grpCoverageTolerance";
			this.grpCoverageTolerance.Size = new System.Drawing.Size(354, 112);
			this.grpCoverageTolerance.TabIndex = 1;
			this.grpCoverageTolerance.TabStop = false;
			this.grpCoverageTolerance.Text = " &Coverage Tolerances:";
			// 
			// lblHelpSatisfactoryUnvisitedLines
			// 
			this.lblHelpSatisfactoryUnvisitedLines.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblHelpSatisfactoryUnvisitedLines.Image = ((System.Drawing.Image)(resources.GetObject("lblHelpSatisfactoryUnvisitedLines.Image")));
			this.lblHelpSatisfactoryUnvisitedLines.Location = new System.Drawing.Point(320, 60);
			this.lblHelpSatisfactoryUnvisitedLines.Name = "lblHelpSatisfactoryUnvisitedLines";
			this.lblHelpSatisfactoryUnvisitedLines.Size = new System.Drawing.Size(20, 20);
			this.lblHelpSatisfactoryUnvisitedLines.TabIndex = 7;
			this.toolTip.SetToolTip(this.lblHelpSatisfactoryUnvisitedLines, "Partially covered tree nodes with this number of unvisited sequence points will b" +
				"e coloured differently.\r\nSpecify 0 to disable this feature.");
			// 
			// lblHelpSatisfactoryPercentage
			// 
			this.lblHelpSatisfactoryPercentage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblHelpSatisfactoryPercentage.Image = ((System.Drawing.Image)(resources.GetObject("lblHelpSatisfactoryPercentage.Image")));
			this.lblHelpSatisfactoryPercentage.Location = new System.Drawing.Point(320, 20);
			this.lblHelpSatisfactoryPercentage.Name = "lblHelpSatisfactoryPercentage";
			this.lblHelpSatisfactoryPercentage.Size = new System.Drawing.Size(20, 20);
			this.lblHelpSatisfactoryPercentage.TabIndex = 3;
			this.toolTip.SetToolTip(this.lblHelpSatisfactoryPercentage, "Partially covered tree nodes exceeding this percentage will be coloured different" +
				"ly.\r\nSpecify 100 (%) to disable this feature.");
			// 
			// lblUnvisitedSeqPnts
			// 
			this.lblUnvisitedSeqPnts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblUnvisitedSeqPnts.Location = new System.Drawing.Point(12, 64);
			this.lblUnvisitedSeqPnts.Name = "lblUnvisitedSeqPnts";
			this.lblUnvisitedSeqPnts.Size = new System.Drawing.Size(148, 15);
			this.lblUnvisitedSeqPnts.TabIndex = 4;
			this.lblUnvisitedSeqPnts.Text = "&Satisfactory Unvisited SeqPts:";
			// 
			// lblThreshold
			// 
			this.lblThreshold.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblThreshold.Location = new System.Drawing.Point(12, 24);
			this.lblThreshold.Name = "lblThreshold";
			this.lblThreshold.Size = new System.Drawing.Size(128, 15);
			this.lblThreshold.TabIndex = 0;
			this.lblThreshold.Text = "&Satisfactory Percentage:";
			// 
			// trackSatisfactorySeqPts
			// 
			this.trackSatisfactorySeqPts.Location = new System.Drawing.Point(180, 60);
			this.trackSatisfactorySeqPts.Name = "trackSatisfactorySeqPts";
			this.trackSatisfactorySeqPts.Size = new System.Drawing.Size(88, 45);
			this.trackSatisfactorySeqPts.TabIndex = 5;
			this.trackSatisfactorySeqPts.Value = 1;
			this.trackSatisfactorySeqPts.Scroll += new System.EventHandler(this.trackSatisfactoryLines_Scroll);
			// 
			// trackSatisfactoryThreshold
			// 
			this.trackSatisfactoryThreshold.Location = new System.Drawing.Point(180, 20);
			this.trackSatisfactoryThreshold.Maximum = 100;
			this.trackSatisfactoryThreshold.Name = "trackSatisfactoryThreshold";
			this.trackSatisfactoryThreshold.Size = new System.Drawing.Size(88, 45);
			this.trackSatisfactoryThreshold.TabIndex = 1;
			this.trackSatisfactoryThreshold.TickFrequency = 10;
			this.trackSatisfactoryThreshold.Value = 95;
			this.trackSatisfactoryThreshold.Scroll += new System.EventHandler(this.trackSatisfactoryThreshold_Scroll);
			// 
			// grpTreeViewOptions
			// 
			this.grpTreeViewOptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpTreeViewOptions.Controls.Add(this.mulFlattenNamespaces);
			this.grpTreeViewOptions.Controls.Add(this.mulTreeGrouping);
			this.grpTreeViewOptions.Controls.Add(this.lblNamespaceAppearance);
			this.grpTreeViewOptions.Controls.Add(this.lblGroupBy);
			this.grpTreeViewOptions.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpTreeViewOptions.Location = new System.Drawing.Point(8, 8);
			this.grpTreeViewOptions.Name = "grpTreeViewOptions";
			this.grpTreeViewOptions.Size = new System.Drawing.Size(354, 80);
			this.grpTreeViewOptions.TabIndex = 0;
			this.grpTreeViewOptions.TabStop = false;
			this.grpTreeViewOptions.Text = " &TreeView Options:";
			// 
			// mulFlattenNamespaces
			// 
			this.mulFlattenNamespaces.Location = new System.Drawing.Point(184, 48);
			this.mulFlattenNamespaces.Name = "mulFlattenNamespaces";
			this.mulFlattenNamespaces.Option1Text = "Flat";
			this.mulFlattenNamespaces.Option2Text = "Nested";
			this.mulFlattenNamespaces.Size = new System.Drawing.Size(148, 24);
			this.mulFlattenNamespaces.TabIndex = 5;
			// 
			// mulTreeGrouping
			// 
			this.mulTreeGrouping.Location = new System.Drawing.Point(184, 20);
			this.mulTreeGrouping.Name = "mulTreeGrouping";
			this.mulTreeGrouping.Option1Text = "Module";
			this.mulTreeGrouping.Option2Text = "Namespace";
			this.mulTreeGrouping.Size = new System.Drawing.Size(148, 24);
			this.mulTreeGrouping.TabIndex = 3;
			// 
			// lblNamespaceAppearance
			// 
			this.lblNamespaceAppearance.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNamespaceAppearance.Location = new System.Drawing.Point(12, 52);
			this.lblNamespaceAppearance.Name = "lblNamespaceAppearance";
			this.lblNamespaceAppearance.Size = new System.Drawing.Size(172, 20);
			this.lblNamespaceAppearance.TabIndex = 4;
			this.lblNamespaceAppearance.Text = "&Namespace Hierarchy:";
			// 
			// lblGroupBy
			// 
			this.lblGroupBy.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblGroupBy.Location = new System.Drawing.Point(12, 24);
			this.lblGroupBy.Name = "lblGroupBy";
			this.lblGroupBy.Size = new System.Drawing.Size(172, 20);
			this.lblGroupBy.TabIndex = 2;
			this.lblGroupBy.Text = "&Group Coverage File Results By:";
			// 
			// tabPageExclusions
			// 
			this.tabPageExclusions.Controls.Add(this.exclusionsListView);
			this.tabPageExclusions.Controls.Add(this.grpExclusionAdd);
			this.tabPageExclusions.Location = new System.Drawing.Point(4, 40);
			this.tabPageExclusions.Name = "tabPageExclusions";
			this.tabPageExclusions.Size = new System.Drawing.Size(368, 344);
			this.tabPageExclusions.TabIndex = 7;
			this.tabPageExclusions.Text = "Exclusions";
			// 
			// exclusionsListView
			// 
			this.exclusionsListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																								 this.lvcExclusionType,
																								 this.lvcExclusionPattern,
																								 this.lvcExclusionEnabled});
			this.exclusionsListView.FullRowSelect = true;
			this.exclusionsListView.GridLines = true;
			this.exclusionsListView.Location = new System.Drawing.Point(8, 8);
			this.exclusionsListView.Name = "exclusionsListView";
			this.exclusionsListView.Size = new System.Drawing.Size(352, 140);
			this.exclusionsListView.SmallImageList = this.imlExclusions;
			this.exclusionsListView.TabIndex = 0;
			this.exclusionsListView.View = System.Windows.Forms.View.Details;
			this.exclusionsListView.KeyDown += new System.Windows.Forms.KeyEventHandler(this._OnExclusionsListViewKeyDown);
			this.exclusionsListView.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this._OnExclusionsListViewColumnClick);
			// 
			// lvcExclusionType
			// 
			this.lvcExclusionType.Text = "Exclusion Type";
			this.lvcExclusionType.Width = 110;
			// 
			// lvcExclusionPattern
			// 
			this.lvcExclusionPattern.Text = "Pattern";
			this.lvcExclusionPattern.Width = 150;
			// 
			// lvcExclusionEnabled
			// 
			this.lvcExclusionEnabled.Text = "Enabled";
			this.lvcExclusionEnabled.Width = 70;
			// 
			// imlExclusions
			// 
			this.imlExclusions.ImageSize = new System.Drawing.Size(16, 16);
			this.imlExclusions.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlExclusions.ImageStream")));
			this.imlExclusions.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// grpExclusionAdd
			// 
			this.grpExclusionAdd.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpExclusionAdd.Controls.Add(this.lblPatternDescription);
			this.grpExclusionAdd.Controls.Add(this.btnExclusionAdd);
			this.grpExclusionAdd.Controls.Add(this.txtExclusionPattern);
			this.grpExclusionAdd.Controls.Add(this.lblExclusionPattern);
			this.grpExclusionAdd.Controls.Add(this.cboExclusionTypes);
			this.grpExclusionAdd.Controls.Add(this.lblExclusionType);
			this.grpExclusionAdd.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpExclusionAdd.Location = new System.Drawing.Point(8, 160);
			this.grpExclusionAdd.Name = "grpExclusionAdd";
			this.grpExclusionAdd.Size = new System.Drawing.Size(354, 152);
			this.grpExclusionAdd.TabIndex = 1;
			this.grpExclusionAdd.TabStop = false;
			this.grpExclusionAdd.Text = " &Add New Exclusion:";
			// 
			// lblPatternDescription
			// 
			this.lblPatternDescription.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblPatternDescription.Location = new System.Drawing.Point(24, 76);
			this.lblPatternDescription.Name = "lblPatternDescription";
			this.lblPatternDescription.Size = new System.Drawing.Size(316, 60);
			this.lblPatternDescription.TabIndex = 5;
			this.lblPatternDescription.Text = "Exclusion patterns should be made as specific as possible to ensure accurate matc" +
				"hes. They are case sensitive. You can specify wildcard matching by using an aste" +
				"risk \'*\'. Assembly matching is against the coverage.xml attribute value.";
			// 
			// btnExclusionAdd
			// 
			this.btnExclusionAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnExclusionAdd.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnExclusionAdd.Location = new System.Drawing.Point(268, 48);
			this.btnExclusionAdd.Name = "btnExclusionAdd";
			this.btnExclusionAdd.TabIndex = 4;
			this.btnExclusionAdd.Text = "&Add";
			this.btnExclusionAdd.Click += new System.EventHandler(this.btnExclusionAdd_Click);
			// 
			// lblExclusionPattern
			// 
			this.lblExclusionPattern.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblExclusionPattern.Location = new System.Drawing.Point(12, 52);
			this.lblExclusionPattern.Name = "lblExclusionPattern";
			this.lblExclusionPattern.Size = new System.Drawing.Size(88, 20);
			this.lblExclusionPattern.TabIndex = 2;
			this.lblExclusionPattern.Text = "&Pattern:";
			// 
			// cboExclusionTypes
			// 
			this.cboExclusionTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboExclusionTypes.Location = new System.Drawing.Point(112, 20);
			this.cboExclusionTypes.Name = "cboExclusionTypes";
			this.cboExclusionTypes.Size = new System.Drawing.Size(104, 21);
			this.cboExclusionTypes.TabIndex = 1;
			// 
			// lblExclusionType
			// 
			this.lblExclusionType.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblExclusionType.Location = new System.Drawing.Point(12, 24);
			this.lblExclusionType.Name = "lblExclusionType";
			this.lblExclusionType.Size = new System.Drawing.Size(88, 20);
			this.lblExclusionType.TabIndex = 0;
			this.lblExclusionType.Text = "&Exclusion Type:";
			// 
			// tabPageOther
			// 
			this.tabPageOther.Controls.Add(this.grpStartupOptions);
			this.tabPageOther.Controls.Add(this.grpOtherOptions);
			this.tabPageOther.Location = new System.Drawing.Point(4, 40);
			this.tabPageOther.Name = "tabPageOther";
			this.tabPageOther.Size = new System.Drawing.Size(368, 344);
			this.tabPageOther.TabIndex = 3;
			this.tabPageOther.Text = "Other Options";
			// 
			// grpStartupOptions
			// 
			this.grpStartupOptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpStartupOptions.Controls.Add(this.lblHelpRestoreSelectionOnReload);
			this.grpStartupOptions.Controls.Add(this.chkRestoreSelectionOnReload);
			this.grpStartupOptions.Controls.Add(this.lblRestoreSelectionOnReload);
			this.grpStartupOptions.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpStartupOptions.Location = new System.Drawing.Point(8, 8);
			this.grpStartupOptions.Name = "grpStartupOptions";
			this.grpStartupOptions.Size = new System.Drawing.Size(354, 56);
			this.grpStartupOptions.TabIndex = 4;
			this.grpStartupOptions.TabStop = false;
			this.grpStartupOptions.Text = " &Startup Options:";
			// 
			// lblHelpRestoreSelectionOnReload
			// 
			this.lblHelpRestoreSelectionOnReload.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblHelpRestoreSelectionOnReload.Image = ((System.Drawing.Image)(resources.GetObject("lblHelpRestoreSelectionOnReload.Image")));
			this.lblHelpRestoreSelectionOnReload.Location = new System.Drawing.Point(216, 20);
			this.lblHelpRestoreSelectionOnReload.Name = "lblHelpRestoreSelectionOnReload";
			this.lblHelpRestoreSelectionOnReload.Size = new System.Drawing.Size(20, 24);
			this.lblHelpRestoreSelectionOnReload.TabIndex = 9;
			this.toolTip.SetToolTip(this.lblHelpRestoreSelectionOnReload, "When reloading the same coverage file, attempt to restore the selected tree node " +
				"and cursor position.\r\nUseful when repeatedly using \"Test With Coverage\" from Tes" +
				"tDriven.Net.");
			// 
			// chkRestoreSelectionOnReload
			// 
			this.chkRestoreSelectionOnReload.Location = new System.Drawing.Point(192, 20);
			this.chkRestoreSelectionOnReload.Name = "chkRestoreSelectionOnReload";
			this.chkRestoreSelectionOnReload.Size = new System.Drawing.Size(30, 24);
			this.chkRestoreSelectionOnReload.TabIndex = 8;
			// 
			// lblRestoreSelectionOnReload
			// 
			this.lblRestoreSelectionOnReload.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblRestoreSelectionOnReload.Location = new System.Drawing.Point(12, 24);
			this.lblRestoreSelectionOnReload.Name = "lblRestoreSelectionOnReload";
			this.lblRestoreSelectionOnReload.Size = new System.Drawing.Size(177, 20);
			this.lblRestoreSelectionOnReload.TabIndex = 0;
			this.lblRestoreSelectionOnReload.Text = "&Restore Selection On Reload:";
			// 
			// grpOtherOptions
			// 
			this.grpOtherOptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpOtherOptions.Controls.Add(this.ntxtRecentFileMenuItems);
			this.grpOtherOptions.Controls.Add(this.lblRecentFileMenuItems);
			this.grpOtherOptions.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpOtherOptions.Location = new System.Drawing.Point(8, 72);
			this.grpOtherOptions.Name = "grpOtherOptions";
			this.grpOtherOptions.Size = new System.Drawing.Size(354, 56);
			this.grpOtherOptions.TabIndex = 3;
			this.grpOtherOptions.TabStop = false;
			this.grpOtherOptions.Text = " &Other Options:";
			// 
			// lblRecentFileMenuItems
			// 
			this.lblRecentFileMenuItems.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblRecentFileMenuItems.Location = new System.Drawing.Point(12, 24);
			this.lblRecentFileMenuItems.Name = "lblRecentFileMenuItems";
			this.lblRecentFileMenuItems.Size = new System.Drawing.Size(177, 20);
			this.lblRecentFileMenuItems.TabIndex = 0;
			this.lblRecentFileMenuItems.Text = "&Recent File Menu Items:";
			// 
			// tabPageStatisticsColors
			// 
			this.tabPageStatisticsColors.Controls.Add(this.grpStatisticsListViewOptions);
			this.tabPageStatisticsColors.Location = new System.Drawing.Point(4, 40);
			this.tabPageStatisticsColors.Name = "tabPageStatisticsColors";
			this.tabPageStatisticsColors.Size = new System.Drawing.Size(368, 344);
			this.tabPageStatisticsColors.TabIndex = 4;
			this.tabPageStatisticsColors.Text = "Statistics";
			// 
			// grpStatisticsListViewOptions
			// 
			this.grpStatisticsListViewOptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpStatisticsListViewOptions.Controls.Add(this.lblDisplayFontStatistics);
			this.grpStatisticsListViewOptions.Controls.Add(this.btnChangeFontStatistics);
			this.grpStatisticsListViewOptions.Controls.Add(this.btnChangeColorStatisticsBackground);
			this.grpStatisticsListViewOptions.Controls.Add(this.lblStatisticsBackground);
			this.grpStatisticsListViewOptions.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpStatisticsListViewOptions.Location = new System.Drawing.Point(8, 8);
			this.grpStatisticsListViewOptions.Name = "grpStatisticsListViewOptions";
			this.grpStatisticsListViewOptions.Size = new System.Drawing.Size(354, 88);
			this.grpStatisticsListViewOptions.TabIndex = 4;
			this.grpStatisticsListViewOptions.TabStop = false;
			this.grpStatisticsListViewOptions.Text = " &Statistics Pane Appearance:";
			// 
			// lblDisplayFontStatistics
			// 
			this.lblDisplayFontStatistics.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayFontStatistics.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayFontStatistics.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDisplayFontStatistics.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayFontStatistics.Location = new System.Drawing.Point(12, 24);
			this.lblDisplayFontStatistics.Name = "lblDisplayFontStatistics";
			this.lblDisplayFontStatistics.Size = new System.Drawing.Size(244, 23);
			this.lblDisplayFontStatistics.TabIndex = 23;
			this.lblDisplayFontStatistics.Text = "Tahoma, 8.25pt";
			this.lblDisplayFontStatistics.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnChangeFontStatistics
			// 
			this.btnChangeFontStatistics.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeFontStatistics.Location = new System.Drawing.Point(268, 24);
			this.btnChangeFontStatistics.Name = "btnChangeFontStatistics";
			this.btnChangeFontStatistics.TabIndex = 24;
			this.btnChangeFontStatistics.Text = "&Font...";
			this.btnChangeFontStatistics.Click += new System.EventHandler(this.btnChangeFontStatistics_Click);
			// 
			// btnChangeColorStatisticsBackground
			// 
			this.btnChangeColorStatisticsBackground.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnChangeColorStatisticsBackground.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorStatisticsBackground.Location = new System.Drawing.Point(268, 52);
			this.btnChangeColorStatisticsBackground.Name = "btnChangeColorStatisticsBackground";
			this.btnChangeColorStatisticsBackground.TabIndex = 23;
			this.btnChangeColorStatisticsBackground.Text = "&Change...";
			this.btnChangeColorStatisticsBackground.Click += new System.EventHandler(this.btnChangeColorStatisticsBackground_Click);
			// 
			// lblStatisticsBackground
			// 
			this.lblStatisticsBackground.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblStatisticsBackground.Location = new System.Drawing.Point(12, 56);
			this.lblStatisticsBackground.Name = "lblStatisticsBackground";
			this.lblStatisticsBackground.Size = new System.Drawing.Size(104, 20);
			this.lblStatisticsBackground.TabIndex = 22;
			this.lblStatisticsBackground.Text = "Background Colour:";
			// 
			// tabPageTreeColors
			// 
			this.tabPageTreeColors.Controls.Add(this.grpCoverageTreeColors);
			this.tabPageTreeColors.Location = new System.Drawing.Point(4, 40);
			this.tabPageTreeColors.Name = "tabPageTreeColors";
			this.tabPageTreeColors.Size = new System.Drawing.Size(368, 344);
			this.tabPageTreeColors.TabIndex = 1;
			this.tabPageTreeColors.Text = "Coverage Tree";
			// 
			// grpCoverageTreeColors
			// 
			this.grpCoverageTreeColors.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpCoverageTreeColors.Controls.Add(this.lblDisplayColorTreeExcludedCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.btnChangeColorTreeExcludedCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblColorTreeExcludedCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblDisplayFontTree);
			this.grpCoverageTreeColors.Controls.Add(this.btnChangeFontTree);
			this.grpCoverageTreeColors.Controls.Add(this.btnChangeColorTreeBackground);
			this.grpCoverageTreeColors.Controls.Add(this.lblColorTreeBackground);
			this.grpCoverageTreeColors.Controls.Add(this.lblDisplayColorTreeNoCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblDisplayColorTreePartialCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblDisplayColorTreeSatisfactoryCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblDisplayColorTreeFullCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.btnChangeColorTreeNoCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblColorTreeNoCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.btnChangeColorTreePartialCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblColorTreePartialCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.btnChangeColorTreeSatisfactoryCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.btnChangeColorTreeFullCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblColorTreeSatisfactoryCoverage);
			this.grpCoverageTreeColors.Controls.Add(this.lblColorTreeFullCoverage);
			this.grpCoverageTreeColors.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpCoverageTreeColors.Location = new System.Drawing.Point(8, 8);
			this.grpCoverageTreeColors.Name = "grpCoverageTreeColors";
			this.grpCoverageTreeColors.Size = new System.Drawing.Size(354, 236);
			this.grpCoverageTreeColors.TabIndex = 0;
			this.grpCoverageTreeColors.TabStop = false;
			this.grpCoverageTreeColors.Text = " Coverage Tree Colours:";
			// 
			// lblDisplayColorTreeExcludedCoverage
			// 
			this.lblDisplayColorTreeExcludedCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblDisplayColorTreeExcludedCoverage.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorTreeExcludedCoverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorTreeExcludedCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorTreeExcludedCoverage.Location = new System.Drawing.Point(128, 136);
			this.lblDisplayColorTreeExcludedCoverage.Name = "lblDisplayColorTreeExcludedCoverage";
			this.lblDisplayColorTreeExcludedCoverage.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorTreeExcludedCoverage.TabIndex = 13;
			this.lblDisplayColorTreeExcludedCoverage.Text = "Excluded";
			this.lblDisplayColorTreeExcludedCoverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnChangeColorTreeExcludedCoverage
			// 
			this.btnChangeColorTreeExcludedCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeColorTreeExcludedCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorTreeExcludedCoverage.Location = new System.Drawing.Point(268, 136);
			this.btnChangeColorTreeExcludedCoverage.Name = "btnChangeColorTreeExcludedCoverage";
			this.btnChangeColorTreeExcludedCoverage.TabIndex = 14;
			this.btnChangeColorTreeExcludedCoverage.Text = "&Change...";
			this.btnChangeColorTreeExcludedCoverage.Click += new System.EventHandler(this.btnChangeColorTreeExcludedCoverage_Click);
			// 
			// lblColorTreeExcludedCoverage
			// 
			this.lblColorTreeExcludedCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorTreeExcludedCoverage.Location = new System.Drawing.Point(12, 140);
			this.lblColorTreeExcludedCoverage.Name = "lblColorTreeExcludedCoverage";
			this.lblColorTreeExcludedCoverage.Size = new System.Drawing.Size(100, 20);
			this.lblColorTreeExcludedCoverage.TabIndex = 12;
			this.lblColorTreeExcludedCoverage.Text = "Excluded:";
			// 
			// lblDisplayFontTree
			// 
			this.lblDisplayFontTree.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblDisplayFontTree.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayFontTree.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayFontTree.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDisplayFontTree.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayFontTree.Location = new System.Drawing.Point(12, 173);
			this.lblDisplayFontTree.Name = "lblDisplayFontTree";
			this.lblDisplayFontTree.Size = new System.Drawing.Size(244, 23);
			this.lblDisplayFontTree.TabIndex = 15;
			this.lblDisplayFontTree.Text = "Tahoma, 8.25pt";
			this.lblDisplayFontTree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnChangeFontTree
			// 
			this.btnChangeFontTree.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeFontTree.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeFontTree.Location = new System.Drawing.Point(268, 173);
			this.btnChangeFontTree.Name = "btnChangeFontTree";
			this.btnChangeFontTree.TabIndex = 16;
			this.btnChangeFontTree.Text = "&Font...";
			this.btnChangeFontTree.Click += new System.EventHandler(this.btnChangeFontTree_Click);
			// 
			// btnChangeColorTreeBackground
			// 
			this.btnChangeColorTreeBackground.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeColorTreeBackground.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnChangeColorTreeBackground.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorTreeBackground.Location = new System.Drawing.Point(268, 200);
			this.btnChangeColorTreeBackground.Name = "btnChangeColorTreeBackground";
			this.btnChangeColorTreeBackground.TabIndex = 18;
			this.btnChangeColorTreeBackground.Text = "&Change...";
			this.btnChangeColorTreeBackground.Click += new System.EventHandler(this.btnChangeColorTreeBackground_Click);
			// 
			// lblColorTreeBackground
			// 
			this.lblColorTreeBackground.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorTreeBackground.Location = new System.Drawing.Point(12, 204);
			this.lblColorTreeBackground.Name = "lblColorTreeBackground";
			this.lblColorTreeBackground.Size = new System.Drawing.Size(104, 20);
			this.lblColorTreeBackground.TabIndex = 17;
			this.lblColorTreeBackground.Text = "Background Colour:";
			// 
			// lblDisplayColorTreeNoCoverage
			// 
			this.lblDisplayColorTreeNoCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblDisplayColorTreeNoCoverage.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorTreeNoCoverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorTreeNoCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorTreeNoCoverage.Location = new System.Drawing.Point(128, 108);
			this.lblDisplayColorTreeNoCoverage.Name = "lblDisplayColorTreeNoCoverage";
			this.lblDisplayColorTreeNoCoverage.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorTreeNoCoverage.TabIndex = 10;
			this.lblDisplayColorTreeNoCoverage.Text = "No Coverage (0%)";
			this.lblDisplayColorTreeNoCoverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblDisplayColorTreePartialCoverage
			// 
			this.lblDisplayColorTreePartialCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblDisplayColorTreePartialCoverage.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorTreePartialCoverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorTreePartialCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorTreePartialCoverage.Location = new System.Drawing.Point(128, 80);
			this.lblDisplayColorTreePartialCoverage.Name = "lblDisplayColorTreePartialCoverage";
			this.lblDisplayColorTreePartialCoverage.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorTreePartialCoverage.TabIndex = 7;
			this.lblDisplayColorTreePartialCoverage.Text = "Partial Coverage (50%)";
			this.lblDisplayColorTreePartialCoverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblDisplayColorTreeSatisfactoryCoverage
			// 
			this.lblDisplayColorTreeSatisfactoryCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblDisplayColorTreeSatisfactoryCoverage.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorTreeSatisfactoryCoverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorTreeSatisfactoryCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorTreeSatisfactoryCoverage.Location = new System.Drawing.Point(128, 52);
			this.lblDisplayColorTreeSatisfactoryCoverage.Name = "lblDisplayColorTreeSatisfactoryCoverage";
			this.lblDisplayColorTreeSatisfactoryCoverage.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorTreeSatisfactoryCoverage.TabIndex = 4;
			this.lblDisplayColorTreeSatisfactoryCoverage.Text = "Satisfactory (95%)";
			this.lblDisplayColorTreeSatisfactoryCoverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblDisplayColorTreeFullCoverage
			// 
			this.lblDisplayColorTreeFullCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.lblDisplayColorTreeFullCoverage.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorTreeFullCoverage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorTreeFullCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorTreeFullCoverage.Location = new System.Drawing.Point(128, 24);
			this.lblDisplayColorTreeFullCoverage.Name = "lblDisplayColorTreeFullCoverage";
			this.lblDisplayColorTreeFullCoverage.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorTreeFullCoverage.TabIndex = 1;
			this.lblDisplayColorTreeFullCoverage.Text = "Full Coverage (100%)";
			this.lblDisplayColorTreeFullCoverage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnChangeColorTreeNoCoverage
			// 
			this.btnChangeColorTreeNoCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeColorTreeNoCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorTreeNoCoverage.Location = new System.Drawing.Point(268, 108);
			this.btnChangeColorTreeNoCoverage.Name = "btnChangeColorTreeNoCoverage";
			this.btnChangeColorTreeNoCoverage.TabIndex = 11;
			this.btnChangeColorTreeNoCoverage.Text = "&Change...";
			this.btnChangeColorTreeNoCoverage.Click += new System.EventHandler(this.btnChangeColorTreeNoCoverage_Click);
			// 
			// lblColorTreeNoCoverage
			// 
			this.lblColorTreeNoCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorTreeNoCoverage.Location = new System.Drawing.Point(12, 112);
			this.lblColorTreeNoCoverage.Name = "lblColorTreeNoCoverage";
			this.lblColorTreeNoCoverage.Size = new System.Drawing.Size(100, 20);
			this.lblColorTreeNoCoverage.TabIndex = 9;
			this.lblColorTreeNoCoverage.Text = "No Coverage:";
			// 
			// btnChangeColorTreePartialCoverage
			// 
			this.btnChangeColorTreePartialCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeColorTreePartialCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorTreePartialCoverage.Location = new System.Drawing.Point(268, 80);
			this.btnChangeColorTreePartialCoverage.Name = "btnChangeColorTreePartialCoverage";
			this.btnChangeColorTreePartialCoverage.TabIndex = 8;
			this.btnChangeColorTreePartialCoverage.Text = "&Change...";
			this.btnChangeColorTreePartialCoverage.Click += new System.EventHandler(this.btnChangeColorTreePartialCoverage_Click);
			// 
			// lblColorTreePartialCoverage
			// 
			this.lblColorTreePartialCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorTreePartialCoverage.Location = new System.Drawing.Point(12, 84);
			this.lblColorTreePartialCoverage.Name = "lblColorTreePartialCoverage";
			this.lblColorTreePartialCoverage.Size = new System.Drawing.Size(100, 20);
			this.lblColorTreePartialCoverage.TabIndex = 6;
			this.lblColorTreePartialCoverage.Text = "Partial Coverage:";
			// 
			// btnChangeColorTreeSatisfactoryCoverage
			// 
			this.btnChangeColorTreeSatisfactoryCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeColorTreeSatisfactoryCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorTreeSatisfactoryCoverage.Location = new System.Drawing.Point(268, 52);
			this.btnChangeColorTreeSatisfactoryCoverage.Name = "btnChangeColorTreeSatisfactoryCoverage";
			this.btnChangeColorTreeSatisfactoryCoverage.TabIndex = 5;
			this.btnChangeColorTreeSatisfactoryCoverage.Text = "&Change...";
			this.btnChangeColorTreeSatisfactoryCoverage.Click += new System.EventHandler(this.btnChangeColorTreeSatisfactoryCoverage_Click);
			// 
			// btnChangeColorTreeFullCoverage
			// 
			this.btnChangeColorTreeFullCoverage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeColorTreeFullCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorTreeFullCoverage.Location = new System.Drawing.Point(268, 24);
			this.btnChangeColorTreeFullCoverage.Name = "btnChangeColorTreeFullCoverage";
			this.btnChangeColorTreeFullCoverage.TabIndex = 2;
			this.btnChangeColorTreeFullCoverage.Text = "&Change...";
			this.btnChangeColorTreeFullCoverage.Click += new System.EventHandler(this.btnChangeColorTreeFullCoverage_Click);
			// 
			// lblColorTreeSatisfactoryCoverage
			// 
			this.lblColorTreeSatisfactoryCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorTreeSatisfactoryCoverage.Location = new System.Drawing.Point(12, 56);
			this.lblColorTreeSatisfactoryCoverage.Name = "lblColorTreeSatisfactoryCoverage";
			this.lblColorTreeSatisfactoryCoverage.Size = new System.Drawing.Size(100, 20);
			this.lblColorTreeSatisfactoryCoverage.TabIndex = 3;
			this.lblColorTreeSatisfactoryCoverage.Text = "Satisfactory:";
			// 
			// lblColorTreeFullCoverage
			// 
			this.lblColorTreeFullCoverage.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorTreeFullCoverage.Location = new System.Drawing.Point(12, 28);
			this.lblColorTreeFullCoverage.Name = "lblColorTreeFullCoverage";
			this.lblColorTreeFullCoverage.Size = new System.Drawing.Size(100, 20);
			this.lblColorTreeFullCoverage.TabIndex = 0;
			this.lblColorTreeFullCoverage.Text = "Full Coverage:";
			// 
			// tabPageThemes
			// 
			this.tabPageThemes.Controls.Add(this.grpThemeOptions);
			this.tabPageThemes.Location = new System.Drawing.Point(4, 40);
			this.tabPageThemes.Name = "tabPageThemes";
			this.tabPageThemes.Size = new System.Drawing.Size(368, 344);
			this.tabPageThemes.TabIndex = 5;
			this.tabPageThemes.Text = "Themes";
			// 
			// grpThemeOptions
			// 
			this.grpThemeOptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpThemeOptions.Controls.Add(this.pnlPreview);
			this.grpThemeOptions.Controls.Add(this.lblThemePreview);
			this.grpThemeOptions.Controls.Add(this.lblThemeReset);
			this.grpThemeOptions.Controls.Add(this.btnThemeResetDefaults);
			this.grpThemeOptions.Controls.Add(this.lblTheme);
			this.grpThemeOptions.Controls.Add(this.btnThemeDelete);
			this.grpThemeOptions.Controls.Add(this.btnThemeSaveAs);
			this.grpThemeOptions.Controls.Add(this.cboThemes);
			this.grpThemeOptions.Controls.Add(this.lblThemeDescription);
			this.grpThemeOptions.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpThemeOptions.Location = new System.Drawing.Point(8, 8);
			this.grpThemeOptions.Name = "grpThemeOptions";
			this.grpThemeOptions.Size = new System.Drawing.Size(354, 256);
			this.grpThemeOptions.TabIndex = 0;
			this.grpThemeOptions.TabStop = false;
			this.grpThemeOptions.Text = " &Appearance Themes:";
			// 
			// pnlPreview
			// 
			this.pnlPreview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPreview.Controls.Add(this.pnlPreviewSource);
			this.pnlPreview.Controls.Add(this.pnlPreviewStatistics);
			this.pnlPreview.Controls.Add(this.pnlPreviewTree);
			this.pnlPreview.Location = new System.Drawing.Point(112, 132);
			this.pnlPreview.Name = "pnlPreview";
			this.pnlPreview.Size = new System.Drawing.Size(148, 80);
			this.pnlPreview.TabIndex = 11;
			// 
			// pnlPreviewSource
			// 
			this.pnlPreviewSource.BackColor = System.Drawing.SystemColors.Window;
			this.pnlPreviewSource.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPreviewSource.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlPreviewSource.Location = new System.Drawing.Point(56, 24);
			this.pnlPreviewSource.Name = "pnlPreviewSource";
			this.pnlPreviewSource.Size = new System.Drawing.Size(90, 54);
			this.pnlPreviewSource.TabIndex = 14;
			// 
			// pnlPreviewStatistics
			// 
			this.pnlPreviewStatistics.BackColor = System.Drawing.SystemColors.Window;
			this.pnlPreviewStatistics.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPreviewStatistics.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlPreviewStatistics.Location = new System.Drawing.Point(56, 0);
			this.pnlPreviewStatistics.Name = "pnlPreviewStatistics";
			this.pnlPreviewStatistics.Size = new System.Drawing.Size(90, 24);
			this.pnlPreviewStatistics.TabIndex = 13;
			// 
			// pnlPreviewTree
			// 
			this.pnlPreviewTree.BackColor = System.Drawing.SystemColors.Window;
			this.pnlPreviewTree.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPreviewTree.Dock = System.Windows.Forms.DockStyle.Left;
			this.pnlPreviewTree.Location = new System.Drawing.Point(0, 0);
			this.pnlPreviewTree.Name = "pnlPreviewTree";
			this.pnlPreviewTree.Size = new System.Drawing.Size(56, 78);
			this.pnlPreviewTree.TabIndex = 12;
			// 
			// lblThemePreview
			// 
			this.lblThemePreview.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblThemePreview.Location = new System.Drawing.Point(12, 136);
			this.lblThemePreview.Name = "lblThemePreview";
			this.lblThemePreview.Size = new System.Drawing.Size(52, 20);
			this.lblThemePreview.TabIndex = 10;
			this.lblThemePreview.Text = "Pre&view:";
			// 
			// lblThemeReset
			// 
			this.lblThemeReset.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblThemeReset.Location = new System.Drawing.Point(12, 224);
			this.lblThemeReset.Name = "lblThemeReset";
			this.lblThemeReset.Size = new System.Drawing.Size(224, 20);
			this.lblThemeReset.TabIndex = 9;
			this.lblThemeReset.Text = "Reset Theme To &NCoverExplorer Default:";
			// 
			// btnThemeResetDefaults
			// 
			this.btnThemeResetDefaults.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnThemeResetDefaults.Location = new System.Drawing.Point(268, 220);
			this.btnThemeResetDefaults.Name = "btnThemeResetDefaults";
			this.btnThemeResetDefaults.Size = new System.Drawing.Size(76, 23);
			this.btnThemeResetDefaults.TabIndex = 8;
			this.btnThemeResetDefaults.Text = "&Reset";
			this.btnThemeResetDefaults.Click += new System.EventHandler(this.btnThemeResetDefaults_Click);
			// 
			// lblTheme
			// 
			this.lblTheme.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblTheme.Location = new System.Drawing.Point(12, 78);
			this.lblTheme.Name = "lblTheme";
			this.lblTheme.Size = new System.Drawing.Size(56, 20);
			this.lblTheme.TabIndex = 0;
			this.lblTheme.Text = "&Theme:";
			// 
			// btnThemeDelete
			// 
			this.btnThemeDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnThemeDelete.Enabled = false;
			this.btnThemeDelete.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnThemeDelete.Location = new System.Drawing.Point(268, 96);
			this.btnThemeDelete.Name = "btnThemeDelete";
			this.btnThemeDelete.TabIndex = 3;
			this.btnThemeDelete.Text = "&Delete";
			this.btnThemeDelete.Click += new System.EventHandler(this.btnThemeDelete_Click);
			// 
			// btnThemeSaveAs
			// 
			this.btnThemeSaveAs.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnThemeSaveAs.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnThemeSaveAs.Location = new System.Drawing.Point(184, 96);
			this.btnThemeSaveAs.Name = "btnThemeSaveAs";
			this.btnThemeSaveAs.TabIndex = 2;
			this.btnThemeSaveAs.Text = "&Save As...";
			this.btnThemeSaveAs.Click += new System.EventHandler(this.btnThemeSaveAs_Click);
			// 
			// cboThemes
			// 
			this.cboThemes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cboThemes.Location = new System.Drawing.Point(12, 98);
			this.cboThemes.Name = "cboThemes";
			this.cboThemes.Size = new System.Drawing.Size(164, 21);
			this.cboThemes.Sorted = true;
			this.cboThemes.TabIndex = 1;
			// 
			// lblThemeDescription
			// 
			this.lblThemeDescription.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblThemeDescription.Location = new System.Drawing.Point(12, 24);
			this.lblThemeDescription.Name = "lblThemeDescription";
			this.lblThemeDescription.Size = new System.Drawing.Size(332, 48);
			this.lblThemeDescription.TabIndex = 0;
			this.lblThemeDescription.Text = "A theme is a combined set of colour and font choices for NCoverExplorer. The them" +
				"e can be customised on the following Coverage Tree, Statistics and Source Code t" +
				"abs.";
			// 
			// tabPageSourceCodeColors
			// 
			this.tabPageSourceCodeColors.Controls.Add(this.grpSourceCodeColors);
			this.tabPageSourceCodeColors.Controls.Add(this.grpHighlightingOptions);
			this.tabPageSourceCodeColors.Location = new System.Drawing.Point(4, 40);
			this.tabPageSourceCodeColors.Name = "tabPageSourceCodeColors";
			this.tabPageSourceCodeColors.Size = new System.Drawing.Size(368, 344);
			this.tabPageSourceCodeColors.TabIndex = 6;
			this.tabPageSourceCodeColors.Text = "Source Code";
			// 
			// grpSourceCodeColors
			// 
			this.grpSourceCodeColors.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpSourceCodeColors.Controls.Add(this.lblColorSourceExcluded);
			this.grpSourceCodeColors.Controls.Add(this.lblDisplayColorSourceExcluded);
			this.grpSourceCodeColors.Controls.Add(this.btnChangeColorSourceExcluded);
			this.grpSourceCodeColors.Controls.Add(this.btnChangeColorSourceBackground);
			this.grpSourceCodeColors.Controls.Add(this.btnChangeColorSourceLineNumbers);
			this.grpSourceCodeColors.Controls.Add(this.lblDisplayColorSourceLineNumbers);
			this.grpSourceCodeColors.Controls.Add(this.lblColorSourceLineNumbers);
			this.grpSourceCodeColors.Controls.Add(this.lblDisplayFontSource);
			this.grpSourceCodeColors.Controls.Add(this.btnChangeFontSource);
			this.grpSourceCodeColors.Controls.Add(this.lblDisplayColorSourceUnvisited);
			this.grpSourceCodeColors.Controls.Add(this.lblDisplayColorSourceVisited);
			this.grpSourceCodeColors.Controls.Add(this.btnChangeColorSourceUnvisited);
			this.grpSourceCodeColors.Controls.Add(this.btnChangeColorSourceVisited);
			this.grpSourceCodeColors.Controls.Add(this.lblColorSourceUnvisited);
			this.grpSourceCodeColors.Controls.Add(this.lblColorSourceVisited);
			this.grpSourceCodeColors.Controls.Add(this.lblColorSourceBackgroundColor);
			this.grpSourceCodeColors.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpSourceCodeColors.Location = new System.Drawing.Point(8, 124);
			this.grpSourceCodeColors.Name = "grpSourceCodeColors";
			this.grpSourceCodeColors.Size = new System.Drawing.Size(354, 208);
			this.grpSourceCodeColors.TabIndex = 1;
			this.grpSourceCodeColors.TabStop = false;
			this.grpSourceCodeColors.Text = " &Source Code Colours:";
			// 
			// lblColorSourceExcluded
			// 
			this.lblColorSourceExcluded.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorSourceExcluded.Location = new System.Drawing.Point(12, 84);
			this.lblColorSourceExcluded.Name = "lblColorSourceExcluded";
			this.lblColorSourceExcluded.Size = new System.Drawing.Size(100, 20);
			this.lblColorSourceExcluded.TabIndex = 6;
			this.lblColorSourceExcluded.Text = "E&xcluded Code:";
			// 
			// lblDisplayColorSourceExcluded
			// 
			this.lblDisplayColorSourceExcluded.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorSourceExcluded.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorSourceExcluded.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorSourceExcluded.Location = new System.Drawing.Point(128, 80);
			this.lblDisplayColorSourceExcluded.Name = "lblDisplayColorSourceExcluded";
			this.lblDisplayColorSourceExcluded.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorSourceExcluded.TabIndex = 7;
			this.lblDisplayColorSourceExcluded.Text = "Source Code Excluded";
			this.lblDisplayColorSourceExcluded.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnChangeColorSourceExcluded
			// 
			this.btnChangeColorSourceExcluded.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorSourceExcluded.Location = new System.Drawing.Point(268, 80);
			this.btnChangeColorSourceExcluded.Name = "btnChangeColorSourceExcluded";
			this.btnChangeColorSourceExcluded.TabIndex = 8;
			this.btnChangeColorSourceExcluded.Text = "&Change...";
			this.btnChangeColorSourceExcluded.Click += new System.EventHandler(this.btnChangeColorSourceExcluded_Click);
			// 
			// btnChangeColorSourceBackground
			// 
			this.btnChangeColorSourceBackground.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnChangeColorSourceBackground.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.btnChangeColorSourceBackground.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorSourceBackground.Location = new System.Drawing.Point(268, 172);
			this.btnChangeColorSourceBackground.Name = "btnChangeColorSourceBackground";
			this.btnChangeColorSourceBackground.TabIndex = 15;
			this.btnChangeColorSourceBackground.Text = "&Change...";
			this.btnChangeColorSourceBackground.Click += new System.EventHandler(this.btnChangeColorSourceBackground_Click);
			// 
			// btnChangeColorSourceLineNumbers
			// 
			this.btnChangeColorSourceLineNumbers.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorSourceLineNumbers.Location = new System.Drawing.Point(268, 144);
			this.btnChangeColorSourceLineNumbers.Name = "btnChangeColorSourceLineNumbers";
			this.btnChangeColorSourceLineNumbers.TabIndex = 13;
			this.btnChangeColorSourceLineNumbers.Text = "&Change...";
			this.btnChangeColorSourceLineNumbers.Click += new System.EventHandler(this.btnChangeColorSourceLineNumbers_Click);
			// 
			// lblDisplayColorSourceLineNumbers
			// 
			this.lblDisplayColorSourceLineNumbers.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorSourceLineNumbers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorSourceLineNumbers.ForeColor = System.Drawing.SystemColors.ControlDark;
			this.lblDisplayColorSourceLineNumbers.Location = new System.Drawing.Point(128, 144);
			this.lblDisplayColorSourceLineNumbers.Name = "lblDisplayColorSourceLineNumbers";
			this.lblDisplayColorSourceLineNumbers.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorSourceLineNumbers.TabIndex = 12;
			this.lblDisplayColorSourceLineNumbers.Text = "10";
			this.lblDisplayColorSourceLineNumbers.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblColorSourceLineNumbers
			// 
			this.lblColorSourceLineNumbers.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorSourceLineNumbers.Location = new System.Drawing.Point(12, 148);
			this.lblColorSourceLineNumbers.Name = "lblColorSourceLineNumbers";
			this.lblColorSourceLineNumbers.Size = new System.Drawing.Size(100, 20);
			this.lblColorSourceLineNumbers.TabIndex = 11;
			this.lblColorSourceLineNumbers.Text = "&Line Numbers:";
			// 
			// lblDisplayFontSource
			// 
			this.lblDisplayFontSource.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayFontSource.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayFontSource.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.lblDisplayFontSource.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayFontSource.Location = new System.Drawing.Point(12, 116);
			this.lblDisplayFontSource.Name = "lblDisplayFontSource";
			this.lblDisplayFontSource.Size = new System.Drawing.Size(244, 23);
			this.lblDisplayFontSource.TabIndex = 9;
			this.lblDisplayFontSource.Text = "Courier New, 10pt";
			this.lblDisplayFontSource.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnChangeFontSource
			// 
			this.btnChangeFontSource.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeFontSource.Location = new System.Drawing.Point(268, 116);
			this.btnChangeFontSource.Name = "btnChangeFontSource";
			this.btnChangeFontSource.TabIndex = 10;
			this.btnChangeFontSource.Text = "&Font...";
			this.btnChangeFontSource.Click += new System.EventHandler(this.btnChangeFontSource_Click);
			// 
			// lblDisplayColorSourceUnvisited
			// 
			this.lblDisplayColorSourceUnvisited.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorSourceUnvisited.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorSourceUnvisited.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorSourceUnvisited.Location = new System.Drawing.Point(128, 52);
			this.lblDisplayColorSourceUnvisited.Name = "lblDisplayColorSourceUnvisited";
			this.lblDisplayColorSourceUnvisited.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorSourceUnvisited.TabIndex = 4;
			this.lblDisplayColorSourceUnvisited.Text = "Source Code Unvisited";
			this.lblDisplayColorSourceUnvisited.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblDisplayColorSourceVisited
			// 
			this.lblDisplayColorSourceVisited.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDisplayColorSourceVisited.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDisplayColorSourceVisited.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblDisplayColorSourceVisited.Location = new System.Drawing.Point(128, 24);
			this.lblDisplayColorSourceVisited.Name = "lblDisplayColorSourceVisited";
			this.lblDisplayColorSourceVisited.Size = new System.Drawing.Size(128, 23);
			this.lblDisplayColorSourceVisited.TabIndex = 1;
			this.lblDisplayColorSourceVisited.Text = "Source Code Visited";
			this.lblDisplayColorSourceVisited.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnChangeColorSourceUnvisited
			// 
			this.btnChangeColorSourceUnvisited.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorSourceUnvisited.Location = new System.Drawing.Point(268, 52);
			this.btnChangeColorSourceUnvisited.Name = "btnChangeColorSourceUnvisited";
			this.btnChangeColorSourceUnvisited.TabIndex = 5;
			this.btnChangeColorSourceUnvisited.Text = "&Change...";
			this.btnChangeColorSourceUnvisited.Click += new System.EventHandler(this.btnChangeColorSourceUnvisited_Click);
			// 
			// btnChangeColorSourceVisited
			// 
			this.btnChangeColorSourceVisited.ForeColor = System.Drawing.SystemColors.ControlText;
			this.btnChangeColorSourceVisited.Location = new System.Drawing.Point(268, 24);
			this.btnChangeColorSourceVisited.Name = "btnChangeColorSourceVisited";
			this.btnChangeColorSourceVisited.TabIndex = 2;
			this.btnChangeColorSourceVisited.Text = "&Change...";
			this.btnChangeColorSourceVisited.Click += new System.EventHandler(this.btnChangeColorSourceVisited_Click);
			// 
			// lblColorSourceUnvisited
			// 
			this.lblColorSourceUnvisited.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorSourceUnvisited.Location = new System.Drawing.Point(12, 56);
			this.lblColorSourceUnvisited.Name = "lblColorSourceUnvisited";
			this.lblColorSourceUnvisited.Size = new System.Drawing.Size(100, 20);
			this.lblColorSourceUnvisited.TabIndex = 3;
			this.lblColorSourceUnvisited.Text = "U&nvisited Code:";
			// 
			// lblColorSourceVisited
			// 
			this.lblColorSourceVisited.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorSourceVisited.Location = new System.Drawing.Point(12, 28);
			this.lblColorSourceVisited.Name = "lblColorSourceVisited";
			this.lblColorSourceVisited.Size = new System.Drawing.Size(100, 20);
			this.lblColorSourceVisited.TabIndex = 0;
			this.lblColorSourceVisited.Text = "V&isited Code:";
			// 
			// lblColorSourceBackgroundColor
			// 
			this.lblColorSourceBackgroundColor.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblColorSourceBackgroundColor.Location = new System.Drawing.Point(12, 176);
			this.lblColorSourceBackgroundColor.Name = "lblColorSourceBackgroundColor";
			this.lblColorSourceBackgroundColor.Size = new System.Drawing.Size(104, 20);
			this.lblColorSourceBackgroundColor.TabIndex = 14;
			this.lblColorSourceBackgroundColor.Text = "&Background Colour:";
			// 
			// grpHighlightingOptions
			// 
			this.grpHighlightingOptions.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpHighlightingOptions.Controls.Add(this.mulHighlightExcludedCode);
			this.grpHighlightingOptions.Controls.Add(this.lblHighlightExcludedCode);
			this.grpHighlightingOptions.Controls.Add(this.mulHighlightUnvisitedCode);
			this.grpHighlightingOptions.Controls.Add(this.mulHighlightVisitedCode);
			this.grpHighlightingOptions.Controls.Add(this.lblHighlightUncoveredCode);
			this.grpHighlightingOptions.Controls.Add(this.lblHighlightVisitedCode);
			this.grpHighlightingOptions.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpHighlightingOptions.Location = new System.Drawing.Point(8, 8);
			this.grpHighlightingOptions.Name = "grpHighlightingOptions";
			this.grpHighlightingOptions.Size = new System.Drawing.Size(354, 108);
			this.grpHighlightingOptions.TabIndex = 0;
			this.grpHighlightingOptions.TabStop = false;
			this.grpHighlightingOptions.Text = " &Code Highlighting Options:";
			// 
			// mulHighlightExcludedCode
			// 
			this.mulHighlightExcludedCode.Location = new System.Drawing.Point(196, 76);
			this.mulHighlightExcludedCode.Name = "mulHighlightExcludedCode";
			this.mulHighlightExcludedCode.Option1Text = "Block";
			this.mulHighlightExcludedCode.Option2Text = "None";
			this.mulHighlightExcludedCode.Size = new System.Drawing.Size(148, 24);
			this.mulHighlightExcludedCode.TabIndex = 5;
			// 
			// lblHighlightExcludedCode
			// 
			this.lblHighlightExcludedCode.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblHighlightExcludedCode.Location = new System.Drawing.Point(12, 80);
			this.lblHighlightExcludedCode.Name = "lblHighlightExcludedCode";
			this.lblHighlightExcludedCode.Size = new System.Drawing.Size(172, 19);
			this.lblHighlightExcludedCode.TabIndex = 4;
			this.lblHighlightExcludedCode.Text = "Highlight &Excluded Code:";
			// 
			// mulHighlightUnvisitedCode
			// 
			this.mulHighlightUnvisitedCode.Location = new System.Drawing.Point(196, 48);
			this.mulHighlightUnvisitedCode.Name = "mulHighlightUnvisitedCode";
			this.mulHighlightUnvisitedCode.Option1Text = "Block";
			this.mulHighlightUnvisitedCode.Option2Text = "Underlined";
			this.mulHighlightUnvisitedCode.Size = new System.Drawing.Size(148, 24);
			this.mulHighlightUnvisitedCode.TabIndex = 3;
			// 
			// mulHighlightVisitedCode
			// 
			this.mulHighlightVisitedCode.Location = new System.Drawing.Point(196, 20);
			this.mulHighlightVisitedCode.Name = "mulHighlightVisitedCode";
			this.mulHighlightVisitedCode.Option1Text = "Block";
			this.mulHighlightVisitedCode.Option2Text = "None";
			this.mulHighlightVisitedCode.Size = new System.Drawing.Size(148, 24);
			this.mulHighlightVisitedCode.TabIndex = 1;
			// 
			// lblHighlightUncoveredCode
			// 
			this.lblHighlightUncoveredCode.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblHighlightUncoveredCode.Location = new System.Drawing.Point(12, 52);
			this.lblHighlightUncoveredCode.Name = "lblHighlightUncoveredCode";
			this.lblHighlightUncoveredCode.Size = new System.Drawing.Size(136, 19);
			this.lblHighlightUncoveredCode.TabIndex = 2;
			this.lblHighlightUncoveredCode.Text = "Highlight &Unvisited Code:";
			// 
			// lblHighlightVisitedCode
			// 
			this.lblHighlightVisitedCode.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblHighlightVisitedCode.Location = new System.Drawing.Point(12, 24);
			this.lblHighlightVisitedCode.Name = "lblHighlightVisitedCode";
			this.lblHighlightVisitedCode.Size = new System.Drawing.Size(133, 19);
			this.lblHighlightVisitedCode.TabIndex = 0;
			this.lblHighlightVisitedCode.Text = "Highlight &Visited Code:";
			// 
			// OptionsDialog
			// 
			this.AcceptButton = this.btnOk;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(398, 440);
			this.Controls.Add(this.tabControl);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOk);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "OptionsDialog";
			this.Text = "NCoverExplorer Options";
			this.tabControl.ResumeLayout(false);
			this.tabPageCoverageTree.ResumeLayout(false);
			this.grpCoverageTolerance.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.trackSatisfactorySeqPts)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trackSatisfactoryThreshold)).EndInit();
			this.grpTreeViewOptions.ResumeLayout(false);
			this.tabPageExclusions.ResumeLayout(false);
			this.grpExclusionAdd.ResumeLayout(false);
			this.tabPageOther.ResumeLayout(false);
			this.grpStartupOptions.ResumeLayout(false);
			this.grpOtherOptions.ResumeLayout(false);
			this.tabPageStatisticsColors.ResumeLayout(false);
			this.grpStatisticsListViewOptions.ResumeLayout(false);
			this.tabPageTreeColors.ResumeLayout(false);
			this.grpCoverageTreeColors.ResumeLayout(false);
			this.tabPageThemes.ResumeLayout(false);
			this.grpThemeOptions.ResumeLayout(false);
			this.pnlPreview.ResumeLayout(false);
			this.tabPageSourceCodeColors.ResumeLayout(false);
			this.grpSourceCodeColors.ResumeLayout(false);
			this.grpHighlightingOptions.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion	

		#region	Public Properties
		
		/// <summary>
		/// Gets whether a complete reload of the coverage file is required.
		/// </summary>
		public bool IsReloadRequired
		{
			get { return _isReloadRequired; }
		}

		#endregion Public Properties

		#region Protected Methods

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Form.Load"/> event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);

			ntxtSatisfactoryThreshold.Minimum = trackSatisfactoryThreshold.Minimum;
			ntxtSatisfactoryThreshold.Maximum = trackSatisfactoryThreshold.Maximum;
			ntxtSatisfactorySeqPts.Minimum = trackSatisfactorySeqPts.Minimum;
			ntxtSatisfactorySeqPts.Maximum = trackSatisfactorySeqPts.Maximum;
			ntxtRecentFileMenuItems.Minimum = 1;
			ntxtRecentFileMenuItems.Maximum = 20;
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#endregion Protected Methods

		#region Private Methods

		#region Initialisation

		/// <summary>
		/// Creates and hooks event handlers for persistent window state of position and size.
		/// </summary>
		private void _HookPersistentFormState()
		{
			_formStatePersister = new FormStatePersister(this, "OptionsDialog", _configuration.FormStates);
		}

		#endregion Initialisation

		#region Display Values

		/// <summary>
		/// Binds the controls to the current configuration information.
		/// </summary>
		private void _BindConfiguration()
		{
			// Populate the form with the currently applied options.
			ntxtSatisfactoryThreshold.Text = _configuration.SatisfactoryCoverageThreshold.ToString();
			trackSatisfactoryThreshold.Value = ntxtSatisfactoryThreshold.Value;
			ntxtSatisfactorySeqPts.Text = _configuration.SatisfactoryUnvisitedSequencePoints.ToString();
			trackSatisfactorySeqPts.Value = ntxtSatisfactorySeqPts.Value;
			mulTreeGrouping.Option1Checked = _configuration.GroupByModule;
			mulFlattenNamespaces.Option1Checked = _configuration.FlattenNamespaces;
			chkRestoreSelectionOnReload.Checked = _configuration.RestoreSelectionOnReload;
			ntxtRecentFileMenuItems.Text = _configuration.NumberOfRecentFiles.ToString();

			_DisplayThemeProperties(_configuration.Theme);
			_LoadThemesCombo();

			_coverageExclusions = _configuration.CoverageExclusions.Clone();
			_LoadExclusionTypesCombo();
			_LoadExclusionListView();

			// Force sorting by the exclusion type.
			_OnExclusionsListViewColumnClick(exclusionsListView, new ColumnClickEventArgs(0));
		}

		/// <summary>
		/// Display current theme colors.
		/// </summary>
		private void _DisplayThemeProperties(Theme theme)
		{
			lblDisplayColorTreeFullCoverage.ForeColor = theme.TreeNodeFullCoverageColor;
			lblDisplayColorTreeSatisfactoryCoverage.ForeColor = theme.TreeNodeSatisfactoryCoverageColor;
			lblDisplayColorTreePartialCoverage.ForeColor = theme.TreeNodePartiallyVisitedColor;
			lblDisplayColorTreeNoCoverage.ForeColor = theme.TreeNodeUnvisitedColor;
			lblDisplayColorTreeExcludedCoverage.ForeColor = theme.TreeNodeExcludedCoverageColor;
			lblDisplayFontTree.Font = theme.CoverageTreeFont;
			lblDisplayFontTree.BackColor = theme.CoverageTreeBackgroundColor;

			lblDisplayFontStatistics.Font = theme.StatisticsPaneFont;
			lblDisplayFontStatistics.BackColor = theme.StatisticsPaneBackgroundColor;
			
			mulHighlightVisitedCode.Option1Checked = theme.HighlightVisitedCodeStyle == HighlightVisitedCodeStyle.Block;
			mulHighlightUnvisitedCode.Option1Checked = theme.HighlightUnvisitedCodeStyle == HighlightUnvisitedCodeStyle.Block;
			mulHighlightExcludedCode.Option1Checked = theme.HighlightExcludedCodeStyle == HighlightVisitedCodeStyle.Block;
			
			lblDisplayColorSourceVisited.BackColor = theme.HighlightVisitedCodeColor;
			lblDisplayColorSourceUnvisited.BackColor = theme.HighlightUnvisitedCodeColor;
			lblDisplayColorSourceExcluded.BackColor = theme.HighlightExcludedCodeColor;

			lblDisplayFontSource.Font = theme.SourceCodeFont;
			lblDisplayFontSource.BackColor = theme.SourceCodeBackgroundColor;
			lblDisplayColorSourceLineNumbers.BackColor = lblDisplayFontSource.BackColor;

			_UpdateFontDescriptions();
			_UpdateBackgroundColors();
		}

		/// <summary>
		/// Display current theme colors.
		/// </summary>
		private void _LoadThemeObjectFromControls(Theme theme)
		{
			theme.TreeNodeFullCoverageColor = lblDisplayColorTreeFullCoverage.ForeColor;
			theme.TreeNodeSatisfactoryCoverageColor = lblDisplayColorTreeSatisfactoryCoverage.ForeColor;
			theme.TreeNodePartiallyVisitedColor = lblDisplayColorTreePartialCoverage.ForeColor;
			theme.TreeNodeUnvisitedColor = lblDisplayColorTreeNoCoverage.ForeColor;
			theme.TreeNodeExcludedCoverageColor = lblDisplayColorTreeExcludedCoverage.ForeColor;
			theme.CoverageTreeFont = lblDisplayFontTree.Font;
			theme.CoverageTreeBackgroundColor = lblDisplayFontTree.BackColor;

			theme.StatisticsPaneFont = lblDisplayFontStatistics.Font;
			theme.StatisticsPaneBackgroundColor = lblDisplayFontStatistics.BackColor;

			theme.HighlightVisitedCodeStyle = mulHighlightVisitedCode.Option1Checked ? HighlightVisitedCodeStyle.Block : HighlightVisitedCodeStyle.None;
			theme.HighlightUnvisitedCodeStyle = mulHighlightUnvisitedCode.Option1Checked ? HighlightUnvisitedCodeStyle.Block : HighlightUnvisitedCodeStyle.Underlined;
			theme.HighlightExcludedCodeStyle = mulHighlightExcludedCode.Option1Checked ? HighlightVisitedCodeStyle.Block : HighlightVisitedCodeStyle.None;
			
			theme.HighlightVisitedCodeColor = lblDisplayColorSourceVisited.BackColor;
			theme.HighlightUnvisitedCodeColor = lblDisplayColorSourceUnvisited.BackColor;
			theme.HighlightExcludedCodeColor = lblDisplayColorSourceExcluded.BackColor;

			theme.SourceCodeFont = lblDisplayFontSource.Font;
			theme.SourceCodeLineNumbersColor = lblDisplayColorSourceLineNumbers.ForeColor;
			theme.SourceCodeBackgroundColor = lblDisplayFontSource.BackColor;
		}

		/// <summary>
		/// Display each font as word description.
		/// </summary>
		private void _UpdateFontDescriptions()
		{
			lblDisplayFontTree.Text = lblDisplayFontTree.Font.FontFamily.Name + ", " + lblDisplayFontTree.Font.Size + "pt";
			lblDisplayFontStatistics.Text = lblDisplayFontStatistics.Font.FontFamily.Name + ", " + lblDisplayFontStatistics.Font.Size + "pt";
			lblDisplayFontSource.Text = lblDisplayFontSource.Font.FontFamily.Name + ", " + lblDisplayFontSource.Font.Size + "pt";
		}

		/// <summary>
		/// Update background colors of labels to match the new selection chosen.
		/// </summary>
		private void _UpdateBackgroundColors()
		{
			lblDisplayColorTreeFullCoverage.BackColor = lblDisplayFontTree.BackColor;
			lblDisplayColorTreeSatisfactoryCoverage.BackColor = lblDisplayFontTree.BackColor;
			lblDisplayColorTreePartialCoverage.BackColor = lblDisplayFontTree.BackColor;
			lblDisplayColorTreeNoCoverage.BackColor = lblDisplayFontTree.BackColor;
			lblDisplayColorTreeExcludedCoverage.BackColor = lblDisplayFontTree.BackColor;
			pnlPreviewTree.BackColor = lblDisplayFontTree.BackColor;
			pnlPreviewStatistics.BackColor = lblDisplayFontStatistics.BackColor;
			pnlPreviewSource.BackColor = lblDisplayFontSource.BackColor;
		}

		#endregion Display Values

		#region Retrieve / Validate Values

		/// <summary>
		/// Handles the Click event of the OK Button control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="T:System.EventArgs"/> instance containing the event data.</param>
		private void _OnOkButtonClicked(object sender, EventArgs e)
		{
			bool isValid = true;
			this.DialogResult = DialogResult.None;

			// Validate the "Other" tab.
			if (!_IsValidNumericValue(ntxtRecentFileMenuItems))
			{
				ntxtRecentFileMenuItems.Focus();
				tabControl.SelectedTab = tabPageOther;
				return;
			}

			// Validate the "Coverage Tree" tab.
			if (!_IsValidNumericValue(ntxtSatisfactorySeqPts))
			{
				ntxtSatisfactorySeqPts.Focus();
				isValid = false;
			}
			if (!_IsValidNumericValue(ntxtSatisfactoryThreshold))
			{
				ntxtSatisfactoryThreshold.Focus();
				isValid = false;
			}
			if (!isValid)
			{
				tabControl.SelectedTab = tabPageCoverageTree;
				return;
			}

			_SetReloadRequiredIfValueChanged(_configuration.GroupByModule != mulTreeGrouping.Option1Checked);
			_SetReloadRequiredIfValueChanged(_configuration.FlattenNamespaces != mulFlattenNamespaces.Option1Checked);
			_SetReloadRequiredIfValueChanged(_coverageExclusions.IsDirty);
			_configuration.GroupByModule = mulTreeGrouping.Option1Checked;
			_configuration.FlattenNamespaces = mulFlattenNamespaces.Option1Checked;

			_configuration.SatisfactoryCoverageThreshold = ntxtSatisfactoryThreshold.Value;
			_configuration.SatisfactoryUnvisitedSequencePoints = ntxtSatisfactorySeqPts.Value;
			_configuration.NumberOfRecentFiles = ntxtRecentFileMenuItems.Value;
			_configuration.RestoreSelectionOnReload = chkRestoreSelectionOnReload.Checked;

			// Copy the values into the configuration Theme rather than using the same object.
			_configuration.Theme.Name = cboThemes.Text;
			_LoadThemeObjectFromControls(_configuration.Theme);

			 _configuration.CoverageExclusions = _coverageExclusions;

			// Now persist the new settings.
			_configuration.Persist();

			this.DialogResult = DialogResult.OK;
			this.Close();
		}

		/// <summary>
		/// Validate the user typed a valid value in the threshold textbox.
		/// </summary>
		private bool _IsValidNumericValue(NumericTextBox textBox)
		{
			errorProvider.SetError(textBox, "");
			if (!textBox.IsValid)
			{
				errorProvider.SetError(textBox, textBox.InvalidReason);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Indicate that a reload of the coverage.xml file is required if this value is changed. Only necessary
		/// for structural changes to the ree such as groupings and namespaces.
		/// </summary>
		/// <param name="isValueChanged">Result of comparison between old and new value.</param>
		private void _SetReloadRequiredIfValueChanged(bool isValueChanged)
		{
			if (isValueChanged)
			{
				_isReloadRequired = true;
			}
		}

		#endregion Retrieve / Validate Values

		#region Themes ComboBox

		/// <summary>
		/// Populate the dropdown list of available themes.
		/// </summary>
		private void _LoadThemesCombo()
		{
			_RefreshThemesCombo();

			// Make sure we only populate the properties with those of the "custom" version of the theme
			// when first loading the dialog.
			cboThemes.SelectedValueChanged -= new System.EventHandler(this.cboThemes_SelectedValueChanged);
			cboThemes.Text = _configuration.Theme.Name;
			cboThemes.SelectedValueChanged += new System.EventHandler(this.cboThemes_SelectedValueChanged);

			_DisplayThemeProperties(_configuration.Theme);
		}

		/// <summary>
		/// Refreshes the themes combo.
		/// </summary>
		private void _RefreshThemesCombo() 
		{
			string selectedText = cboThemes.Text;
			cboThemes.SelectedValueChanged -= new System.EventHandler(this.cboThemes_SelectedValueChanged);
			cboThemes.BeginUpdate();
			try 
			{
				cboThemes.Items.Clear();
				foreach (Theme theme in _configuration.Themes)
				{
					cboThemes.Items.Add(theme);
				}
				cboThemes.Sorted = true;
			} 
			finally 
			{
				cboThemes.EndUpdate();
				cboThemes.SelectedValueChanged += new System.EventHandler(this.cboThemes_SelectedValueChanged);
				cboThemes.Text = selectedText;
				if (cboThemes.SelectedIndex == -1)
				{
					cboThemes.SelectedIndex = 0;
				}
			} 
		}

		/// <summary>
		/// Handles the SelectedValueChanged event of the cboThemes control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void cboThemes_SelectedValueChanged(object sender, System.EventArgs e)
		{
			_DisplayThemeProperties(_configuration.Themes[cboThemes.Text]);
			btnThemeDelete.Enabled = (cboThemes.Text != Theme.DefaultThemeName);
		}

		#endregion Themes ComboBox

		#region Exclusion Types ComboBox

		/// <summary>
		/// Populate the dropdown list of available exclusion types.
		/// </summary>
		private void _LoadExclusionTypesCombo()
		{
			cboExclusionTypes.Items.Clear();
			cboExclusionTypes.DataSource = System.Enum.GetValues(typeof(ExclusionType));
			cboExclusionTypes.SelectedIndex = 0;
		}

		#endregion Exclusion Types ComboBox

		#region Exclusions ListView

		/// <summary>
		/// Populates the coverage exclusions listview.
		/// </summary>
		private void _LoadExclusionListView() 
		{
			exclusionsListView.SelectedIndexChanged -= new EventHandler(_OnExclusionsListViewSelectedIndexChanged);
			exclusionsListView.BeginUpdate();
			try 
			{
				exclusionsListView.Items.Clear();
				foreach (CoverageExclusion coverageExclusion in _coverageExclusions)
				{
					ListViewItem listViewItem = new ListViewItem(coverageExclusion.ExclusionType.ToString());
					listViewItem.SubItems.Add(coverageExclusion.Pattern);
					listViewItem.SubItems.Add(coverageExclusion.Enabled.ToString());
					listViewItem.ImageIndex = (int)coverageExclusion.ExclusionType;
					listViewItem.Tag = coverageExclusion;
					exclusionsListView.Items.Add(listViewItem);
				}
			} 
			finally 
			{
				exclusionsListView.EndUpdate();
				exclusionsListView.SelectedIndexChanged += new EventHandler(_OnExclusionsListViewSelectedIndexChanged);
			} 
		}

		#endregion Exclusionss ListView

		#region Color / Font Picker Dialogs

		/// <summary>
		/// Displays the color picker dialog and returns the user's selection.
		/// </summary>
		/// <param name="currentColor">Current color.</param>
		/// <returns>New color.</returns>
		private Color _GetColorFromDialog(Color currentColor)
		{
			using (ColorDialog colorDialog = new ColorDialog())
			{
				colorDialog.AllowFullOpen = true;
				colorDialog.FullOpen = true;
				colorDialog.SolidColorOnly = true;
				colorDialog.CustomColors = _configuration.Theme.GetDefaultCustomColorsForPicker();
				colorDialog.Color = currentColor;
   
				if (colorDialog.ShowDialog() == DialogResult.OK)
				{
					return  colorDialog.Color;
				}
				return currentColor;
			}
		}

		/// <summary>
		/// Displays the font picker dialog and returns the user's selection.
		/// </summary>
		/// <param name="currentFont">Current font.</param>
		/// <returns>New font.</returns>
		private Font _GetFontFromDialog(Font currentFont)
		{
			using (FontDialog fontDialog = new FontDialog())
			{
				fontDialog.AllowScriptChange = false;
				fontDialog.AllowVerticalFonts =false;
				fontDialog.FontMustExist = true;
				fontDialog.Font = currentFont;
				fontDialog.ShowApply = false;
				fontDialog.ShowColor = false;
				fontDialog.ShowEffects = true;
				fontDialog.ShowHelp = false;
   
				if (fontDialog.ShowDialog() == DialogResult.OK)
				{
					return  fontDialog.Font;
				}
				return currentFont;
			}
		}

		#endregion Color / Font Picker Dialogs

		#region Coverage Tree Tab Event Handlers

		/// <summary>
		/// Handles the Scroll event of the trackSatisfactoryThreshold control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void trackSatisfactoryThreshold_Scroll(object sender, EventArgs e)
		{
			ntxtSatisfactoryThreshold.Text = trackSatisfactoryThreshold.Value.ToString();
		}

		/// <summary>
		/// Handles the Scroll event of the trackSatisfactoryLines control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void trackSatisfactoryLines_Scroll(object sender, EventArgs e)
		{
			ntxtSatisfactorySeqPts.Text = trackSatisfactorySeqPts.Value.ToString();
		}

		/// <summary>
		/// Handles the Leave event of the ntxtSatisfactoryThreshold control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void ntxtSatisfactoryThreshold_Leave(object sender, EventArgs e)
		{
			if (ntxtSatisfactoryThreshold.IsValid)
			{
				trackSatisfactoryThreshold.Value = ntxtSatisfactoryThreshold.Value;
			}
		}

		/// <summary>
		/// Handles the Leave event of the ntxtSatisfactoryLines control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void ntxtSatisfactoryLines_Leave(object sender, EventArgs e)
		{
			if (ntxtSatisfactorySeqPts.IsValid)
			{
				trackSatisfactorySeqPts.Value = ntxtSatisfactorySeqPts.Value;
			}
		}

		#endregion Coverage Tree Tab Event Handlers

		#region Exclusions Tab Event Handlers

		/// <summary>
		/// Handles the ColumnClick event of the exclusionsListView control to apply sorting.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.ColumnClickEventArgs"/> instance containing the event data.</param>
		private void _OnExclusionsListViewColumnClick(object sender, ColumnClickEventArgs e)
		{
			// Set the ListViewItemSorter as appropriate.
			ExclusionsListViewItemComparer comparer = exclusionsListView.ListViewItemSorter as ExclusionsListViewItemComparer;

			if (comparer == null)
			{
				exclusionsListView.ListViewItemSorter = new ExclusionsListViewItemComparer(e.Column, true);
			}
			else
			{
				if (comparer.SortColumn == e.Column)
				{
					// Sort on same column, just the opposite direction.
					comparer.SortAscending = !comparer.SortAscending;
				}
				else
				{
					comparer.SortAscending = true;
					comparer.SortColumn = e.Column;
				}
			}

			exclusionsListView.Sort();
		}

		/// <summary>
		/// Handles the KeyDown event of the exclusions listview control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.KeyEventArgs"/> instance containing the event data.</param>
		private void _OnExclusionsListViewKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.A)
			{
				foreach (ListViewItem listViewItem in exclusionsListView.Items)
				{
					listViewItem.Selected = true;
				}
			}
		}

		/// <summary>
		/// Handles the Click event of the exclusions listview control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnExclusionsListViewSelectedIndexChanged(object sender, EventArgs e)
		{
			if (exclusionsListView.SelectedItems.Count > 0)
			{
				CoverageExclusion coverageExclusion = (CoverageExclusion)exclusionsListView.SelectedItems[0].Tag;
				cboExclusionTypes.Text = coverageExclusion.ExclusionType.ToString();
				txtExclusionPattern.Text = coverageExclusion.Pattern;
			}

		}

		/// <summary>
		/// Handles the Click event of the btnExclusionAdd control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnExclusionAdd_Click(object sender, EventArgs e)
		{
			errorProvider.SetError(txtExclusionPattern, "");

			// Validate the users entry
			if (txtExclusionPattern.Text.Length == 0)
			{
				errorProvider.SetError(txtExclusionPattern, "You must specify a pattern to add a value.");
				txtExclusionPattern.Focus();
				return;
			}
			else if (txtExclusionPattern.Text.IndexOf(' ') >= 0)
			{
				errorProvider.SetError(txtExclusionPattern, "Do not include spaces in your pattern.");
				txtExclusionPattern.Focus();
				return;
			}

			CoverageExclusion coverageExclusion = new CoverageExclusion(
				(ExclusionType)cboExclusionTypes.SelectedItem, 
				txtExclusionPattern.Text);
			if (_coverageExclusions.Contains(coverageExclusion))
			{
				errorProvider.SetError(txtExclusionPattern, "This exclusion already exists.");
				txtExclusionPattern.Focus();
				return;
			}

			_coverageExclusions.Add(coverageExclusion);
			_LoadExclusionListView();
		}

		private void contextMenuExclusions_Popup(object sender, System.EventArgs e)
		{
			_ctxExclusionEnableItem.Enabled = true;
			if (exclusionsListView.Items.Count == 0 || exclusionsListView.SelectedItems.Count == 0)
			{
				_ctxExclusionEnableItem.Enabled = false;
			}
			_ctxExclusionDisableItem.Enabled = _ctxExclusionEnableItem.Enabled;
			_ctxExclusionDelete.Enabled = _ctxExclusionEnableItem.Enabled;
		}

		private void ctxExclusionEnableItem_Click(object sender, System.EventArgs e)
		{
			_EnableOrDisableExclusions(true);
		}

		private void ctxExclusionDisableItem_Click(object sender, System.EventArgs e)
		{
			_EnableOrDisableExclusions(false);
		}

		private void ctxExclusionDelete_Click(object sender, System.EventArgs e)
		{
			foreach (ListViewItem listViewItem in exclusionsListView.SelectedItems)
			{
				CoverageExclusion coverageExclusion = (CoverageExclusion)listViewItem.Tag;
				_coverageExclusions.Remove(coverageExclusion);
			}
			_LoadExclusionListView();
		}

		private void _EnableOrDisableExclusions(bool enabledOrDisabled)
		{
			bool isChanged = false;
			foreach (ListViewItem listViewItem in exclusionsListView.SelectedItems)
			{
				CoverageExclusion coverageExclusion = (CoverageExclusion)listViewItem.Tag;
				if (coverageExclusion.Enabled != enabledOrDisabled)
				{
					isChanged = true;
					coverageExclusion.Enabled = enabledOrDisabled;
				}
			}
			if (isChanged)
			{
				_coverageExclusions.IsDirty = true;
				_LoadExclusionListView();
			}
		}

		#endregion Exclusions Tab Event Handlers

		#region Theme Appearance Tab Event Handlers

		/// <summary>
		/// Handles the Click event of the btnThemeResetDefaults control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnThemeResetDefaults_Click(object sender, System.EventArgs e)
		{
			IThemeManager themeManager = new FileThemeManager();
			ThemeCollection defaultThemes = themeManager.LoadDefaultThemes();
			if (defaultThemes[cboThemes.Text] != null)
			{
				_configuration.Themes[cboThemes.Text] = defaultThemes[cboThemes.Text];
				_DisplayThemeProperties(_configuration.Themes[cboThemes.Text]);
			}
		}

		/// <summary>
		/// Handles the Click event of the btnThemeSaveAs control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnThemeSaveAs_Click(object sender, System.EventArgs e)
		{
			InputBoxResult result = InputBox.Show(_configuration, "Enter a name for the theme:", "Theme Name", cboThemes.Text, 30);
			if (result.OK)
			{
				if (result.Text.Length == 0)
				{
					MessageBox.Show("You must specify a theme name!", "NCoverExplorer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
					return;
				}

				string themeName = result.Text.Trim();
				if (_configuration.Themes[themeName] == null)
				{
					Theme theme = new Theme(themeName);
					_LoadThemeObjectFromControls(theme);
					_configuration.Themes.Add(theme);
					_RefreshThemesCombo();
					cboThemes.Text = themeName;
				}
				else if (MessageBox.Show("Do you wish to overwrite the existing theme?", "Theme Exists", 
					MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					_LoadThemeObjectFromControls(_configuration.Themes[themeName]);
					_RefreshThemesCombo();
					cboThemes.Text = themeName;
				}
			}
		}

		/// <summary>
		/// Handles the Click event of the btnThemeDelete control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnThemeDelete_Click(object sender, System.EventArgs e)
		{
			if (cboThemes.Text != Theme.DefaultThemeName)
			{
				Theme currentTheme = (Theme)cboThemes.SelectedItem;
				if (MessageBox.Show("Are you sure you wish to delete the theme '" + currentTheme.Name + "'?", "NCoverExplorer", 
					MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					_configuration.Themes.Remove(currentTheme);
					_RefreshThemesCombo();
				}
			}
		}

		#endregion Theme Appearance Tab Event Handlers

		#region Tree Appearance Tab Event Handlers

		private void btnChangeColorTreeFullCoverage_Click(object sender, EventArgs e)
		{
			lblDisplayColorTreeFullCoverage.ForeColor = _GetColorFromDialog(lblDisplayColorTreeFullCoverage.ForeColor);
		}

		private void btnChangeColorTreeSatisfactoryCoverage_Click(object sender, EventArgs e)
		{
			lblDisplayColorTreeSatisfactoryCoverage.ForeColor = _GetColorFromDialog(lblDisplayColorTreeSatisfactoryCoverage.ForeColor);
		}

		private void btnChangeColorTreePartialCoverage_Click(object sender, EventArgs e)
		{
			lblDisplayColorTreePartialCoverage.ForeColor = _GetColorFromDialog(lblDisplayColorTreePartialCoverage.ForeColor);
		}

		private void btnChangeColorTreeNoCoverage_Click(object sender, EventArgs e)
		{
			lblDisplayColorTreeNoCoverage.ForeColor = _GetColorFromDialog(lblDisplayColorTreeNoCoverage.ForeColor);
		}

		private void btnChangeColorTreeExcludedCoverage_Click(object sender, System.EventArgs e)
		{
			lblDisplayColorTreeExcludedCoverage.ForeColor = _GetColorFromDialog(lblDisplayColorTreeExcludedCoverage.ForeColor);
		}

		private void btnChangeColorTreeBackground_Click(object sender, EventArgs e)
		{
			lblDisplayFontTree.BackColor = _GetColorFromDialog(lblDisplayFontTree.BackColor);
			_UpdateBackgroundColors();
		}

		private void btnChangeFontTree_Click(object sender, EventArgs e)
		{
			lblDisplayFontTree.Font = _GetFontFromDialog(lblDisplayFontTree.Font);
			_UpdateFontDescriptions();
		}

		#endregion Tree Appearance Tab Event Handlers

		#region Statistics Appearance Tab Event Handlers

		private void btnChangeColorStatisticsBackground_Click(object sender, EventArgs e)
		{
			lblDisplayFontStatistics.BackColor = _GetColorFromDialog(lblDisplayFontStatistics.BackColor);
		}

		private void btnChangeFontStatistics_Click(object sender, EventArgs e)
		{
			lblDisplayFontStatistics.Font = _GetFontFromDialog(lblDisplayFontStatistics.Font);
			_UpdateFontDescriptions();
		}

		#endregion Statistics Appearance Tab Event Handlers

		#region Source Code Appearance Tab Event Handlers

		private void btnChangeColorSourceVisited_Click(object sender, EventArgs e)
		{
			lblDisplayColorSourceVisited.BackColor = _GetColorFromDialog(lblDisplayColorSourceVisited.BackColor);
		}

		private void btnChangeColorSourceUnvisited_Click(object sender, EventArgs e)
		{
			lblDisplayColorSourceUnvisited.BackColor = _GetColorFromDialog(lblDisplayColorSourceUnvisited.BackColor);
		}

		private void btnChangeColorSourceExcluded_Click(object sender, System.EventArgs e)
		{
			lblDisplayColorSourceExcluded.BackColor = _GetColorFromDialog(lblDisplayColorSourceExcluded.BackColor);
		}

		private void btnChangeColorSourceBackground_Click(object sender, System.EventArgs e)
		{
			lblDisplayFontSource.BackColor = _GetColorFromDialog(lblDisplayFontSource.BackColor);
			lblDisplayColorSourceLineNumbers.BackColor = lblDisplayFontSource.BackColor;
		}

		private void btnChangeColorSourceLineNumbers_Click(object sender, System.EventArgs e)
		{
			lblDisplayColorSourceLineNumbers.ForeColor = _GetColorFromDialog(lblDisplayColorSourceLineNumbers.ForeColor);
		}

		private void btnChangeFontSource_Click(object sender, EventArgs e)
		{
			lblDisplayFontSource.Font = _GetFontFromDialog(lblDisplayFontSource.Font);
			_UpdateFontDescriptions();
		}

		#endregion Source Code Appearance Tab Event Handlers

		#endregion Private Methods
	}
}