using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

using NCoverExplorer.Core.Presentation.Controls;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Displays summary author information and a big pretty icon.
	/// </summary>
	public class AboutDialog : System.Windows.Forms.Form
	{
		#region Private Variables

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private string _additionalText;
		private string _authorName;
		private string _companyUrl;
		private string _copyright;
		private Version _version;
		private HighColorIcon _highColorIcon;
		private Icon _icon;
		private HtmlLinkLabel _lblDetail;
		private Button cmdOK;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="AboutDialog"/> class.
		/// </summary>
		public AboutDialog()
		{
			InitializeComponent();

			this.Text = "About " + Application.ProductName;
			_version = new Version(Application.ProductVersion);
			_authorName = "Developed By <a href=\"mailto:support@ncoverexplorer.org\">Grant Drake</a>";
			_companyUrl = "http://www.kiwidude.com/blog/";
			_additionalText = "\nInspired by <a href=\"http://www.sliver.com/dotnet/NCoverBrowser\">NCoverBrowser</a> by Jeff Key." +
				"\nThanks also to <a href=\"http://weblogs.asp.net/nunitaddin\">Jamie Cansdale</a> for bundling with "+
				"<a href=\"http://www.testdriven.net/\">TestDriven.Net</a>, " +
				"<a href=\"http://www.icsharpcode.net\">ICSharpCode</a> for the TextEditor and " + 
				"<a href=\"http://www.aisto.com/roeder/dotnet\">Lutz Roeder</a> for CommandBar.";

			Assembly assembly = Assembly.GetExecutingAssembly();
			_icon = new Icon(assembly.GetManifestResourceStream("NCoverExplorer.Core.Presentation.About.ico"));
			AssemblyCopyrightAttribute copyrightAttribute = 
				(AssemblyCopyrightAttribute) Attribute.GetCustomAttribute(assembly, typeof(AssemblyCopyrightAttribute));
			_copyright = copyrightAttribute.Copyright;
		}

		#endregion Constructors

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(AboutDialog));
			this.cmdOK = new System.Windows.Forms.Button();
			this._lblDetail = new NCoverExplorer.Core.Presentation.Controls.HtmlLinkLabel();
			this._highColorIcon = new NCoverExplorer.Core.Presentation.Controls.HighColorIcon();
			this.SuspendLayout();
			// 
			// cmdOK
			// 
			this.cmdOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.cmdOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.cmdOK.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.cmdOK.Location = new System.Drawing.Point(302, 150);
			this.cmdOK.Name = "cmdOK";
			this.cmdOK.TabIndex = 4;
			this.cmdOK.Text = "OK";
			// 
			// _lblDetail
			// 
			this._lblDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this._lblDetail.Location = new System.Drawing.Point(152, 12);
			this._lblDetail.Name = "_lblDetail";
			this._lblDetail.Size = new System.Drawing.Size(224, 137);
			this._lblDetail.TabIndex = 6;
			// 
			// _highColorIcon
			// 
			this._highColorIcon.Location = new System.Drawing.Point(12, 24);
			this._highColorIcon.Name = "_highColorIcon";
			this._highColorIcon.Size = new System.Drawing.Size(128, 128);
			this._highColorIcon.TabIndex = 7;
			// 
			// AboutDialog
			// 
			this.AcceptButton = this.cmdOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.CancelButton = this.cmdOK;
			this.ClientSize = new System.Drawing.Size(388, 184);
			this.Controls.Add(this._lblDetail);
			this.Controls.Add(this.cmdOK);
			this.Controls.Add(this._highColorIcon);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "AboutDialog";
			this.ShowInTaskbar = false;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "About NCoverExplorer";
			this.ResumeLayout(false);

		}

		#endregion Windows Form Designer generated code

		#region Protected Methods

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Form.Load"/> event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
		protected override void OnLoad(EventArgs e)
		{
			_highColorIcon.Icon = _icon;
			
			_lblDetail.Text = string.Format(
				"Version {0}\n{1}\n<a href=\"{2}\">{2}</a>\n{3}\n{4}",
				_version, 
				_authorName, 
				_companyUrl, 
				_copyright, 
				_additionalText);
			
			base.OnLoad(e);
		}

		#endregion Protected Methods
	}
}