using System;
using System.Drawing;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Static methods to assist with rendering tree nodes and listview items.
	/// </summary>
	public sealed class AppearanceHelper
	{
		#region Public Constants

		public const string ExcludedNodeSuffix = " [Excluded]";
		public const string FilteredNodeSuffix = " [Filtered]";
		public const string MergedSuffix = " [Merged*]";

		#endregion Public Constants

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="AppearanceHelper"/> class.
		/// </summary>
		[CoverageExclude]
		private AppearanceHelper()
		{
		}

		#endregion Constructor

		#region Public Static Methods

		/// <summary>
		/// Gets the coverage percentage as a formatted text string. Due to rounding has special handling for >99.5%.
		/// </summary>
		/// <param name="percent">The percent.</param>
		/// <returns></returns>
		public static string GetCoveragePercentText(float percent)
		{
			if (percent == 100 || percent < 99.5)
			{
				return string.Format("{0:n0}%", percent);
			}
			else
			{
				return ">99.5%";
			}
		}

		/// <summary>
		/// Gets the foreground color of the node based on it's coverage percentage.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="coveredPercent">The covered percent.</param>
		/// <param name="unvisitedSequencePoints">The unvisited sequence points total.</param>
		/// <param name="totalNonExcludedSequencePoints">The total number of sequence points.</param>
		/// <returns>The color for the node.</returns>
		public static Color GetNodeColor(IExplorerConfiguration configuration, float coveredPercent, 
			int unvisitedSequencePoints, int totalNonExcludedSequencePoints, bool isExcluded, bool isFiltered)
		{
			if (configuration == null)
			{
				throw new ArgumentNullException("configuration", "Must supply a valid configuration to determine node colors.");
			}
			if (isExcluded || isFiltered)
			{
				return configuration.Theme.TreeNodeExcludedCoverageColor;
			}
			switch (configuration.CoverageTreeReportStyle)
			{
				default:
				case CoverageTreeReportStyle.SequencePointCoveragePercentage:
				case CoverageTreeReportStyle.SequencePointCoveragePercentageAndUnvisitedSeqPts:
				case CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints:
					if (coveredPercent == 0)
					{
						if (totalNonExcludedSequencePoints == 0)
						{
							return configuration.Theme.TreeNodeExcludedCoverageColor;
						}
						else
						{
							return configuration.Theme.TreeNodeUnvisitedColor;
						}
					}
					else if (unvisitedSequencePoints == 0)
					{
						return configuration.Theme.TreeNodeFullCoverageColor;
					}
					else
					{
						// A node with partial coverage
						if (coveredPercent >= configuration.SatisfactoryCoverageThreshold)
						{
							return configuration.Theme.TreeNodeSatisfactoryCoverageColor;
						}
						else if (unvisitedSequencePoints <= configuration.SatisfactoryUnvisitedSequencePoints)
						{
							return configuration.Theme.TreeNodeSatisfactoryCoverageColor;
						}
						return configuration.Theme.TreeNodePartiallyVisitedColor;
					}

				case CoverageTreeReportStyle.FunctionCoverage:
					if (coveredPercent == 0)
					{
						if (totalNonExcludedSequencePoints == 0)
						{
							return configuration.Theme.TreeNodeExcludedCoverageColor;
						}
						else
						{
							return configuration.Theme.TreeNodeUnvisitedColor;
						}
					}
					else
					{
						return configuration.Theme.TreeNodeFullCoverageColor;
					}
			}
		}

		/// <summary>
		/// Gets the image index for a coverage file.
		/// </summary>
		/// <returns>Image index.</returns>
		public static int GetImageIndexForCoverageFile()
		{
			return (int)CodeElementIconIndex.CoverageFile;
		}

		/// <summary>
		/// Gets the image index for a namespace based on it's coverage percentage.
		/// </summary>
		/// <param name="namespaceTreeNode">The namespace tree node.</param>
		/// <returns>Image index.</returns>
		public static int GetImageIndexForNamespace(NamespaceTreeNode namespaceTreeNode)
		{
			if (!namespaceTreeNode.IsExcluded && !namespaceTreeNode.IsFiltered && namespaceTreeNode.CoveragePercentage > 0)
			{
				return (int)CodeElementIconIndex.Namespace;
			}
			else
			{
				return (int)CodeElementIconIndex.NamespaceNoVisits;
			}
		}

		/// <summary>
		/// Gets the image index for a module based on it's coverage percentage.
		/// </summary>
		/// <param name="moduleTreeNode">The module tree node.</param>
		/// <returns>Image index.</returns>
		public static int GetImageIndexForModule(ModuleTreeNode moduleTreeNode)
		{
			if (!moduleTreeNode.IsExcluded && !moduleTreeNode.IsFiltered && moduleTreeNode.CoveragePercentage > 0)
			{
				return (int)CodeElementIconIndex.Module;
			}
			else
			{
				return (int)CodeElementIconIndex.ModuleNoVisits;
			}
		}

		/// <summary>
		/// Gets the image index for a class based on it's coverage percentage.
		/// </summary>
		/// <param name="classTreeNode">The class tree node.</param>
		/// <returns>Image index.</returns>
		public static int GetImageIndexForClass(ClassTreeNode classTreeNode)
		{
			if (!classTreeNode.IsExcluded && !classTreeNode.IsFiltered && classTreeNode.CoveragePercentage > 0)
			{
				return (int)CodeElementIconIndex.Class;
			}
			else
			{
				return (int)CodeElementIconIndex.ClassNoVisits;
			}
		}

		/// <summary>
		/// Gets the image index for a method based on it's type and coverage percentage.
		/// </summary>
		/// <returns>Image index.</returns>
		public static int GetImageIndexForMethod(MethodTreeNode methodTreeNode)
		{
			if (methodTreeNode.IsParentProperty)
			{
				if (!methodTreeNode.IsExcluded && !methodTreeNode.IsFiltered && methodTreeNode.CoveragePercentage > 0)
				{
					return (int)CodeElementIconIndex.Property;
				}
				else
				{
					return (int)CodeElementIconIndex.PropertyNoVisits;
				}
			}
			else
			{
				if (!methodTreeNode.IsExcluded && !methodTreeNode.IsFiltered && methodTreeNode.CoveragePercentage > 0)
				{
					return (int)CodeElementIconIndex.Method;
				}
				else
				{
					return (int)CodeElementIconIndex.MethodNoVisits;
				}
			}
		}

		/// <summary>
		/// Gets the image index for an excluded root bin node.
		/// </summary>
		/// <returns></returns>
		public static int GetImageIndexForExcluded()
		{
			return (int)CodeElementIconIndex.Excluded;
		}

		/// <summary>
		/// Gets the image index for an filtered root node.
		/// </summary>
		/// <param name="unvisitedSequencePoints">Number of unvisited sequence points.</param>
		/// <returns></returns>
		public static int GetImageIndexForFiltered(int unvisitedSequencePoints)
		{
			if (unvisitedSequencePoints == 0)
			{
				return (int)CodeElementIconIndex.FilteredFullCoverage;
			}
			else
			{
				return (int)CodeElementIconIndex.FilteredZeroCoverage;
			}
		}

		#endregion Public Static Methods
	}
}
