using System;
using System.Runtime.Serialization;
using System.Security.Permissions;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Exception thrown when a problem occurs while rendering a sequence point.
	/// </summary>
	[Serializable]
	public class DisplaySequencePointException : Exception
	{
		#region Private Variables

		private SequencePoint _sequencePoint = null;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="DisplaySequencePointException"/> class.
		/// </summary>
		public DisplaySequencePointException() 
			: base()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="DisplaySequencePointException"/> class with a specified message.
		/// </summary>
		/// <param name="message">The error message that explains the reason for the exception.</param>
		public DisplaySequencePointException(string message) 
			: base(message)
		{
		} 

		/// <summary>
		/// Initializes a new instance of the <see cref="DisplaySequencePointException"/> class with a specified error message 
		/// and a reference to the inner exception that is the cause of this exception.
		/// </summary>
		/// <param name="message">The error message that explains the reason for the exception.</param>
		/// <param name="innerException">The exception that is the cause of the current exception. If the innerException parameter is not a null reference, the current exception is raised in a catch block that handles the inner exception.</param>
		public DisplaySequencePointException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="DisplaySequencePointException"/> class with serialized data.
		/// </summary>
		/// <param name="info">The object that holds the serialized object data.</param>
		/// <param name="context">The contextual information about the source or destination. </param>
		protected DisplaySequencePointException(SerializationInfo info, StreamingContext context) 
			: base(info, context)
		{
			_sequencePoint = (SequencePoint)info.GetValue("_sequencePoint", typeof(SequencePoint));
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="DisplaySequencePointException"/> class with sequence point details.
		/// </summary>
		/// <param name="message">The message.</param>
		/// <param name="sequencePoint">The sequence point.</param>
		public DisplaySequencePointException(string message, SequencePoint sequencePoint) 
			: base(message)
		{
			_sequencePoint = sequencePoint;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="DisplaySequencePointException"/> class with sequence point details.
		/// </summary>
		/// <param name="sequencePoint">The sequence point.</param>
		public DisplaySequencePointException(SequencePoint sequencePoint) 
			: base()
		{
			_sequencePoint = sequencePoint;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="DisplaySequencePointException"/> class with sequence point details and an inner exception.
		/// </summary>
		/// <param name="sequencePoint">The sequence point.</param>
		/// <param name="innerException">The inner exception.</param>
		public DisplaySequencePointException(SequencePoint sequencePoint, Exception innerException) 
			: base("", innerException)
		{
			_sequencePoint = sequencePoint;
		}

		#endregion Constructors	

		#region Properties

		/// <summary>
		/// Gets the <see cref="SequencePoint"/> which was being processed when exception occurred.
		/// </summary>
		/// <value>The sequence point.</value>
		public SequencePoint SequencePoint 
		{
			get { return _sequencePoint; }
		}

		/// <summary>
		/// Gets a message that describes the current exception.
		/// </summary>
		/// <value>Message including workitem id.</value>
		public override string Message
		{
			get	
			{ 
				if (_sequencePoint == null)
				{
					return base.Message;
				}
				else
				{
					return "Problem while displaying the following code: " + Environment.NewLine + 
						"File: " + _sequencePoint.FileName + Environment.NewLine +
						"Method: " + _sequencePoint.MethodName + Environment.NewLine +
						"StartLine: " + _sequencePoint.StartLine + ", StartColumn: " + _sequencePoint.StartColumn + Environment.NewLine +
						"EndLine: " + _sequencePoint.EndLine + ", EndColumn: " + _sequencePoint.EndColumn + Environment.NewLine;
				}
			}
		}

		
		#endregion Properties

		#region ISerializable Methods

		/// <summary>
		/// Override GetObjectData to serialize state data
		/// </summary>
		/// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> that holds the serialized object data about the exception being thrown.</param>
		/// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"/> that contains contextual information about the source or destination.</param>
		/// <exception cref="T:System.ArgumentNullException">The <paramref name="info"/> parameter is a null reference (<see langword="Nothing"/> in Visual Basic).</exception>
		[SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
		public override void GetObjectData(SerializationInfo info, StreamingContext context)
		{
			// Serialize this class' state and then call the base class GetObjectData
			base.GetObjectData(info, context);
			info.AddValue("_sequencePoint", _sequencePoint, typeof(SequencePoint));
		}

		#endregion ISerializable Methods

	}
}
