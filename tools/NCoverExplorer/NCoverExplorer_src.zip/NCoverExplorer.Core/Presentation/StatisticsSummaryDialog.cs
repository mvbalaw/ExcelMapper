using System;
using System.ComponentModel;
using System.Windows.Forms;

using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Statistics;
using NCoverExplorer.Core.Utilities;
using NCoverExplorer.Core.Visitors;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Display summary statistics for the currently loaded coverage file(s) such as #files, #classes etc.
	/// </summary>
	public class StatisticsSummaryDialog : System.Windows.Forms.Form
	{
		#region Private Variables

		private CoverageFileTreeNode _coverageFileTreeNode;

		#endregion Private Variables

		#region Designer Variables

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;
		private System.Windows.Forms.GroupBox grpStatistics;
		private System.Windows.Forms.Label lblNumberOfUnvisitedSeqPts;
		private System.Windows.Forms.Label lblUnvisitedSeqPts;
		private System.Windows.Forms.Label lblNumberOfSeqPts;
		private System.Windows.Forms.Label lblTotalSeqPts;
		private System.Windows.Forms.Label lblNumberOfNonCommentLines;
		private System.Windows.Forms.Label lblNonCommentLines;
		private System.Windows.Forms.Label lblNumberOfFiles;
		private System.Windows.Forms.Label lblFiles;
		private System.Windows.Forms.Label lblNumberOfMembers;
		private System.Windows.Forms.Label lblMembers;
		private System.Windows.Forms.Label lblNumberOfClasses;
		private System.Windows.Forms.Label lblClasses;
		private System.Windows.Forms.Button btnOK;

		#endregion Designer Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsSummaryDialog"/> class.
		/// </summary>
		protected StatisticsSummaryDialog()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="StatisticsSummaryDialog"/> class.
		/// </summary>
		public StatisticsSummaryDialog(CoverageFileTreeNode coverageFileTreeNode)
			: this()
		{
			_coverageFileTreeNode = coverageFileTreeNode;
		}

		#endregion Constructors

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(StatisticsSummaryDialog));
			this.btnOK = new System.Windows.Forms.Button();
			this.grpStatistics = new System.Windows.Forms.GroupBox();
			this.lblNumberOfUnvisitedSeqPts = new System.Windows.Forms.Label();
			this.lblUnvisitedSeqPts = new System.Windows.Forms.Label();
			this.lblNumberOfSeqPts = new System.Windows.Forms.Label();
			this.lblTotalSeqPts = new System.Windows.Forms.Label();
			this.lblNumberOfNonCommentLines = new System.Windows.Forms.Label();
			this.lblNonCommentLines = new System.Windows.Forms.Label();
			this.lblNumberOfFiles = new System.Windows.Forms.Label();
			this.lblFiles = new System.Windows.Forms.Label();
			this.lblNumberOfMembers = new System.Windows.Forms.Label();
			this.lblMembers = new System.Windows.Forms.Label();
			this.lblNumberOfClasses = new System.Windows.Forms.Label();
			this.lblClasses = new System.Windows.Forms.Label();
			this.grpStatistics.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnOK
			// 
			this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnOK.Location = new System.Drawing.Point(76, 168);
			this.btnOK.Name = "btnOK";
			this.btnOK.TabIndex = 2;
			this.btnOK.Text = "OK";
			// 
			// grpStatistics
			// 
			this.grpStatistics.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpStatistics.Controls.Add(this.lblNumberOfUnvisitedSeqPts);
			this.grpStatistics.Controls.Add(this.lblUnvisitedSeqPts);
			this.grpStatistics.Controls.Add(this.lblNumberOfSeqPts);
			this.grpStatistics.Controls.Add(this.lblTotalSeqPts);
			this.grpStatistics.Controls.Add(this.lblNumberOfNonCommentLines);
			this.grpStatistics.Controls.Add(this.lblNonCommentLines);
			this.grpStatistics.Controls.Add(this.lblNumberOfFiles);
			this.grpStatistics.Controls.Add(this.lblFiles);
			this.grpStatistics.Controls.Add(this.lblNumberOfMembers);
			this.grpStatistics.Controls.Add(this.lblMembers);
			this.grpStatistics.Controls.Add(this.lblNumberOfClasses);
			this.grpStatistics.Controls.Add(this.lblClasses);
			this.grpStatistics.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpStatistics.Location = new System.Drawing.Point(8, 8);
			this.grpStatistics.Name = "grpStatistics";
			this.grpStatistics.Size = new System.Drawing.Size(206, 152);
			this.grpStatistics.TabIndex = 13;
			this.grpStatistics.TabStop = false;
			this.grpStatistics.Text = " Ignoring Excluded Code:";
			// 
			// lblNumberOfUnvisitedSeqPts
			// 
			this.lblNumberOfUnvisitedSeqPts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNumberOfUnvisitedSeqPts.Location = new System.Drawing.Point(116, 124);
			this.lblNumberOfUnvisitedSeqPts.Name = "lblNumberOfUnvisitedSeqPts";
			this.lblNumberOfUnvisitedSeqPts.Size = new System.Drawing.Size(80, 16);
			this.lblNumberOfUnvisitedSeqPts.TabIndex = 24;
			this.lblNumberOfUnvisitedSeqPts.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblUnvisitedSeqPts
			// 
			this.lblUnvisitedSeqPts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblUnvisitedSeqPts.Location = new System.Drawing.Point(12, 124);
			this.lblUnvisitedSeqPts.Name = "lblUnvisitedSeqPts";
			this.lblUnvisitedSeqPts.Size = new System.Drawing.Size(92, 16);
			this.lblUnvisitedSeqPts.TabIndex = 23;
			this.lblUnvisitedSeqPts.Text = "Unvisited SeqPts:";
			// 
			// lblNumberOfSeqPts
			// 
			this.lblNumberOfSeqPts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNumberOfSeqPts.Location = new System.Drawing.Point(116, 104);
			this.lblNumberOfSeqPts.Name = "lblNumberOfSeqPts";
			this.lblNumberOfSeqPts.Size = new System.Drawing.Size(80, 16);
			this.lblNumberOfSeqPts.TabIndex = 22;
			this.lblNumberOfSeqPts.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblTotalSeqPts
			// 
			this.lblTotalSeqPts.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblTotalSeqPts.Location = new System.Drawing.Point(12, 104);
			this.lblTotalSeqPts.Name = "lblTotalSeqPts";
			this.lblTotalSeqPts.Size = new System.Drawing.Size(92, 16);
			this.lblTotalSeqPts.TabIndex = 21;
			this.lblTotalSeqPts.Text = "Total SeqPts:";
			// 
			// lblNumberOfNCLOC
			// 
			this.lblNumberOfNonCommentLines.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNumberOfNonCommentLines.Location = new System.Drawing.Point(116, 84);
			this.lblNumberOfNonCommentLines.Name = "lblNumberOfNonCommentLines";
			this.lblNumberOfNonCommentLines.Size = new System.Drawing.Size(80, 16);
			this.lblNumberOfNonCommentLines.TabIndex = 20;
			this.lblNumberOfNonCommentLines.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblNCLOC
			// 
			this.lblNonCommentLines.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNonCommentLines.Location = new System.Drawing.Point(12, 84);
			this.lblNonCommentLines.Name = "lblNonCommentLines";
			this.lblNonCommentLines.Size = new System.Drawing.Size(92, 16);
			this.lblNonCommentLines.TabIndex = 19;
			this.lblNonCommentLines.Text = "NCLOC:";
			// 
			// lblNumberOfFiles
			// 
			this.lblNumberOfFiles.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNumberOfFiles.Location = new System.Drawing.Point(116, 22);
			this.lblNumberOfFiles.Name = "lblNumberOfFiles";
			this.lblNumberOfFiles.Size = new System.Drawing.Size(80, 16);
			this.lblNumberOfFiles.TabIndex = 18;
			this.lblNumberOfFiles.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblFiles
			// 
			this.lblFiles.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblFiles.Location = new System.Drawing.Point(12, 22);
			this.lblFiles.Name = "lblFiles";
			this.lblFiles.Size = new System.Drawing.Size(92, 16);
			this.lblFiles.TabIndex = 17;
			this.lblFiles.Text = "Files:";
			// 
			// lblNumberOfMembers
			// 
			this.lblNumberOfMembers.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNumberOfMembers.Location = new System.Drawing.Point(116, 64);
			this.lblNumberOfMembers.Name = "lblNumberOfMembers";
			this.lblNumberOfMembers.Size = new System.Drawing.Size(80, 16);
			this.lblNumberOfMembers.TabIndex = 16;
			this.lblNumberOfMembers.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblMembers
			// 
			this.lblMembers.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblMembers.Location = new System.Drawing.Point(12, 64);
			this.lblMembers.Name = "lblMembers";
			this.lblMembers.Size = new System.Drawing.Size(92, 16);
			this.lblMembers.TabIndex = 15;
			this.lblMembers.Text = "Members:";
			// 
			// lblNumberOfClasses
			// 
			this.lblNumberOfClasses.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblNumberOfClasses.Location = new System.Drawing.Point(116, 44);
			this.lblNumberOfClasses.Name = "lblNumberOfClasses";
			this.lblNumberOfClasses.Size = new System.Drawing.Size(80, 16);
			this.lblNumberOfClasses.TabIndex = 14;
			this.lblNumberOfClasses.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// lblClasses
			// 
			this.lblClasses.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblClasses.Location = new System.Drawing.Point(12, 44);
			this.lblClasses.Name = "lblClasses";
			this.lblClasses.Size = new System.Drawing.Size(92, 16);
			this.lblClasses.TabIndex = 13;
			this.lblClasses.Text = "Classes:";
			// 
			// StatisticsSummaryDialog
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.CancelButton = this.btnOK;
			this.ClientSize = new System.Drawing.Size(222, 200);
			this.Controls.Add(this.grpStatistics);
			this.Controls.Add(this.btnOK);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "StatisticsSummaryDialog";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Statistics Summary";
			this.grpStatistics.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Protected Methods

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Form.Load"/> event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
			if (!this.DesignMode)
			{
				StatisticsTreeNodeVisitor statisticsTreeNodeVisitor = new StatisticsTreeNodeVisitor();
				
				StatusPublisher.Display("Calculating statistics...");
				try
				{
					Cursor.Current = Cursors.WaitCursor;

					_coverageFileTreeNode.AcceptVisitor(statisticsTreeNodeVisitor);
				}
				finally
				{
					Cursor.Current = Cursors.Default;
					StatusPublisher.Display("Ready");
				}

				_DisplayStatistics(statisticsTreeNodeVisitor.StatisticsSummary);
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion Protected Methods

		#region Private Methods

		/// <summary>
		/// Displays the statistics.
		/// </summary>
		/// <param name="summary">The summary.</param>
		private void _DisplayStatistics(StatisticsSummary summary)
		{
			lblNumberOfFiles.Text = summary.NumberOfFiles.ToString("#,###0");
			lblNumberOfClasses.Text = summary.NumberOfClasses.ToString("#,###0");
			lblNumberOfMembers.Text = summary.NumberOfMembers.ToString("#,###0");
			lblNumberOfNonCommentLines.Text = summary.NumberOfNonCommentLines.ToString("#,###0");
			lblNumberOfSeqPts.Text = summary.NumberOfSequencePoints.ToString("#,###0");
			lblNumberOfUnvisitedSeqPts.Text = summary.NumberOfUnvisitedSequencePoints.ToString("#,###0");
		}

		#endregion Private Methods
	}
}
