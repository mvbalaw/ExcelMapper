using System;

namespace NCoverExplorer.Core.Presentation.Mouse
{
	/// <summary>
	/// Summary description for HookEventArgs.
	/// </summary>
	public class HookEventArgs : EventArgs
	{
		public int HookCode;	// Hook code
		public IntPtr wParam;	// WPARAM argument
		public IntPtr lParam;	// LPARAM argument
	}
}
