using System;
using System.Runtime.InteropServices;

namespace NCoverExplorer.Core.Presentation.Mouse
{
	public class LocalWindowsHook
	{
		#region Public Events

		/// <summary>
		/// Event raised when the hook is invoked.
		/// </summary>
		public event HookEventHandler HookInvoked;

		#endregion Public Events

		#region Protected Variables

		protected IntPtr m_hhook = IntPtr.Zero;
		protected HookProc m_filterFunc = null;
		protected HookType m_hookType;

		#endregion Protected Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="LocalWindowsHook"/> class.
		/// </summary>
		/// <param name="hook">The hook.</param>
		public LocalWindowsHook(HookType hook)
		{
			m_hookType = hook;
			m_filterFunc = new HookProc(this.CoreHookProc); 
		}
		/// <summary>
		/// Initializes a new instance of the <see cref="LocalWindowsHook"/> class.
		/// </summary>
		/// <param name="hook">The hook.</param>
		/// <param name="func">The func.</param>
		public LocalWindowsHook(HookType hook, HookProc func)
		{
			m_hookType = hook;
			m_filterFunc = func; 
		}

		#endregion Constructors

		#region Public Properties

		/// <summary>
		/// Gets a value indicating whether this hook is installed.
		/// </summary>
		public bool IsInstalled
		{
			get{ return m_hhook != IntPtr.Zero; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Installs the hook.
		/// </summary>
		public void Install()
		{
			m_hhook = SetWindowsHookEx(
				m_hookType, 
				m_filterFunc, 
				IntPtr.Zero, 
				(int)GetCurrentThreadId());
		}

		/// <summary>
		/// Uninstall the hook
		/// </summary>
		public void Uninstall()
		{
			UnhookWindowsHookEx(m_hhook); 
			m_hhook = IntPtr.Zero;
		}

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Default filter function
		/// </summary>
		/// <param name="code">The code.</param>
		/// <param name="wParam">The wParam.</param>
		/// <param name="lParam">The lParam.</param>
		/// <returns></returns>
		protected int CoreHookProc(int code, IntPtr wParam, IntPtr lParam)
		{
			if (code < 0)
				return CallNextHookEx(m_hhook, code, wParam, lParam);

			// Let clients determine what to do
			HookEventArgs e = new HookEventArgs();
			e.HookCode = code;
			e.wParam = wParam;
			e.lParam = lParam;
			OnHookInvoked(e);

			// Yield to the next hook in the chain
			return CallNextHookEx(m_hhook, code, wParam, lParam);
		}

		/// <summary>
		/// Raises the hook invoked event.
		/// </summary>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Presentation.Mouse.HookEventArgs"/> instance containing the event data.</param>
		protected void OnHookInvoked(HookEventArgs e)
		{
			if (HookInvoked != null)
				HookInvoked(this, e);
		}

		#endregion Protected Methods

		#region Win32 Imports

        [DllImport("user32.dll")]
		protected static extern IntPtr SetWindowsHookEx(HookType code, 
			HookProc func,
			IntPtr hInstance,
			int threadID);

        [DllImport("user32.dll")]
		protected static extern int UnhookWindowsHookEx(IntPtr hhook); 

        [DllImport("user32.dll")]
		protected static extern int CallNextHookEx(IntPtr hhook, 
			int code, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll")]
        public static extern int GetCurrentThreadId();

        #endregion Win32 Imports
	}

	#region Delegates

	public delegate int HookProc(int code, IntPtr wParam, IntPtr lParam);
	public delegate void HookEventHandler(object sender, HookEventArgs e);

	#endregion Delegates
}
