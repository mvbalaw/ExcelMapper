using System.Windows.Forms;

namespace NCoverExplorer.Core.Presentation.Mouse
{
	/// <summary>
	/// Contains the values passed by the MouseHook to the internal MouseProc,
	/// repackaged as .NET types
	/// </summary>
	public class MouseHookEventArgs
	{
		#region Public Fields

		/// <summary>
		/// The button that is associated with the event
		/// </summary>
		public readonly MouseButtons Button = MouseButtons.None;

		/// <summary>
		/// The X location of the mouse when the event occured
		/// </summary>
		public readonly int X = 0;

		/// <summary>
		/// The Y location of the mouse when the event occured
		/// </summary>
		public readonly int Y = 0;

		/// <summary>
		/// The control that will ultimately receive the hooked message
		/// </summary>
		public readonly Control Control = null;

		/// <summary>
		/// The window area that the mouse is over
		/// </summary>
		public readonly HitTestCode HitTestCode = HitTestCode.HTNOWHERE;

		#endregion Public Fields

		#region Private Variables

		private bool _isNonClientArea = false;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MouseHookEventArgs"/> class.
		/// </summary>
		/// <param name="button">The button.</param>
		/// <param name="x">The x.</param>
		/// <param name="y">The y.</param>
		/// <param name="control">The control.</param>
		/// <param name="hitTestCode">The hit test code.</param>
		public MouseHookEventArgs( MouseButtons button, int x, int y, Control control, HitTestCode hitTestCode )
		{
			Button = button;
			X = x;
			Y = y;
			Control = control;
			HitTestCode = hitTestCode;
		}

		#endregion

		#region Public Properties

		/// <summary>
		/// Did the event occur over a non-client area
		/// </summary>
		public bool IsNonClientArea
		{
			get{ return _isNonClientArea; }
		}

		#endregion Public Properties

		#region Internal Methods

		internal void SetNonClient()
		{ 
			_isNonClientArea = true; 
		}

		#endregion Internal Methods
	}
}
