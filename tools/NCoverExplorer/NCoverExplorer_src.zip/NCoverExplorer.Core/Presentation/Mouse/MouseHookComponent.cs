using System.ComponentModel;

namespace NCoverExplorer.Core.Presentation.Mouse
{
	/// <summary>
	/// A component based MouseHook that can be placed on a design surface
	/// and automatically installs itself when created with a valid container
	/// </summary>
	public class MouseHookComponent : System.ComponentModel.Component
	{
		#region Public Events

		/// <summary>
		/// Event raised when a mouse button is down.
		/// </summary>
		public event MouseHookEventHandler MouseDown;
		/// <summary>
		/// Event raised when a mouse button is release.
		/// </summary>
		public event MouseHookEventHandler MouseUp;
		/// <summary>
		/// Event raised when the mouse is moved.
		/// </summary>
		public event MouseHookEventHandler MouseMove;
		/// <summary>
		/// Event raised when a mouse button is double clicked.
		/// </summary>
		public event MouseHookEventHandler MouseDoubleClick;

		#endregion Public Events

		#region Private Variables

		private MouseHook hook = null;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Creates a new instance of the MouseHookComponent class
		/// and installs the hook
		/// </summary>
		/// <param name="container">Parent Component container</param>
		public MouseHookComponent(IContainer container) : this()
		{
			container.Add( this );

			if ( !base.DesignMode )
				hook.Install();
		}

		/// <summary>
		/// Creates a new instance of the MouseHookComponent class
		/// and does not install the hook. The client is responsible for calling install
		/// </summary>
		public MouseHookComponent()
		{
			hook = new MouseHook();

			hook.MouseDoubleClick += new MouseHookEventHandler(hook_MouseDoubleClick);
			hook.MouseDown += new MouseHookEventHandler(hook_MouseDown);
			hook.MouseMove += new MouseHookEventHandler(hook_MouseMove);
			hook.MouseUp += new MouseHookEventHandler(hook_MouseUp);
		}

		#endregion Constructors

		#region Dispose

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			hook.Dispose();

			base.Dispose( disposing );
		}

		#endregion Dispose

		#region Private Methods

		private void hook_MouseDown(object sender, MouseHookEventArgs e)
		{
			if ( MouseDown != null )
				MouseDown( this, e );
		}

		private void hook_MouseUp(object sender, MouseHookEventArgs e)
		{
			if ( MouseUp != null )
				MouseUp( this, e );
		}

		private void hook_MouseMove(object sender, MouseHookEventArgs e)
		{
			if ( MouseMove != null )
				MouseMove( this, e );
		}

		private void hook_MouseDoubleClick(object sender, MouseHookEventArgs e)
		{
			if ( MouseDoubleClick != null )
				MouseDoubleClick( this, e );
		}

		#endregion Private Methods
	}
}
