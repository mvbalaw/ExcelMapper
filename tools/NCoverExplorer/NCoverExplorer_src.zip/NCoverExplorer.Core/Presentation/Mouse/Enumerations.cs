
namespace NCoverExplorer.Core.Presentation.Mouse
{
	#region HitTestCode Enum

	/// <summary>
	/// .NET version of the NCHHITEST Win32 API enum
	/// </summary>
	public enum HitTestCode : int
	{
		HTERROR            = -2,
		HTTRANSPARENT      = -1,
		HTNOWHERE          = 0,
		HTCLIENT           = 1,
		HTCAPTION          = 2,
		HTSYSMENU          = 3,
		HTGROWBOX          = 4,
		HTSIZE             = HTGROWBOX,
		HTMENU             = 5,
		HTHSCROLL          = 6,
		HTVSCROLL          = 7,
		HTMINBUTTON        = 8,
		HTMAXBUTTON        = 9,
		HTLEFT             = 10,
		HTRIGHT            = 11,
		HTTOP              = 12,
		HTTOPLEFT          = 13,
		HTTOPRIGHT         = 14,
		HTBOTTOM           = 15,
		HTBOTTOMLEFT       = 16,
		HTBOTTOMRIGHT      = 17,
		HTBORDER           = 18,
		HTREDUCE           = HTMINBUTTON,
		HTZOOM             = HTMAXBUTTON,
		HTSIZEFIRST        = HTLEFT,
		HTSIZELAST         = HTBOTTOMRIGHT,
		HTOBJECT           = 19,
		HTCLOSE            = 20,
		HTHELP             = 21,
	}

	#endregion HitTestCode Enum

	#region HookType Enum

	// Hook Types
	public enum HookType : int
	{
		WH_JOURNALRECORD = 0,
		WH_JOURNALPLAYBACK = 1,
		WH_KEYBOARD = 2,
		WH_GETMESSAGE = 3,
		WH_CALLWNDPROC = 4,
		WH_CBT = 5,
		WH_SYSMSGFILTER = 6,
		WH_MOUSE = 7,
		WH_HARDWARE = 8,
		WH_DEBUG = 9,
		WH_SHELL = 10,
		WH_FOREGROUNDIDLE = 11,
		WH_CALLWNDPROCRET = 12,		
		WH_KEYBOARD_LL = 13,
		WH_MOUSE_LL = 14
	}

	#endregion
}
