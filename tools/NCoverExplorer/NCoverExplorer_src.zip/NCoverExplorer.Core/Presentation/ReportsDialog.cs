using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Reporting;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Display a dialog offering the user options of the report to generate and the output type.
	/// </summary>
	public class ReportsDialog : System.Windows.Forms.Form
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private FormStatePersister _formStatePersister;
		private CoverageFileTreeNode _coverageFileTreeNode;
		private int _lastReportTypeIndex = 0;

		#endregion Private Variables

		#region Designer Variables

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private Container components = null;
		private System.Windows.Forms.GroupBox grpStatistics;
		private System.Windows.Forms.Label lblCreateIn;
		private System.Windows.Forms.Label lblFileName;
		private System.Windows.Forms.Label lblProjectName;
		private System.Windows.Forms.Label lblReportOutputType;
		private System.Windows.Forms.Label lblReportType;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.TextBox txtProjectName;
		private System.Windows.Forms.ComboBox cboReportTypes;
		private NCoverExplorer.Core.Presentation.Controls.MultipleChoice mulOutputType;
		private System.Windows.Forms.TextBox txtFileName;
		private System.Windows.Forms.Button btnGenerateReport;
		private System.Windows.Forms.Button btnChooseFileName;
		private System.Windows.Forms.ErrorProvider errorProvider;
		private System.Windows.Forms.TextBox txtFileNameFolder;
		private System.Windows.Forms.CheckBox chkShowExcludedFooter;
		private System.Windows.Forms.CheckBox chkDisplayAfterGeneration;

		#endregion Designer Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="ReportsDialog"/> class.
		/// </summary>
		protected ReportsDialog()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ReportsDialog"/> class.
		/// </summary>
		public ReportsDialog(IExplorerConfiguration configuration, CoverageFileTreeNode coverageFileTreeNode)
			: this()
		{
			_configuration = configuration;
			_coverageFileTreeNode = coverageFileTreeNode;

			_HookPersistentFormState();
			_BindConfiguration();
		}

		#endregion Constructors

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(ReportsDialog));
			this.btnGenerateReport = new System.Windows.Forms.Button();
			this.grpStatistics = new System.Windows.Forms.GroupBox();
			this.txtFileNameFolder = new System.Windows.Forms.TextBox();
			this.btnChooseFileName = new System.Windows.Forms.Button();
			this.txtFileName = new System.Windows.Forms.TextBox();
			this.mulOutputType = new NCoverExplorer.Core.Presentation.Controls.MultipleChoice();
			this.cboReportTypes = new System.Windows.Forms.ComboBox();
			this.txtProjectName = new System.Windows.Forms.TextBox();
			this.lblCreateIn = new System.Windows.Forms.Label();
			this.lblFileName = new System.Windows.Forms.Label();
			this.lblProjectName = new System.Windows.Forms.Label();
			this.lblReportOutputType = new System.Windows.Forms.Label();
			this.lblReportType = new System.Windows.Forms.Label();
			this.btnCancel = new System.Windows.Forms.Button();
			this.chkDisplayAfterGeneration = new System.Windows.Forms.CheckBox();
			this.errorProvider = new System.Windows.Forms.ErrorProvider();
			this.chkShowExcludedFooter = new System.Windows.Forms.CheckBox();
			this.grpStatistics.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnGenerateReport
			// 
			this.btnGenerateReport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnGenerateReport.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnGenerateReport.Location = new System.Drawing.Point(200, 212);
			this.btnGenerateReport.Name = "btnGenerateReport";
			this.btnGenerateReport.TabIndex = 1;
			this.btnGenerateReport.Text = "Generate";
			this.btnGenerateReport.Click += new System.EventHandler(this.btnGenerateReport_Click);
			// 
			// grpStatistics
			// 
			this.grpStatistics.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.grpStatistics.Controls.Add(this.chkShowExcludedFooter);
			this.grpStatistics.Controls.Add(this.txtFileNameFolder);
			this.grpStatistics.Controls.Add(this.btnChooseFileName);
			this.grpStatistics.Controls.Add(this.txtFileName);
			this.grpStatistics.Controls.Add(this.mulOutputType);
			this.grpStatistics.Controls.Add(this.cboReportTypes);
			this.grpStatistics.Controls.Add(this.txtProjectName);
			this.grpStatistics.Controls.Add(this.lblCreateIn);
			this.grpStatistics.Controls.Add(this.lblFileName);
			this.grpStatistics.Controls.Add(this.lblProjectName);
			this.grpStatistics.Controls.Add(this.lblReportOutputType);
			this.grpStatistics.Controls.Add(this.lblReportType);
			this.grpStatistics.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.grpStatistics.Location = new System.Drawing.Point(8, 8);
			this.grpStatistics.Name = "grpStatistics";
			this.grpStatistics.Size = new System.Drawing.Size(354, 196);
			this.grpStatistics.TabIndex = 0;
			this.grpStatistics.TabStop = false;
			this.grpStatistics.Text = " &Report Options:";
			// 
			// txtFileNameFolder
			// 
			this.txtFileNameFolder.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.errorProvider.SetIconAlignment(this.txtFileNameFolder, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtFileNameFolder.Location = new System.Drawing.Point(112, 108);
			this.txtFileNameFolder.MaxLength = 50;
			this.txtFileNameFolder.Multiline = true;
			this.txtFileNameFolder.Name = "txtFileNameFolder";
			this.txtFileNameFolder.ReadOnly = true;
			this.txtFileNameFolder.Size = new System.Drawing.Size(236, 16);
			this.txtFileNameFolder.TabIndex = 11;
			this.txtFileNameFolder.TabStop = false;
			this.txtFileNameFolder.Text = "";
			this.txtFileNameFolder.WordWrap = false;
			// 
			// btnChooseFileName
			// 
			this.btnChooseFileName.ForeColor = System.Drawing.SystemColors.WindowText;
			this.btnChooseFileName.Location = new System.Drawing.Point(304, 76);
			this.btnChooseFileName.Name = "btnChooseFileName";
			this.btnChooseFileName.Size = new System.Drawing.Size(24, 23);
			this.btnChooseFileName.TabIndex = 6;
			this.btnChooseFileName.Text = "...";
			this.btnChooseFileName.Click += new System.EventHandler(this.btnChooseFileName_Click);
			// 
			// txtFileName
			// 
			this.errorProvider.SetIconAlignment(this.txtFileName, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtFileName.Location = new System.Drawing.Point(112, 76);
			this.txtFileName.MaxLength = 50;
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.Size = new System.Drawing.Size(188, 21);
			this.txtFileName.TabIndex = 5;
			this.txtFileName.Text = "";
			// 
			// mulOutputType
			// 
			this.mulOutputType.Location = new System.Drawing.Point(112, 48);
			this.mulOutputType.Name = "mulOutputType";
			this.mulOutputType.Option1Text = "&HTML";
			this.mulOutputType.Option2Text = "&XML";
			this.mulOutputType.Size = new System.Drawing.Size(140, 24);
			this.mulOutputType.TabIndex = 3;
			// 
			// cboReportTypes
			// 
			this.cboReportTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.errorProvider.SetIconAlignment(this.cboReportTypes, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.cboReportTypes.Location = new System.Drawing.Point(112, 20);
			this.cboReportTypes.Name = "cboReportTypes";
			this.cboReportTypes.Size = new System.Drawing.Size(216, 21);
			this.cboReportTypes.TabIndex = 1;
			// 
			// txtProjectName
			// 
			this.errorProvider.SetIconAlignment(this.txtProjectName, System.Windows.Forms.ErrorIconAlignment.MiddleLeft);
			this.txtProjectName.Location = new System.Drawing.Point(112, 132);
			this.txtProjectName.MaxLength = 50;
			this.txtProjectName.Name = "txtProjectName";
			this.txtProjectName.Size = new System.Drawing.Size(192, 21);
			this.txtProjectName.TabIndex = 10;
			this.txtProjectName.Text = "";
			// 
			// lblCreateIn
			// 
			this.lblCreateIn.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblCreateIn.Location = new System.Drawing.Point(12, 108);
			this.lblCreateIn.Name = "lblCreateIn";
			this.lblCreateIn.Size = new System.Drawing.Size(92, 16);
			this.lblCreateIn.TabIndex = 7;
			this.lblCreateIn.Text = "Create In Folder:";
			// 
			// lblFileName
			// 
			this.lblFileName.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblFileName.Location = new System.Drawing.Point(12, 80);
			this.lblFileName.Name = "lblFileName";
			this.lblFileName.Size = new System.Drawing.Size(92, 16);
			this.lblFileName.TabIndex = 4;
			this.lblFileName.Text = "&File Name:";
			// 
			// lblProjectName
			// 
			this.lblProjectName.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblProjectName.Location = new System.Drawing.Point(12, 136);
			this.lblProjectName.Name = "lblProjectName";
			this.lblProjectName.Size = new System.Drawing.Size(92, 16);
			this.lblProjectName.TabIndex = 9;
			this.lblProjectName.Text = "&Project Name:";
			// 
			// lblReportOutputType
			// 
			this.lblReportOutputType.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblReportOutputType.Location = new System.Drawing.Point(12, 52);
			this.lblReportOutputType.Name = "lblReportOutputType";
			this.lblReportOutputType.Size = new System.Drawing.Size(92, 16);
			this.lblReportOutputType.TabIndex = 2;
			this.lblReportOutputType.Text = "&Output Type:";
			// 
			// lblReportType
			// 
			this.lblReportType.ForeColor = System.Drawing.SystemColors.ControlText;
			this.lblReportType.Location = new System.Drawing.Point(12, 24);
			this.lblReportType.Name = "lblReportType";
			this.lblReportType.Size = new System.Drawing.Size(92, 16);
			this.lblReportType.TabIndex = 0;
			this.lblReportType.Text = "&Report Type:";
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(284, 212);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 2;
			this.btnCancel.Text = "Cancel";
			// 
			// chkDisplayAfterGeneration
			// 
			this.chkDisplayAfterGeneration.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.chkDisplayAfterGeneration.ForeColor = System.Drawing.SystemColors.WindowText;
			this.chkDisplayAfterGeneration.Location = new System.Drawing.Point(20, 212);
			this.chkDisplayAfterGeneration.Name = "chkDisplayAfterGeneration";
			this.chkDisplayAfterGeneration.Size = new System.Drawing.Size(160, 24);
			this.chkDisplayAfterGeneration.TabIndex = 12;
			this.chkDisplayAfterGeneration.Text = "&Display After Generation";
			// 
			// errorProvider
			// 
			this.errorProvider.ContainerControl = this;
			// 
			// chkShowExcludedFooter
			// 
			this.chkShowExcludedFooter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
			this.chkShowExcludedFooter.ForeColor = System.Drawing.SystemColors.WindowText;
			this.chkShowExcludedFooter.Location = new System.Drawing.Point(12, 164);
			this.chkShowExcludedFooter.Name = "chkShowExcludedFooter";
			this.chkShowExcludedFooter.Size = new System.Drawing.Size(276, 24);
			this.chkShowExcludedFooter.TabIndex = 13;
			this.chkShowExcludedFooter.Text = "&Show Excluded nodes in the footer of the report.";
			// 
			// ReportsDialog
			// 
			this.AcceptButton = this.btnGenerateReport;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(370, 244);
			this.Controls.Add(this.chkDisplayAfterGeneration);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.grpStatistics);
			this.Controls.Add(this.btnGenerateReport);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "ReportsDialog";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Report Generation";
			this.grpStatistics.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		#region Protected Methods

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Form.Load"/> event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
			if (!this.DesignMode)
			{
				cboReportTypes.SelectedIndex = _lastReportTypeIndex;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion Protected Methods

		#region Private Methods

		#region Form Persistence

		/// <summary>
		/// Creates and hooks event handlers for persistent window state of position and size.
		/// </summary>
		private void _HookPersistentFormState()
		{
			_formStatePersister = new FormStatePersister(this, "ReportDialog", _configuration.FormStates);

			_formStatePersister.LoadState += new FormStateEventHandler(_OnLoadState);
			_formStatePersister.SaveState += new FormStateEventHandler(_OnSaveState);
		}

		/// <summary>
		/// Handles the LoadState event of the form persistence object.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Configuration.FormStateEventArgs"/> instance containing the event data.</param>
		private void _OnLoadState(object sender, FormStateEventArgs e)
		{
			chkDisplayAfterGeneration.Checked = e.FormState.GetBoolean("DisplayAfterGeneration", true);
			chkShowExcludedFooter.Checked = e.FormState.GetBoolean("ShowExcludedFooter", true);
			mulOutputType.Option1Checked = e.FormState.GetBoolean("OutputAsHtml", true);
			_lastReportTypeIndex = e.FormState.GetInt32("LastReportIndex", 0);
		}

		/// <summary>
		/// Handles the SaveState event of the form persistence object.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Configuration.FormStateEventArgs"/> instance containing the event data.</param>
		private void _OnSaveState(object sender, FormStateEventArgs e)
		{
			e.FormState.SetValue("DisplayAfterGeneration", chkDisplayAfterGeneration.Checked);
			e.FormState.SetValue("ShowExcludedFooter", chkShowExcludedFooter.Checked);
			e.FormState.SetValue("OutputAsHtml", mulOutputType.Option1Checked);
			e.FormState.SetValue("LastReportIndex", _lastReportTypeIndex);
		}

		#endregion Form Persistence

		#region Initialisation

		/// <summary>
		/// Binds the controls to the current configuration information.
		/// </summary>
		private void _BindConfiguration()
		{
			_LoadReportTypesCombo();

			txtFileName.Text = "CoverageReport.html";
			_RenameFileToMatchOutputType();

			_SetFileNameFolderLabel(_coverageFileTreeNode.CoverageFileNames[0]);
			txtProjectName.Text = _configuration.ProjectName;

			mulOutputType.CheckedChanged += new EventHandler(_OnOutputTypeCheckedChanged);
		}

		/// <summary>
		/// Populate the dropdown list of available report types.
		/// </summary>
		private void _LoadReportTypesCombo()
		{
			cboReportTypes.Items.Clear();
			cboReportTypes.Items.Add("Module Summary");
			cboReportTypes.Items.Add("Namespace Summary");
			cboReportTypes.Items.Add("Module/Namespace Summary");
			cboReportTypes.Items.Add("Module/Class Summary");
		}

		#endregion Initialisation

		#region Control Event Handlers

		/// <summary>
		/// Handles the CheckedChanged event of the OutputType multiple choice control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnOutputTypeCheckedChanged(object sender, EventArgs e)
		{
			_RenameFileToMatchOutputType();
		}

		/// <summary>
		/// Handles the Click event of the btnChooseFileName control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnChooseFileName_Click(object sender, System.EventArgs e)
		{
			using (SaveFileDialog saveFileDialog = new SaveFileDialog())
			{
				saveFileDialog.Title = "Save report file";
				saveFileDialog.FileName = txtFileName.Text;
				if (mulOutputType.Option1Checked)
				{
					saveFileDialog.DefaultExt = "html";
					saveFileDialog.Filter = "HTML Document|*.html|All Files (*.*)|*.*";
				}
				else 
				{
					saveFileDialog.DefaultExt = "xml";
					saveFileDialog.Filter = "XML Document|*.xml|All Files (*.*)|*.*";
				}
				saveFileDialog.FilterIndex = 0;
				saveFileDialog.AddExtension = true;
				saveFileDialog.InitialDirectory = txtFileNameFolder.Text;

				if (saveFileDialog.ShowDialog() == DialogResult.OK)
				{
					_SetFileNameFolderLabel(saveFileDialog.FileName);
					txtFileName.Text = Path.GetFileName(saveFileDialog.FileName);
				}
			}
		}

		/// <summary>
		/// Handles the Click event of the btnGenerateReport control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void btnGenerateReport_Click(object sender, System.EventArgs e)
		{
			this.DialogResult = DialogResult.None;

			if (!_IsValidOptionsInDialog())
			{
				return;
			}

			string xmlFileName = string.Empty;
			string htmlFileName = string.Empty;
			if (mulOutputType.Option1Checked)
			{
				htmlFileName = Path.Combine(txtFileNameFolder.Text, txtFileName.Text);
			}
			else
			{
				xmlFileName = Path.Combine(txtFileNameFolder.Text, txtFileName.Text);
			}
			_lastReportTypeIndex = cboReportTypes.SelectedIndex;
			ReportType reportType = (ReportType)(_lastReportTypeIndex + 1);
			string fileName = Path.Combine(txtFileNameFolder.Text, txtFileName.Text);
			_configuration.ProjectName = txtProjectName.Text;
			bool showExcludedFooter = chkShowExcludedFooter.Checked;

			try
			{
				Cursor.Current = Cursors.WaitCursor;
				StatusPublisher.Display("Generating report: " + fileName);
				ReportHelper.CreateReport(reportType, xmlFileName, htmlFileName, _coverageFileTreeNode, showExcludedFooter);

				if (File.Exists(fileName) && chkDisplayAfterGeneration.Checked)
				{
					Process.Start(fileName);
				}
				StatusPublisher.Display("Report created: " + fileName);
			}
			finally
			{
				Cursor.Current = Cursors.Default;
			}
			this.DialogResult = DialogResult.OK;
		}

		#endregion Control Event Handlers

		#region Validation Functions

		/// <summary>
		/// Ensure the file name folder label is set to the folder including the trailing slash.
		/// </summary>
		/// <param name="fileName">Full path name of the file.</param>
		private void _SetFileNameFolderLabel(string fileName)
		{
			txtFileNameFolder.Text = Path.GetDirectoryName(fileName);
			if (!txtFileNameFolder.Text.EndsWith(@"\"))
			{
				txtFileNameFolder.Text += @"\";
			}
		}

		/// <summary>
		/// Renames the file name extension to match the desired output type.
		/// </summary>
		private void _RenameFileToMatchOutputType()
		{
			string extension = ".html";
			if (mulOutputType.Option2Checked)
			{
				extension = ".xml";
			}

			string fileName = txtFileName.Text;
			if (fileName.Length == 0)
			{
				fileName = "CoverageReport";
			}
			txtFileName.Text = Path.GetFileNameWithoutExtension(fileName) + extension;
		}

		/// <summary>
		/// Validates the users selections in the dialog.
		/// </summary>
		/// <returns><c>false</c> if not valid.</returns>
		private bool _IsValidOptionsInDialog()
		{
			errorProvider.SetError(txtFileName, "");
			if (txtFileName.Text.Length == 0)
			{
				errorProvider.SetError(txtFileName, "You must specify a file name.");
				txtFileName.Focus();
				return false;
			}
			if (!_configuration.GroupByModule && ((ReportType)(cboReportTypes.SelectedIndex + 1) != ReportType.NamespaceSummary))
			{
				string message = "Only the Namespace Summary report is available when grouping by namespace." 
					+ Environment.NewLine + "To change this, go to the options dialog and choose Group by Module.";
				MessageBox.Show(message, "NCoverExplorer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
				return false;
			}
			if (txtProjectName.Text.Length == 0)
			{
				txtProjectName.Text = "Unknown";
			}
			return true;
		}

		#endregion Validation Functions

		#endregion Private Methods
	}
}
