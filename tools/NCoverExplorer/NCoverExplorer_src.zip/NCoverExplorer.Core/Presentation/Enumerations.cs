
namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Enumeration for the icons associated with the treeview of code elements.
	/// </summary>
	public enum CodeElementIconIndex
	{
		/// <summary>Module node in the tree.</summary>
		CoverageFile = 0,
		/// <summary>Module node in the tree.</summary>
		Module = 1,
		/// <summary>Module node with no code coverage.</summary>
		ModuleNoVisits = 2,
		/// <summary>Namespace node in the tree.</summary>
		Namespace = 3,
		/// <summary>Namespace node with no code coverage.</summary>
		NamespaceNoVisits = 4,
		/// <summary>Class node in the tree.</summary>
		Class = 5,
		/// <summary>Class node with no code coverage.</summary>
		ClassNoVisits = 6,
		/// <summary>Method node in the tree.</summary>
		Method = 7,
		/// <summary>Method node with no code coverage.</summary>
		MethodNoVisits = 8,
		/// <summary>Property node in the tree.</summary>
		Property = 9,
		/// <summary>Property node with no code coverage.</summary>
		PropertyNoVisits = 10,
		/// <summary>Excluded folder node.</summary>
		Excluded = 11,
		/// <summary>Filtered folder node for 100% coverage.</summary>
		FilteredFullCoverage = 12,
		/// <summary>Filtered folder node for 0% coverage.</summary>
		FilteredZeroCoverage = 13
	}
}
