using System.Drawing;

using ICSharpCode.TextEditor;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.SourceCode;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// Holds state information for restoring the position within the tree/document when reloading a coverage.xml file.
	/// </summary>
	public class SelectionStateManager
	{
		#region Private Variables

		private bool _restoreSelectionAfterLoad;
		private string _savedPathToNodeBeforeReload;
		private int _savedCaretOffset;
		private Point _savedCaretPosition;
		private int _savedCaretLine;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SelectionStateManager"/> class.
		/// For use when first opened or when the restore functionality is turned off.
		/// </summary>
		public SelectionStateManager()
		{
			Clear();
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets a value indicating whether this instance has selection.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has selection; otherwise, <c>false</c>.
		/// </value>
		public bool HasSelection
		{
			get { return _restoreSelectionAfterLoad; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Clears any saved selection state information.
		/// </summary>
		public void Clear()
		{
			_restoreSelectionAfterLoad = false;
			_savedCaretOffset = -1;
			_savedCaretPosition = Point.Empty;
			_savedCaretLine = -1;
			_savedPathToNodeBeforeReload = string.Empty;
		}

		/// <summary>
		/// Sets the current selection based on the node selected in the treeview. Used when there is no source
		/// code loaded.
		/// </summary>
		/// <param name="lastSelectedNode">The last selected node.</param>
		public void SetSelectionForNode(TreeNodeBase lastSelectedNode)
		{
			Clear();

			if (lastSelectedNode == null)
			{
				return;
			}

			_restoreSelectionAfterLoad = true;
			_savedPathToNodeBeforeReload =  lastSelectedNode.GetNodeNamePathToSelectedNode();
		}

		/// <summary>
		/// Sets the current selection based on the position in the source code document.
		/// </summary>
		/// <param name="lastSelectedClassNode">The last selected class node.</param>
		/// <param name="sourceCodeTabControl">The source code tab control which has the files open.</param>
		public void SetSelectionForCaretPosition(ClassTreeNode lastSelectedClassNode, SourceCodeTabControl sourceCodeTabControl)
		{
			Clear();

			_restoreSelectionAfterLoad = true;
			_savedPathToNodeBeforeReload =  lastSelectedClassNode.GetNodeNamePathToSelectedNode();
			if (lastSelectedClassNode.IsExpanded)
			{
				TextEditorControl textEditor = sourceCodeTabControl.ActiveTextEditor;
				if (textEditor != null)
				{
					_savedCaretOffset = textEditor.ActiveTextAreaControl.Caret.Offset;
					_savedCaretPosition = textEditor.ActiveTextAreaControl.Caret.Position;
					_savedCaretLine = textEditor.ActiveTextAreaControl.Caret.Line + 1;
				}
			}
		}

		/// <summary>
		/// Restores the selection (if any) in the supplied treeview and source code text editor.
		/// </summary>
		/// <param name="tvCoverage">The tv coverage.</param>
		/// <param name="sourceCodeTabControl">The source code tabs.</param>
		public void RestoreSelection(CoverageTreeView tvCoverage, SourceCodeTabControl sourceCodeTabControl)
		{
			if (tvCoverage.Nodes.Count == 0)
			{
				return;
			}
			TreeNodeBase currentNode = (TreeNodeBase)tvCoverage.Nodes[0];
			currentNode.Expand();
			if (_restoreSelectionAfterLoad)
			{
				string[] nodePathNames = _savedPathToNodeBeforeReload.Split(currentNode.SelectionPathNodeSeparator);
				if (currentNode.NodeName == nodePathNames[0])
				{
					// We have the correct coverage file.
					int nodeIndex = 1;
					TreeNodeBase nextNode = null;
					ClassTreeNode lastSelectedClassNode = null;

					while (nodeIndex <= nodePathNames.Length - 1)
					{
						nextNode = currentNode.GetChildNodeByName(nodePathNames[nodeIndex]);
						if (nextNode == null)
						{
							break;
						}
						currentNode = nextNode;
						if (nodeIndex < nodePathNames.Length - 1)
						{
							currentNode.Expand();
						}
						if (currentNode is ClassTreeNode)
						{
							// Make sure we select it to ensure the source code is loaded.
							lastSelectedClassNode = (ClassTreeNode)currentNode;
							tvCoverage.SelectedNode = currentNode;
						}
						nodeIndex++;
					}
					if (currentNode != null && lastSelectedClassNode != null && _savedCaretOffset != -1)
					{
						// Force the source code file to be loaded and displayed.
						tvCoverage.SelectedNode = currentNode;
						// Arrived at a method node - but there is a chance that due to overloading it isn't the one we want
						// as all method overloads have the same name in current NCover. So instead we will once again attempt
						// to find the matching node for our saved caret position.
						MethodTreeNode methodToSelect = lastSelectedClassNode.FindNodeContainingSequencePointLine(_savedCaretLine);
						if (methodToSelect != null)
						{
							tvCoverage.SelectedNode = currentNode = methodToSelect;
							TextEditorControl textEditor = sourceCodeTabControl.ActiveTextEditor;
							textEditor.ActiveTextAreaControl.TextArea.Caret.Position = _savedCaretPosition;
							textEditor.Focus();
							return;	// To make sure we don't spoil things by the code below!
						}

					}
				}
			}
			tvCoverage.SelectedNode = currentNode;
			tvCoverage.Focus();
		}

		#endregion Public Methods
	}
}
