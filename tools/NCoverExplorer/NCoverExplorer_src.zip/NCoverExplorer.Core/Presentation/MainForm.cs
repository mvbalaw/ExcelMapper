using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

using ICSharpCode.TextEditor;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Presentation.Controls;
using NCoverExplorer.Core.SourceCode;
using NCoverExplorer.Core.Statistics;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Core.Presentation
{
	/// <summary>
	/// The main browser screen for NCoverExplorer, displaying the Assembly/Namespace/Class/Method nodes and the 
	/// corresponding source code.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form, IStatusMessageRecipient
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private MainFormController _controller;

		private FormStatePersister _formStatePersister;
		private MruMenu _mruMenu;
		private SelectionStateManager _selectionStateManager;
		private bool _isSelectingClassByClickingOnTab;
		private bool _isCtrlKeyPressed;
	
		private CommandBarManager _commandBarManager;
		private CommandBar _menuBar;
		private CommandBar _toolBar;
		private CommandBarMenu _fileMenu;
		private CommandBarMenu _viewMenu;
		private CommandBarMenu _helpMenu;
		private CommandBarContextMenu _treeContextMenu;
		private CommandBarContextMenu _sourceContextMenu;
		private CommandBarContextMenu _statisticsContextMenu;

		private CommandBarButton _openButton;
		private CommandBarButton _mergeButton;
		private CommandBarButton _closeButton;
		private CommandBarButton _saveButton;
		private CommandBarButton _saveAsButton;
		private CommandBarButton _reloadButton;
		private CommandBarButton _exploreFolderButton;
		private CommandBarButton _printButton;
		private CommandBarMenu _recentFilesMenu;
		private CommandBarButton _exitButton;

		private CommandBarMenu _themeMenu;

		private CommandBarMenu _coverageMenu;
		private CommandBarCheckBox _coverageSequencePointPercentButton;
		private CommandBarCheckBox _coverageSequencePointPercentUnvisitedButton;
		private CommandBarCheckBox _coverageSequencePointUnvisitedButton;
		private CommandBarCheckBox _coverageFunctionCoverageButton;

		private CommandBarMenu _filterMenu;
		private CommandBarMenu _contextFilterMenu;
		private CommandBarCheckBox _filterHideFullyCoveredButton;
		private CommandBarCheckBox _filterHideUnvisitedButton;
		private CommandBarCheckBox _filterNoneButton;

		private CommandBarMenu _sortByMenu;
		private CommandBarMenu _contextSortByMenu;
		private CommandBarCheckBox _sortByNameButton;
		private CommandBarCheckBox _sortByClassLineNumberButton;
		private CommandBarCheckBox _sortByCoverageAscendingButton;
		private CommandBarCheckBox _sortByCoverageDescendingButton;
		private CommandBarCheckBox _sortByUnvisitedPointsAscendingButton;
		private CommandBarCheckBox _sortByUnvisitedPointsDescendingButton;
		private CommandBarCheckBox _sortByVisitCountAscendingButton;
		private CommandBarCheckBox _sortByVisitCountDescendingButton;

		private CommandBarButton _statisticsSummaryButton;
		private CommandBarButton _reportsButton;
		private CommandBarCheckBox _showStatisticsPaneButton;
		private CommandBarCheckBox _showToolbarButton;
		private CommandBarButton _showOptionsButton;
		private CommandBarButton _navigatePreviousClassButton;
		private CommandBarButton _navigatePreviousUnvisitedLineButton;
		private CommandBarButton _navigateNextUnvisitedLineButton;
		private CommandBarButton _navigateNextClassButton;

		private CommandBarButton _helpFAQButton;
		private CommandBarButton _helpReleaseNotesButton;
		private CommandBarButton _helpHomePageButton;
		private CommandBarButton _helpBlogButton;
		private CommandBarButton _helpDonationButton;
		private CommandBarButton _helpSendFeedbackButton;
		private CommandBarButton _helpAboutButton;

		private CommandBarButton _editInVSNetButton;
		private CommandBarButton _excludeFromResultsButton;
		private CommandBarButton _includeInResults;
		private CommandBarButton _expandCoveredButton;
		private CommandBarButton _expandAllButton;
		private CommandBarButton _collapseAllButton;

		#endregion Private Variables

		#region Designer Variables

		private System.ComponentModel.IContainer components;
		private StatisticsListView statisticsListView;
		private System.Windows.Forms.StatusBar statusBar;
		private System.Windows.Forms.Panel pnlLeft;
		private System.Windows.Forms.Panel pnlMain;
		private System.Windows.Forms.Splitter splitterTreeView;
		private System.Windows.Forms.ImageList imlTreeView;
		private CoverageTreeView coverageTreeView;
		private System.Windows.Forms.Panel pnlStatistics;
		private System.Windows.Forms.Splitter splitterStatistics;

		private System.Windows.Forms.Label lblSorting;
		private System.Windows.Forms.StatusBarPanel statusBarMessagePanel;
		private NCoverExplorer.Core.Presentation.Mouse.MouseHookComponent mouseHook;
		private SourceCodeTabControl sourceCodeTabControl;

		#endregion Designer Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="MainForm"/> class. 
		/// Constructor for use by designer.
		/// </summary>
		protected MainForm()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MainForm"/> class.
		/// Constructor for use by NCoverExplorer application.
		/// </summary>
		/// <param name="configuration">The NCoverExplorer configuration.</param>
		public MainForm(IExplorerConfiguration configuration) 
			: this()
		{
			_configuration = configuration;

			_CreateController();

			StatusPublisher.Initialise(this);
			_CreateMenus();
			_InitialiseFormControls();

			if (configuration.CommandLineOptions.HasCoverageFileName)
			{
				_controller.LoadCoverageXmlFiles(configuration.CommandLineOptions.CoverageFileNames);
			}
		}

		#endregion Constructors

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(MainForm));
			this.coverageTreeView = new NCoverExplorer.Core.CoverageTree.CoverageTreeView();
			this.imlTreeView = new System.Windows.Forms.ImageList(this.components);
			this.statisticsListView = new NCoverExplorer.Core.Statistics.StatisticsListView();
			this.pnlLeft = new System.Windows.Forms.Panel();
			this.lblSorting = new System.Windows.Forms.Label();
			this.splitterTreeView = new System.Windows.Forms.Splitter();
			this.pnlStatistics = new System.Windows.Forms.Panel();
			this.splitterStatistics = new System.Windows.Forms.Splitter();
			this.pnlMain = new System.Windows.Forms.Panel();
			this.sourceCodeTabControl = new NCoverExplorer.Core.SourceCode.SourceCodeTabControl();
			this.statusBar = new System.Windows.Forms.StatusBar();
			this.statusBarMessagePanel = new System.Windows.Forms.StatusBarPanel();
			this.mouseHook = new NCoverExplorer.Core.Presentation.Mouse.MouseHookComponent(this.components);
			this.pnlLeft.SuspendLayout();
			this.pnlStatistics.SuspendLayout();
			this.pnlMain.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.statusBarMessagePanel)).BeginInit();
			this.SuspendLayout();
			// 
			// coverageTreeView
			// 
			this.coverageTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.coverageTreeView.HideSelection = false;
			this.coverageTreeView.ImageList = this.imlTreeView;
			this.coverageTreeView.Location = new System.Drawing.Point(0, 0);
			this.coverageTreeView.Name = "coverageTreeView";
			this.coverageTreeView.PathSeparator = ".";
			this.coverageTreeView.Size = new System.Drawing.Size(252, 499);
			this.coverageTreeView.Sorted = true;
			this.coverageTreeView.TabIndex = 0;
			// 
			// imlTreeView
			// 
			this.imlTreeView.ImageSize = new System.Drawing.Size(16, 16);
			this.imlTreeView.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlTreeView.ImageStream")));
			this.imlTreeView.TransparentColor = System.Drawing.Color.Transparent;
			// 
			// statisticsListView
			// 
			this.statisticsListView.Dock = System.Windows.Forms.DockStyle.Fill;
			this.statisticsListView.FullRowSelect = true;
			this.statisticsListView.HideSelection = false;
			this.statisticsListView.Location = new System.Drawing.Point(0, 0);
			this.statisticsListView.MultiSelect = false;
			this.statisticsListView.Name = "statisticsListView";
			this.statisticsListView.Size = new System.Drawing.Size(615, 116);
			this.statisticsListView.SmallImageList = this.imlTreeView;
			this.statisticsListView.TabIndex = 1;
			this.statisticsListView.View = System.Windows.Forms.View.Details;
			this.statisticsListView.SelectedIndexChanged += new System.EventHandler(this._OnStatisticsListViewSelectedIndexChanged);
			// 
			// pnlLeft
			// 
			this.pnlLeft.Controls.Add(this.coverageTreeView);
			this.pnlLeft.Controls.Add(this.lblSorting);
			this.pnlLeft.Dock = System.Windows.Forms.DockStyle.Left;
			this.pnlLeft.Location = new System.Drawing.Point(0, 0);
			this.pnlLeft.Name = "pnlLeft";
			this.pnlLeft.Size = new System.Drawing.Size(252, 499);
			this.pnlLeft.TabIndex = 2;
			// 
			// lblSorting
			// 
			this.lblSorting.BackColor = System.Drawing.SystemColors.Window;
			this.lblSorting.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblSorting.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lblSorting.Location = new System.Drawing.Point(0, 0);
			this.lblSorting.Name = "lblSorting";
			this.lblSorting.Size = new System.Drawing.Size(252, 499);
			this.lblSorting.TabIndex = 1;
			this.lblSorting.Text = "Sorting... Please Wait";
			this.lblSorting.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// splitterTreeView
			// 
			this.splitterTreeView.Location = new System.Drawing.Point(252, 0);
			this.splitterTreeView.Name = "splitterTreeView";
			this.splitterTreeView.Size = new System.Drawing.Size(5, 499);
			this.splitterTreeView.TabIndex = 3;
			this.splitterTreeView.TabStop = false;
			// 
			// pnlStatistics
			// 
			this.pnlStatistics.Controls.Add(this.statisticsListView);
			this.pnlStatistics.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlStatistics.DockPadding.Right = 4;
			this.pnlStatistics.Location = new System.Drawing.Point(257, 0);
			this.pnlStatistics.Name = "pnlStatistics";
			this.pnlStatistics.Size = new System.Drawing.Size(619, 116);
			this.pnlStatistics.TabIndex = 4;
			// 
			// splitterStatistics
			// 
			this.splitterStatistics.Dock = System.Windows.Forms.DockStyle.Top;
			this.splitterStatistics.Location = new System.Drawing.Point(257, 116);
			this.splitterStatistics.Name = "splitterStatistics";
			this.splitterStatistics.Size = new System.Drawing.Size(619, 5);
			this.splitterStatistics.TabIndex = 5;
			this.splitterStatistics.TabStop = false;
			// 
			// pnlMain
			// 
			this.pnlMain.Controls.Add(this.sourceCodeTabControl);
			this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlMain.DockPadding.Right = 2;
			this.pnlMain.Location = new System.Drawing.Point(257, 121);
			this.pnlMain.Name = "pnlMain";
			this.pnlMain.Size = new System.Drawing.Size(619, 378);
			this.pnlMain.TabIndex = 6;
			// 
			// sourceCodeTabControl
			// 
			this.sourceCodeTabControl.Appearance = System.Windows.Forms.TabAppearance.Buttons;
			this.sourceCodeTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
			this.sourceCodeTabControl.Location = new System.Drawing.Point(0, 0);
			this.sourceCodeTabControl.Name = "sourceCodeTabControl";
			this.sourceCodeTabControl.SelectedIndex = 0;
			this.sourceCodeTabControl.ShowToolTips = true;
			this.sourceCodeTabControl.Size = new System.Drawing.Size(617, 378);
			this.sourceCodeTabControl.TabIndex = 2;
			// 
			// statusBar
			// 
			this.statusBar.Location = new System.Drawing.Point(0, 499);
			this.statusBar.Name = "statusBar";
			this.statusBar.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						 this.statusBarMessagePanel});
			this.statusBar.ShowPanels = true;
			this.statusBar.Size = new System.Drawing.Size(876, 22);
			this.statusBar.TabIndex = 1;
			// 
			// statusBarMessagePanel
			// 
			this.statusBarMessagePanel.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.statusBarMessagePanel.MinWidth = 100;
			this.statusBarMessagePanel.Width = 860;
			// 
			// mouseHook
			// 
			this.mouseHook.MouseUp += new NCoverExplorer.Core.Presentation.Mouse.MouseHookEventHandler(this._OnMouseHookMouseUp);
			// 
			// MainForm
			// 
			this.AllowDrop = true;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(876, 521);
			this.Controls.Add(this.pnlMain);
			this.Controls.Add(this.splitterStatistics);
			this.Controls.Add(this.pnlStatistics);
			this.Controls.Add(this.splitterTreeView);
			this.Controls.Add(this.pnlLeft);
			this.Controls.Add(this.statusBar);
			this.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.MinimumSize = new System.Drawing.Size(650, 300);
			this.Name = "MainForm";
			this.Text = "NCoverExplorer";
			this.DragDrop += new System.Windows.Forms.DragEventHandler(this._OnMainFormDragDrop);
			this.DragEnter += new System.Windows.Forms.DragEventHandler(this._OnMainFormDragEnter);
			this.pnlLeft.ResumeLayout(false);
			this.pnlStatistics.ResumeLayout(false);
			this.pnlMain.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.statusBarMessagePanel)).EndInit();
			this.ResumeLayout(false);

		}
		
		#endregion Windows Form Designer generated code

		#region Protected Methods

		/// <summary>
		/// Handles window messages - looking for requests to open file in same instance from TestDriven.Net
		/// </summary>
		/// <param name="m">The m.</param>
		protected override void WndProc(ref Message m)
		{
			const short WM_COPYDATA = 74;
			switch (m.Msg)
			{
				case WM_COPYDATA:
					string fileName = RemoteController.Receive(m);
					if (fileName!= null && fileName.Length > 0)
					{
						if (_controller.IsCoverageFileLoaded && coverageTreeView.LastSelectedNode != null)
						{
							_SaveCurrentSelection();
						}
						string[] fileNames = fileName.Split(';');
						_controller.LoadCoverageXmlFiles(fileNames);
					}
					else
					{
						StatusPublisher.Display("Request for open file but no filename passed.");
					}
					return;
			}
			base.WndProc (ref m);
		}

		/// <summary>
		/// Processes the CMD key.
		/// </summary>
		/// <param name="msg">The MSG.</param>
		/// <param name="keyData">The key data.</param>
		/// <returns></returns>
		protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
		{
			if (_commandBarManager.PreProcessMessage(ref msg))
			{
				return true;
			}

			return base.ProcessCmdKey(ref msg, keyData);
		}

		/// <summary>
		/// Make sure that we persist our configuration information such as form position and most recently
		/// used information when closing down the application.
		/// </summary>
		/// <param name="e">The <see cref="T:System.EventArgs"/> that contains the event data.</param>
		protected override void OnClosed(EventArgs e)
		{
			if (_configuration != null)
			{
				_configuration.Persist();
			}
			base.OnClosed (e);
		}

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Control.KeyDown"/> event.
		/// </summary>
		/// <param name="e">A <see cref="T:System.Windows.Forms.KeyEventArgs"/> that contains the event data.</param>
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.Control)
			{
				_isCtrlKeyPressed = true;
			}
			base.OnKeyDown (e);
		}

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Control.KeyUp"/> event.
		/// </summary>
		/// <param name="e">A <see cref="T:System.Windows.Forms.KeyEventArgs"/> that contains the event data.</param>
		protected override void OnKeyUp(KeyEventArgs e)
		{
			base.OnKeyUp (e);
			_isCtrlKeyPressed = false;
		}



		#region Dispose

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion Dispose

		#endregion Protected Methods

		#region Private Methods

		#region Create Menus And Toolbar

		/// <summary>
		/// Create the menus programmatically.
		/// </summary>
		private void _CreateMenus()
		{
			_commandBarManager = new CommandBarManager();
			_menuBar = new CommandBar(_commandBarManager, CommandBarStyle.Menu);
			_toolBar = new CommandBar(_commandBarManager, CommandBarStyle.ToolBar);
	
			// Menu and toolbar
			_openButton = new CommandBarButton(Images.Open, "&Open...", new EventHandler(_OnOpenButtonClick), Keys.Control | Keys.O);
			_mergeButton = new CommandBarButton(Images.Merge, "&Merge...", new EventHandler(_OnMergeButtonClick));
			_saveButton = new CommandBarButton(Images.Save, "&Save", new EventHandler(_OnSaveButtonClick), Keys.Control | Keys.S);
			_saveAsButton = new CommandBarButton("Save &As...", new EventHandler(_OnSaveAsButtonClick));
			_closeButton = new CommandBarButton("&Close", new EventHandler(_OnCloseButtonClick));
			_reloadButton = new CommandBarButton(Images.Reload, "&Reload", new EventHandler(_OnReloadButtonClick), Keys.F5);
			_exploreFolderButton = new CommandBarButton(Images.Explore, "&Explore Coverage Folder", new EventHandler(_OnExploreFolderButtonClick));
			_printButton = new CommandBarButton(Images.Print, "&Print...", new EventHandler(_OnPrintButtonClick));
			_exitButton = new CommandBarButton("E&xit", new EventHandler(_OnExitButtonClick));
		
			_coverageSequencePointPercentButton = new CommandBarCheckBox("&Sequence Points (%)", new EventHandler(_OnCoverageSequencePointPercentButtonClick), Keys.Control | Keys.D1);
			_coverageSequencePointPercentUnvisitedButton = new CommandBarCheckBox("S&equence Points (%) (unvisited#)", new EventHandler(_OnCoverageSequencePointPercentUnvisitedButtonClick), Keys.Control | Keys.D2);
			_coverageSequencePointUnvisitedButton = new CommandBarCheckBox("Se&quence Points (unvisited#)", new EventHandler(_OnCoverageSequencePointUnvisitedButtonClick), Keys.Control | Keys.D3);
			_coverageFunctionCoverageButton = new CommandBarCheckBox("&Function Coverage (visits)", new EventHandler(_OnCoverageFunctionCoverageButtonClick), Keys.Control | Keys.D4);

			_filterHideFullyCoveredButton = new CommandBarCheckBox(Images.Filter100Percent, "Hide All &100% Covered", new EventHandler(_OnFilterHideFullyCoveredClick), Keys.Alt | Keys.D1);
			_filterHideUnvisitedButton = new CommandBarCheckBox(Images.Filter0Percent, "Hide All &Unvisited", new EventHandler(_OnFilterHideUnvisitedClick), Keys.Alt | Keys.D2);
			_filterNoneButton = new CommandBarCheckBox("&None", new EventHandler(_OnFilterNoneClick), Keys.Alt | Keys.D0);
			_filterNoneButton.Checked = true;

			_sortByNameButton = new CommandBarCheckBox("&Name", new EventHandler(_OnSortByNameClick), Keys.Control | Keys.Shift | Keys.D1);
			_sortByClassLineNumberButton = new CommandBarCheckBox("&Name / Method Line #", new EventHandler(_OnSortByClassLineNumberClick), Keys.Control | Keys.Shift | Keys.D2);
			_sortByCoverageAscendingButton = new CommandBarCheckBox("&Coverage % Ascending", new EventHandler(_OnSortByCoverageAscendingClick), Keys.Control | Keys.Shift | Keys.D3);
			_sortByCoverageDescendingButton = new CommandBarCheckBox("C&overage % Descending", new EventHandler(_OnSortByCoverageDescendingClick), Keys.Control | Keys.Shift | Keys.D4);
			_sortByUnvisitedPointsAscendingButton = new CommandBarCheckBox("&Unvisited Points Ascending", new EventHandler(_OnSortByUncoveredAscendingClick), Keys.Control | Keys.Shift | Keys.D5);
			_sortByUnvisitedPointsDescendingButton = new CommandBarCheckBox("Unvi&sited Points Descending", new EventHandler(_OnSortByUncoveredDescendingClick), Keys.Control | Keys.Shift | Keys.D6);
			_sortByVisitCountAscendingButton = new CommandBarCheckBox("&Visit Count Ascending", new EventHandler(_OnSortByVisitCountAscendingClick), Keys.Control | Keys.Shift | Keys.D7);
			_sortByVisitCountDescendingButton = new CommandBarCheckBox("V&isit Count Descending", new EventHandler(_OnSortByVisitCountDescendingClick), Keys.Control | Keys.Shift | Keys.D8);

			_statisticsSummaryButton = new CommandBarButton(Images.Statistics, "&Statistics Summary...", new EventHandler(_OnStatisticsSummaryButtonClick), Keys.F3);
			_reportsButton = new CommandBarButton(Images.Report, "&Reports...", new EventHandler(_OnReportsButtonClick), Keys.F6);
			_showStatisticsPaneButton = new CommandBarCheckBox(Images.ShowStatisticsPane, "Show Statistics &Pane", new EventHandler(_OnShowStatisticsButtonClick));
			_showStatisticsPaneButton.Checked = true;
			_showToolbarButton = new CommandBarCheckBox("Show Tool&bar", new EventHandler(_OnShowToolbarButtonClick));
			_showToolbarButton.Checked = true;
			_showOptionsButton = new CommandBarButton(Images.Options, "&Options...", new EventHandler(_OnOptionsButtonClick), Keys.F2);
			_navigatePreviousClassButton = new CommandBarButton(Images.PreviousClass, "Previous Partially Or Unvisited Class In Namespace", new EventHandler(_OnNavigatePreviousClassButtonClick), Keys.Control | Keys.P);
			_navigatePreviousUnvisitedLineButton = new CommandBarButton(Images.PreviousSequencePt, "Previous Unvisited Line In Class", new EventHandler(_OnNavigatePreviousUnvisitedLineButtonClick), Keys.P);
			_navigateNextUnvisitedLineButton = new CommandBarButton(Images.NextSequencePt, "Next Unvisited Line In Class", new EventHandler(_OnNavigateNextUnvisitedLineButtonClick), Keys.N);
			_navigateNextClassButton = new CommandBarButton(Images.NextClass, "Next Partially Or Unvisited Class In Namespace", new EventHandler(_OnNavigateNextClassButtonClick), Keys.Control | Keys.N);

			_helpFAQButton = new CommandBarButton(Images.Help, "&Frequently Asked Questions", new EventHandler(_OnFAQButtonClick));
			_helpReleaseNotesButton = new CommandBarButton("Release &Notes", new EventHandler(_OnReleaseNotesButtonClick));
			_helpHomePageButton = new CommandBarButton(Images.Home, "&Home Page", new EventHandler(_OnHomePageButtonClick));
			_helpBlogButton = new CommandBarButton("Developer &Blog", new EventHandler(_OnBlogButtonClick));
			_helpDonationButton = new CommandBarButton("&Want To Contribute?", new EventHandler(_OnDonationButtonClick));
			_helpSendFeedbackButton = new CommandBarButton(Images.Mail, "&Send Feedback", new EventHandler(_OnSendFeedbackButtonClick));
			_helpAboutButton = new CommandBarButton("&About NCoverExplorer...", new EventHandler(_OnAboutButtonClick));

			_editInVSNetButton = new CommandBarButton(Images.EditInVSNet, "&Edit In VS.Net", new EventHandler(_OnEditInVSNetContextMenuClick), Keys.Control | Keys.E);
			_excludeFromResultsButton = new CommandBarButton(Images.Exclude, "Ex&clude This From Results", new EventHandler(_OnExcludeFromResultsContextMenuClick), Keys.Delete);
			_includeInResults = new CommandBarButton(Images.Include, "&Include This In Results", new EventHandler(_OnIncludeInResultsContextMenuClick), Keys.Insert);
			_expandCoveredButton = new CommandBarButton("E&xpand Covered", new EventHandler(_OnExpandCoveredContextMenuClick), Keys.Control | Keys.Q);
			_expandAllButton = new CommandBarButton("Ex&pand All", new EventHandler(_OnExpandAllContextMenuClick), Keys.Control | Keys.L);
			_collapseAllButton = new CommandBarButton("Collapse &All", new EventHandler(_OnCollapseAllContextMenuClick));

			_fileMenu = _menuBar.Items.AddMenu("&File");
			_fileMenu.Items.Add(_openButton);
			_fileMenu.Items.Add(_mergeButton);
			_fileMenu.Items.Add(_closeButton);
			_fileMenu.Items.AddSeparator();
			_fileMenu.Items.Add(_saveButton);
			_fileMenu.Items.Add(_saveAsButton);
			_fileMenu.Items.AddSeparator();
			_fileMenu.Items.Add(_reloadButton);
			_fileMenu.Items.Add(_exploreFolderButton);
			_fileMenu.Items.Add(_printButton);
			_fileMenu.Items.AddSeparator();
			_recentFilesMenu = _fileMenu.Items.AddMenu("Recent &Files");
			_fileMenu.Items.AddSeparator();
			_fileMenu.Items.Add(_exitButton);

			_viewMenu = _menuBar.Items.AddMenu("&View");
			_viewMenu.DropDown += new EventHandler(_OnViewMenuDropDown);
			_themeMenu = _viewMenu.Items.AddMenu("&Theme");
			_coverageMenu = _viewMenu.Items.AddMenu("&Coverage");
			_filterMenu = _viewMenu.Items.AddMenu("&Filter");
			_sortByMenu = _viewMenu.Items.AddMenu(Images.Sort, "Sort &By");
			_viewMenu.Items.AddSeparator();
			_viewMenu.Items.Add(_statisticsSummaryButton);
			_viewMenu.Items.Add(_reportsButton);
			_viewMenu.Items.AddSeparator();
			_viewMenu.Items.Add(_showStatisticsPaneButton);
			_viewMenu.Items.Add(_showToolbarButton);
			_viewMenu.Items.AddSeparator();
			_viewMenu.Items.Add(_showOptionsButton);

			_helpMenu = _menuBar.Items.AddMenu("&Help");
			_helpMenu.Items.Add(_helpFAQButton);
			_helpMenu.Items.Add(_helpReleaseNotesButton);
			_helpMenu.Items.AddSeparator();
			_helpMenu.Items.Add(_helpSendFeedbackButton);
			_helpMenu.Items.Add(_helpHomePageButton);	
			_helpHomePageButton.Visible = false; // Until the Home page gets written
			_helpMenu.Items.Add(_helpBlogButton);
			_helpMenu.Items.Add(_helpDonationButton);
			_helpMenu.Items.AddSeparator();
			_helpMenu.Items.Add(_helpAboutButton);

			_coverageMenu.Items.Add(_coverageSequencePointPercentButton);
			_coverageMenu.Items.Add(_coverageSequencePointPercentUnvisitedButton);
			_coverageMenu.Items.Add(_coverageSequencePointUnvisitedButton);
			_coverageMenu.Items.Add(_coverageFunctionCoverageButton);

			_filterMenu.Items.Add(_filterHideFullyCoveredButton);
			_filterMenu.Items.Add(_filterHideUnvisitedButton);
			_filterMenu.Items.AddSeparator();
			_filterMenu.Items.Add(_filterNoneButton);

			_sortByMenu.Items.Add(_sortByNameButton);
			_sortByMenu.Items.Add(_sortByClassLineNumberButton);
			_sortByMenu.Items.Add(_sortByCoverageAscendingButton);
			_sortByMenu.Items.Add(_sortByCoverageDescendingButton);
			_sortByMenu.Items.Add(_sortByUnvisitedPointsAscendingButton);
			_sortByMenu.Items.Add(_sortByUnvisitedPointsDescendingButton);
			_sortByMenu.Items.Add(_sortByVisitCountAscendingButton);
			_sortByMenu.Items.Add(_sortByVisitCountDescendingButton);

			_toolBar.Items.Add(_openButton);
			_toolBar.Items.Add(_mergeButton);
			_toolBar.Items.Add(_saveButton);
			_toolBar.Items.Add(_reloadButton);
			_toolBar.Items.AddSeparator();
			_toolBar.Items.Add(_editInVSNetButton);
			_toolBar.Items.AddSeparator();
			_toolBar.Items.Add(_filterHideFullyCoveredButton);
			_toolBar.Items.Add(_filterHideUnvisitedButton);
			_toolBar.Items.AddSeparator();
			_toolBar.Items.Add(_excludeFromResultsButton);
			_toolBar.Items.Add(_includeInResults);
			_toolBar.Items.AddSeparator();
			_toolBar.Items.Add(_statisticsSummaryButton);
			_toolBar.Items.Add(_reportsButton);
			_toolBar.Items.AddSeparator();
			_toolBar.Items.Add(_showStatisticsPaneButton);
			_toolBar.Items.Add(_showOptionsButton);
			_toolBar.Items.AddSeparator();
			_toolBar.Items.Add(_navigatePreviousClassButton);
			_toolBar.Items.Add(_navigatePreviousUnvisitedLineButton);
			_toolBar.Items.Add(_navigateNextUnvisitedLineButton);
			_toolBar.Items.Add(_navigateNextClassButton);

			_treeContextMenu = new CommandBarContextMenu();
			_treeContextMenu.Items.Add(_expandCoveredButton);
			_treeContextMenu.Items.Add(_expandAllButton);
			_treeContextMenu.Items.Add(_collapseAllButton);
			_treeContextMenu.Items.AddSeparator();
			_contextFilterMenu = _treeContextMenu.Items.AddMenu("&Filter");
			_treeContextMenu.Items.Add(_excludeFromResultsButton);
			_treeContextMenu.Items.Add(_includeInResults);
			_treeContextMenu.Items.AddSeparator();
			_treeContextMenu.Items.Add(_editInVSNetButton);
			_treeContextMenu.Items.AddSeparator();
			_contextSortByMenu = _treeContextMenu.Items.AddMenu(Images.Sort, "Sort &By");
	
			_contextFilterMenu.Items.Add(_filterHideFullyCoveredButton);
			_contextFilterMenu.Items.Add(_filterHideUnvisitedButton);
			_contextFilterMenu.Items.AddSeparator();
			_contextFilterMenu.Items.Add(_filterNoneButton);

			_contextSortByMenu.Items.Add(_sortByNameButton);
			_contextSortByMenu.Items.Add(_sortByClassLineNumberButton);
			_contextSortByMenu.Items.Add(_sortByCoverageAscendingButton);
			_contextSortByMenu.Items.Add(_sortByCoverageDescendingButton);
			_contextSortByMenu.Items.Add(_sortByUnvisitedPointsAscendingButton);
			_contextSortByMenu.Items.Add(_sortByUnvisitedPointsDescendingButton);
			_contextSortByMenu.Items.Add(_sortByVisitCountAscendingButton);
			_contextSortByMenu.Items.Add(_sortByVisitCountDescendingButton);

			coverageTreeView.ContextMenu = _treeContextMenu;

			_sourceContextMenu = new CommandBarContextMenu();
			_sourceContextMenu.Items.Add(_editInVSNetButton);

			_statisticsContextMenu = new CommandBarContextMenu();
			_statisticsContextMenu.Items.Add(_editInVSNetButton);
			statisticsListView.ContextMenu = _statisticsContextMenu;
		
			_commandBarManager.CommandBars.Add(_menuBar);
			_commandBarManager.CommandBars.Add(_toolBar);
			this.Controls.Add(_commandBarManager);
		}

		#endregion CreateMenus

		#region Initialisation

		/// <summary>
		/// Creates the controller and subscribes to key events.
		/// </summary>
		private void _CreateController()
		{
			_controller = new MainFormController(_configuration);
			_controller.CoverageFileLoaded += new CoverageFilesEventHandler(_OnCoverageFileLoaded);
			_controller.CoverageFileLoadFailed += new CoverageFileLoadFailedEventHandler(_OnCoverageFileLoadFailed);
			_controller.CoverageFileSaved += new CoverageFilesEventHandler(_OnCoverageFileSaved);
			_controller.CoverageFileClosed += new EventHandler(_OnCoverageFileClosed);
			_controller.ConfigurationChanged += new ConfigurationChangedEventHandler(_OnConfigurationChanged);
		}

		/// <summary>
		/// Initialise the form controls and class variables.
		/// </summary>
		private void _InitialiseFormControls()
		{
			_HookPersistentFormState();

			_ApplyTheme();

			coverageTreeView.Initialise(_configuration);
			coverageTreeView.BeforeSort += new SortEventHandler(_OnCoverageTreeBeforeSort);
			coverageTreeView.AfterSort += new SortEventHandler(_OnCoverageTreeAfterSort);
			coverageTreeView.AfterClassNodeSelect += new TreeViewEventHandler(_OnCoverageTreeAfterClassNodeSelect);
			coverageTreeView.AfterMethodNodeSelect += new TreeViewEventHandler(_OnCoverageTreeAfterMethodNodeSelect);
			coverageTreeView.AfterNonCodeNodeSelect += new TreeViewEventHandler(_OnCoverageTreeAfterNonCodeNodeSelect);

			sourceCodeTabControl.Initialise(_controller, _configuration, _sourceContextMenu);
			sourceCodeTabControl.Click +=new EventHandler(_OnSourceCodeTabControlClick);
			_isSelectingClassByClickingOnTab = false;

			statisticsListView.Initialise(_configuration);
	
			_selectionStateManager = new SelectionStateManager();
	
			// Construct an inline recent menu items menu.
			_mruMenu = new MruMenu(
				_recentFilesMenu, 
				new MruMenuClickEventHandler(_OnRecentFilesSubMenuButtonClick), 
				_configuration.MruStates, 
				"File", 
				_configuration.NumberOfRecentFiles);

			//toolBarButtonSort.DropDownMenu = toolbarSortContextMenu;
			_UpdateButtonsAfterCoverageFileEvent(false);
			_UpdateButtonStatesAfterSelection();
		}

		#endregion Initialisation

		#region Controller Event Handlers

		/// <summary>
		/// Handles the CoverageFileLoaded event of the controller.
		/// Add the supplied parsed coverage tree nodes onto the screen.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="CoverageFilesEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageFileLoaded(object sender, CoverageFilesEventArgs e)
		{
			if (e.IsNewCoverageTree)
			{
				coverageTreeView.LoadCoverageNodes(e.CoverageFileTreeNode);
			}
			else
			{
				e.CoverageFileTreeNode.InitialiseForFirstDisplay();
			}

			_mruMenu.AddFile(e.FileNames[0]);
			statisticsListView.Items.Clear();
			sourceCodeTabControl.Clear();

			_configuration.TreeFilterStyle = TreeFilterStyle.None;
			if (e.IsNewCoverageTree)
			{
				_selectionStateManager.RestoreSelection(coverageTreeView, sourceCodeTabControl);
			}

			if (!e.IsNewCoverageTree || (_configuration.TreeSortStyle != TreeSortStyle.Name))
			{
				// Need to reapply the sort.
				coverageTreeView.SortTreeView(_configuration.TreeSortStyle);
			}
			_UpdateButtonsAfterCoverageFileEvent(true);

			_SetWindowTitleBasedOnCoverageFileNames(e.FileNames);
			StatusPublisher.Display(string.Format("Loaded in {0:n2} seconds.", e.Duration));
		}

		/// <summary>
		/// Handles the CoverageFileLoadFailed event of the controller.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Presentation.CoverageFileLoadFailedEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageFileLoadFailed(object sender, CoverageFileLoadFailedEventArgs e)
		{
			if (e.IsFileAlreadyLoaded)
			{
				// Nothing necessary to do - warnings already thrown to user.
			}
			else if (e.IsMergeDifferenceProblem)
			{
				string message = "Unable to merge due to unresolvable differences in the coverage files."
					+ Environment.NewLine + "Run your code coverage again to ensure the results are consistent against the same source code."
					+ Environment.NewLine 
					+ Environment.NewLine + "The merge has been aborted.";
				_closeButton.PerformClick();
				MessageBox.Show(message, "NCoverExplorer", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			else if (_mruMenu.FindFileNameMenuIndex(e.FileName) >= 0)
			{
				string message = "The file '" + e.FileName + "' cannot be opened. Do you want to remove the reference to it from the Recent list?";
				if (MessageBox.Show(message, "NCoverExplorer", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
				{
					_mruMenu.RemoveFile(e.FileName);
				}
			}
		}

		/// <summary>
		/// Handles the CoverageFileSaved event of the controller.
		/// Update the meu menu and display time taken.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="CoverageFilesEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageFileSaved(object sender, CoverageFilesEventArgs e)
		{
			_mruMenu.AddFile(e.FileNames[0]);
			e.CoverageFileTreeNode.InitialiseForFirstDisplay();
			_SetWindowTitleBasedOnCoverageFileNames(e.FileNames);
			StatusPublisher.Display(string.Format("Saved in {0:n2} seconds.", e.Duration));
		}

		/// <summary>
		/// Handles the CoverageFileClosed event of the controller.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnCoverageFileClosed(object sender, EventArgs e)
		{
			coverageTreeView.ClearSelectionHistory();
			coverageTreeView.Nodes.Clear();
			statisticsListView.Items.Clear();
			sourceCodeTabControl.Clear();
			_configuration.TreeFilterStyle = TreeFilterStyle.None;
			_UpdateButtonsAfterCoverageFileEvent(false);
			_SetWindowTitleBasedOnCoverageFileNames(null);
			StatusPublisher.Display("Ready");
		}

		/// <summary>
		/// Set window title based on coverage file names.
		/// </summary>
		/// <param name="fileNames">The file names.</param>
		private void _SetWindowTitleBasedOnCoverageFileNames(string[] fileNames)
		{
			if (fileNames == null || fileNames.Length == 0)
			{
				this.Text = "NCoverExplorer";
			}
			else
			{
				this.Text = "NCoverExplorer - " + fileNames[0];
				if (fileNames.Length > 1)
				{
					this.Text += AppearanceHelper.MergedSuffix;
				}
			}
		}

		/// <summary>
		/// Handles the ConfigurationChanged event of the controller.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnConfigurationChanged(object sender, ConfigurationChangedEventArgs e)
		{
			_ApplyTheme();
			if (!e.IsReloadRequired && _controller.IsCoverageFileLoaded)
			{
				_RefreshScreenWithoutReloadingCoverageFile();
			}

			// Force a screen refresh for systems with slower graphics cards
			this.Refresh();

			_mruMenu.MaxEntries = _configuration.NumberOfRecentFiles;

			// Ensure themes menu will be repopulated automatically.
			_themeMenu.Items.Clear();

			if (e.IsReloadRequired && _controller.IsCoverageFileLoaded)
			{
				_HandleReloadCoverageXmlFileRequest();
			}
		}

		/// <summary>
		/// Refresh screen without reloading coverage file after changing themes or some options.
		/// </summary>
		private void _RefreshScreenWithoutReloadingCoverageFile()
		{
			coverageTreeView.RefreshAllNodes();
			statisticsListView.RefreshAllItems();
		}

		/// <summary>
		/// Handle the reload coverage XML file request.
		/// </summary>
		private void _HandleReloadCoverageXmlFileRequest()
		{
			if (!_controller.IsCoverageFileLoaded)
			{
				// User has not loaded a file in this session so do nothing.
				StatusPublisher.Display("No file currently open to reload.");
				return;
			}
			_SaveCurrentSelection();
			sourceCodeTabControl.Clear();
			_controller.ReloadCoverageXmlFile();
		}

		#endregion Controller Event Handlers

		#region Apply Theme

		/// <summary>
		/// Applies the appearance settings as specified in the custom configuration.
		/// </summary>
		private void _ApplyTheme()
		{
			lblSorting.BackColor = _configuration.Theme.CoverageTreeBackgroundColor;
			coverageTreeView.ApplyTheme(_configuration.Theme);
			statisticsListView.ApplyTheme(_configuration.Theme);
			sourceCodeTabControl.ApplyTheme(_configuration.Theme);
		}

		#endregion Apply Theme

		#region Setting Button States

		/// <summary>
		/// Updates button states when a coverage file is loaded or closed.
		/// </summary>
		private void _UpdateButtonsAfterCoverageFileEvent(bool isCoverageFileLoaded)
		{
			_mergeButton.Enabled = isCoverageFileLoaded;
			_saveButton.Enabled = isCoverageFileLoaded && _configuration.GroupByModule;
			_saveAsButton.Enabled = isCoverageFileLoaded;
			_closeButton.Enabled = isCoverageFileLoaded;
			_reloadButton.Enabled = isCoverageFileLoaded;
			_exploreFolderButton.Enabled = isCoverageFileLoaded;
			_printButton.Enabled = isCoverageFileLoaded;

			_filterHideFullyCoveredButton.Enabled = isCoverageFileLoaded;
			_filterHideUnvisitedButton.Enabled = isCoverageFileLoaded;
			_statisticsSummaryButton.Enabled = isCoverageFileLoaded;
			_reportsButton.Enabled = isCoverageFileLoaded;

			_filterMenu.Enabled = isCoverageFileLoaded;
			_contextFilterMenu.Enabled = isCoverageFileLoaded;
			_sortByMenu.Enabled = isCoverageFileLoaded;
			_contextSortByMenu.Enabled = isCoverageFileLoaded;

			_navigatePreviousClassButton.Enabled = false;
			_navigatePreviousUnvisitedLineButton.Enabled = false;
			_navigateNextUnvisitedLineButton.Enabled = false;
			_navigateNextClassButton.Enabled = false;
		}

		/// <summary>
		/// Updates button states when the selection changes in the treeview.
		/// </summary>
		private void _UpdateButtonStatesAfterSelection()
		{
			TreeNodeBase selectedNode = (TreeNodeBase)coverageTreeView.SelectedNode;
			if (selectedNode == null)
			{
				_excludeFromResultsButton.Enabled = false;
				_includeInResults.Enabled = false;
				_editInVSNetButton.Enabled = false;
				_filterHideFullyCoveredButton.Enabled = false;
				_filterHideUnvisitedButton.Enabled = false;

				_expandCoveredButton.Enabled = false;
				_expandAllButton.Enabled = false;
				_collapseAllButton.Enabled = false;

				_navigatePreviousUnvisitedLineButton.Enabled = false;
				_navigateNextUnvisitedLineButton.Enabled = false;
				return;
			}

			bool isChildGetSetOfPropertyNode = (selectedNode is MethodTreeNode) && ((MethodTreeNode)selectedNode).IsNestedProperty;
			_excludeFromResultsButton.Enabled = !(selectedNode is CoverageFileTreeNode) && !selectedNode.IsExcluded && !selectedNode.IsFiltered && !isChildGetSetOfPropertyNode;
			_includeInResults.Enabled = (selectedNode is ExcludedTreeNode) || (selectedNode.IsExcluded && (selectedNode.Parent is ExcludedTreeNode));
			_editInVSNetButton.Enabled = sourceCodeTabControl.IsSourceCodeDisplayed 
				&& (selectedNode is ClassTreeNode || selectedNode is MethodTreeNode);
			_filterHideFullyCoveredButton.Enabled = true;
			_filterHideUnvisitedButton.Enabled = true;

			_navigatePreviousClassButton.Enabled = !selectedNode.IsExcluded && !selectedNode.IsFiltered 
				&& (selectedNode is ClassTreeNode || selectedNode is MethodTreeNode || selectedNode is NamespaceTreeNode);
			_navigateNextClassButton.Enabled = _navigatePreviousClassButton.Enabled;
			_navigatePreviousUnvisitedLineButton.Enabled = !selectedNode.IsExcluded && !selectedNode.IsFiltered 
				&& (selectedNode is ClassTreeNode || selectedNode is MethodTreeNode);
			_navigateNextUnvisitedLineButton.Enabled = _navigatePreviousUnvisitedLineButton.Enabled;

			_expandCoveredButton.Enabled = !(selectedNode is MethodTreeNode) && selectedNode.VisitedSequencePoints > 0;
			_expandAllButton.Enabled = true;
			_collapseAllButton.Enabled = true;

			_UpdateSortingButtonState();
			_SetCurrentFilterButtonStates();
		}

		#endregion Setting Button States

		#region Form State Persistence

		/// <summary>
		/// Creates and hooks event handlers for persistent window state of position and size.
		/// </summary>
		private void _HookPersistentFormState()
		{
			_formStatePersister = new FormStatePersister(this, "MainForm", _configuration.FormStates);

			_formStatePersister.LoadState += new FormStateEventHandler(_OnLoadState);
			_formStatePersister.SaveState += new FormStateEventHandler(_OnSaveState);
		}

		/// <summary>
		/// Handles the LoadState event of the form persistence object.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Configuration.FormStateEventArgs"/> instance containing the event data.</param>
		private void _OnLoadState(object sender, FormStateEventArgs e)
		{
			pnlLeft.Width = e.FormState.GetInt32("LeftPanelWidth", 250);
			pnlStatistics.Height = e.FormState.GetInt32("VisitPaneHeight", 200);

			bool isStatisticsPaneVisible = e.FormState.GetBoolean("ViewStatistics", true);
			if (!isStatisticsPaneVisible)
			{
				_showStatisticsPaneButton.PerformClick();
			}
			pnlStatistics.Visible = isStatisticsPaneVisible;
			splitterStatistics.Visible = isStatisticsPaneVisible;

			bool isToolbarVisible = e.FormState.GetBoolean("ViewToolBar", true);
			if (!isToolbarVisible)
			{
				_showToolbarButton.PerformClick();
			}

			// Get the column widths for the statistics listview
			statisticsListView.LoadColumnWidths(e.FormState);

			// No need to load the MRU menu as the class does that itself.
		}

		/// <summary>
		/// Handles the SaveState event of the form persistence object.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Configuration.FormStateEventArgs"/> instance containing the event data.</param>
		private void _OnSaveState(object sender, FormStateEventArgs e)
		{
			e.FormState.SetValue("LeftPanelWidth", pnlLeft.Width);
			e.FormState.SetValue("ViewStatistics", _showStatisticsPaneButton.Checked);
			e.FormState.SetValue("VisitPaneHeight", pnlStatistics.Height);
			e.FormState.SetValue("ViewToolBar", _toolBar.Visible);

			statisticsListView.SaveColumnWidths(e.FormState);

			// Also save the MRU file menu.
			_mruMenu.SaveToPersistedState();
		}

		#endregion Form State Persistence

		#region Main Menu Event Handlers

		#region File Menu

		private void _OnExitButtonClick(object sender, EventArgs e)
		{
			this.Close();
			Application.Exit();
		}

		private void _OnOpenButtonClick(object sender, EventArgs e)
		{
			_controller.OpenCoverageXmlFile();
		}

		private void _OnMergeButtonClick(object sender, System.EventArgs e)
		{
			_controller.MergeCoverageXmlFile();
		}

		private void _OnCloseButtonClick(object sender, System.EventArgs e)
		{
			_controller.CloseCoverageFile();
		}

		private void _OnReloadButtonClick(object sender, EventArgs e)
		{
			_HandleReloadCoverageXmlFileRequest();
		}

		private void _OnSaveButtonClick(object sender, System.EventArgs e)
		{
			_controller.SaveCoverageFile();
		}

		private void _OnSaveAsButtonClick(object sender, System.EventArgs e)
		{
			_controller.SaveAsCoverageFile();
		}

		private void _OnExploreFolderButtonClick(object sender, EventArgs e)
		{
			Process.Start(Path.GetDirectoryName(_controller.CoverageFileNames[0]));
		}

		private void _OnPrintButtonClick(object sender, EventArgs e)
		{
			sourceCodeTabControl.ActiveTextEditor.PrintDocument.Print();
		}

		/// <summary>
		/// Handles the click events of the recent files menu.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.Presentation.Controls.MruMenuClickEventArgs"/> instance containing the event data.</param>
		private void _OnRecentFilesSubMenuButtonClick(object sender, MruMenuClickEventArgs e)
		{
			_mruMenu.SetFirstFile(e.Number);
			_controller.LoadCoverageXmlFile(e.FileName);
		}

		#endregion File Menu

		#region View Menu

		private void _OnViewMenuDropDown(object sender, EventArgs e)
		{
			_DynamicallyCreateThemeSubMenu();
			_UpdateCoverageMenuButtonStates();
		}

		private void _OnShowStatisticsButtonClick(object sender, EventArgs e)
		{
			pnlStatistics.Visible = _showStatisticsPaneButton.Checked;
			splitterStatistics.Visible = _showStatisticsPaneButton.Checked;
		}

		private void _OnShowToolbarButtonClick(object sender, System.EventArgs e)
		{
			if (_commandBarManager.CommandBars.Contains(_toolBar))
			{
				_commandBarManager.CommandBars.Remove(_toolBar);
			}
			else
			{
				_commandBarManager.CommandBars.Add(_toolBar);
			}
		}

		private void _OnStatisticsSummaryButtonClick(object sender, System.EventArgs e)
		{
			_controller.ShowStatisticsSummaryDialog();
		}

		private void _OnReportsButtonClick(object sender, System.EventArgs e)
		{
			_controller.ShowReportsDialog();
		}

		private void _OnOptionsButtonClick(object sender, EventArgs e)
		{
			_controller.ShowOptionsDialog();
		}

		#endregion View Menu

		#region Themes Menu

		/// <summary>
		/// Dynamically create the theme submenu from the list of available themes.
		/// </summary>
		private void _DynamicallyCreateThemeSubMenu()
		{
			if (_themeMenu.Items.Count != 0)
			{
				// Nothing to do
				return;
			}
			string[] names = new string[_configuration.Themes.Count];
			int index = 0;
			foreach (Theme theme in _configuration.Themes)
			{
				names[index++] = theme.Name;
			}
			Array.Sort(names);

			CommandBarCheckBox themeMenuItem;
			foreach (string name in names)
			{
				themeMenuItem = _themeMenu.Items.AddCheckBox(name);
				themeMenuItem.Click += new EventHandler(_OnThemeSubMenuButtonClick);
				if (name == _configuration.Theme.Name)
				{
					themeMenuItem.Checked = true;
				}
			}
		}

		/// <summary>
		/// Handles the click events of the themes submenus.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnThemeSubMenuButtonClick(object sender, EventArgs e)
		{
			CommandBarCheckBox menuItem = (CommandBarCheckBox)sender;
			_configuration.Theme = _configuration.Themes[menuItem.Text].Clone();
			_ApplyTheme();
			// Ensure that the themes menu will be recreated next time to display appropriate checkbox
			_themeMenu.Items.Clear();
			_RefreshScreenWithoutReloadingCoverageFile();
		}

		#endregion Themes Menu

		#region Coverage Menu

		private void _UpdateCoverageMenuButtonStates()
		{
			_coverageSequencePointPercentButton.Checked = (_configuration.CoverageTreeReportStyle == CoverageTreeReportStyle.SequencePointCoveragePercentage);
			_coverageSequencePointPercentUnvisitedButton.Checked = (_configuration.CoverageTreeReportStyle == CoverageTreeReportStyle.SequencePointCoveragePercentageAndUnvisitedSeqPts);
			_coverageSequencePointUnvisitedButton.Checked = (_configuration.CoverageTreeReportStyle == CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints);
			_coverageFunctionCoverageButton.Checked = (_configuration.CoverageTreeReportStyle == CoverageTreeReportStyle.FunctionCoverage);
		}

		private void _OnCoverageSequencePointPercentButtonClick(object sender, System.EventArgs e)
		{
			if (_configuration.CoverageTreeReportStyle != CoverageTreeReportStyle.SequencePointCoveragePercentage)
			{
				_SwitchCoverageReportStyle(CoverageTreeReportStyle.SequencePointCoveragePercentage);
			}
		}

		private void _OnCoverageSequencePointPercentUnvisitedButtonClick(object sender, System.EventArgs e)
		{
			if (_configuration.CoverageTreeReportStyle != CoverageTreeReportStyle.SequencePointCoveragePercentageAndUnvisitedSeqPts)
			{
				_SwitchCoverageReportStyle(CoverageTreeReportStyle.SequencePointCoveragePercentageAndUnvisitedSeqPts);
			}
		}

		private void _OnCoverageSequencePointUnvisitedButtonClick(object sender, System.EventArgs e)
		{
			if (_configuration.CoverageTreeReportStyle != CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints)
			{
				_SwitchCoverageReportStyle(CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints);
			}
		}

		private void _OnCoverageFunctionCoverageButtonClick(object sender, System.EventArgs e)
		{
			if (_configuration.CoverageTreeReportStyle != CoverageTreeReportStyle.FunctionCoverage)
			{
				_SwitchCoverageReportStyle(CoverageTreeReportStyle.FunctionCoverage);
			}
		}
		
		/// <summary>
		/// Switch the coverage report style.
		/// </summary>
		/// <param name="coverageTreeReportStyle">The coverage tree report style.</param>
		private void _SwitchCoverageReportStyle(CoverageTreeReportStyle coverageTreeReportStyle)
		{
			_configuration.CoverageTreeReportStyle = coverageTreeReportStyle;
			_UpdateCoverageMenuButtonStates();
			_RefreshScreenWithoutReloadingCoverageFile();
		}

		#endregion Coverage Menu

		#region Help Menu

		private void _OnFAQButtonClick(object sender, EventArgs e)
		{
			_controller.ShowFAQPage();
		}

		private void _OnReleaseNotesButtonClick(object sender, EventArgs e)
		{
			_controller.ShowReleaseNotesPage();
		}

		private void _OnHomePageButtonClick(object sender, EventArgs e)
		{
			_controller.ShowHomePage();
		}

		private void _OnBlogButtonClick(object sender, EventArgs e)
		{
			_controller.ShowBlogPage();
		}

		private void _OnDonationButtonClick(object sender, System.EventArgs e)
		{
			_controller.ShowDonationPage();
		}

		private void _OnSendFeedbackButtonClick(object sender, EventArgs e)
		{
			_controller.RequestFeedback();
		}

		private void _OnAboutButtonClick(object sender, EventArgs e)
		{
			_controller.ShowAboutDialog();
		}

		#endregion Help Menu

		#endregion Main Menu Event Handlers

		#region Context Menu Event Handlers
 
		/// <summary>
		/// Handles the Click event of the "Edit In VS.Net" ContextMenu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnEditInVSNetContextMenuClick(object sender, EventArgs e)
		{
			_OnOpenSourceInVSNet();
		}

		/// <summary>
		/// Handles the Click event of the "Expand Covered" ContextMenu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnExpandCoveredContextMenuClick(object sender, System.EventArgs e)
		{
			TreeNodeBase selectedNode = (TreeNodeBase)coverageTreeView.SelectedNode;

			if ((selectedNode != null)
				&& !(selectedNode is MethodTreeNode)
				&& (selectedNode.VisitedSequencePoints > 0))
			{
				StatusPublisher.Display("Expanding nodes with coverage...");
				HighPerformanceTimer timer = new HighPerformanceTimer();
				Cursor.Current = Cursors.WaitCursor;
				timer.Start();

				coverageTreeView.ExpandCoveredNodes(selectedNode);

				timer.Stop();
				selectedNode.EnsureVisible();
				StatusPublisher.Display(string.Format("Expanded in {0:n2} seconds.", timer.Duration));
				Cursor.Current = Cursors.Default;
			}
		}

		/// <summary>
		/// Handles the Click event of the "Expand All" ContextMenu control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnExpandAllContextMenuClick(object sender, System.EventArgs e)
		{
			if (coverageTreeView.Nodes.Count > 0)
			{
				Cursor.Current = Cursors.WaitCursor;

				coverageTreeView.ExpandAll();

				Cursor.Current = Cursors.Default;
				StatusPublisher.Display("All namespaces expanded.");
			}
		}

		/// <summary>
		/// Handles the Click event of the ctxTreeCollapseAll control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnCollapseAllContextMenuClick(object sender, System.EventArgs e)
		{
			if (coverageTreeView.Nodes.Count > 0)
			{
				TreeNodeBase rootNode = ((TreeNodeBase)coverageTreeView.Nodes[0]);
				Cursor.Current = Cursors.WaitCursor;

				rootNode.CollapseRecursive();
				// Close all the tabs.
				sourceCodeTabControl.Clear();
				// Now select the root node to make sure all the other screen elements are updated.
				coverageTreeView.SelectAndClickNode(rootNode);

				Cursor.Current = Cursors.Default;
				StatusPublisher.Display("All namespaces collapsed.");
			}
		}

		/// <summary>
		/// Handles the Click event of the "Exclude From Results" ContextMenu control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnExcludeFromResultsContextMenuClick(object sender, System.EventArgs e)
		{
			TreeNodeBase selectedNode = (TreeNodeBase)coverageTreeView.SelectedNode;
			bool isChildGetSetOfPropertyNode = (selectedNode is MethodTreeNode) && ((MethodTreeNode)selectedNode).IsNestedProperty;
			if (selectedNode.IsExcluded || selectedNode is CoverageFileTreeNode || selectedNode.IsFiltered || isChildGetSetOfPropertyNode)
			{
				StatusPublisher.Display("The selected item is not excludable.");
				return;
			}

			coverageTreeView.BeginUpdate();
			Cursor.Current = Cursors.WaitCursor;
			try
			{
				// Exclude the node from the tree and recalculate coverage recursively upwards.
				SourceCodeTabInfo activeTabInfo = sourceCodeTabControl.ActiveTabInfo;
				TreeNodeBase newSelectedNode = coverageTreeView.GetSelectedNodeAfterExcludingFromResults(selectedNode);
			
				if (activeTabInfo != null)
				{
					activeTabInfo.SourceCodeTextEditor.Document.MarkerStrategy.TextMarker.Clear();
					sourceCodeTabControl.LoadAndHighlightClassCode(activeTabInfo.ClassTreeNode);
				}

				if (newSelectedNode != null)
				{
					coverageTreeView.SelectAndClickNode(newSelectedNode);
				}
			}
			finally
			{
				coverageTreeView.EndUpdate();
				Cursor.Current = Cursors.Default;
			}
		}

		/// <summary>
		/// Handles the Click event of the "Include In Results" ContextMenu control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnIncludeInResultsContextMenuClick(object sender, System.EventArgs e)
		{
			TreeNodeBase selectedNode = (TreeNodeBase)coverageTreeView.SelectedNode;
			bool isExcludedBinNode = (selectedNode is ExcludedTreeNode);
			bool isDirectChildOfExclusionBin = selectedNode.IsExcluded && (selectedNode.Parent is ExcludedTreeNode);
			if (!isExcludedBinNode && !isDirectChildOfExclusionBin)
			{
				return;
			}

			coverageTreeView.BeginUpdate();
			Cursor.Current = Cursors.WaitCursor;
			try
			{
				SourceCodeTabInfo activeTabInfo = sourceCodeTabControl.ActiveTabInfo;
				if (isExcludedBinNode)
				{
					// Iterate through all the child nodes and include them in the results
					selectedNode = coverageTreeView.GetSelectedNodeAfterIncludingAllInResults((ExcludedTreeNode)selectedNode);
				}
				else if (isDirectChildOfExclusionBin && selectedNode.Parent.Nodes.Count == 1)
				{
					selectedNode = coverageTreeView.GetSelectedNodeAfterIncludingAllInResults((ExcludedTreeNode)selectedNode.Parent);
				}
				else if (isDirectChildOfExclusionBin)
				{
					// Just include this node.
					coverageTreeView.IncludeNodeInResults(selectedNode);
					TreeViewSorter.SortTreeNodeChildren(selectedNode.Parent);
				}
			
				if (activeTabInfo != null)
				{
					activeTabInfo.SourceCodeTextEditor.Document.MarkerStrategy.TextMarker.Clear();
					sourceCodeTabControl.LoadAndHighlightClassCode(activeTabInfo.ClassTreeNode);
				}

				coverageTreeView.SelectAndClickNode(selectedNode);
			}
			finally
			{
				coverageTreeView.EndUpdate();
				Cursor.Current = Cursors.Default;
			}
		}

		#endregion Context Menu Event Handlers

		#region Filter Event Handlers

		/// <summary>
		/// Sets the current sorting main menu items checked.
		/// </summary>
		private void _SetCurrentFilterButtonStates()
		{
			TreeFilterStyle treefilterStyle = _configuration.TreeFilterStyle;
			_filterHideFullyCoveredButton.Checked = (treefilterStyle == TreeFilterStyle.HideFullyCovered);
			_filterHideUnvisitedButton.Checked = (treefilterStyle == TreeFilterStyle.HideUnvisited);
			_filterNoneButton.Checked = (treefilterStyle == TreeFilterStyle.None);
			_toolBar.Refresh();
		}

		/// <summary>
		/// Handles the Click event of the FilterHideFullyCovered menus.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnFilterHideFullyCoveredClick(object sender, System.EventArgs e)
		{
			_SetCurrentFilterButtonStates();
			coverageTreeView.FilterTreeView(TreeFilterStyle.HideFullyCovered);
		}

		/// <summary>
		/// Handles the Click event of the FilterHideUnvisited menus.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnFilterHideUnvisitedClick(object sender, System.EventArgs e)
		{
			_SetCurrentFilterButtonStates();
			coverageTreeView.FilterTreeView(TreeFilterStyle.HideUnvisited);
		}

		/// <summary>
		/// Handles the Click event of the FilterNone menus.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnFilterNoneClick(object sender, System.EventArgs e)
		{
			_SetCurrentFilterButtonStates();
			coverageTreeView.FilterTreeView(TreeFilterStyle.None);
		}

		#endregion Filter Event Handlers

		#region Sorting Event Handlers

		/// <summary>
		/// Sets the current sorting context menu item checked.
		/// </summary>
		private void _UpdateSortingButtonState()
		{
			TreeSortStyle treeSortStyle = _configuration.TreeSortStyle;
			_sortByNameButton.Checked = (treeSortStyle == TreeSortStyle.Name);
			_sortByClassLineNumberButton.Checked = (treeSortStyle == TreeSortStyle.ClassLine);
			_sortByCoverageAscendingButton.Checked = (treeSortStyle == TreeSortStyle.CoveragePercentageAscending);
			_sortByCoverageDescendingButton.Checked = (treeSortStyle == TreeSortStyle.CoveragePercentageDescending);
			_sortByUnvisitedPointsAscendingButton.Checked = (treeSortStyle == TreeSortStyle.UnvisitedSequencePointsAscending);
			_sortByUnvisitedPointsDescendingButton.Checked = (treeSortStyle == TreeSortStyle.UnvisitedSequencePointsDescending);
			_sortByVisitCountAscendingButton.Checked = (treeSortStyle == TreeSortStyle.VisitCountAscending);
			_sortByVisitCountDescendingButton.Checked = (treeSortStyle == TreeSortStyle.VisitCountDescending);
		}

		/// <summary>
		/// Handles the Click event of the SortName menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByNameClick(object sender, EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.Name);
			_UpdateSortingButtonState();
		}

		/// <summary>
		/// Handles the Click event of the SortLineNumber menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByClassLineNumberClick(object sender, EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.ClassLine);
			_UpdateSortingButtonState();
		}

		/// <summary>
		/// Handles the Click event of the SortCoverageAscending menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByCoverageAscendingClick(object sender, EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.CoveragePercentageAscending);
			_UpdateSortingButtonState();
		}

		/// <summary>
		/// Handles the Click event of the SortCoverageDescending menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByCoverageDescendingClick(object sender, EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.CoveragePercentageDescending);
			_UpdateSortingButtonState();
		}

		/// <summary>
		/// Handles the Click event of the SortUncoveredAscending menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByUncoveredAscendingClick(object sender, EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.UnvisitedSequencePointsAscending);
			_UpdateSortingButtonState();
		}

		/// <summary>
		/// Handles the Click event of the SortUncoveredDescending menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByUncoveredDescendingClick(object sender, EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.UnvisitedSequencePointsDescending);
			_UpdateSortingButtonState();
		}

		/// <summary>
		/// Handles the Click event of the SortVisitCountAscending menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByVisitCountAscendingClick(object sender, System.EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.VisitCountAscending);
			_UpdateSortingButtonState();
		}

		/// <summary>
		/// Handles the Click event of the SortVisitCountDescending menu controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSortByVisitCountDescendingClick(object sender, System.EventArgs e)
		{
			coverageTreeView.SortTreeView(TreeSortStyle.VisitCountDescending);
			_UpdateSortingButtonState();
		}

		#endregion Sorting Event Handlers

		#region CoverageTreeView Event Handlers

		/// <summary>
		/// Handles the BeforeSort event of the CoverageTree control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.CoverageTree.SortEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageTreeBeforeSort(object sender, SortEventArgs e)
		{
			Cursor.Current = Cursors.WaitCursor;
			lblSorting.BringToFront();
			lblSorting.Refresh();
			pnlLeft.Refresh();
			StatusPublisher.Display("Sorting...");

			statisticsListView.Items.Clear();
			sourceCodeTabControl.Clear();
		}

		/// <summary>
		/// Handles the AfterSort event of the CoverageTree control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="NCoverExplorer.Core.CoverageTree.SortEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageTreeAfterSort(object sender, SortEventArgs e)
		{
			coverageTreeView.BringToFront();
			coverageTreeView.SelectedNode = e.SelectedNode;
			e.SelectedNode.EnsureVisible();
			if (e.SelectedNode is ClassTreeNode)
			{
				// Ensure the statistics pane is refreshed after sorting.
				_OnCoverageTreeAfterClassNodeSelect(coverageTreeView, new TreeViewEventArgs(e.SelectedNode));
			}

			StatusPublisher.Display(string.Format("Sorted in {0:n2} seconds.", e.ElapsedTime));
			Cursor.Current = Cursors.Default;
		}

		/// <summary>
		/// Handles the AfterClassNodeSelect event of the CoverageTreeView control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.TreeViewEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageTreeAfterClassNodeSelect(object sender, TreeViewEventArgs e)
		{
			ClassTreeNode classTreeNode = (ClassTreeNode)e.Node;
			statisticsListView.PopulateStatisticsListViewForClass(classTreeNode);

			if (statisticsListView.Items.Count > 0)
			{
				StatisticsListViewItem firstListViewItem = (StatisticsListViewItem) this.statisticsListView.Items[0];

				if (!_isSelectingClassByClickingOnTab)
				{
					string fileName = firstListViewItem.SequencePoint.FileName;
					if (!sourceCodeTabControl.IsTabForFileLoaded(fileName))
					{
						coverageTreeView.ClearSelectionHistory();
						if (!sourceCodeTabControl.LoadAndHighlightClassCode(coverageTreeView.GetCurrentClassTreeNode()))
						{
							coverageTreeView.Focus();
							_UpdateButtonStatesAfterSelection();
							return;
						}
						sourceCodeTabControl.ActiveTextEditor.ActiveTextAreaControl.Refresh();
					}
					sourceCodeTabControl.DisplayTab(firstListViewItem.SequencePoint.FileName);
					// We know we have the file loaded in a tab - but if multiple classes are declared in that file
					// then it's possible this class was not highlighted in it yet.
					sourceCodeTabControl.EnsureClassHighlightedInTab(coverageTreeView.GetCurrentClassTreeNode());
				}

				coverageTreeView.Focus();
			}

			// Update the status bar with the full namespace path to this class.
			StatusPublisher.Display(classTreeNode.FullyQualifiedDisplayName);
			_UpdateButtonStatesAfterSelection();
		}

		/// <summary>
		/// Handles the AfterMethodNodeSelect event of the CoverageTreeView control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.TreeViewEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageTreeAfterMethodNodeSelect(object sender, TreeViewEventArgs e)
		{
			MethodTreeNode methodTreeNode = (MethodTreeNode)e.Node;
			statisticsListView.PopulateStatisticsListViewForMethod(methodTreeNode);

			if (statisticsListView.Items.Count > 0)
			{
				StatisticsListViewItem firstListViewItem = (StatisticsListViewItem) this.statisticsListView.Items[0];
				string fileName = firstListViewItem.SequencePoint.FileName;
				if (!sourceCodeTabControl.IsTabForFileLoaded(fileName))
				{
					coverageTreeView.ClearSelectionHistory();
					if (!sourceCodeTabControl.LoadAndHighlightClassCode(coverageTreeView.GetCurrentClassTreeNode()))
					{
						coverageTreeView.Focus();
						_UpdateButtonStatesAfterSelection();
						return;
					}
				}
				sourceCodeTabControl.DisplayTab(fileName);
				// We know we have the file loaded in a tab - but if multiple classes are declared in that file
				// then it's possible this class was not highlighted in it yet.
				sourceCodeTabControl.EnsureClassHighlightedInTab(coverageTreeView.GetCurrentClassTreeNode());
				coverageTreeView.Focus();

				// Select the first list view item to try to ensure the start of the method source code is visible.
				_ScrollToFirstSequencePointForFile(fileName);
				// Select the last list view item to try to ensure end of method source code is visible.
				_ScrollToLastSequencePointForFile(fileName);

				// Now select the first item which has a visit count of 0 if any.
				// If we don't find any just go to the first line in the visit count window.
				statisticsListView.SelectFirstZeroCoverageItem();
			}
			coverageTreeView.Focus();

			// Finally let's update the status bar with the file name for the method
			// Update the status bar with the full namespace path to this method.
			StatusPublisher.Display(methodTreeNode.FullyQualifiedDisplayName);
			_UpdateButtonStatesAfterSelection();
		}

		/// <summary>
		/// Handles the AfterNonCodeNodeSelect event of the CoverageTreeView control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.TreeViewEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageTreeAfterNonCodeNodeSelect(object sender, TreeViewEventArgs e)
		{
			statisticsListView.Items.Clear();

			// Update the status bar with the full namespace path to this node.
			TreeNodeBase selectedNode = (TreeNodeBase)e.Node;
			StatusPublisher.Display(selectedNode.FullyQualifiedDisplayName);
			_UpdateButtonStatesAfterSelection();
		}

		/// <summary>
		/// Scroll the source code window to the sequence point with the specified index.
		/// </summary>
		private void _ScrollToFirstSequencePointForFile(string fileName)
		{
			for (int index = 0; index < statisticsListView.Items.Count; index++)
			{
				StatisticsListViewItem statisticsListViewItem = (StatisticsListViewItem)statisticsListView.Items[index];
				if (statisticsListViewItem.SequencePoint.FileName == fileName)
				{
					sourceCodeTabControl.ActiveTextEditor.ScrollToSequencePoint(statisticsListViewItem.SequencePoint, false);
					break;
				}
			}
		}

		/// <summary>
		/// Scroll the source code window to the last sequence point with the matching filename.
		/// </summary>
		private void _ScrollToLastSequencePointForFile(string fileName)
		{
			for (int index = statisticsListView.Items.Count - 1; index > 0; index--)
			{
				StatisticsListViewItem statisticsListViewItem = (StatisticsListViewItem)statisticsListView.Items[index];
				if (statisticsListViewItem.SequencePoint.FileName == fileName)
				{
					sourceCodeTabControl.ActiveTextEditor.ScrollToSequencePoint(statisticsListViewItem.SequencePoint, false);
					break;
				}
			}
		}

		#endregion CoverageTreeView Event Handlers

		#region Statistics ListView Event Handlers

		/// <summary>
		/// Handles the SelectedIndexChanged event of the listView control. Clicking on an item in
		/// this control will force the relevant source code to be scrolled into view and highlighted.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnStatisticsListViewSelectedIndexChanged(object sender, EventArgs e)
		{
			if (statisticsListView.SelectedItems.Count == 1)
			{
				StatisticsListViewItem statisticsListViewItem = (StatisticsListViewItem)statisticsListView.SelectedItems[0];
				SequencePoint sequencePoint = statisticsListViewItem.SequencePoint;

				if (sourceCodeTabControl.ActiveTextEditor != null)
				{
					sourceCodeTabControl.ActiveTextEditor.ClearExistingSelection();
				}
				if (!sourceCodeTabControl.IsTabForFileLoaded(sequencePoint.FileName))
				{
					coverageTreeView.ClearSelectionHistory();
					sourceCodeTabControl.LoadAndHighlightClassCode(coverageTreeView.GetCurrentClassTreeNode());
				}

				// Display the source file if we are not already.
				sourceCodeTabControl.DisplayTab(sequencePoint.FileName);
                
				if (sourceCodeTabControl.IsSourceCodeDisplayed)
				{
					sourceCodeTabControl.ActiveTextEditor.ScrollToSequencePoint(sequencePoint, true);
				}
				// Ensure that for users scrolling up/down with the keyboard that a filename change didnt steal focus
				statisticsListView.Focus();
			}
		}

		#endregion Statistics ListView Event Handlers

		#region SourceCodeTabControl Event Handlers
		
		/// <summary>
		/// Handles the Click event of the SourceCodeTabControl control. Resync the tree node by selecting the class
		/// that this tab belongs to.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnSourceCodeTabControlClick(object sender, EventArgs e)
		{
			if (sourceCodeTabControl.SelectedTab != null)
			{
				SourceCodeTabInfo sourceCodeTabInfo = (SourceCodeTabInfo)sourceCodeTabControl.SelectedTab.Tag;
				if (sourceCodeTabInfo.ClassTreeNode != null)
				{
					if (sourceCodeTabInfo.ClassTreeNode != coverageTreeView.GetCurrentClassTreeNode())
					{
						_isSelectingClassByClickingOnTab = true;
						coverageTreeView.SelectAndClickNode(sourceCodeTabInfo.ClassTreeNode);
						_isSelectingClassByClickingOnTab = false;
						sourceCodeTabControl.Focus();
					}
				}
			}
		}

		#endregion SourceCodeTabControl Event Handlers

		#region Navigation Buttons Event Handlers

		/// <summary>
		/// Handles the Click event of the NavigateNextClassButton control.
		/// </summary>
		private void _OnNavigateNextClassButtonClick(object sender, EventArgs e)
		{
			_SelectNextClassInNamespace();
			//_SelectNextSequencePointInClass();
		}

		/// <summary>
		/// Handles the Click event of the NavigateNextUnvisitedLineButton control.
		/// </summary>
		private void _OnNavigateNextUnvisitedLineButtonClick(object sender, EventArgs e)
		{
			_SelectNextUnvisitedLineInClass();
		}

		/// <summary>
		/// Handles the Click event of the NavigatePreviousUnvisitedLineButton control.
		/// </summary>
		private void _OnNavigatePreviousUnvisitedLineButtonClick(object sender, EventArgs e)
		{
			_SelectPreviousUnvisitedLineInClass();
		}

		/// <summary>
		/// Handles the Click event of the NavigatePreviousClassButton control.
		/// </summary>
		private void _OnNavigatePreviousClassButtonClick(object sender, EventArgs e)
		{
			_SelectPreviousClassInNamespace();
			//_SelectNextSequencePointInClass();
		}

		private void _SelectNextClassInNamespace()
		{
			// Iterate up to find the namespace node.
			int currentClassIndex = 0;
			NamespaceTreeNode namespaceTreeNode = _GetParentNamespaceTreeNode(ref currentClassIndex);
			if (namespaceTreeNode == null)
			{
				return;
			}
			if (!_SelectNextUnvisitedClassInNamespace(namespaceTreeNode, currentClassIndex + 1, namespaceTreeNode.Nodes.Count - 1))
			{
				// Reset to the beginning of the namespace classes.
				_SelectNextUnvisitedClassInNamespace(namespaceTreeNode, 0, currentClassIndex);
			}
		}

		private void _SelectPreviousClassInNamespace()
		{
			// Iterate up to find the namespace node.
			int currentClassIndex = 0;
			NamespaceTreeNode namespaceTreeNode = _GetParentNamespaceTreeNode(ref currentClassIndex);
			if (namespaceTreeNode == null)
			{
				return;
			}
			if (!_SelectPreviousUnvisitedClassInNamespace(namespaceTreeNode, 0, currentClassIndex - 1))
			{
				// Move to the end of the namespace classes.
				_SelectPreviousUnvisitedClassInNamespace(namespaceTreeNode, currentClassIndex, namespaceTreeNode.Nodes.Count - 1);
			}
		}

		private NamespaceTreeNode _GetParentNamespaceTreeNode(ref int currentClassIndex)
		{
			TreeNode treeNode = coverageTreeView.SelectedNode;
			while (treeNode != null && !(treeNode is NamespaceTreeNode))
			{
				if (treeNode is ClassTreeNode)
				{
					currentClassIndex = treeNode.Index;
				}
				treeNode = treeNode.Parent;
			}
			return treeNode as NamespaceTreeNode;
		}

		private void _SelectPreviousUnvisitedLineInClass()
		{
			if (coverageTreeView.SelectedNode is ClassTreeNode)
			{
				ClassTreeNode classTreeNode = coverageTreeView.SelectedNode as ClassTreeNode;
				_SelectPreviousUnvisitedMethodInClass(classTreeNode, 0, classTreeNode.Nodes.Count - 1);
			}
			else
			{
				// Currently within a method. Try to navigate to previous sequence point in the method.
				if (!statisticsListView.NavigateToPreviousUnvisitedLineInMethod())
				{
					// No unvisited sequence point, move to the previous unvisited method in the class.
					ClassTreeNode classTreeNode = coverageTreeView.SelectedNode.Parent as ClassTreeNode;
					if (classTreeNode != null)
					{
						int currentIndex = coverageTreeView.SelectedNode.Index;
						if (!_SelectPreviousUnvisitedMethodInClass(classTreeNode, 0, currentIndex - 1))
						{
							// Move to the end of the class methods.
							_SelectPreviousUnvisitedMethodInClass(classTreeNode, currentIndex, classTreeNode.Nodes.Count - 1);
						}
					}
				}
			}
		}

		private void _SelectNextUnvisitedLineInClass()
		{
			if (coverageTreeView.SelectedNode is ClassTreeNode)
			{
				ClassTreeNode classTreeNode = coverageTreeView.SelectedNode as ClassTreeNode;
				_SelectNextUnvisitedMethodInClass(classTreeNode, 0, classTreeNode.Nodes.Count - 1);
			}
			else
			{
				// Currently within a method. Try to navigate to next sequence point in the method.
				if (!statisticsListView.NavigateToNextUnvisitedLineInMethod())
				{
					// No unvisited sequence point, move to the next unvisited method in the class.
					ClassTreeNode classTreeNode = coverageTreeView.SelectedNode.Parent as ClassTreeNode;
					if (classTreeNode != null)
					{
						int currentIndex = coverageTreeView.SelectedNode.Index;
						if (!_SelectNextUnvisitedMethodInClass(classTreeNode, currentIndex + 1, classTreeNode.Nodes.Count - 1))
						{
							// Reset to the beginning of the class methods.
							_SelectNextUnvisitedMethodInClass(classTreeNode, 0, currentIndex);
						}
					}
				}
			}
		}

		private bool _SelectPreviousUnvisitedMethodInClass(ClassTreeNode classTreeNode, int startIndex, int endIndex)
		{
			for (int index = endIndex; index >= startIndex; index--)
			{
				if (classTreeNode.Nodes[index] is MethodTreeNode)
				{
					MethodTreeNode methodTreeNode = (MethodTreeNode)classTreeNode.Nodes[index];
					if (methodTreeNode.UnvisitedSequencePoints > 0)
					{
						coverageTreeView.SelectAndClickNode(methodTreeNode);
						statisticsListView.SelectFirstZeroCoverageItem();
						return true;
					}
				}
			}
			return false;
		}

		private bool _SelectNextUnvisitedMethodInClass(ClassTreeNode classTreeNode, int startIndex, int endIndex)
		{
			for (int index = startIndex; index <= endIndex; index++)
			{
				if (classTreeNode.Nodes[index] is MethodTreeNode)
				{
					MethodTreeNode methodTreeNode = (MethodTreeNode)classTreeNode.Nodes[index];
					if (methodTreeNode.UnvisitedSequencePoints > 0)
					{
						coverageTreeView.SelectAndClickNode(methodTreeNode);
						statisticsListView.SelectFirstZeroCoverageItem();
						return true;
					}
				}
			}
			return false;
		}

		private bool _SelectPreviousUnvisitedClassInNamespace(NamespaceTreeNode namespaceTreeNode, int startIndex, int endIndex)
		{
			for (int index = endIndex; index >= startIndex; index--)
			{
				if (namespaceTreeNode.Nodes[index] is ClassTreeNode)
				{
					ClassTreeNode classTreeNode = (ClassTreeNode)namespaceTreeNode.Nodes[index];
					if (classTreeNode.UnvisitedSequencePoints > 0)
					{
						coverageTreeView.SelectAndClickNode(classTreeNode);
						return true;
					}
				}
			}
			return false;
		}

		private bool _SelectNextUnvisitedClassInNamespace(NamespaceTreeNode namespaceTreeNode, int startIndex, int endIndex)
		{
			for (int index = startIndex; index <= endIndex; index++)
			{
				if (namespaceTreeNode.Nodes[index] is ClassTreeNode)
				{
					ClassTreeNode classTreeNode = (ClassTreeNode)namespaceTreeNode.Nodes[index];
					if (classTreeNode.UnvisitedSequencePoints > 0)
					{
						coverageTreeView.SelectAndClickNode(classTreeNode);
						return true;
					}
				}
			}
			return false;
		}

		#endregion Navigation Buttons Event Handlers

		#region Drag/Drop Events

		/// <summary>
		/// Handles the DragEnter event of the form.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.DragEventArgs"/> instance containing the event data.</param>
		private void _OnMainFormDragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop)) 
			{
				e.Effect = DragDropEffects.Copy;
			}
			else
			{
				e.Effect = DragDropEffects.None;
			}
		}

		/// <summary>
		/// Handles the DragDrop event of the form.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.DragEventArgs"/> instance containing the event data.</param>
		private void _OnMainFormDragDrop(object sender, DragEventArgs e)
		{
			this.Activate();
			string[] fileNames = (string[]) e.Data.GetData(DataFormats.FileDrop, false);
			bool isMergeRequired = false;

			if (_controller.IsCoverageFileLoaded)
			{
				string message = "Do you wish to merge the following file(s) into the currently displayed coverage?" + Environment.NewLine;
				foreach (string fileName in fileNames)
				{
					message += Environment.NewLine + fileName;
				}

				DialogResult dialogResult = MessageBox.Show(message, "NCoverExplorer", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
				if (dialogResult == DialogResult.Cancel)
				{
					return;
				}
				isMergeRequired = (dialogResult == DialogResult.Yes);
			}

			if (isMergeRequired)
			{
				_controller.MergeCoverageXmlFiles(fileNames);
			}
			else
			{
				_controller.LoadCoverageXmlFiles(fileNames);
			}
		}

		#endregion Drag/Drop Events

		#region Open File in VisualStudio.Net

		/// <summary>
		/// Opens the source code file in VS.Net at the specified line.
		/// </summary>
		private void _OnOpenSourceInVSNet()
		{
			if (!_controller.IsCoverageFileLoaded)
			{
				StatusPublisher.Display("No coverage file loaded.");
				return;
			}
			if (!sourceCodeTabControl.IsSourceCodeDisplayed)
			{
				StatusPublisher.Display("No source code file open.");
				return;
			}

			try
			{
				int line = 1;
				int offset = 1;
				if (statisticsListView.Items.Count > 0)
				{
					Caret caret = sourceCodeTabControl.ActiveTextEditor.ActiveTextAreaControl.Caret;
					// Text-editor uses zero based lines/columns whereas VS.Net is 1-based
					line = caret.Line + 1;
					offset = caret.Column + 1;
				}
				VisualStudioUtilities.MoveToLineAndOffset(sourceCodeTabControl.ActiveTextEditor.CurrentSourceCodeFileName, line, offset);
			}
			catch (Exception ex)
			{
				StatusPublisher.DisplayException(ex);
			}
		}

		#endregion Open File in VisualStudio.Net

		#region Save Selection To Restore After Load

		/// <summary>
		/// Saves current selection information about the current node selected and the position within the 
		/// source code document on the screen.
		/// </summary>
		private void _SaveCurrentSelection()
		{
			if (_configuration.RestoreSelectionOnReload)
			{
				TreeNodeBase selectedTreeNode = coverageTreeView.LastSelectedNode;
				if (sourceCodeTabControl.IsSourceCodeDisplayed && selectedTreeNode is ClassTreeNode || selectedTreeNode is MethodTreeNode)
				{
					// We can go all the way with a selection down to the caret position.
					_selectionStateManager.SetSelectionForCaretPosition(coverageTreeView.LastSelectedClassNode, sourceCodeTabControl);
				}
				else
				{
					// We can just remember which now they had selected.
					_selectionStateManager.SetSelectionForNode(selectedTreeNode);
				}
			}
			else
			{
				// We are not going to remember anything about their current selections.
				_selectionStateManager.Clear();
			}
		}

		#endregion Save Selection To Restore After Load

		#region Mouse Hook Event Handlers
		
		/// <summary>
		/// Special mouse hook handler to catch the forward/back buttons on the mouse.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void _OnMouseHookMouseUp(object sender, NCoverExplorer.Core.Presentation.Mouse.MouseHookEventArgs e)
		{
			if (_navigateNextUnvisitedLineButton.Enabled)
			{
				if (_isCtrlKeyPressed)
				{
					if ( e.Button == MouseButtons.XButton1 )
					{
						// Back mouse button.
						_navigatePreviousClassButton.PerformClick();
					}
					else if ( e.Button == MouseButtons.XButton2 )
					{
						// Forward mouse button.
						_navigateNextClassButton.PerformClick();
					}
				}
				else
				{
					if ( e.Button == MouseButtons.XButton1 )
					{
						// Back mouse button.
						_navigatePreviousUnvisitedLineButton.PerformClick();
					}
					else if ( e.Button == MouseButtons.XButton2 )
					{
						// Forward mouse button.
						_navigateNextUnvisitedLineButton.PerformClick();
					}
				}
			}
		}

		#endregion Mouse Hook Event Handlers

		#endregion Private Methods

		#region IStatusMessageRecipient

		/// <summary>
		/// Publishes the specified message.
		/// </summary>
		/// <param name="message">The message.</param>
		public void Publish(string message)
		{
			if (!coverageTreeView.IsSortInProgress)
			{
				statusBarMessagePanel.Text = message;
			}
		}

		/// <summary>
		/// Publishes the specified exception.
		/// </summary>
		/// <param name="ex">The exception.</param>
		public void Publish(Exception ex)
		{
			statusBarMessagePanel.Text = ex.Message;
		}

		#endregion IStatusMessageRecipient

		#region Images Class (Private)

		private class Images
		{
			private static Image[] images = null;

			// ImageList.Images[int index] does not preserve alpha channel.
			static Images()
			{
				Assembly assembly = Assembly.GetExecutingAssembly();
				using (Bitmap bitmap = new Bitmap(assembly.GetManifestResourceStream("NCoverExplorer.Core.Presentation.ImageList16.png")))
				{
					int count = bitmap.Width / bitmap.Height;
					images = new Image[count];
					Rectangle rectangle = new Rectangle(0, 0, bitmap.Height, bitmap.Height);
					for (int i = 0; i < count; i++)
					{
						images[i] = bitmap.Clone(rectangle, bitmap.PixelFormat);
						rectangle.X += bitmap.Height;
					}
				}
			}	

			public static Image Open				{ get { return images[0];  } }
			public static Image Merge				{ get { return images[1];  } }
			public static Image Save				{ get { return images[2];  } }
			public static Image Reload				{ get { return images[3];  } }
			public static Image Explore				{ get { return images[4];  } }
			public static Image Print				{ get { return images[5];  } }
			public static Image Sort				{ get { return images[6];  } }
			public static Image Statistics			{ get { return images[7];  } }
			public static Image Report				{ get { return images[8];  } }
			public static Image Options				{ get { return images[9];  } }
			public static Image Help				{ get { return images[10]; } }
			public static Image Filter100Percent	{ get { return images[11]; } }
			public static Image Filter0Percent		{ get { return images[12]; } }
			public static Image Exclude				{ get { return images[13]; } }
			public static Image Include				{ get { return images[14]; } }
			public static Image EditInVSNet			{ get { return images[15]; } }
			public static Image ShowStatisticsPane	{ get { return images[16]; } }
			public static Image Home				{ get { return images[17]; } }
			public static Image Mail				{ get { return images[18]; } }
			public static Image ChangeSourcePath	{ get { return images[19]; } }
			public static Image PreviousClass		{ get { return images[20]; } }
			public static Image PreviousSequencePt	{ get { return images[21]; } }
			public static Image NextSequencePt		{ get { return images[22]; } }
			public static Image NextClass			{ get { return images[23]; } }
		}

		#endregion Images Class (Private)
	}	
}
	

