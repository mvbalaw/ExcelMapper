using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// Hyperlinked label supporting multiple url's and capable of launching other processes
	/// when clicked by subclassing.
	/// 
	/// Class originally by Jeff Key, and published into the public domain on
	/// http://www.sliver.com/dotnet/HtmlLinkLabel/
	/// </summary>
	public class HtmlLinkLabel : Control
	{
		#region Events

		/// <summary>
		/// Event raised when a link is clicked.
		/// </summary>
		[Description("Occurs when a link is clicked.")]
		public event HtmlLinkClickedEventHandler HtmlLinkClicked;

		#endregion Events

		#region Private Variables

		private static Regex _regex;
		private LinkLabel _linkLabel;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes the <see cref="HtmlLinkLabel"/> class.
		/// </summary>
		static HtmlLinkLabel()
		{
			HtmlLinkLabel._regex = new Regex("<a href=\"(?<url>.*?)\">(?<text>.*?)</a>", RegexOptions.IgnoreCase);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="HtmlLinkLabel"/> class.
		/// </summary>
		public HtmlLinkLabel()
		{
			_linkLabel = new LinkLabel();
			_linkLabel.Dock = DockStyle.Fill;
			_linkLabel.LinkClicked += new LinkLabelLinkClickedEventHandler(_OnLinkLabelLinkClicked);
			this.Controls.Add(_linkLabel);
		}

		#endregion Constructors

		#region Properties

		/// <summary>
		/// Gets or sets the text associated with this control.
		/// </summary>
		/// <value></value>
		[Description("The text (with optional <A> tags) to display in the control.")]
		public override string Text
		{
			get { return base.Text; }
			set
			{
				base.Text = value;
				string text1 = value;
				_linkLabel.Links.Clear();
				for (Match match1 = HtmlLinkLabel._regex.Match(text1); match1 != Match.Empty; match1 = HtmlLinkLabel._regex.Match(text1))
				{
					string text2 = match1.Groups["text"].Value;
					string text3 = match1.Groups["url"].Value;
					text1 = text1.Remove(match1.Index, match1.Length);
					text1 = text1.Insert(match1.Index, text2);
					HtmlLinkLabel.HtmlLinkLabelInfo info1 = new HtmlLinkLabel.HtmlLinkLabelInfo(text3, text2);
					_linkLabel.Links.Add(match1.Index, text2.Length, info1);
				}
				_linkLabel.Text = text1;
			}
		}

		#endregion Properties

		#region Protected Methods

		/// <summary>
		/// Raises the HTML link clicked event.
		/// </summary>
		/// <param name="e">The <see cref="HtmlLinkClickedEventArgs"/> instance containing the event data.</param>
		protected void OnHtmlLinkClicked(HtmlLinkClickedEventArgs e)
		{
			if (HtmlLinkClicked == null)
			{
				StartProcess(e.Href);
			}
			else
			{
				HtmlLinkClicked(this, e);
				if (!e.Handled)
				{
					StartProcess(e.Href);
				}
			}
		}

		#endregion Protected Methods

		#region Private Methods

		/// <summary>
		/// Handles the LinkLabelLinkClicked event of the label control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.LinkLabelLinkClickedEventArgs"/> instance containing the event data.</param>
		private void _OnLinkLabelLinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			HtmlLinkLabel.HtmlLinkLabelInfo info1 = (HtmlLinkLabel.HtmlLinkLabelInfo) e.Link.LinkData;
			OnHtmlLinkClicked(new HtmlLinkClickedEventArgs(info1.Text, info1.Href));
		}

		/// <summary>
		/// Starts the process.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		private void StartProcess(string fileName)
		{
			try
			{
				Process.Start(fileName);
			}
			catch (Exception exception1)
			{
				MessageBox.Show(string.Format("Error while trying to start '{0}'.  The error follows:\n\n{1}", fileName, exception1.Message), "NCoverExplorer", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		#endregion Private Methods

		#region HtmlLinkLabelInfo CLass

		/// <summary>
		/// Hyperlink information class for the HtmlLinkLabel.
		/// </summary>
		public class HtmlLinkLabelInfo
		{
			public string Href;
			public string Text;

			/// <summary>
			/// Initializes a new instance of the <see cref="HtmlLinkLabelInfo"/> class.
			/// </summary>
			/// <param name="href">The href.</param>
			/// <param name="text">The text.</param>
			public HtmlLinkLabelInfo(string href, string text)
			{
				Href = href;
				Text = text;
			}
		}

		#endregion HtmlLinkLabelInfo CLass
	}

	#region Delegates

	/// <summary>
	/// Delegate for the HtmlLinkClicked event.
	/// </summary>
	public delegate void HtmlLinkClickedEventHandler(object sender, HtmlLinkClickedEventArgs e);

	#endregion Delegates

	#region HtmlLinkClickedEventArgs CLass

	/// <summary>
	/// Event arguments passed when the Html link is clicked.
	/// </summary>
	public class HtmlLinkClickedEventArgs : LinkClickedEventArgs
	{
		#region Private Variables

		private bool _handled;
		private string _href;

		#endregion Private Variables
		
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="HtmlLinkClickedEventArgs"/> class.
		/// </summary>
		/// <param name="linkText">The link text.</param>
		/// <param name="href">The href.</param>
		public HtmlLinkClickedEventArgs(string linkText, string href) : base(linkText)
		{
			_handled = false;
			_href = "";
			_href = href;
		}

		#endregion Constructor

		#region Properties

		/// <summary>
		/// Gets or sets a value indicating whether this <see cref="HtmlLinkClickedEventArgs"/> is handled.
		/// </summary>
		/// <value><c>true</c> if handled; otherwise, <c>false</c>.</value>
		public bool Handled
		{
			get { return _handled; }
			set { _handled = value; }
		}

		/// <summary>
		/// Gets or sets the href.
		/// </summary>
		/// <value>The href.</value>
		public string Href
		{
			get { return _href; }
			set { _href = value; }
		}

		#endregion Properties
	}

	#endregion HtmlLinkClickedEventArgs CLass
}