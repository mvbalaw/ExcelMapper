using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// Displays an icon with full alpha blending on a form.
	/// 
	/// Class originally by Jeff Key, and published into the public domain on
	/// http://www.sliver.com/dotnet/HighColorIcon/
	/// </summary>
	public class HighColorIcon : Control
	{
		#region Private Variables

		private Icon _icon;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="HighColorIcon"/> class.
		/// </summary>
		public HighColorIcon()
		{
		}

		#endregion Constructor

		#region Properties

		/// <summary>
		/// Gets or sets the font of the text displayed by the control.
		/// </summary>
		/// <value></value>
		[Browsable(false)]
		public override Font Font
		{
			get { return base.Font; }
			set { base.Font = value; }
		}

		/// <summary>
		/// Gets or sets the icon.
		/// </summary>
		/// <value>The icon.</value>
		[DefaultValue(null)]
		public Icon Icon
		{
			get { return this._icon; }
			set
			{
				this._icon = value;
				this.Invalidate();
			}
		}

		/// <summary>
		/// Gets or sets the text associated with this control.
		/// </summary>
		/// <value></value>
		[Browsable(false)]
		public override string Text
		{
			get { return base.Text; }
			set { base.Text = value; }
		}

		#endregion Properties

		#region Protected Methods

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Control.Paint"/> event.
		/// </summary>
		/// <param name="e">A <see cref="T:System.Windows.Forms.PaintEventArgs"/> that contains the event data.</param>
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (_icon != null)
			{
				using (Graphics graphics = this.CreateGraphics())
				{
					graphics.DrawIcon(new Icon(_icon, this.Width, this.Height), this.ClientRectangle);
				}
			}
		}

		/// <summary>
		/// Raises the <see cref="E:System.Windows.Forms.Control.Resize"/> event.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			if ((this.Width >= 128) || (this.Height >= 128))
			{
				this.Width = 128;
				this.Height = 128;
			}
			else if ((this.Width >= 64) || (this.Height >= 64))
			{
				this.Width = 64;
				this.Height = 64;
			}
			else if ((this.Width >= 32) || (this.Height >= 32))
			{
				this.Width = 32;
				this.Height = 32;
			}
			else if ((this.Width >= 24) || (this.Height >= 24))
			{
				this.Width = 24;
				this.Height = 24;
			}
			else
			{
				this.Width = 16;
				this.Height = 16;
			}
			this.Invalidate();
		}

		#endregion Protected Methods
	}
}