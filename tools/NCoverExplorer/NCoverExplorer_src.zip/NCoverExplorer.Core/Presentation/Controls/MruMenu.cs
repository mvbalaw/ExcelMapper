using System;
using System.IO;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// Class originally by Joe Woodbury, and published into the public domain on
	/// CodeProject.com at:
	/// http://www.codeproject.com/csharp/mrumenu.asp
	/// 
	/// Adapted for use with NCoverExplorer by Grant Drake.
	/// </summary>
	public class MruMenu
	{
		#region Protected/Private Variables

		protected const int MAX_ENTRIES_DEFAULT = 4;

		protected MruStateCollection _mruStates;
		protected string _menuId;

		private CommandBarMenu _recentFileCommandBarMenu;
		private MruMenuClickEventHandler _clickEventHandler;
		private int _numEntries = 0;
		private int _maxEntries = MAX_ENTRIES_DEFAULT;
		private int _maxShortenPathLength = 80;

		#endregion Protected/Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenu"/> class.
		/// </summary>
		protected MruMenu()
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenu"/> class.
		/// </summary>
		/// <param name="recentFileCommandBarMenu">The recent file menu item.</param>
		/// <param name="clickEventHandler">The click event handler.</param>
		/// <param name="mruStates">The collection of menus in persistence store.</param>
		/// <param name="menuId">Identify this menu.</param>
		public MruMenu(CommandBarMenu recentFileCommandBarMenu, MruMenuClickEventHandler clickEventHandler, 
			MruStateCollection mruStates, string menuId)
		{
			Init(recentFileCommandBarMenu, clickEventHandler, mruStates, menuId, MAX_ENTRIES_DEFAULT);
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenu"/> class.
		/// </summary>
		/// <param name="recentFileCommandBarMenu">The recent file menu item.</param>
		/// <param name="clickEventHandler">The click event handler.</param>
		/// <param name="mruStates">The collection of menus in persistence store.</param>
		/// <param name="menuId">Identify this menu.</param>
		/// <param name="maxEntries">The max entries.</param>
		public MruMenu(CommandBarMenu recentFileCommandBarMenu, MruMenuClickEventHandler clickEventHandler, 
			MruStateCollection mruStates, string menuId, int maxEntries)
		{
			Init(recentFileCommandBarMenu, clickEventHandler, mruStates, menuId, maxEntries);
		}

		#endregion Constructors

		#region Properties

		/// <summary>
		/// Gets the menu items.
		/// </summary>
		/// <value>The menu items.</value>
		public virtual CommandBarItemCollection CommandBarItems
		{
			get { return _recentFileCommandBarMenu.Items; }
		}

		/// <summary>
		/// Gets the start index.
		/// </summary>
		/// <value>The start index.</value>
		public virtual int StartIndex
		{
			get { return 0; }
		}

		/// <summary>
		/// Gets the end index.
		/// </summary>
		/// <value>The end index.</value>
		public virtual int EndIndex
		{
			get { return _numEntries; }
		}

		/// <summary>
		/// Gets the num entries.
		/// </summary>
		/// <value>The num entries.</value>
		public int NumEntries
		{
			get { return _numEntries; }
		}

		/// <summary>
		/// Gets or sets the max entries.
		/// </summary>
		/// <value>The max entries.</value>
		public int MaxEntries
		{
			get { return _maxEntries; }
			set
			{
				if (value > 16)
				{
					_maxEntries = 16;
				}
				else
				{
					_maxEntries = value < 4 ? 4 : value;

					int index = StartIndex + _maxEntries;
					while (_numEntries > _maxEntries)
					{
						CommandBarItems.RemoveAt(index);
						_numEntries--;
					}
				}
			}
		}

		/// <summary>
		/// Gets or sets the length of the max shorten path.
		/// </summary>
		/// <value>The length of the max shorten path.</value>
		public int MaxShortenPathLength
		{
			get { return _maxShortenPathLength; }
			set { _maxShortenPathLength = value < 16 ? 16 : value; }
		}

		/// <summary>
		/// Gets or sets the recent file menu item. Exposed for derived classes.
		/// </summary>
		/// <value>The recent file menu item.</value>
		protected CommandBarMenu RecentFileCommandBarItem
		{
			get { return _recentFileCommandBarMenu; }
			set { _recentFileCommandBarMenu = value; }
		}

		#endregion Properties

		#region Public Methods

		#region Get Methods

		/// <summary>
		/// Finds the fileName number.
		/// </summary>
		/// <param name="fileName">The fileName.</param>
		/// <returns></returns>
		public int FindFileNameNumber(string fileName)
		{
			if (fileName == null)
			{
				throw new ArgumentNullException("fileName");
			}

			if (fileName.Length == 0)
			{
				throw new ArgumentException("fileName");
			}

			if (_numEntries > 0)
			{
				int number = 0;
				for (int i = StartIndex; i < EndIndex; i++, number++)
				{
					if (string.Compare(((MruMenuItem) CommandBarItems[i]).FileName, fileName, true) == 0)
					{
						return number;
					}
				}
			}
			return -1;
		}

		/// <summary>
		/// Finds the index of the mrnu item matching this fileName.
		/// </summary>
		/// <param name="fileName">The fileName.</param>
		/// <returns></returns>
		public int FindFileNameMenuIndex(string fileName)
		{
			int number = FindFileNameNumber(fileName);
			return number < 0 ? -1 : StartIndex + number;
		}

		/// <summary>
		/// Gets the index of the menu.
		/// </summary>
		/// <param name="number">The number.</param>
		/// <returns></returns>
		public int GetMenuIndex(int number)
		{
			if (number < 0 || number >= _numEntries)
			{
				throw new ArgumentOutOfRangeException("number");
			}

			return StartIndex + number;
		}

		/// <summary>
		/// Gets the file at specified position.
		/// </summary>
		/// <param name="number">The number.</param>
		/// <returns></returns>
		public string GetFileAt(int number)
		{
			if (number < 0 || number >= _numEntries)
			{
				throw new ArgumentOutOfRangeException("number");
			}

			return ((MruMenuItem) CommandBarItems[StartIndex + number]).FileName;
		}

		/// <summary>
		/// Gets the filenames.
		/// </summary>
		/// <returns></returns>
		public string[] GetFiles()
		{
			string[] fileNames = new string[_numEntries];

			int index = StartIndex;
			for (int i = 0; i < fileNames.GetLength(0); i++, index++)
			{
				fileNames[i] = ((MruMenuItem) CommandBarItems[index]).FileName;
			}

			return fileNames;
		}

		#endregion Get Methods

		#region Add Methods

		/// <summary>
		/// Sets the first file in the list.
		/// </summary>
		/// <param name="number">The number.</param>
		public void SetFirstFile(int number)
		{
			if (number > 0 && _numEntries > 1 && number < _numEntries)
			{
				CommandBarItem menuItem = CommandBarItems[StartIndex + number];
				CommandBarItems.RemoveAt(StartIndex + number);
				CommandBarItems.Insert(StartIndex, menuItem);
				SetFirstFile(menuItem);
				FixupPrefixes(0);
			}
		}

		/// <summary>
		/// Replaces any existing entries with those supplied.
		/// </summary>
		/// <param name="fileNames">The fileNames.</param>
		public void SetFiles(string[] fileNames)
		{
			RemoveAll();
			for (int i = fileNames.GetLength(0) - 1; i >= 0; i--)
			{
				AddFile(fileNames[i]);
			}
		}

		/// <summary>
		/// Adds the files to the menu.
		/// </summary>
		/// <param name="fileNames">The fileNames.</param>
		public void AddFiles(string[] fileNames)
		{
			for (int i = fileNames.GetLength(0) - 1; i >= 0; i--)
			{
				AddFile(fileNames[i]);
			}
		}

		/// <summary>
		/// Shortens the pathname by either removing consecutive components of a path
		/// and/or by removing characters from the end of the fileName and replacing
		/// then with three elipses (...)
		///
		/// In all cases, the root of the passed path will be preserved in it's entirety.
		///
		/// If a UNC path is used or the pathname and maxLength are particularly short,
		/// the resulting path may be longer than maxLength.
		///
		/// This method expects fully resolved pathnames to be passed to it.
		/// (Use Path.GetFullPath() to obtain this.)
		/// </summary>
		/// <param name="pathname">The pathname.</param>
		/// <param name="maxLength">Length of the max.</param>
		/// <returns></returns>
		static public string ShortenPathname(string pathname, int maxLength)
		{
			if (pathname.Length <= maxLength)
			{
				return pathname;
			}

			string root = Path.GetPathRoot(pathname);
			if (root.Length > 3)
			{
				root += Path.DirectorySeparatorChar;
			}

			string[] elements = pathname.Substring(root.Length).Split(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

			int fileNameIndex = elements.GetLength(0) - 1;

			if (elements.GetLength(0) == 1) // pathname is just a root and fileName
			{
				if (elements[0].Length > 5) // long enough to shorten
				{
					// if path is a UNC path, root may be rather long
					if (root.Length + 6 >= maxLength)
					{
						return root + elements[0].Substring(0, 3) + "...";
					}
					else
					{
						return pathname.Substring(0, maxLength - 3) + "...";
					}
				}
			}
			else if ((root.Length + 4 + elements[fileNameIndex].Length) > maxLength) // pathname is just a root and fileName
			{
				root += "...\\";

				int len = elements[fileNameIndex].Length;
				if (len < 6)
				{
					return root + elements[fileNameIndex];
				}

				if ((root.Length + 6) >= maxLength)
				{
					len = 3;
				}
				else
				{
					len = maxLength - root.Length - 3;
				}
				return root + elements[fileNameIndex].Substring(0, len) + "...";
			}
			else if (elements.GetLength(0) == 2)
			{
				return root + "...\\" + elements[1];
			}
			else
			{
				int len = 0;
				int begin = 0;

				for (int i = 0; i < fileNameIndex; i++)
				{
					if (elements[i].Length > len)
					{
						begin = i;
						len = elements[i].Length;
					}
				}

				int totalLength = pathname.Length - len + 3;
				int end = begin + 1;

				while (totalLength > maxLength)
				{
					if (begin > 0)
					{
						totalLength -= elements[--begin].Length - 1;
					}

					if (totalLength <= maxLength)
					{
						break;
					}

					if (end < fileNameIndex)
					{
						totalLength -= elements[++end].Length - 1;
					}

					if (begin == 0 && end == fileNameIndex)
					{
						break;
					}
				}

				// assemble final string

				for (int i = 0; i < begin; i++)
				{
					root += elements[i] + '\\';
				}

				root += "...\\";

				for (int i = end; i < fileNameIndex; i++)
				{
					root += elements[i] + '\\';
				}

				return root + elements[fileNameIndex];
			}
			return pathname;
		}

		/// <summary>
		/// Adds the file to the menu.
		/// </summary>
		/// <param name="fileName">The fileName.</param>
		public void AddFile(string fileName)
		{
			string pathname = Path.GetFullPath(fileName);
			AddFile(pathname, ShortenPathname(pathname, MaxShortenPathLength));
		}

		/// <summary>
		/// Adds the file to the menu.
		/// </summary>
		/// <param name="fileName">The fileName.</param>
		/// <param name="entryName">The entryName.</param>
		public void AddFile(string fileName, string entryName)
		{
			if (fileName == null)
			{
				throw new ArgumentNullException("fileName");
			}

			if (fileName.Length == 0)
			{
				throw new ArgumentException("fileName");
			}

			if (_numEntries > 0)
			{
				int index = FindFileNameMenuIndex(fileName);
				if (index >= 0)
				{
					SetFirstFile(index - StartIndex);
					return;
				}
			}

			if (_numEntries < _maxEntries)
			{
				MruMenuItem menuItem = new MruMenuItem(fileName, FixupEntryName(0, entryName), new EventHandler(OnMruMenuClick));
				CommandBarItems.Insert(StartIndex, menuItem);
				SetFirstFile(menuItem);

				if (_numEntries++ == 0)
				{
					Enable();
				}
				else
				{
					FixupPrefixes(1);
				}
			}
			else if (_numEntries > 1)
			{
				MruMenuItem menuItem = (MruMenuItem) CommandBarItems[StartIndex + _numEntries - 1];
				menuItem.Text = FixupEntryName(0, entryName);
				menuItem.FileName = fileName;
				SetFirstFile(menuItem);
				FixupPrefixes(1);
			}
		}

		#endregion Add Methods

		#region Remove Methods

		/// <summary>
		/// Removes the file.
		/// </summary>
		/// <param name="number">The number.</param>
		public void RemoveFile(int number)
		{
			if (number >= 0 && number < _numEntries)
			{
				if (--_numEntries == 0)
				{
					Disable();
				}
				else
				{
					int startIndex = StartIndex;
					if (number == 0)
					{
						SetFirstFile(CommandBarItems[startIndex + 1]);
					}

					CommandBarItems.RemoveAt(startIndex + number);

					if (number < _numEntries)
					{
						FixupPrefixes(number);
					}
				}
			}
		}

		/// <summary>
		/// Removes the file from the menu.
		/// </summary>
		/// <param name="fileName">The fileName.</param>
		public void RemoveFile(string fileName)
		{
			if (_numEntries > 0)
			{
				RemoveFile(FindFileNameNumber(fileName));
			}
		}

		/// <summary>
		/// Removes all menu items from the recent menu.
		/// </summary>
		public void RemoveAll()
		{
			if (_numEntries > 0)
			{
				for (int index = EndIndex - 1; index > StartIndex; index--)
				{
					CommandBarItems.RemoveAt(index);
				}
				Disable();
				_numEntries = 0;
			}
		}

		#endregion Remove Methods

		#region Persistence Methods

		/// <summary>
		/// Loads from persistence store.
		/// </summary>
		public void LoadFromPersistedState()
		{
			if (_mruStates != null && _menuId != null)
			{
				RemoveAll();

				MruState mruState = _mruStates[_menuId];

				if (mruState != null)
				{
					for (int number = mruState.Count - 1; number >= 0; number--)
					{
						string fileName = mruState[number];
						if (fileName != null)
						{
							AddFile(fileName);
						}
					}
				}
			}
		}

		/// <summary>
		/// Saves to persistence store.
		/// </summary>
		public void SaveToPersistedState()
		{
			if (_mruStates != null && _menuId != null)
			{
				MruState mruState = _mruStates[_menuId];
				if (mruState == null)
				{
					mruState = new MruState(_menuId);
					_mruStates.Add(mruState);
				}
				mruState.Clear();

				for (int i = StartIndex; i < EndIndex; i++)
				{
					mruState.Add(((MruMenuItem) CommandBarItems[i]).FileName.Trim());
				}
			}
		}

		#endregion Persistence Methods

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Initialises the specified recent file menu item.
		/// </summary>
		/// <param name="recentFileCommandBarMenu">The recent file menu item.</param>
		/// <param name="clickEventHandler">The click event handler.</param>
		/// <param name="mruStates">The collection of menus in persistence store.</param>
		/// <param name="menuId">Identify this menu.</param>
		/// <param name="maxEntries">The max entries.</param>
		protected void Init(CommandBarMenu recentFileCommandBarMenu, MruMenuClickEventHandler clickEventHandler, 
			MruStateCollection mruStates, string menuId, int maxEntries)
		{
			if (recentFileCommandBarMenu == null)
			{
				throw new ArgumentNullException("recentFileCommandBarItem");
			}

			if (recentFileCommandBarMenu.Parents.Count == 0)
			{
				throw new ArgumentException("recentFileCommandBarItem is not part of a menu");
			}

			_recentFileCommandBarMenu = recentFileCommandBarMenu;
			_recentFileCommandBarMenu.Enabled = false;

			_mruStates = mruStates;
			_menuId = menuId;
			_maxEntries = maxEntries;
			_clickEventHandler = clickEventHandler;

			if (menuId != null)
			{
				LoadFromPersistedState();
			}
		}

		/// <summary>
		/// Called when an mru menu item is clicked.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		protected void OnMruMenuClick(object sender, System.EventArgs e)
		{
			MruMenuItem menuItem = (MruMenuItem) sender;
			MruMenuClickEventArgs mruMenuClickEventArgs = new MruMenuClickEventArgs(menuItem.Index - StartIndex, menuItem.FileName);
			if (_clickEventHandler != null)
			{
				_clickEventHandler(menuItem, mruMenuClickEventArgs);
			}
		}

		/// <summary>
		/// Enables the recent file menu.
		/// </summary>
		protected virtual void Enable()
		{
			_recentFileCommandBarMenu.Enabled = true;
		}

		/// <summary>
		/// Disables the recent file menu.
		/// </summary>
		protected virtual void Disable()
		{
			_recentFileCommandBarMenu.Enabled = false;
			//_recentFileCommandBarMenu.CommandBarItems.RemoveAt(0);
		}

		/// <summary>
		/// Fixups the name of the entry.
		/// </summary>
		/// <param name="number">The number.</param>
		/// <param name="entryName">The entryName.</param>
		/// <returns></returns>
		protected string FixupEntryName(int number, string entryName)
		{
			if (number < 9)
			{
				return "&" + (number + 1).ToString() + " " + entryName;
			}
			else if (number == 9)
			{
				return "1&0" + " " + entryName;
			}
			else
			{
				return (number + 1).ToString() + " " + entryName;
			}
		}

		/// <summary>
		/// Fixups the prefixes.
		/// </summary>
		/// <param name="startNumber">The start number.</param>
		protected void FixupPrefixes(int startNumber)
		{
			if (startNumber < 0)
			{
				startNumber = 0;
			}

			if (startNumber < _maxEntries)
			{
				for (int i = StartIndex + startNumber; i < EndIndex; i++, startNumber++)
				{
					// Grant: BugFix of names getting truncated from 10 onwards.
					string menuText = CommandBarItems[i].Text;
					int spaceIndex = menuText.IndexOf(' ');
					CommandBarItems[i].Text = FixupEntryName(startNumber, menuText.Substring(spaceIndex).Trim());
				}
			}
		}

		/// <summary>
		/// To be overridden in derived classes.
		/// </summary>
		/// <param name="menuItem">The menu item.</param>
		protected virtual void SetFirstFile(CommandBarItem menuItem)
		{
		}

		#endregion Protected Methods
	}

	#region Delegates

	/// <summary>
	/// Delegate for clicks on a recent file menu item.
	/// </summary>
	public delegate void MruMenuClickEventHandler(object sender, MruMenuClickEventArgs e);

	#endregion Delegates

	#region MruMenuClickEventArgs

	/// <summary>
	/// Event arguments passed with click event.
	/// </summary>
	public class MruMenuClickEventArgs : EventArgs
	{
		#region Private Variables

		private int _number;
		private string _fileName;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenuClickEventArgs"/> class.
		/// </summary>
		/// <param name="number">The number in the menu.</param>
		/// <param name="fileName">Name of the file.</param>
		public MruMenuClickEventArgs(int number, string fileName)
		{
			_number = number;
			_fileName = fileName;
		}

		#endregion Constructor

		#region Properties

		/// <summary>
		/// Gets or the menu number.
		/// </summary>
		/// <value>The menu number.</value>
		public int Number
		{
			get { return _number; }
		}

		/// <summary>
		/// Gets or the name of the file.
		/// </summary>
		/// <value>The name of the file.</value>
		public string FileName
		{
			get { return _fileName; }
		}

		#endregion Properties
	}

	#endregion MruMenuClickEventArgs
}