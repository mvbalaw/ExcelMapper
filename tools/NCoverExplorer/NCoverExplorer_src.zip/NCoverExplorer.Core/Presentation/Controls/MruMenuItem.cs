using System;
using System.Windows.Forms;

namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// Class originally by Joe Woodbury, and published into the public domain on
	/// CodeProject.com at:
	/// http://www.codeproject.com/csharp/mrumenu.asp
	/// 
	/// Adapted for use with NCoverExplorer by Grant Drake.
	///
	/// The menu may display a shortened or otherwise invalid pathname
	/// This class is used to store the actual filename, preferably as
	/// a fully resolved name.
	/// </summary>
	public class MruMenuItem : CommandBarButton
	{
		#region Protected Variables

		protected string _fileName;

		#endregion Protected Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenuItem"/> class.
		/// </summary>
		public MruMenuItem()
		{
			_fileName = "";
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruMenuItem"/> class.
		/// </summary>
		/// <param name="fileName">The file name.</param>
		/// <param name="entryName">The entry name.</param>
		/// <param name="eventHandler">The event handler.</param>
		public MruMenuItem(string fileName, string entryName, EventHandler eventHandler)
			: base(entryName, eventHandler)
		{
			_fileName = fileName;
		}

		#endregion Constructors

		#region Public Properties

		/// <summary>
		/// Gets or sets the filename.
		/// </summary>
		/// <value>The filename.</value>
		public string FileName
		{
			get { return _fileName; }
			set { _fileName = value; }
		}

		/// <summary>
		/// Gets or sets the index of this item.
		/// </summary>
		/// <value>The index of this item in the menu.</value>
		public int Index
		{
			get 
			{ 
				CommandBarMenu parent = (CommandBarMenu)this.Parents[0];
				return parent.Items.IndexOf(this); 
			}
		}

		#endregion Public Properties
	}
}
