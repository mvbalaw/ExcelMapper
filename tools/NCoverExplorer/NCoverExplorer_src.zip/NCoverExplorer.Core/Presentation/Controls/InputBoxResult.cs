
namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// Stores the result of an InputBox.Show message.
	/// </summary>
	public class InputBoxResult
	{
		#region Private Variables

		private bool _ok;
		private string _text;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Default constructor.
		/// </summary>
		/// <param name="ok">True if the user clicked OK.</param>
		/// <param name="text">The text entered by the user.</param>
		public InputBoxResult(bool ok, string text)
		{
			_ok = ok;
			_text = text;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets if the OK button was pressed.
		/// </summary>
		/// <value><c>true</c> if OK pressed; otherwise, <c>false</c>.</value>
		public bool OK
		{
			get { return _ok; }
		}

		/// <summary>
		/// Gets the text entered into the input box
		/// </summary>
		/// <value>The text.</value>
		public string Text
		{
			get { return _text; }
		}

		#endregion Public Properties
	}
}