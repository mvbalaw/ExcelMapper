using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// Control offering two radio buttons for selection.
	/// </summary>
	public class MultipleChoice : System.Windows.Forms.UserControl
	{
		#region Events

		/// <summary>
		/// Event raised when one of the option buttons is clicked.
		/// </summary>
		public event EventHandler CheckedChanged;

		#endregion Events

		#region Private Variables

		private RadioButton radOption1;
		private RadioButton radOption2;
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private Container components = null;

		private MultipleChoiceDisplayStyle _displayStyle;
		private int _spacing;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MultipleChoice"/> class.
		/// </summary>
		public MultipleChoice()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			_displayStyle = MultipleChoiceDisplayStyle.Horizontal;
			_spacing = 64;
			radOption1.CheckedChanged += new EventHandler(_OnCheckedChanged);
			radOption2.CheckedChanged += new EventHandler(_OnCheckedChanged);
		}

		#endregion Constructor

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.radOption1 = new System.Windows.Forms.RadioButton();
			this.radOption2 = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// radOption1
			// 
			this.radOption1.Checked = true;
			this.radOption1.Dock = System.Windows.Forms.DockStyle.Left;
			this.radOption1.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radOption1.Location = new System.Drawing.Point(0, 0);
			this.radOption1.Name = "radOption1";
			this.radOption1.Size = new System.Drawing.Size(64, 24);
			this.radOption1.TabIndex = 1;
			this.radOption1.TabStop = true;
			this.radOption1.Text = "Option1";
			// 
			// radOption2
			// 
			this.radOption2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.radOption2.ForeColor = System.Drawing.SystemColors.ControlText;
			this.radOption2.Location = new System.Drawing.Point(64, 0);
			this.radOption2.Name = "radOption2";
			this.radOption2.Size = new System.Drawing.Size(76, 24);
			this.radOption2.TabIndex = 2;
			this.radOption2.Text = "Option2";
			// 
			// MultipleChoice
			// 
			this.Controls.Add(this.radOption2);
			this.Controls.Add(this.radOption1);
			this.Name = "MultipleChoice";
			this.Size = new System.Drawing.Size(140, 24);
			this.ResumeLayout(false);

		}
		#endregion

		#region Public Properties

		/// <summary>
		/// Gets or sets a value indicating whether the radio buttons are displayed horizontally or vertically.
		/// </summary>
		/// <value>The display style.</value>
		[Description("A value indicating whether Option 2 radio button is checked.")]
		[DefaultValue(MultipleChoiceDisplayStyle.Horizontal)]
		public MultipleChoiceDisplayStyle DisplayStyle
		{
			get { return _displayStyle; }
			set 
			{
				if (value != _displayStyle)
				{
					if (!Enum.IsDefined(typeof(MultipleChoiceDisplayStyle), value))
					{
						throw new InvalidEnumArgumentException("DisplayStyle", (int)value, typeof(MultipleChoiceDisplayStyle));
					}
					_displayStyle = value;
					if (_displayStyle == MultipleChoiceDisplayStyle.Horizontal)
					{
						radOption1.Dock = System.Windows.Forms.DockStyle.Left;
						this.Spacing = 64;
					}
					else
					{
						radOption1.Dock = System.Windows.Forms.DockStyle.Top;
						this.Spacing = 24;
					}
					this.Refresh();
				}
			}
		}

		/// <summary>
		/// Gets or sets the text for Option 1 radio button.
		/// </summary>
		/// <value>The option1 text.</value>
		[Description("The text for Option 1 radio button.")]
		[DefaultValue("Option1")]
		public string Option1Text
		{
			get { return radOption1.Text; }
			set { radOption1.Text = value; }
		}

		/// <summary>
		/// Gets or sets the text for Option 2 radio button.
		/// </summary>
		/// <value>The option2 text.</value>
		[Description("The text for Option 2 radio button.")]
		[DefaultValue("Option2")]
		public string Option2Text
		{
			get { return radOption2.Text; }
			set { radOption2.Text = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether Option 1 radio button is checked.
		/// </summary>
		/// <value><c>true</c> if Option 1 checked; otherwise, <c>false</c>.</value>
		[Description("A value indicating whether Option 1 radio button is checked.")]
		[DefaultValue(true)]
		public bool Option1Checked
		{
			get { return radOption1.Checked; }
			set 
			{ 
				radOption1.Checked = value; 
				radOption2.Checked = !value; 
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether Option 2 radio button is checked.
		/// </summary>
		/// <value><c>true</c> if Option 2 checked; otherwise, <c>false</c>.</value>
		[Description("A value indicating whether Option 2 radio button is checked.")]
		[DefaultValue(false)]
		public bool Option2Checked
		{
			get { return radOption2.Checked; }
			set 
			{ 
				radOption2.Checked = value; 
				radOption1.Checked = !value; 
			}
		}

		/// <summary>
		/// Gets or sets the spacing between the radio button options (horizontal or vertical).
		/// </summary>
		/// <value>The spacing between the radio button options (horizontal or vertical).</value>
		[Description("The spacing between the radio button options (horizontal or vertical).")]
		[DefaultValue(64)]
		public int Spacing
		{
			get { return _spacing; }
			set 
			{
				if (_spacing != value)
				{
					_spacing = value;
					if (_displayStyle == MultipleChoiceDisplayStyle.Horizontal)
					{
						radOption1.Width = _spacing;
					}
					else
					{
						radOption1.Height = _spacing;
					}
				}
			}
		}

		#endregion Public Properties

		#region Protected Methods

		/// <summary>
		/// Raises the CheckedChanged event.
		/// </summary>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		protected void OnCheckedChanged(EventArgs e)
		{
			if (CheckedChanged != null)
			{
				CheckedChanged(this, e);
			}
		}

		/// <summary> 
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#endregion Protected Methods

		#region Private Methods

		/// <summary>
		/// Handles the CheckedChanged event of the radio button controls.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnCheckedChanged(object sender, EventArgs e)
		{
			OnCheckedChanged(e);
		}

		#endregion Private Methods
	}

	/// <summary>
	/// Style for the display of the radio buttons in the MultipleChoice control.
	/// </summary>
	public enum MultipleChoiceDisplayStyle
	{
		/// <summary>Display the radio buttons horizontally (default).</summary>
		Horizontal = 0,
		/// <summary>Display the radio buttons one above the other.</summary>
		Vertical = 1
	}

}
