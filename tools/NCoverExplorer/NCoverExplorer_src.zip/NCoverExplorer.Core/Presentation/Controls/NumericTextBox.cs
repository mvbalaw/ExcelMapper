using System.ComponentModel;
using System.Windows.Forms;
using ComponentModel_DesignerSerializationVisibility = System.ComponentModel.DesignerSerializationVisibility;

namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// TextBox derived control to restrict characters entered to whole numeric input - crude but does the job!
	/// </summary>
	public class NumericTextBox : TextBox
	{
		#region Private Variables

		private int _minValue;
		private int _maxValue;
		private string _invalidReason;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="NumericTextBox"/> class.
		/// </summary>
		public NumericTextBox()
		{
			_minValue = 0;
			_maxValue = 100;
			_invalidReason = string.Empty;
		}

		#endregion Constructor

		#region Public Properties
		
		/// <summary>
		/// Gets or sets the minimum valid value.
		/// </summary>
		/// <value>The minimum valid value.</value>
		[Description("The minimum valid value.")]
		[DefaultValue(0)]
		public int Minimum
		{
			get { return _minValue; }
			set { _minValue = value; }
		}
		
		/// <summary>
		/// Gets or sets the maximum valid value.
		/// </summary>
		/// <value>The maximum valid value.</value>
		[Description("The maximum valid value.")]
		[DefaultValue(100)]
		public int Maximum
		{
			get { return _maxValue; }
			set { _maxValue = value; }
		}
		
		/// <summary>
		/// Gets or sets the current integer value. Returns 0 if not valid.
		/// </summary>
		/// <value>The current integer value.</value>
		[Description("The current integer value.")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public int Value
		{
			get 
			{
				if (!IsValid)
				{
					return 0;
				}
				return int.Parse(this.Text);
			}
			set 
			{ 
				this.Text = value.ToString(); 
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether Option 1 radio button is checked.
		/// </summary>
		/// <value><c>true</c> if Option 1 checked; otherwise, <c>false</c>.</value>
		[Description("A value indicating whether currently entered value is valid.")]
		[DefaultValue(true)]
		public bool IsValid
		{
			get 
			{ 
				_invalidReason = "Value must be between " + _minValue.ToString() + " and " + _maxValue.ToString();
				if (this.Text.Length == 0)
				{
					return false;
				}

				int interimResult;
				try
				{
					interimResult = int.Parse(this.Text);
				}
				catch
				{
					return false;
				}
				if (interimResult < _minValue || interimResult > _maxValue)
				{
					return false;
				}
				_invalidReason = string.Empty;
				return true;
			}
		}

		/// <summary>
		/// Gets a message reason as to why the value is invalid (if it is invalid, empty string if not).
		/// </summary>
		/// <value>Invliad reason string.</value>
		[Browsable(false)]
		public string InvalidReason
		{
			get { return _invalidReason; }
		}

		#endregion Public Properties

		#region Protected Methods

		/// <summary>
		/// Handles window message processing to filter out non-numeric keys.
		/// </summary>
		/// <param name="m">The m.</param>
		protected override void WndProc(ref Message m)
		{
			const int WM_CHAR = 0x102;
			switch (m.Msg)
			{
				case WM_CHAR:
					int key = m.WParam.ToInt32();
					// Check for digits, backspace and minus key
					if ((key > 57 || key < 48) && (key != 8) && (key != 45))
					{
						return;
					}
					if (ModifierKeys == Keys.Control && ((key == 3) || (key == 22) || (key == 24)))
					{
						// Ctrl+C, Ctrl+X, Ctrl+V
						return;
					}
					break;
			}
			base.WndProc(ref m);
		}

		#endregion Protected Methods
	}
}
