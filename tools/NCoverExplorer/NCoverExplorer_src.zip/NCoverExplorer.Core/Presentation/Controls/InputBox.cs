using System;
using System.Drawing;
using System.Windows.Forms;
using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Core.Presentation.Controls
{
	/// <summary>
	/// The InputBox class is used to show a user input prompt in a dialog box using 
	/// the static method Show().
	/// </summary>
	public class InputBox : Form
	{
		#region Designer Variables

		private System.Windows.Forms.Label labelPrompt;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.TextBox txtInputText;
		private System.ComponentModel.IContainer components = null;

		#endregion Designer Variables

		#region Class Variables

		private FormStatePersister _formStatePersister;
		private IExplorerConfiguration _configuration;

		#endregion Class Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="InputBox"/> class.
		/// </summary>
		protected InputBox()
		{
			InitializeComponent();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="InputBox"/> class.
		/// </summary>
		public InputBox(IExplorerConfiguration configuration)
			: this()
		{
			_configuration = configuration;
			_formStatePersister = new FormStatePersister(this, "InputBox", _configuration.FormStates);
		}

		#endregion Constructors

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(InputBox));
			this.btnOK = new System.Windows.Forms.Button();
			this.btnCancel = new System.Windows.Forms.Button();
			this.txtInputText = new System.Windows.Forms.TextBox();
			this.labelPrompt = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btnOK
			// 
			this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Location = new System.Drawing.Point(296, 8);
			this.btnOK.Name = "btnOK";
			this.btnOK.TabIndex = 2;
			this.btnOK.Text = "&OK";
			this.btnOK.Click += new System.EventHandler(this.buttonOK_Click);
			// 
			// btnCancel
			// 
			this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnCancel.CausesValidation = false;
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(296, 36);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.Size = new System.Drawing.Size(75, 22);
			this.btnCancel.TabIndex = 3;
			this.btnCancel.Text = "&Cancel";
			this.btnCancel.Click += new System.EventHandler(this.buttonCancel_Click);
			// 
			// txtInputText
			// 
			this.txtInputText.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtInputText.Location = new System.Drawing.Point(10, 66);
			this.txtInputText.Name = "txtInputText";
			this.txtInputText.Size = new System.Drawing.Size(362, 20);
			this.txtInputText.TabIndex = 1;
			this.txtInputText.Text = "";
			// 
			// labelPrompt
			// 
			this.labelPrompt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.labelPrompt.Location = new System.Drawing.Point(10, 8);
			this.labelPrompt.Name = "labelPrompt";
			this.labelPrompt.Size = new System.Drawing.Size(279, 52);
			this.labelPrompt.TabIndex = 0;
			this.labelPrompt.Text = "prompt";
			// 
			// InputBox
			// 
			this.AcceptButton = this.btnOK;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.CancelButton = this.btnCancel;
			this.ClientSize = new System.Drawing.Size(382, 97);
			this.Controls.Add(this.labelPrompt);
			this.Controls.Add(this.txtInputText);
			this.Controls.Add(this.btnCancel);
			this.Controls.Add(this.btnOK);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.MaximumSize = new System.Drawing.Size(388, 133);
			this.MinimizeBox = false;
			this.Name = "InputBox";
			this.Text = "Title";
			this.ResumeLayout(false);

		}
		#endregion Windows Form Designer generated code

		#region Public Static Methods
		
		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response</param>
		/// <param name="maxLength">The maximum length of the input text (-1 is infinite).</param>
		/// <param name="icon">The icon to display the dialog with</param>
		/// <param name="xpos">Numeric expression that specifies the distance of the left edge of the dialog box from the left edge of the screen.</param>
		/// <param name="ypos">Numeric expression that specifies the distance of the upper edge of the dialog box from the top of the screen</param>
		/// <param name="owner">The owner or parent form to display the dialog over (nullable).</param>
		/// <returns>
		/// An InputBoxResult object containing the results.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText, int maxLength, Icon icon, int xpos, int ypos, Form owner) 
		{
			using (InputBox form = new InputBox(configuration)) 
			{
				// Setup form
				form.Owner = owner;

				if ( prompt != null )
				{
					form.labelPrompt.Text = prompt;
				}
				if ( title != null )
				{
					form.Text = title;
				}
				else
				{
					form.Text = "";
				}

				if(icon != null)
				{
					form.Icon = icon;
				}

				if ( maxLength > 0 )
				{
					form.txtInputText.MaxLength = maxLength;
				}

				if ( defaultText != null )
				{
					form.txtInputText.Text = defaultText;
				}

				// Show form
				DialogResult result = form.ShowDialog();

				// Return results
				InputBoxResult retval;
				if (result == DialogResult.OK) 
				{
					retval = new InputBoxResult( true, form.txtInputText.Text );
				}
				else
				{
					retval = new InputBoxResult( false, string.Empty );
				}
				return retval;
			}
		}

		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response</param>
		/// <param name="maxLength">The maximum length of the input text (-1 is infinite).</param>
		/// <param name="icon">The icon to display the dialog with</param>
		/// <param name="xpos">Numeric expression that specifies the distance of the left edge of the dialog box from the left edge of the screen.</param>
		/// <param name="ypos">Numeric expression that specifies the distance of the upper edge of the dialog box from the top of the screen</param>
		/// <returns>
		/// An InputBoxResult object containing the results.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText, int maxLength, Icon icon, int xpos, int ypos) 
		{
			return Show(configuration, prompt, title, defaultText, maxLength, icon, xpos, ypos, null);
		}

		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response</param>
		/// <param name="maxLength">The maximum length of the input text (-1 is infinite).</param>
		/// <param name="xpos">Numeric expression that specifies the distance of the left edge of the dialog box from the left edge of the screen.</param>
		/// <param name="ypos">Numeric expression that specifies the distance of the upper edge of the dialog box from the top of the screen</param>
		/// <returns>
		/// An InputBoxResult object containing the results.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText, int maxLength, int xpos, int ypos)
		{
			return Show(configuration, prompt, title, defaultText, -1, null, xpos, ypos, null);
		}

		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response</param>
		/// <param name="maxLength">The maximum length of the input text (-1 is infinite).</param>
		/// <param name="icon">The icon to display the dialog with (nullable).</param>
		/// <returns>
		/// An InputBoxResult object containing the results of the prompt.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText, int maxLength, Icon icon) 
		{
			return Show(configuration, prompt, title, defaultText, maxLength, icon, -1, -1, null);
		}

		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box.</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box.</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response.</param>
		/// <param name="owner">The owner or parent form to display the dialog over (nullable).</param>
		/// <returns>
		/// An InputBoxResult object containing the results of the prompt.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText, Form owner) 
		{
			return Show(configuration, prompt, title, defaultText, -1, owner.Icon, -1, -1, owner);
		}

		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box.</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box.</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response.</param>
		/// <param name="icon">The icon to display the dialog with (nullable).</param>
		/// <returns>
		/// An InputBoxResult object containing the results of the prompt.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText, Icon icon) 
		{
			return Show(configuration, prompt, title, defaultText, -1, icon, -1, -1, null);
		}

		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box.</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box.</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response.</param>
		/// <param name="maxLength">The maximum length of the input text (-1 is infinite).</param>
		/// <returns>
		/// An InputBoxResult object containing the results of the prompt.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText, int maxLength) 
		{
			return Show(configuration, prompt, title, defaultText, maxLength, null, -1, -1, null);
		}

		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box</param>
		/// <param name="defaultText">String expression displayed in the text box as the default response</param>
		/// <returns>
		/// An InputBoxResult object with the Text and the OK property set to true when OK was clicked.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title, string defaultText) 
		{
			return Show(configuration, prompt, title, defaultText, -1, null, -1, -1, null);
		}


		/// <summary>
		/// Displays a prompt in a dialog box, waits for the user to input text or click a button.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="prompt">String expression displayed as the message in the dialog box</param>
		/// <param name="title">String expression displayed in the title bar of the dialog box</param>
		/// <returns>
		/// An InputBoxResult object with the Text and the OK property set to true when OK was clicked.
		/// </returns>
		public static InputBoxResult Show(IExplorerConfiguration configuration, string prompt, string title) 
		{
			return Show(configuration, prompt, title, null, -1, null, -1, -1, null);
		}

		#endregion Public Static Methods

		#region Protected Methods

		/// <summary>
		/// Ensure dialog is active window when displayed.
		/// </summary>
		/// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad (e);
			this.Activate();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}
		
		#endregion Protected Methods

		#region Private Methods

		private void buttonCancel_Click(object sender, System.EventArgs e) 
		{
			this.Close();
		}

		private void buttonOK_Click(object sender, System.EventArgs e) 
		{
			this.Close();
		}

		#endregion Private Methods
	}
}
