using System;
using System.Windows.Forms;
using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.SourceCode
{
	/// <summary>
	/// Container class stored in the tag of a tab page holding various information to link objects together.
	/// </summary>
	public class SourceCodeTabInfo : IDisposable
	{
		private string _fileName;
		private TabPage _tabPage;
		private CoverageTextEditor _sourceCodeTextEditor;
		private ClassTreeNode _classTreeNode;
		private bool _isDisposed;

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SourceCodeTabInfo"/> class.
		/// </summary>
		public SourceCodeTabInfo(string fileName)
		{
			_fileName = fileName;
			_classTreeNode = null;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the tab page.
		/// </summary>
		/// <value>The tab page.</value>
		public TabPage TabPage
		{
			get { return _tabPage; }
			set 
			{
				_tabPage = value;
				_sourceCodeTextEditor = (CoverageTextEditor)_tabPage.Controls[0].Controls[0];
			}
		}

		/// <summary>
		/// Gets the source code text editor.
		/// </summary>
		/// <value>The source code text editor.</value>
		public CoverageTextEditor SourceCodeTextEditor
		{
			get { return _sourceCodeTextEditor; }
		}

		/// <summary>
		/// Gets the name of the file.
		/// </summary>
		/// <value>The name of the file.</value>
		public string FileName
		{
			get { return _fileName; }
		}

		/// <summary>
		/// Gets or sets the class tree node this tab is associated with.
		/// </summary>
		/// <value>The class tree node.</value>
		public ClassTreeNode ClassTreeNode
		{
			get { return _classTreeNode; }
			set { _classTreeNode = value; }
		}

		#endregion Public Properties

		#region IDisposable Members

		public void Dispose()
		{
			if (!_isDisposed)
			{
				if (_sourceCodeTextEditor != null)
				{
					_sourceCodeTextEditor.Dispose();
				}
				_classTreeNode = null;
				_tabPage.Dispose();
				_isDisposed = true;
			}
		}

		#endregion IDisposable Members
	}
}
