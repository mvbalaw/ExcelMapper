using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

using ICSharpCode.TextEditor;
using ICSharpCode.TextEditor.Document;
using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.SourceCode;

namespace NCoverExplorer.Core.SourceCode
{
	/// <summary>
	/// Text editor control setup for the read-only display and highlighting of source code files.
	/// </summary>
	public class CoverageTextEditor : ICSharpCode.TextEditor.TextEditorControl
	{
		#region Events

		public event TabKeyPressedEventHandler TabKeyPressed;

		#endregion Events

		#region Private Variables

		/// <summary>
		/// Extra number of rows to scroll down past the selected line in the hope of displaying
		/// the complete method on screen.
		/// </summary>
		private const int ExtraVisibleEditorLineCountWhenScrolling = 3;

		private IExplorerConfiguration _configuration;
		private string _currentSourceCodeFileName;
		private System.Timers.Timer _highlightSelectionTimer;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageTextEditor"/> class.
		/// </summary>
		public CoverageTextEditor()
		{
			_configuration = null;
			_currentSourceCodeFileName = string.Empty;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets a value indicating whether a source code file is currently being displayed.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if a source code file is currently displayed; otherwise, <c>false</c>.
		/// </value>
		public bool IsSourceCodeDisplayed
		{
			get { return _currentSourceCodeFileName.Length > 0;}
		}

		/// <summary>
		/// Gets or sets the file name of the currently displayed file.
		/// </summary>
		/// <value>The name of the current source code file.</value>
		public string CurrentSourceCodeFileName
		{
			get { return _currentSourceCodeFileName; }
			set
			{
				if (value == null)
				{
					_currentSourceCodeFileName = string.Empty;
				}
				else
				{
					_currentSourceCodeFileName = value;
				}
			}
		}

		#endregion Public Properties

		#region Public Methods

		#region Initialisation

		/// <summary>
		/// Initialises the text editor control.
		/// </summary>
		public void Initialise(IExplorerConfiguration configuration)
		{
			_configuration = configuration;
			Clear();
			ShowMatchingBracket = false;
			ShowEOLMarkers = false;
			ShowVRuler = false;
			ShowSpaces = false;
			ShowTabs = false;
			IsReadOnly = true;
			Encoding = Encoding.Default;

			ActiveTextAreaControl.TextArea.DoProcessDialogKey -= new DialogKeyProcessor(_OnTextAreaDoProcessDialogKey);
			ActiveTextAreaControl.TextArea.DoProcessDialogKey += new DialogKeyProcessor(_OnTextAreaDoProcessDialogKey);
			this.ActiveTextAreaControl.TextArea.MouseDown -= new MouseEventHandler(_OnTextAreaMouseDown);
			this.ActiveTextAreaControl.TextArea.MouseDown += new MouseEventHandler(_OnTextAreaMouseDown);

			_currentSourceCodeFileName = string.Empty;

			_InitialiseHighlightTimer();
		}

		#endregion Initialisation

		#region Population

		/// <summary>
		/// Loads the source code file.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		public void LoadSourceCodeFile(string fileName)
		{
			Clear();
			this.LoadFile(fileName);

			PrintDocument.DocumentName = Path.GetFileName(fileName);
			CurrentSourceCodeFileName = fileName;

			// Reapply the theme just in case this is not a .cs file
			ApplyTheme(_configuration.Theme);

			// Enable the scrollbars now we have a document loaded.
			ActiveTextAreaControl.HScrollBar.Enabled = true;
			ActiveTextAreaControl.VScrollBar.Enabled = true;
		}

		#endregion Population

		#region Clear

		/// <summary>
		/// Clears the text and anyhing else within this control.
		/// </summary>
		public void Clear()
		{
			//Document.MarkerStrategy.TextMarker.Clear();
			Text = "";
			ActiveTextAreaControl.TextArea.Refresh();
			_currentSourceCodeFileName = string.Empty;

			// Turn off scrollbars when no file is loaded.
			ActiveTextAreaControl.HScrollBar.Enabled = false;
			ActiveTextAreaControl.VScrollBar.Enabled = false;
		}

		#endregion Clear

		#region ApplyTheme

		/// <summary>
		/// Applies the theme to the appearance of this control.
		/// </summary>
		/// <param name="theme">The theme.</param>
		public void ApplyTheme(Theme theme)
		{
			Font = theme.SourceCodeFont;

			// Note this is my "hack" to get around the ICSharpCode standard behaviour of forcing the loading
			// of syntax files by the developer to change colors.
			DefaultHighlightingStrategy strategy;
			if (_currentSourceCodeFileName.ToLower().EndsWith("vb"))
			{
				strategy = (DefaultHighlightingStrategy)HighlightingManager.Manager.FindHighlighter("VBNET");
			}
			else
			{
				strategy = (DefaultHighlightingStrategy)HighlightingManager.Manager.FindHighlighter("C#");
			}
			strategy.SetColorFor("DefaultBackground", new HighlightBackground(theme.SourceCodeBackgroundColor, theme.SourceCodeBackgroundColor, false, false));
			strategy.SetColorFor("Default", new HighlightBackground(SystemColors.WindowText, theme.SourceCodeBackgroundColor, false, false));
			strategy.SetColorFor("LineNumbers", new HighlightBackground(theme.SourceCodeLineNumbersColor, theme.SourceCodeBackgroundColor, false, false));
			Document.HighlightingStrategy = strategy;

			ActiveTextAreaControl.Refresh();
		}

		#endregion ApplyTheme

		#region Highlighting & Selections

		/// <summary>
		/// Clears the existing selection if it exists from the highlighting timer.
		/// </summary>
		public void ClearExistingSelection()
		{
			if (_highlightSelectionTimer.Enabled)
			{
				// We had a timer running from a previous selection - stop that and clear selection.
				_highlightSelectionTimer.Stop();
				ActiveTextAreaControl.TextArea.SelectionManager.ClearSelection();
			}
		}

		#endregion Highlighting & Selections

		#region Scrolling

		/// <summary>
		/// Scroll the source code window to display the specified sequence points, and optionally
		/// highlighting the sequence point with a timed highlight selection bar.
		/// </summary>
		/// <param name="sequencePoint">Sequence points to highlight.</param>
		/// <param name="highlightSelection">Whether to select the source code text for a brief time period to highlight it.</param>
		public void ScrollToSequencePoint(SequencePoint sequencePoint, bool highlightSelection)
		{
			Point startPoint = new Point(sequencePoint.StartColumn - 1, sequencePoint.StartLine - 1);
			Point endPoint = new Point(sequencePoint.EndColumn - 1, sequencePoint.EndLine - 1);
	
			// When we scroll add a couple more lines "extra" in the hope it will display
			// the end of the method if nothing but closing braces following.
			int realScrollY = startPoint.Y + ExtraVisibleEditorLineCountWhenScrolling;
			if (sequencePoint.IsOnFirstLineInMethod)
			{
				// If looking at first line in method apply offset the "other" way.
				realScrollY = Math.Max(0, startPoint.Y - 2 * ExtraVisibleEditorLineCountWhenScrolling);
			}

			ActiveTextAreaControl.ScrollTo(realScrollY);
			ActiveTextAreaControl.TextArea.Caret.Position = startPoint;

			if (highlightSelection)
			{
				if (sequencePoint.StartLine == sequencePoint.EndLine)
				{
					// Is a single line sequence point - we can do this the easy way.
					ActiveTextAreaControl.TextArea.SelectionManager.SetSelection(startPoint, endPoint);
				}
				else
				{
					// A multiple line sequence point to highlight. Tried an "easy" way of just figuring out the total length
					// but that shows the leading whitespace on following lines of the code selected which looks pretty ugly.
					// Instead iterate through the range and select just the text on each line without leading whitespace.
					for	(int line = sequencePoint.StartLine; line <= sequencePoint.EndLine; line++)
					{
						_CalculateSelectionPointsForLine(sequencePoint, line, out startPoint, out endPoint);
						if (!startPoint.IsEmpty)
						{
							ActiveTextAreaControl.TextArea.SelectionManager.SetSelection(startPoint, endPoint);
						}
					}
				}
				_highlightSelectionTimer.Start();
			}
		}

		#endregion Scrolling

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Raises the TabKeyPressed event.
		/// </summary>
		/// <param name="e">The <see cref="TabKeyPressedEventArgs"/> instance containing the event data.</param>
		protected void OnTabKeyPressed(TabKeyPressedEventArgs e)
		{
			if (TabKeyPressed != null)
			{
				TabKeyPressed(this, e);
			}
		}

		/// <summary>
		/// Overridden to dispose of timer.
		/// </summary>
		/// <param name="disposing">if set to <c>true</c> is disposing.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (_highlightSelectionTimer != null)
				{
					_highlightSelectionTimer.Dispose();
				}
				base.Dispose (disposing);
			}
		}


		#endregion Protected Methods

		#region Private Methods

		/// <summary>
		/// Hack required due to ICSharp control having some "bugs" (differing behaviour to the VS.Net IDE).
		/// This fix ensures that a right-click to bring up a context menu also moves to caret position.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Windows.Forms.MouseEventArgs"/> instance containing the event data.</param>
		private void _OnTextAreaMouseDown(object sender, MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right && this.Document.TotalNumberOfLines > 1)
			{
				TextArea textArea = this.ActiveTextAreaControl.TextArea;

				// Change the selection caret to the current position if have a document
				Point newPosition = textArea.TextView.GetLogicalPosition(e.X - textArea.TextView.DrawingPosition.X, e.Y - textArea.TextView.DrawingPosition.Y);
				textArea.Caret.Position = newPosition;
			}
		}

		/// <summary>
		/// Handles the DoProcessDialogKey event for the TextEditor control.
		/// </summary>
		/// <param name="keyData">The key data.</param>
		/// <returns><c>true</c> if have overridden the behaviour for this keypress.</returns>
		private bool _OnTextAreaDoProcessDialogKey(Keys keyData)
		{
			// Override the Tab/ShiftTab behaviour so it switches focus between the controls since text editor
			// is not editable in NCoverExplorer.
			if (keyData == Keys.Tab)
			{
				OnTabKeyPressed(new TabKeyPressedEventArgs(false));
				return true;
			}
			else if (keyData == (Keys.Shift | Keys.Tab))
			{
				OnTabKeyPressed(new TabKeyPressedEventArgs(true));
				return true;
			}
			return false;
		}

		/// <summary>
		///  Instantiate the timer used for highlighting uncovered code.
		/// </summary>
		private void _InitialiseHighlightTimer()
		{
			_highlightSelectionTimer = new System.Timers.Timer();
			_highlightSelectionTimer.Interval = 1000;
			_highlightSelectionTimer.Enabled = false;
			_highlightSelectionTimer.Elapsed += new System.Timers.ElapsedEventHandler(_OnHighlightSelectionTimerElapsed);
		}

		/// <summary>
		/// Determine the start and end points for a text selection for a sequence point on this line.
		/// </summary>
		private void _CalculateSelectionPointsForLine(SequencePoint sequencePoint, int line, out Point startPoint, out Point endPoint)
		{
			LineSegment segment = Document.GetLineSegment(line - 1);
			string text = Document.GetText(segment);
			if (text.Length == 0)
			{
				startPoint = Point.Empty;
				endPoint = Point.Empty;
				return;
			}

			if (line == sequencePoint.StartLine)
			{
				// On the first line we want to highlight from specified sequence point column all the way to the end of the line
				startPoint = new Point(sequencePoint.StartColumn - 1, line - 1);
				endPoint = new Point(text.Length, line - 1);
			}
			else
			{
				int whitespaceColumnOffset = 0;
				while ((whitespaceColumnOffset < text.Length) && ((text[whitespaceColumnOffset] == ' ') || (text[whitespaceColumnOffset] == '\t')))
				{
					whitespaceColumnOffset++;
				}
				startPoint = new Point(whitespaceColumnOffset, line - 1);

				if (line == sequencePoint.EndLine)
				{
					// On the last line we want to highlight to specified sequence point end column (excluding leading whitespace)
					endPoint = new Point(sequencePoint.EndColumn, line - 1);
				}
				else
				{
					// On any lines in between highlight all the text on the line excluding leading whitespace
					endPoint = new Point(text.Length, line - 1);
				}
			}
		}

		/// <summary>
		/// Handles the TimerElapsed event of the highlight timer control.
		/// Indicates we should remove any highlighting if we have any.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Timers.ElapsedEventArgs"/> instance containing the event data.</param>
		private void _OnHighlightSelectionTimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
		{
			ActiveTextAreaControl.TextArea.SelectionManager.ClearSelection();
			// Job done so don't fire again until user clicks another node in the tree/listview.
			_highlightSelectionTimer.Stop();
		}

		#endregion Private Methods
	}

	#region Delegates

	/// <summary>
	/// Delegate for the TabKeyPressed event.
	/// </summary>
	public delegate void TabKeyPressedEventHandler(object sender, TabKeyPressedEventArgs e);

	#endregion Delegates

	#region TabKeyPressedEventArgs Class

	/// <summary>
	/// EventArgs passed with the TabKeyPressed event.
	/// </summary>
	public class TabKeyPressedEventArgs : EventArgs
	{
		private bool _isShiftTab;

		/// <summary>
		/// Initializes a new instance of the <see cref="TabKeyPressedEventArgs"/> class.
		/// </summary>
		public TabKeyPressedEventArgs(bool isShiftTab)
		{
			_isShiftTab = isShiftTab;
		}

		/// <summary>
		/// Gets whether the shift key was pressed with the Tab key.
		/// </summary>
		/// <value>Whether the shift key was pressed with the Tab key.</value>
		public bool IsShiftTab
		{
			get { return _isShiftTab; }
		}
	}

	#endregion TabKeyPressedEventArgs Class
}

