using System.Drawing;
using ICSharpCode.TextEditor.Document;
using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Core.SourceCode
{
	/// <summary>
	/// Represents a visual text highlight for painting onto the TextEditor control.
	/// </summary>
	public class CoverageTextMarker : TextMarker
	{
 		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageTextMarker"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="offset">The offset.</param>
		/// <param name="length">The length.</param>
		/// <param name="visitCount">The visit count.</param>
        public CoverageTextMarker(IExplorerConfiguration configuration, int offset, int length, long visitCount, bool isExcluded)
            : base(offset, length, _GetTextMarkerType(configuration, visitCount, isExcluded), _GetColor(configuration, visitCount, isExcluded))
        {
            this.ToolTip = _GetToolTip(visitCount, isExcluded);
		}

		#endregion Constructor

		#region Private Static Methods

		/// <summary>
		/// Gets the type of text marker based on configuration settings and visit count.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="visitCount">The visit count.</param>
		/// <returns></returns>
		private static TextMarkerType _GetTextMarkerType(IExplorerConfiguration configuration, long visitCount, bool isExcluded)
		{
			if (isExcluded || visitCount > 0)
			{
				return TextMarkerType.SolidBlock;
			}
			else
			{
				if (configuration.Theme.HighlightUnvisitedCodeStyle == HighlightUnvisitedCodeStyle.Block)
				{
					return TextMarkerType.SolidBlock;
				}
				else
				{
					return TextMarkerType.WaveLine;
				}
			}
		}

		/// <summary>
		/// Gets the colour for this node based on the visit count and the highlighting style.
		/// </summary>
		/// <param name="visitCount">The visit count.</param>
		/// <returns></returns>
		private static Color _GetColor(IExplorerConfiguration configuration, long visitCount, bool isExcluded)
		{
			if (isExcluded)
			{
				if (configuration.Theme.HighlightExcludedCodeStyle == HighlightVisitedCodeStyle.Block)
				{
					return configuration.Theme.HighlightExcludedCodeColor;
				}
				else
				{
					return SystemColors.Window;
				}
			}
			else if (visitCount > 0)
			{
				if (configuration.Theme.HighlightVisitedCodeStyle == HighlightVisitedCodeStyle.Block)
				{
					return configuration.Theme.HighlightVisitedCodeColor;
				}
				else
				{
					return SystemColors.Window;
				}
			}
			else // visitCount == 0 && !isExcluded
			{
				return configuration.Theme.HighlightUnvisitedCodeColor;
			}
		}

		/// <summary>
		/// Gets the tool tip for this node based on the visit count.
		/// </summary>
		/// <param name="visitCount">The visit count.</param>
		/// <param name="isExcluded">if set to <c>true</c> [is excluded].</param>
		/// <returns>Tool tip text.</returns>
		private static string _GetToolTip(long visitCount, bool isExcluded)
		{
			string toolTipMessage = string.Empty;

			if (isExcluded)
			{
				toolTipMessage = "Code was excluded";
			}
			else if (visitCount == 0)
			{
				toolTipMessage = "Code was not visited";
			}
			else if (visitCount == 1)
			{
				toolTipMessage = "Code was visited once";
			}
			else
			{
				toolTipMessage = string.Format("Code was visited {0} times", visitCount);
			}

			return toolTipMessage;
		}

		#endregion Private Static Methods
	}
}
