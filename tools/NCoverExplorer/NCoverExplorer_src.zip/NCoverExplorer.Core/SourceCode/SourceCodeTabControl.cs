using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.SourceCode
{
	/// <summary>
	/// Derived TabControl for displaying source code tabs, one for each file.
	/// </summary>
	public class SourceCodeTabControl : TabControl
	{
		#region Private Variables

		private CommandBarContextMenu sourceCodeTabContextMenu;
		private CommandBarButton ctxSourceCodeTabClose;
		private CommandBarButton ctxSourceCodeTabCloseAllButThis;
		private CommandBarButton ctxSourceCodeTabCloseAll;

		private IExplorerConfiguration _configuration;
		private Hashtable _sourceCodeTabInfos;
		private CommandBarContextMenu _contextMenu;
		private CoverageHighlighter _coverageHighlighter;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SourceCodeTabControl"/> class.
		/// </summary>
		public SourceCodeTabControl()
		{
			_CreateContextMenu();

			_sourceCodeTabInfos = new Hashtable(10);
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the active text editor.
		/// </summary>
		/// <value>The active text editor.</value>
		public CoverageTextEditor ActiveTextEditor
		{
			get
			{
				if (TabCount == 0)
				{
					return null;
				}
				SourceCodeTabInfo activeTabInfo = (SourceCodeTabInfo)SelectedTab.Tag;
				return activeTabInfo.SourceCodeTextEditor;
			}
		}

		/// <summary>
		/// Gets the active tab info.
		/// </summary>
		/// <value>The active text editor.</value>
		public SourceCodeTabInfo ActiveTabInfo
		{
			get
			{
				if (TabCount == 0)
				{
					return null;
				}
				return (SourceCodeTabInfo)SelectedTab.Tag;
			}
		}

		/// <summary>
		/// Gets a value indicating whether source code is currently displayed in the active tab.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this source code is displayed; otherwise, <c>false</c>.
		/// </value>
		public bool IsSourceCodeDisplayed
		{
			get { return (TabCount > 0) && ActiveTextEditor.IsSourceCodeDisplayed; }
		}

		#endregion Public Properties

		#region Public Methods

		#region Initialisation

		/// <summary>
		/// Initialises the tab control for usage by NCoverExplorer.
		/// </summary>
		/// <param name="mainFormController">The main form controller.</param>
		/// <param name="configuration">The configuration.</param>
		/// <param name="sourceContextMenu">The context menu.</param>
		public void Initialise(MainFormController mainFormController, IExplorerConfiguration configuration, 
			CommandBarContextMenu sourceContextMenu)
		{
			_configuration = configuration;
			_contextMenu = sourceContextMenu;
			_coverageHighlighter = new CoverageHighlighter(mainFormController, _configuration, this);
		}

		#endregion Initialisation

		#region ApplyTheme

		/// <summary>
		/// Applies the theme to the appearance of this control.
		/// </summary>
		/// <param name="theme">The theme.</param>
		public void ApplyTheme(Theme theme)
		{
			if (TabCount > 0)
			{
				foreach (SourceCodeTabInfo sourceCodeTabInfo in _sourceCodeTabInfos.Values)
				{
					sourceCodeTabInfo.SourceCodeTextEditor.ApplyTheme(theme);
	
					// Also need to refresh the highlighting as it could have changed.
					// Clear highlighting for other classes in the same file.
					sourceCodeTabInfo.SourceCodeTextEditor.Document.MarkerStrategy.TextMarker.Clear();
					// Highlight just this class.
					_coverageHighlighter.HighlightClassCode(sourceCodeTabInfo.ClassTreeNode);
					sourceCodeTabInfo.SourceCodeTextEditor.Refresh();
				}
				ActiveTabInfo.SourceCodeTextEditor.Refresh();
			}
		}

		#endregion ApplyTheme

		#region Clear

		/// <summary>
		/// Clears the tab pages.
		/// </summary>
		public void Clear()
		{
			TabPages.Clear();
			_sourceCodeTabInfos.Clear();
			this.Appearance  = TabAppearance.Buttons;
		}

		#endregion Clear

		#region Population

		/// <summary>
		/// Load all the files that make up this class node and highlight the code sequence points.
		/// </summary>
		/// <param name="classTreeNode">The class tree node.</param>
		/// <returns>Whether the file was loaded into a tab without errors.</returns>
		public bool LoadAndHighlightClassCode(ClassTreeNode classTreeNode)
		{
			if (classTreeNode != null)
			{
				return _coverageHighlighter.HighlightClassCode(classTreeNode);
			}
			else
			{
				return false;
			}
		}

		/// <summary>
		/// Returns whether we have a tab for this file loaded.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <returns></returns>
		public bool IsTabForFileLoaded(string fileName)
		{
			return _sourceCodeTabInfos.ContainsKey(fileName);
		}

		/// <summary>
		/// Displays the source code tab for this filename, creating it if it does not exist.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <returns></returns>
		public void DisplayTab(string fileName)
		{
			SelectedTab = GetLoadedTabForFileName(fileName).TabPage;
		}

		/// <summary>
		/// Gets the source code tab for this filename, creating it if it does not exist.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <returns></returns>
		public SourceCodeTabInfo GetLoadedTabForFileName(string fileName)
		{
			SourceCodeTabInfo sourceCodeTabInfo = null;
			if (!IsTabForFileLoaded(fileName))
			{
				sourceCodeTabInfo = _CreateSourceCodeTabInfo(fileName);
				_sourceCodeTabInfos.Add(fileName, sourceCodeTabInfo);
				// Now need to read the file as well!
				_LoadSourceCodeFile(sourceCodeTabInfo.SourceCodeTextEditor, fileName);
			}
			else
			{
				sourceCodeTabInfo = (SourceCodeTabInfo)_sourceCodeTabInfos[fileName];
			}
			return sourceCodeTabInfo;
		}

		/// <summary>
		/// Ensures this class is highlighted in text editor for current tab.
		/// </summary>
		/// <param name="currentParentClassNode">The current parent class node.</param>
		public void EnsureClassHighlightedInTab(ClassTreeNode currentParentClassNode)
		{
			SourceCodeTabInfo sourceCodeTabInfo = (SourceCodeTabInfo)SelectedTab.Tag;
			if (currentParentClassNode != sourceCodeTabInfo.ClassTreeNode)
			{
				// Clear highlighting for other classes in the same file.
				sourceCodeTabInfo.SourceCodeTextEditor.Document.MarkerStrategy.TextMarker.Clear();
				// Highlight just this class.
				_coverageHighlighter.HighlightClassCode(currentParentClassNode);
				// Since a different class highlighted in the tab make sure we reflect that
				sourceCodeTabInfo.ClassTreeNode = currentParentClassNode;
			}
		}

		#endregion Population

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Ensure we select a tab when it is right-clicked on.
		/// </summary>
		/// <param name="e">A <see cref="T:System.Windows.Forms.MouseEventArgs"/> that contains the event data.</param>
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Right)
			{
				for (int index = 0; index < TabCount; index++)
				{
					Rectangle rect = GetTabRect(index);
					if (rect.Contains(e.X, e.Y))
					{
						SelectedTab = TabPages[index];
						break;
					}
				}
			}
			base.OnMouseDown (e);
		}

		#endregion Protected Methods

		#region Private Methods

		#region Tabs Context Menu

		/// <summary>
		/// Creates the tabs context menu.
		/// </summary>
		private void _CreateContextMenu()
		{
			ctxSourceCodeTabClose = new CommandBarButton("&Close", new EventHandler(ctxSourceCodeTabClose_Click));
			ctxSourceCodeTabCloseAllButThis = new CommandBarButton("Close All &But This", new EventHandler(ctxSourceCodeTabCloseAllButThis_Click));
			ctxSourceCodeTabCloseAll = new CommandBarButton("Close &All", new EventHandler(ctxSourceCodeTabCloseAll_Click));
	
			sourceCodeTabContextMenu = new CommandBarContextMenu();
			sourceCodeTabContextMenu.Popup += new EventHandler(sourceCodeTabContextMenu_Popup);
			sourceCodeTabContextMenu.Items.Add(ctxSourceCodeTabClose);
			sourceCodeTabContextMenu.Items.Add(ctxSourceCodeTabCloseAllButThis);
			sourceCodeTabContextMenu.Items.Add(ctxSourceCodeTabCloseAll);
	
			ContextMenu = sourceCodeTabContextMenu;
		}

		private void sourceCodeTabContextMenu_Popup(object sender, EventArgs e)
		{
			ctxSourceCodeTabClose.Enabled = TabCount > 0;
			ctxSourceCodeTabCloseAllButThis.Enabled = TabCount > 1;
			ctxSourceCodeTabCloseAll.Enabled = TabCount > 0;
		}
	
		private void ctxSourceCodeTabClose_Click(object sender, EventArgs e)
		{
			_CloseTab(SelectedTab);
		}

		private void ctxSourceCodeTabCloseAllButThis_Click(object sender, EventArgs e)
		{
			int nextTabIndex = SelectedTab.TabIndex + 1; 
			while (TabCount > nextTabIndex)
			{
				_CloseTab(TabPages[nextTabIndex]);
			}
			while (TabCount > 1)
			{
				_CloseTab(TabPages[0]);
			}
		}

		private void ctxSourceCodeTabCloseAll_Click(object sender, EventArgs e)
		{
			this.Clear();
		}

		private void _CloseTab(TabPage tabPage)
		{
			SourceCodeTabInfo sourceCodeTabInfo = (SourceCodeTabInfo)tabPage.Tag;
			_sourceCodeTabInfos.Remove(sourceCodeTabInfo.FileName);
			TabPages.Remove(tabPage);
			sourceCodeTabInfo.Dispose();
		}

		#endregion Tabs Context Menu

		/// <summary>
		/// Create a new tab page with all it's associated controls and return the container object.
		/// </summary>
		/// <returns></returns>
		private SourceCodeTabInfo _CreateSourceCodeTabInfo(string fileName)
		{
			SourceCodeTabInfo sourceCodeTabInfo = new SourceCodeTabInfo(fileName);
			
			CoverageTextEditor coverageTextEditor = new CoverageTextEditor();
			Panel panel = new Panel();
			TabPage tabPage = new TabPage();
			tabPage.Tag = sourceCodeTabInfo;
			tabPage.Text = Path.GetFileName(fileName);
			tabPage.ToolTipText = fileName;

			coverageTextEditor.ContextMenu = _contextMenu;
			coverageTextEditor.Dock = System.Windows.Forms.DockStyle.Fill;
			coverageTextEditor.Encoding = Encoding.Default;
			coverageTextEditor.IsIconBarVisible = false;
			coverageTextEditor.ShowEOLMarkers = true;
			coverageTextEditor.ShowInvalidLines = false;
			coverageTextEditor.ShowSpaces = true;
			coverageTextEditor.ShowTabs = true;
			coverageTextEditor.ShowVRuler = true;
			coverageTextEditor.TabIndex = 0;
			coverageTextEditor.VRulerRow = 40;
			coverageTextEditor.Initialise(_configuration);
			coverageTextEditor.TabKeyPressed += new TabKeyPressedEventHandler(_OnCoverageTextEditorTabKeyPressed);

			panel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			panel.Controls.Add(coverageTextEditor);
			panel.Dock = System.Windows.Forms.DockStyle.Fill;
			panel.TabIndex = 1;

			tabPage.Controls.Add(panel);

			Controls.Add(tabPage);
			Appearance = TabAppearance.Normal;
			sourceCodeTabInfo.TabPage = tabPage;

			return sourceCodeTabInfo;
		}

		/// <summary>
		/// Checks to see if we already have the source code file loaded in the editor, and if not loads it.
		/// </summary>
		/// <param name="coverageTextEditor">The coverage text editor.</param>
		/// <param name="fileName">The file name.</param>
		/// <returns><c>true</c> if able to load the source code file, otherwise <c>false</c>.</returns>
		private bool _LoadSourceCodeFile(CoverageTextEditor coverageTextEditor, string fileName)
		{
			if (!File.Exists(fileName))
			{
				coverageTextEditor.Clear();
				coverageTextEditor.Text = string.Format("The file '{0}' does not exist.", fileName);
				coverageTextEditor.ActiveTextAreaControl.Refresh();
				return false;
			}

			coverageTextEditor.LoadSourceCodeFile(fileName);
			return true;
		}
		
		#region CoverageTextEditor Event Handlers
		
		/// <summary>
		/// Handles the TabKeyPressed event of the CoverageTreeEditor control.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="TabKeyPressedEventArgs"/> instance containing the event data.</param>
		private void _OnCoverageTextEditorTabKeyPressed(object sender, TabKeyPressedEventArgs e)
		{
			this.Focus();
//			if (e.IsShiftTab)
//			{
//				if (pnlStatistics.Visible)
//				{
//					statisticsListView.Focus();
//				}
//				else
//				{
//					coverageTreeView.Focus();
//				}
//			}
//			else
//			{
//				coverageTreeView.Focus();
//			}
		}

		#endregion CoverageTextEditor Event Handlers

		#endregion Private Methods
	}
}
