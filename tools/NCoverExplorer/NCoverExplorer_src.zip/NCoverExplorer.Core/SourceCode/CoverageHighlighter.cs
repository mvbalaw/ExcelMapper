using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using ICSharpCode.TextEditor.Document;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Presentation;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Core.SourceCode
{
	/// <summary>
	/// Class responsible for highlighting sequence points in a CoverageTextEditor control for a file.
	/// </summary>
	public class CoverageHighlighter
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private SourceCodeTabControl _sourceCodeTabControl;
		private MainFormController _controller;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageHighlighter"/> class.
		/// </summary>
		/// <param name="mainFormController">The main form controller.</param>
		/// <param name="configuration">The configuration.</param>
		/// <param name="sourceCodeTabControl">Tab control containing all the open files.</param>
		public CoverageHighlighter(MainFormController mainFormController, IExplorerConfiguration configuration, 
			SourceCodeTabControl sourceCodeTabControl)
		{
			_controller = mainFormController;
			_configuration = configuration;
			_sourceCodeTabControl = sourceCodeTabControl;
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Recurse through the class node and any inner nested classes highlighting all methods.
		/// </summary>
		/// <param name="selectedClassNode">The selected class node.</param>
		/// <returns>Whether the file was loaded into a tab and highlighted without errors.</returns>
		public bool HighlightClassCode(TreeNodeBase selectedClassNode)
		{
			string lastFileName = string.Empty;
			CoverageTextEditor coverageTextEditor = null;
			foreach (TreeNode childNode in selectedClassNode.Nodes)
			{
				if (childNode is MethodTreeNode)
				{
					MethodTreeNode methodTreeNode = (MethodTreeNode)childNode;
					foreach (SequencePoint sequencePoint in methodTreeNode.SequencePoints)
					{
						try
						{
							if (sequencePoint.FileName != lastFileName)
							{
								lastFileName = sequencePoint.FileName;
								if (!File.Exists(lastFileName))
								{
									if (_configuration.WarnAboutMissingSourceCode)
									{
										if (_controller.ChangeSourceCodePath(lastFileName))
										{
											return false;
										}
									}
									// Abort the highlighting process
									StatusPublisher.Display("File not found: " + lastFileName);
									return false;
								}
								SourceCodeTabInfo sourceCodeTabInfo = _sourceCodeTabControl.GetLoadedTabForFileName(sequencePoint.FileName);
								// Only assign the class node if have not already - handles recursive situations.
								if (sourceCodeTabInfo.ClassTreeNode == null && selectedClassNode is ClassTreeNode)
								{
									sourceCodeTabInfo.ClassTreeNode = (ClassTreeNode)selectedClassNode;
								}
								coverageTextEditor = sourceCodeTabInfo.SourceCodeTextEditor;
							}
							_HighlightSequencePoint(coverageTextEditor, sequencePoint);
						}
						catch (DisplaySequencePointException d)
						{
							MessageBox.Show(d.Message, "NCoverExplorer", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
							// Abort the displaying of this file.
							return false;
						}
						catch (Exception e)
						{
							throw new DisplaySequencePointException(sequencePoint, e);
						}
					}
				}
				else // if (childNode is ClassTreeNode)
				{
					HighlightClassCode((TreeNodeBase)childNode);//(ClassTreeNode)childNode);
				}
			}

			// Force the highlights to refresh.
			if (coverageTextEditor != null)
			{
				coverageTextEditor.ActiveTextAreaControl.Refresh();
			}
			return true;
		}

		#endregion Public Methods

		#region Private Methods

		/// <summary>
		/// Highlights the sequence point in the text editor with the relevant highlighting type.
		/// </summary>
		/// <param name="sequencePoint">The sequence point.</param>
		private void _HighlightSequencePoint(CoverageTextEditor coverageTextEditor, SequencePoint sequencePoint)
		{
			int offset = 0;
			int length = 0;
			if (sequencePoint.EndLine > coverageTextEditor.Document.LineSegmentCollection.Count)
			{
				throw new DisplaySequencePointException("Unable to highlight as the source code file has changed since the coverage file was generated:"
					+ Environment.NewLine + coverageTextEditor.CurrentSourceCodeFileName
					+ Environment.NewLine + Environment.NewLine + "Run NCover again to ensure the coverage is in sync with the latest source.");
			}

			// The following nastiness is necessary because unfortunately the ICSharpCode guys thought
			// that "they know best" when it comes to highlighting. By this I mean the control doesn't
			// actually use the exact coordinates you pass it in the marker strategy - instead it finds
			// all the "words" covered by that selection and highlights them. The following kludges are
			// my attempts to work around the issue as best as possible.
			if (sequencePoint.StartLine == sequencePoint.EndLine)
			{
				// Is a single line sequence point
				LineSegment lineSegment = coverageTextEditor.Document.GetLineSegment(sequencePoint.StartLine - 1);
				offset = lineSegment.Offset;
				string lineText = coverageTextEditor.Document.GetText(lineSegment);
				if (lineText.Length < sequencePoint.StartColumn - 1)
				{
					// Gone horribly wrong - must be opening a coverage file for an old source code file.
					throw new DisplaySequencePointException("Could not find source code to match @ " + sequencePoint.StartLine + "," + sequencePoint.StartColumn
						+ Environment.NewLine + coverageTextEditor.CurrentSourceCodeFileName
						+ Environment.NewLine + Environment.NewLine + "Run NCover again to ensure the coverage is in sync with the latest source.");
				}

				if (sequencePoint.EndColumn == 0)
				{
					// This is probably a C++ file where NCover has reported an issue but doesn't have the column information.
					// Highlight the entire line.
					length = lineText.Length;
				}
				else
				{
					offset += sequencePoint.StartColumn;
					length = sequencePoint.EndColumn - sequencePoint.StartColumn - 1;
				}
				coverageTextEditor.Document.MarkerStrategy.TextMarker.Add(
					new CoverageTextMarker(_configuration, offset, length, sequencePoint.VisitCount, sequencePoint.IsExcluded));
			}
			else
			{
				// A multiple line sequence point to highlight. Tried an "easy" way of just figuring out the total length
				// but that leaves the leading whitespace on following lines of the code highlighted which looks pretty ugly.
				// Instead iterate through the range and highlight just the text on each line without leading whitespace.
				for	(int line = sequencePoint.StartLine; line <= sequencePoint.EndLine; line++)
				{
					_CalculateVisibleSequencePointOnLine(coverageTextEditor, sequencePoint, line, out offset, out length);
					if (offset >= 0)
					{
						coverageTextEditor.Document.MarkerStrategy.TextMarker.Add(
							new CoverageTextMarker(_configuration, offset, length, sequencePoint.VisitCount, sequencePoint.IsExcluded));
					}
				}
			}
		}

		/// <summary>
		/// Determine the offset and length coordinates for highlighting this specified sequence point on this line.
		/// </summary>
		private void _CalculateVisibleSequencePointOnLine(CoverageTextEditor coverageTextEditor, SequencePoint sequencePoint, int line, out int offset, out int length)
		{
			LineSegment segment = coverageTextEditor.Document.GetLineSegment(line - 1);
			offset = segment.Offset;
			length = 0;
	
			string text = coverageTextEditor.Document.GetText(segment);
			if (text.Length == 0)
			{
				offset = -1;
				return;
			}

			if (line == sequencePoint.StartLine)
			{
				// On the first line we want to highlight from specified sequence point column all the way to the end of the line
				offset = coverageTextEditor.Document.PositionToOffset(new Point(sequencePoint.StartColumn, line - 1));
				length = text.Length - sequencePoint.StartColumn - 1;
			}
			else
			{
				int whitespaceColumnOffset = 0;
				while ((whitespaceColumnOffset < text.Length) && ((text[whitespaceColumnOffset] == ' ') || (text[whitespaceColumnOffset] == '\t')))
				{
					whitespaceColumnOffset++;
					offset++;
				}
				offset++;

				if (line == sequencePoint.EndLine)
				{
					// On the last line we want to highlight to specified sequence point end column (excluding leading whitespace)
					length = coverageTextEditor.Document.PositionToOffset(new Point(sequencePoint.EndColumn, line - 1)) - offset;
				}
				else
				{
					// On any lines in between highlight all the text on the line excluding leading whitespace
					length = text.Length - whitespaceColumnOffset;
				}
			}
		}

		#endregion Private Methods
	}
}
