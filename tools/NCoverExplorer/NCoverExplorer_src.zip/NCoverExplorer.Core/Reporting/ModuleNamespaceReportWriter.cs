using System.Collections;
using System.Xml;

using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Iterators;

namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Creates a summary xml report detailing loaded statistics and overall coverage per module. 
	/// Within each module it also contains namespace summary statistics for that module.
	/// </summary>
	public class ModuleNamespaceReportWriter : ModuleReportWriter
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleNamespaceReportWriter"/> class.
		/// </summary>
		public ModuleNamespaceReportWriter()
		{
		}

		#endregion Constructor

		#region Protected Members

		/// <summary>
		/// Gets the report title.
		/// </summary>
		/// <value>The report title.</value>
		protected override string ReportTitle
		{
			get { return "Module Namespace Summary"; }
		}

		/// <summary>
		/// Called when writing module element nodes as an opportunity to write detail for that module.
		/// In this class we write out namespace information.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="moduleTreeNode">The module tree node.</param>
		protected override void OnWriteDetailForModule(XmlTextWriter xmlTextWriter, ModuleTreeNode moduleTreeNode)
		{
			IEnumerator enumerator = new ModuleNamespaceTreeIterator(moduleTreeNode);
			while (enumerator.MoveNext())
			{
				this.WriteNamespaceReportXml(xmlTextWriter, (NamespaceTreeNode)enumerator.Current);
			}
		}

		#endregion Protected Members
	}
}
