using System.Collections;
using System.Xml;

using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Iterators;

namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Creates a summary xml report detailing loaded statistics and overall coverage per module.
	/// Also contains namespaces per module.
	/// </summary>
	public class ModuleReportWriter : ReportWriterBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleReportWriter"/> class.
		/// </summary>
		public ModuleReportWriter()
		{
		}

		#endregion Constructor

		#region Protected Members

		/// <summary>
		/// Gets the report title.
		/// </summary>
		/// <value>The report title.</value>
		protected override string ReportTitle
		{
			get { return "Module Summary"; }
		}

		/// <summary>
		/// Writes the report detail.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		protected override void OnWriteDetailForCoverageFile(XmlTextWriter xmlTextWriter, CoverageFileTreeNode coverageFileTreeNode)
		{
			xmlTextWriter.WriteStartElement("modules");

			IEnumerator enumerator = new ModuleTreeIterator(coverageFileTreeNode);
			while (enumerator.MoveNext())
			{
				WriteModuleReportXml(xmlTextWriter, (ModuleTreeNode)enumerator.Current, 
					coverageFileTreeNode.Configuration.SatisfactoryCoverageThreshold,
					coverageFileTreeNode.Configuration.ModuleThresholds);
			}

			xmlTextWriter.WriteEndElement(); // modules
		}

		#endregion Protected Members
	}
}
