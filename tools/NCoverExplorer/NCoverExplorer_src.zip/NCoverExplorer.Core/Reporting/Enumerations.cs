
namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Potential report types.
	/// </summary>
	public enum ReportType
	{
		/// <summary>None.</summary>
		None = 0,
		/// <summary>Modules summary only.</summary>
		ModuleSummary = 1,
		/// <summary>Namespaces summary only.</summary>
		NamespaceSummary = 2,
		/// <summary>Modules summary followed with a namespaces by module summary.</summary>
		ModuleNamespaceSummary = 3,
		/// <summary>Modules summary followed with a classes by namespace summary.</summary>
		ModuleClassSummary = 4
	}
}
