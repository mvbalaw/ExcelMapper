using System.Collections;

namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Container class for summarising the immediate children of ExcludedTreeNode nodes in the coverage
	/// tree for use with the output reports.
	/// </summary>
	public class ExcludedNodesSummary
	{
		#region Private Variables

		private ArrayList _excludedModules;
		private ArrayList _excludedNamespaces;
		private ArrayList _excludedClasses;
		private ArrayList _excludedMethods;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ExcludedNodesSummary"/> class.
		/// </summary>
		public ExcludedNodesSummary()
		{
			_excludedModules = new ArrayList();
			_excludedNamespaces = new ArrayList();
			_excludedClasses = new ArrayList();
			_excludedMethods = new ArrayList();
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the excluded modules.
		/// </summary>
		/// <value>The excluded modules.</value>
		public ArrayList ExcludedModules
		{
			get { return _excludedModules; }
		}

		/// <summary>
		/// Gets the excluded namespaces.
		/// </summary>
		/// <value>The excluded namespaces.</value>
		public ArrayList ExcludedNamespaces
		{
			get { return _excludedNamespaces; }
		}

		/// <summary>
		/// Gets the excluded classes.
		/// </summary>
		/// <value>The excluded classes.</value>
		public ArrayList ExcludedClasses
		{
			get { return _excludedClasses; }
		}

		/// <summary>
		/// Gets the excluded methods.
		/// </summary>
		/// <value>The excluded methods.</value>
		public ArrayList ExcludedMethods
		{
			get { return _excludedMethods; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Sorts all the collections of excluded nodes.
		/// </summary>
		public void Sort()
		{
			_excludedModules.Sort();
			_excludedNamespaces.Sort();
			_excludedClasses.Sort();
			_excludedMethods.Sort();
		}

		#endregion Public Methods
	}
}
