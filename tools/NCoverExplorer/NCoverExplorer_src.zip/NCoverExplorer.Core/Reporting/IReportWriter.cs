using System.IO;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Statistics;

namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Interface for all the various report writers to implement for different report types.
	/// </summary>
	public interface IReportWriter
	{
		/// <summary>
		/// Creates an xml report in an output stream.
		/// </summary>
		/// <param name="outputStream">Output stream.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="statisticsSummary">The statistics summary.</param>
		/// <param name="showExcludedFooter">If set to <c>true</c> will add a list of excluded nodes at bottom.</param>
		void CreateReport(Stream outputStream, CoverageFileTreeNode coverageFileTreeNode, 
			StatisticsSummary statisticsSummary, bool showExcludedFooter);
	}
}
