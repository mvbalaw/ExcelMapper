using System;
using System.IO;
using System.Reflection;
using System.Xml.XPath;
using System.Xml.Xsl;

using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Visitors;

namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Helper class with static methods for creating reports.
	/// </summary>
	public class ReportHelper
	{
		#region Public Constants

		public const string ReportStylesheet = "CoverageReport.xsl";

		#endregion Private Constants

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ReportHelper"/> class.
		/// </summary>
		private ReportHelper()
		{
		}

		#endregion Constructor

		#region Public Static Methods

		/// <summary>
		/// Factory method to create the report specified in the enum.
		/// </summary>
		/// <param name="reportType">Type of report to create such as module or namespace summary.</param>
		/// <param name="xmlFileName">Name of the XML file.</param>
		/// <param name="htmlFileName">Name of the HTML file.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="showExcludedFooter">If set to <c>true</c> will add a list of excluded nodes at bottom.</param>
		public static void CreateReport(ReportType reportType, string xmlFileName, string htmlFileName,
			CoverageFileTreeNode coverageFileTreeNode, bool showExcludedFooter)
		{
			IReportWriter reportWriter = null;

			switch (reportType)
			{
				case ReportType.None:
					return;

				case ReportType.ModuleSummary:
					reportWriter = new ModuleReportWriter();
					break;

				case ReportType.NamespaceSummary:
					reportWriter = new NamespaceReportWriter();
					break;

				case ReportType.ModuleNamespaceSummary:
					reportWriter = new ModuleNamespaceReportWriter();
					break;

				case ReportType.ModuleClassSummary:
					reportWriter = new ModuleClassReportWriter();
					break;

				default:
					throw new ArgumentOutOfRangeException("ReportType", reportType.ToString());
			}

			if (reportWriter != null)
			{
				if (xmlFileName.Length > 0)
				{
					_CreateXmlFileReport(reportWriter, xmlFileName, coverageFileTreeNode, showExcludedFooter);
				}
				if (htmlFileName.Length > 0)
				{
					_CreateHtmlFileReport(reportWriter, htmlFileName, coverageFileTreeNode, showExcludedFooter);
				}
			}
		}

		#endregion Public Static Methods

		#region Private Static Methods

		/// <summary>
		/// Creates the report using the specified report writer.
		/// </summary>
		/// <param name="reportWriter">The report writer.</param>
		/// <param name="fileName">Name of the output file.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="showExcludedFooter">If set to <c>true</c> will add a list of excluded nodes at bottom.</param>
		public static void _CreateXmlFileReport(IReportWriter reportWriter, string fileName, 
			CoverageFileTreeNode coverageFileTreeNode, bool showExcludedFooter)
		{
			StatisticsTreeNodeVisitor visitor = new StatisticsTreeNodeVisitor();
			coverageFileTreeNode.AcceptVisitor(visitor);

			using (Stream fileStream = File.Create(fileName))
			{
				reportWriter.CreateReport(fileStream, coverageFileTreeNode, visitor.StatisticsSummary, showExcludedFooter);
				
				fileStream.Close();
			}

			_CopyStylesheetToOutputFolder(Path.GetDirectoryName(fileName));
		}

		/// <summary>
		/// Creates the report using the specified report writer.
		/// </summary>
		/// <param name="reportWriter">The report writer.</param>
		/// <param name="fileName">Name of the output file.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="showExcludedFooter">If set to <c>true</c> will add a list of excluded nodes at bottom.</param>
		public static void _CreateHtmlFileReport(IReportWriter reportWriter, string fileName, 
			CoverageFileTreeNode coverageFileTreeNode, bool showExcludedFooter)
		{
			StatisticsTreeNodeVisitor visitor = new StatisticsTreeNodeVisitor();
			coverageFileTreeNode.AcceptVisitor(visitor);

			using (MemoryStream memoryStream = new MemoryStream())
			{
				reportWriter.CreateReport(memoryStream, coverageFileTreeNode, visitor.StatisticsSummary, showExcludedFooter);
				
				memoryStream.Position = 0;

				_OutputToHtmlFile(memoryStream, fileName);
				
				memoryStream.Close();
			}
		}

		/// <summary>
		/// Outputs an xml stream to an html file by applying a transformation.
		/// </summary>
		/// <param name="xmlStream">The XML stream.</param>
		/// <param name="fileName">Name of the file.</param>
		private static void _OutputToHtmlFile(Stream xmlStream, string fileName)
		{
			string fullStylesheetPath = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), ReportStylesheet);
			if (!File.Exists(fullStylesheetPath))
			{
				throw new FileNotFoundException("Cannot find xsl stylesheet: " + fullStylesheetPath, fullStylesheetPath);
			}

			XslTransform xslt = new XslTransform();
			xslt.Load(fullStylesheetPath);

			XPathDocument xpathDocument = new XPathDocument(xmlStream);
			
			using (Stream fileStream = File.Create(fileName))
			{
				xslt.Transform(xpathDocument.CreateNavigator(), null, fileStream);
				
				fileStream.Flush();
				fileStream.Close();
			}
		}

		/// <summary>
		/// Copies the stylesheet to the output folder.
		/// </summary>
		/// <param name="destinationFolder">The destination folder.</param>
		private static void _CopyStylesheetToOutputFolder(string destinationFolder)
		{
			string fullStylesheetPath = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), ReportStylesheet);
			if (!File.Exists(fullStylesheetPath))
			{
				throw new FileNotFoundException("Cannot find xsl stylesheet: " + fullStylesheetPath, fullStylesheetPath);
			}
			string destStylesheetPath = Path.Combine(destinationFolder, ReportStylesheet);
			if (fullStylesheetPath != destStylesheetPath)
			{
				File.Copy(fullStylesheetPath, destStylesheetPath, true);
			}
		}

		#endregion Private Static Methods
	}
}
