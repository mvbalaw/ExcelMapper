using System.Collections;
using System.Xml;

using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Iterators;

namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Creates a summary xml report detailing loaded statistics and overall coverage per namespace.
	/// </summary>
	public class NamespaceReportWriter : ReportWriterBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="NamespaceReportWriter"/> class.
		/// </summary>
		public NamespaceReportWriter()
		{
		}

		#endregion Constructor

		#region Protected Members

		/// <summary>
		/// Gets the report title.
		/// </summary>
		/// <value>The report title.</value>
		protected override string ReportTitle
		{
			get { return "Namespace Summary"; }
		}

		/// <summary>
		/// Writes the report detail.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		protected override void OnWriteDetailForCoverageFile(XmlTextWriter xmlTextWriter, CoverageFileTreeNode coverageFileTreeNode)
		{
			xmlTextWriter.WriteStartElement("namespaces");

			IEnumerator enumerator;

			if (coverageFileTreeNode.Configuration.GroupByModule)
			{
				// The coverage tree has been grouped by module which makes life a bit harder to produce this report.
				// We need to build a list of all the namespaces from the modules, sort it, and only then iterate.
				enumerator = new SortedNamespaceTreeIterator(coverageFileTreeNode);
			}
			else
			{
				// The coverage tree is grouped by namespace which makes life simple.
				enumerator = new NamespaceTreeIterator(coverageFileTreeNode);
			}

			while (enumerator.MoveNext())
			{
				WriteNamespaceReportXml(xmlTextWriter, (NamespaceTreeNode)enumerator.Current);
			}

			xmlTextWriter.WriteEndElement(); // namespaces
		}

		#endregion Protected Members
	}
}
