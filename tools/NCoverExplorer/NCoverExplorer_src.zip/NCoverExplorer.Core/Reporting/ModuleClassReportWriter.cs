using System.Collections;
using System.Xml;

using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Iterators;

namespace NCoverExplorer.Core.Reporting
{
	/// <summary>
	/// Creates a summary xml report detailing loaded statistics and overall coverage per module. 
	/// Within each module it also contains class summary statistics per namespace for that module.
	/// </summary>
	public class ModuleClassReportWriter : ModuleReportWriter
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleClassReportWriter"/> class.
		/// </summary>
		public ModuleClassReportWriter()
		{
		}

		#endregion Constructor

		#region Protected Members

		/// <summary>
		/// Gets the report title.
		/// </summary>
		/// <value>The report title.</value>
		protected override string ReportTitle
		{
			get { return "Module Class Summary"; }
		}

		/// <summary>
		/// Called when writing module element nodes as an opportunity to write detail for that module.
		/// In this class we write out namespace information per module.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="moduleTreeNode">The module tree node.</param>
		protected override void OnWriteDetailForModule(XmlTextWriter xmlTextWriter, ModuleTreeNode moduleTreeNode)
		{
			IEnumerator enumerator = new ModuleNamespaceTreeIterator(moduleTreeNode);
			while (enumerator.MoveNext())
			{
				// Only write out the namespace node if there are child class nodes
				NamespaceTreeNode namespaceTreeNode = (NamespaceTreeNode)enumerator.Current;
				IEnumerator classEnumerator = new NamespaceClassTreeIterator(namespaceTreeNode);
				if (classEnumerator.MoveNext())
				{
					this.WriteNamespaceReportXml(xmlTextWriter, namespaceTreeNode);
				}
			}
		}

		/// <summary>
		/// Called when writing namespace element nodes as an opportunity to write detail for that namespace.
		/// In this class we write out class information per namespace.
		/// </summary>
		/// <param name="xmlTextWriter">The XML text writer.</param>
		/// <param name="namespaceTreeNode">The namespace tree node.</param>
		protected override void OnWriteDetailForNamespace(XmlTextWriter xmlTextWriter, NamespaceTreeNode namespaceTreeNode)
		{
			IEnumerator enumerator = new NamespaceClassTreeIterator(namespaceTreeNode);
			while (enumerator.MoveNext())
			{
				this.WriteClassReportXml(xmlTextWriter, (ClassTreeNode)enumerator.Current);
			}
		}

		#endregion Protected Members
	}
}
