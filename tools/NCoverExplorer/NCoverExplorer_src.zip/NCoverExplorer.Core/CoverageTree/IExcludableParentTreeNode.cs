
namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// Interface for all nodes that are able to have excludable children.
	/// </summary>
	public interface IExcludableParentTreeNode
	{
		/// <summary>
		/// Gets or sets the excluded node containing items excluded for this class, namespace, module or coverage file.
		/// </summary>
		/// <value>The excluded node.</value>
		ExcludedTreeNode ExcludedNode { get; set; }
		/// <summary>
		/// Gets or whether this tree node has an excluded node with children.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has an excluded node; otherwise, <c>false</c>.
		/// </value>
		bool HasExcludedNode { get; }
	}
}
