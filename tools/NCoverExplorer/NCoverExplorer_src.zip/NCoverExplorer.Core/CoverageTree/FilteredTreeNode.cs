using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// A node in the treeview display representing a parent for all the filtered nodes for this class/namespace/module.
	/// Each "IFilterParentTreeNode" class can have of these nodes as a child containing the filtered
	/// nodes within it.
	/// </summary>
	public class FilteredTreeNode : TreeNodeBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="FilteredTreeNode"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		public FilteredTreeNode(IExplorerConfiguration configuration) 
			: base(configuration, "zzzzzFiltered")
		{
			this.NodeName = "Filtered";
			this.FullyQualifiedName = "Filtered nodes";
			this.IsFiltered = true;
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Sets the appropriate icon and node text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost.
		/// </summary>
		public override void InitialiseForFirstDisplay()
		{
			// Set the node text and colour.
			base.InitialiseForFirstDisplay();

			TreeNodeBase firstChild = (TreeNodeBase)this.Nodes[0];
			this.ImageIndex = AppearanceHelper.GetImageIndexForFiltered(firstChild.UnvisitedSequencePoints);
			this.SelectedImageIndex = this.ImageIndex;
			IsFiltered = true;
		}

		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public override bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager)
		{
			return false;
		}

		#endregion Public Methods
	}
}
