using System;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// Displays the code coverage nodes in the tree.
	/// </summary>
	public class CoverageTreeView : TreeView
	{
		#region Events

		public event SortEventHandler BeforeSort;
		public event SortEventHandler AfterSort;
		public event TreeViewEventHandler AfterClassNodeSelect;
		public event TreeViewEventHandler AfterMethodNodeSelect;
		public event TreeViewEventHandler AfterNonCodeNodeSelect;

		#endregion Events

		#region Private Variables

		private IExplorerConfiguration _configuration;
		private TreeNodeBase _lastSelectedNode;
		private ClassTreeNode _lastSelectedClassNode;
		private bool _isSortInProgress;
		private bool _isFilterInProgress;
		private ToolTip _toolTip;
		private string _oldNodeName; 

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageTreeView"/> class.
		/// </summary>
		public CoverageTreeView()
		{
			_configuration = null;
			_lastSelectedNode = null;
			_lastSelectedClassNode = null;
			_isSortInProgress = false;
			_isFilterInProgress = false;

			_toolTip = new ToolTip();
			_toolTip.InitialDelay = 300;
			_toolTip.ReshowDelay = 0;
			_oldNodeName = string.Empty;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the last selected node.
		/// </summary>
		/// <value>The last selected node.</value>
		public TreeNodeBase LastSelectedNode
		{
			get { return _lastSelectedNode; }
		}

		/// <summary>
		/// Gets the last selected class node.
		/// </summary>
		/// <value>The last selected class node.</value>
		public ClassTreeNode LastSelectedClassNode
		{
			get { return _lastSelectedClassNode; }
		}

		/// <summary>
		/// Gets whether a sort is currently in progress.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if a sort is in progress; otherwise, <c>false</c>.
		/// </value>
		public bool IsSortInProgress
		{
			get { return _isSortInProgress; }
		}

		#endregion Public Properties

		#region Public Methods

		#region Initialisation

		/// <summary>
		/// Initialises the tree.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		public void Initialise(IExplorerConfiguration configuration)
		{
			_configuration = configuration;
		}

		#endregion Initialisation

		#region Population

		/// <summary>
		/// Displays the coverage nodes in the tree.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		public void LoadCoverageNodes(CoverageFileTreeNode coverageFileTreeNode)
		{
			Nodes.Clear();
			BeginUpdate();
			try
			{
				this.Sorted = true;
				Nodes.Add(coverageFileTreeNode);
				coverageFileTreeNode.InitialiseForFirstDisplay();
				coverageFileTreeNode.Expand();
			}
			finally
			{
				EndUpdate();
				_lastSelectedNode = null;
				_lastSelectedClassNode = null;
			}
		}

		#endregion Population

		#region Refresh
		
		/// <summary>
		/// Refreshes the appearance of the entire tree.
		/// </summary>
		public void RefreshAllNodes()
		{
			if (Nodes.Count > 0)
			{
				_RefreshLoadedNodeWithChildren((TreeNodeBase)Nodes[0]);
			}
		}

		#endregion Refresh

		#region Sorting

		/// <summary>
		/// Sorts the tree view.
		/// </summary>
		/// <param name="treeSortStyle">The tree sort style.</param>
		public void SortTreeView(TreeSortStyle treeSortStyle)
		{
			TreeNodeBase selectedNode = (TreeNodeBase)SelectedNode;
			if (selectedNode == null)
			{
				return;
			}
			_configuration.TreeSortStyle = treeSortStyle;
			_lastSelectedClassNode = null;
			_isSortInProgress = true;

			HighPerformanceTimer highPerformanceTimer = new HighPerformanceTimer();
			highPerformanceTimer.Start();
			bool isNodeExpanded = selectedNode.IsExpanded;
			Scrollable = false;  // Stop nasty flicker as nodes are expanded.
			Sorted = false;		// Ensure default sorting is switched off.

			OnBeforeSort(new SortEventArgs(selectedNode));

			TreeViewSorter.SortTreeView(this);

			Scrollable = true;   // Restore for usage.
			Visible = true;
			_isSortInProgress = false;
			if (isNodeExpanded)
			{
				selectedNode.Expand();
			}
			highPerformanceTimer.Stop();

			OnAfterSort(new SortEventArgs(selectedNode, highPerformanceTimer.Duration));
		}

		#endregion Sorting

		#region Selection

		/// <summary>
		/// Gets the current class tree node (iterating up the tree as necessary).
		/// Returns null if no class node selected.
		/// </summary>
		/// <returns></returns>
		public ClassTreeNode GetCurrentClassTreeNode()
		{
			TreeNodeBase treeNode = (TreeNodeBase)SelectedNode;
			if (treeNode == null) { return null; }

			// The first thing we must do is iterate upwards until we hit a tree node that is NOT a class node
			// This ensures that for nested classes we highlight everything in the file.
			while (treeNode.Parent is ClassTreeNode || treeNode is MethodTreeNode)
			{
				treeNode = (TreeNodeBase)treeNode.Parent;
			}
			if (!(treeNode is ClassTreeNode))
			{
				// Must be a namespace node so nothing to select - just exit.
				return null;
			}

			ClassTreeNode selectedClassNode = (ClassTreeNode)treeNode;
			_lastSelectedClassNode = selectedClassNode;
			return _lastSelectedClassNode;
		}

		/// <summary>
		/// Clears the selection history.
		/// </summary>
		public void ClearSelectionHistory()
		{
			_lastSelectedClassNode = null;
		}

		/// <summary>
		/// Selects the and click node in treeview.
		/// </summary>
		/// <param name="nodeToSelect">The node to select.</param>
		public void SelectAndClickNode(TreeNodeBase nodeToSelect)
		{
			SelectedNode = nodeToSelect;
			OnAfterSelect(new TreeViewEventArgs(nodeToSelect));
		}

		#endregion Selection

		#region ApplyTheme

		/// <summary>
		/// Applies the theme to the appearance of this control.
		/// </summary>
		/// <param name="theme">The theme.</param>
		public void ApplyTheme(Theme theme)
		{
			BackColor = theme.CoverageTreeBackgroundColor;
			Font = theme.CoverageTreeFont;
		}

		#endregion ApplyTheme

		#region Expansion

		/// <summary>
		/// Recurse through all the children of this node, expanding all the ones whose coverage is greater than 0%
		/// </summary>
		public void ExpandCoveredNodes(TreeNodeBase selectedNode)
		{
			// First ensure that this node is loaded
			if (!selectedNode.IsExpanded)
			{
				selectedNode.Expand();
			}

			// Now recurse through each expanding each child node with coverage that isn't a method.
			foreach (TreeNodeBase treeNode in selectedNode.Nodes)
			{
				if (treeNode.VisitedSequencePoints > 0 && !(treeNode is MethodTreeNode))
				{
					ExpandCoveredNodes(treeNode);
				}
			}
		}

		#endregion Expansion

		#region Exclude From Results

		/// <summary>
		/// Gets the selected node after excluding from results.
		/// </summary>
		/// <param name="childNodeToExclude">The child node to exclude.</param>
		/// <returns></returns>
		public TreeNodeBase GetSelectedNodeAfterExcludingFromResults(TreeNodeBase childNodeToExclude)
		{
			TreeNodeBase parentTreeNode = (TreeNodeBase)childNodeToExclude.Parent;

			_ExcludeNodeWithChildrenRecursively(childNodeToExclude);
			parentTreeNode.RecalculateAllStatisticsUpTreeBranch();

			return _MoveAllExcludedChildrenIntoParentExclusionBin(childNodeToExclude);
		}

		#endregion Exclude From Results

		#region Include In Results

		/// <summary>
		/// Gets the selected node after including all excluded child nodes in the results.
		/// </summary>
		/// <param name="excludedTreeNode">The exclusions bin node.</param>
		/// <returns></returns>
		public TreeNodeBase GetSelectedNodeAfterIncludingAllInResults(ExcludedTreeNode excludedTreeNode)
		{
			TreeNodeBase selectedNode = (TreeNodeBase)excludedTreeNode.Nodes[0];
			TreeNodeBase newParentNode = (TreeNodeBase)excludedTreeNode.Parent;

			for (int index = excludedTreeNode.Nodes.Count - 1; index >= 0; index--)
			{
				TreeNodeBase nodeToInclude = (TreeNodeBase)excludedTreeNode.Nodes[index];
				nodeToInclude.Remove();
				newParentNode.Nodes.Add(nodeToInclude);
				nodeToInclude.IncludeNodesRecursively();
				nodeToInclude.InitialiseForFirstDisplay();
			}
			if (_configuration.TreeFilterStyle != TreeFilterStyle.None)
			{
				_ApplyFiltersToChildren((IFilterParentTreeNode)newParentNode, _configuration.TreeFilterStyle);
			}

			IExcludableParentTreeNode excludableParentTreeNode = (IExcludableParentTreeNode)newParentNode;
			excludableParentTreeNode.ExcludedNode = null;
			excludedTreeNode.Remove();

			TreeViewSorter.SortTreeNodeChildren(newParentNode);

			newParentNode.RecalculateAllStatisticsUpTreeBranch();

			return selectedNode;
		}

		/// <summary>
		/// Includes the node in results.
		/// </summary>
		/// <param name="nodeToInclude">The node to include.</param>
		public void IncludeNodeInResults(TreeNodeBase nodeToInclude)
		{
			TreeNodeBase newParentNode = (TreeNodeBase)nodeToInclude.Parent.Parent;
			nodeToInclude.Remove();
			nodeToInclude.IncludeNodesRecursively();
			newParentNode.Nodes.Add(nodeToInclude);
			if (_configuration.TreeFilterStyle != TreeFilterStyle.None)
			{
				_ApplyFiltersToChildren((IFilterParentTreeNode)newParentNode, _configuration.TreeFilterStyle);
			}

			TreeViewSorter.SortTreeNodeChildren(newParentNode);

			nodeToInclude.RecalculateAllStatisticsUpTreeBranch();
		}

		#endregion Include In Results

		#region Filter

		/// <summary>
		/// Filters the tree view.
		/// </summary>
		/// <param name="treeFilterStyle">The tree filter style to apply to whatever is already applied.</param>
		public void FilterTreeView(TreeFilterStyle treeFilterStyle)
		{
			if (treeFilterStyle == TreeFilterStyle.None)
			{
				if (_configuration.TreeFilterStyle == TreeFilterStyle.None)
				{
					StatusPublisher.Display("No filter applied.");
					return;
				}
			}
			else if (_configuration.TreeFilterStyle == treeFilterStyle)
			{
				StatusPublisher.Display("Filter already applied.");
				return;
			}

			_isFilterInProgress = true;
			TreeNodeBase selectedNode = (TreeNodeBase)this.SelectedNode;
			CoverageFileTreeNode coverageFileTreeNode = (CoverageFileTreeNode)this.Nodes[0];
			bool isChangingFromExistingFilter = _configuration.TreeFilterStyle != TreeFilterStyle.None;

			if (treeFilterStyle == TreeFilterStyle.None || isChangingFromExistingFilter)
			{
				_UndoAllFilters(coverageFileTreeNode);
			}

			if (treeFilterStyle == TreeFilterStyle.None)
			{
				// Make sure the nodes are sorted appropriately
				SortTreeView(_configuration.TreeSortStyle);
				StatusPublisher.Display("All filters removed.");
			}
			else
			{
				_ApplyFiltersToChildren(coverageFileTreeNode, treeFilterStyle);
				if (isChangingFromExistingFilter)
				{
					SortTreeView(_configuration.TreeSortStyle);
				}

				if (treeFilterStyle == TreeFilterStyle.HideUnvisited)
				{
					StatusPublisher.Display("Filter has hidden unvisited nodes.");
				}
				else if (treeFilterStyle == TreeFilterStyle.HideFullyCovered)
				{
					StatusPublisher.Display("Filter has hidden 100% covered nodes.");
				}
			}
			_isFilterInProgress = false;

			_configuration.TreeFilterStyle = treeFilterStyle;
			SelectAndClickNode(selectedNode);
		}

		#endregion Filter

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Handles the AfterSelect event of the treeView control.
		/// </summary>
		/// <param name="e">A <see cref="T:System.Windows.Forms.TreeViewEventArgs"/> that contains the event data.</param>
		protected override void OnAfterSelect(TreeViewEventArgs e)
		{
			if (_isSortInProgress || _isFilterInProgress)
			{
				return;
			}

			_lastSelectedNode = (TreeNodeBase)e.Node;

			TreeNodeBase selectedNode = (TreeNodeBase)e.Node;
			if (selectedNode is MethodTreeNode)
			{
				OnAfterMethodNodeSelect(e);
			}
			else if (selectedNode is ClassTreeNode)
			{
				OnAfterClassNodeSelect(e);
			}
			else
			{
				OnAfterNonCodeNodeSelect(e);
			}

			base.OnAfterSelect(e);
		}

		/// <summary>
		/// Handles the BeforeExpand event of the treeView control.
		/// </summary>
		/// <param name="e">The <see cref="System.Windows.Forms.TreeViewCancelEventArgs"/> instance containing the event data.</param>
		protected override void OnBeforeExpand(TreeViewCancelEventArgs e)
		{
			TreeNodeBase treeNode = (TreeNodeBase)e.Node;
			if (!treeNode.HasBeenLoaded)
			{
				// Make sure all the children have the appropriate graphics and node text.
				foreach (TreeNodeBase childTreeNode in treeNode.Nodes)
				{
					childTreeNode.InitialiseForFirstDisplay();
				}
				treeNode.HasBeenLoaded = true;
			}
			// Perform a "smart" auto expansion recursively if we are not the exclusions bin and have only one child.
			if (treeNode.Nodes.Count == 1 && !treeNode.IsExcluded)
			{
				treeNode.Nodes[0].Expand();
			}
			base.OnBeforeExpand(e);
		}

		/// <summary>
		/// Handles the MouseDown event of the treeView control.
		/// </summary>
		/// <param name="e">The <see cref="System.Windows.Forms.MouseEventArgs"/> instance containing the event data.</param>
		protected override void OnMouseDown(MouseEventArgs e)
		{
			TreeNode treeNode = this.GetNodeAt(e.X, e.Y);
			if (treeNode != null)
			{
				if (treeNode == _lastSelectedNode)
				{
					OnAfterSelect(new TreeViewEventArgs(treeNode));
				}
				else if (e.Button == MouseButtons.Right)
				{
					SelectedNode = this.GetNodeAt(e.X, e.Y);
				}
			}

			base.OnMouseDown(e);
		}

		/// <summary>
		/// Handles the MouseMove event of the treeView control to show tooltips.
		/// </summary>
		/// <param name="e">A <see cref="T:System.Windows.Forms.MouseEventArgs"/> that contains the event data.</param>
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove (e);
			TreeNodeBase treeNodeBase = (TreeNodeBase)GetNodeAt(e.X, e.Y);
			if (treeNodeBase != null)
			{
				string currentNodeName = treeNodeBase.FullyQualifiedName;
				if (currentNodeName != _oldNodeName)
				{
					_oldNodeName = currentNodeName;
					if (_toolTip != null && _toolTip.Active)
					{
						_toolTip.Active = false; //turn it off
					}

					if (treeNodeBase.ToolTipText.Length > 0)
					{
						_toolTip.SetToolTip(this, treeNodeBase.ToolTipText);
						_toolTip.Active = true; //make it active so it can show
					}
				}
			} 
		}


		/// <summary>
		/// Raises the BeforeSort event.
		/// </summary>
		/// <param name="e">The <see cref="NCoverExplorer.Core.CoverageTree.SortEventArgs"/> instance containing the event data.</param>
		protected void OnBeforeSort(SortEventArgs e)
		{
			if (BeforeSort != null)
			{
				BeforeSort(this, e);
			}
		}

		/// <summary>
		/// Raises the AfterSort event.
		/// </summary>
		/// <param name="e">The <see cref="NCoverExplorer.Core.CoverageTree.SortEventArgs"/> instance containing the event data.</param>
		protected void OnAfterSort(SortEventArgs e)
		{
			if (AfterSort != null)
			{
				AfterSort(this, e);
			}
		}

		/// <summary>
		/// Raises the AfterClassNodeSelect event.
		/// </summary>
		protected void OnAfterClassNodeSelect(TreeViewEventArgs e)
		{
			if (AfterClassNodeSelect != null)
			{
				AfterClassNodeSelect(this, e);
			}
		}

		/// <summary>
		/// Raises the AfterMethodNodeSelect event.
		/// </summary>
		protected void OnAfterMethodNodeSelect(TreeViewEventArgs e)
		{
			if (AfterMethodNodeSelect != null)
			{
				AfterMethodNodeSelect(this, e);
			}
		}

		/// <summary>
		/// Raises the AfterNonCodeNodeSelect event.
		/// </summary>
		protected void OnAfterNonCodeNodeSelect(TreeViewEventArgs e)
		{
			if (AfterNonCodeNodeSelect != null)
			{
				AfterNonCodeNodeSelect(this, e);
			}
		}

		#endregion Protected Methods

		#region Private Methods

		#region Moving Nodes Into Exclusion Bin

		/// <summary>
		/// Mark this node as excluded and clear it's statistics, recursing downwards to it's children as well.
		/// If we find a node that already has an exclusions bin, put all the nodes in that back under the parent since
		/// this whole branch will end up in an exclusions bin higher up the tree.
		/// </summary>
		/// <param name="nodeToExcludeWithChildren">The node to exclude with children.</param>
		private void _ExcludeNodeWithChildrenRecursively(TreeNodeBase nodeToExcludeWithChildren)
		{
			nodeToExcludeWithChildren.IsExcluded = true;
			nodeToExcludeWithChildren.SetVisitCountsToZero();
			nodeToExcludeWithChildren.Collapse();
			nodeToExcludeWithChildren.HasBeenLoaded = false;

			if (!(nodeToExcludeWithChildren is IExcludableParentTreeNode))
			{
				return;
			}

			if (nodeToExcludeWithChildren is IFilterParentTreeNode)
			{
				_UndoAllFilters((IFilterParentTreeNode)nodeToExcludeWithChildren);
			}

			for	(int nodeIndex = nodeToExcludeWithChildren.Nodes.Count - 1; nodeIndex >= 0; nodeIndex--)
			{
				TreeNodeBase childNode = (TreeNodeBase)nodeToExcludeWithChildren.Nodes[nodeIndex];
				if (!childNode.IsExcluded)
				{
					_ExcludeNodeWithChildrenRecursively(childNode);
				}
			}

			_MoveChildrenOutOfExcludedBin(nodeToExcludeWithChildren);
		}

		/// <summary>
		/// Invoked when we know the parent node contains nothing but excluded nodes - since the parent will be going
		/// in an exclusions bin lets move any nodes in this bin back under the normal node parent and remove
		/// the exclusions bin so they dont appear nested.
		/// </summary>
		/// <param name="parentNode">The parent node.</param>
		private static void _MoveChildrenOutOfExcludedBin(TreeNodeBase parentNode)
		{
			IExcludableParentTreeNode excludableParent = (IExcludableParentTreeNode)parentNode;
			TreeNodeBase existingExcludedNode = null;
			if (excludableParent.HasExcludedNode)
			{
				existingExcludedNode = excludableParent.ExcludedNode;
				for	(int nodeIndex = existingExcludedNode.Nodes.Count -1; nodeIndex >= 0; nodeIndex--)
				{
					TreeNodeBase childNode = (TreeNodeBase)existingExcludedNode.Nodes[nodeIndex];
					childNode.Remove();
					parentNode.Nodes.Add(childNode);
				}
				excludableParent.ExcludedNode = null;
				existingExcludedNode.Remove();
			}
		}

		/// <summary>
		/// Recursing up the tree identify which parent nodes now have no non-excluded code. If they have some non-excluded
		/// code we can just add to that parent's exclusion bin. If they do not, then remove any exclusion bin it may already
		/// have and recurse further up the tree.
		/// </summary>
		/// <param name="excludedChildNode">The excluded child node.</param>
		/// <returns></returns>
		private TreeNodeBase _MoveAllExcludedChildrenIntoParentExclusionBin(TreeNodeBase excludedChildNode)
		{
			TreeNodeBase parentTreeNode = (TreeNodeBase)excludedChildNode.Parent;
			if (parentTreeNode.TotalSequencePoints > 0 || parentTreeNode.Parent == null)
			{
				// We have a mixture of excluded and non excluded children.
				TreeNodeBase newSelectedNode = _GetNextNodeToSelect(excludedChildNode);
				excludedChildNode.Collapse();
				excludedChildNode.Remove();
				((IExcludableParentTreeNode)parentTreeNode).ExcludedNode.Nodes.Add(excludedChildNode);
				// Ensure this node is updated to reflect it's new state of excluded.
				excludedChildNode.InitialiseForFirstDisplay();
				return newSelectedNode;
			}
			else
			{
				// This parent node only has excluded children - so lets recurse upwards
				_MoveChildrenOutOfExcludedBin(parentTreeNode);
				// Ensure the child nodes will be forced to have their text and images updated when node is expanded.
				parentTreeNode.HasBeenLoaded = false;
				parentTreeNode.IsExcluded = true;
				return _MoveAllExcludedChildrenIntoParentExclusionBin(parentTreeNode);
			}
		}
	
		/// <summary>
		/// Based on the available siblings, determine what node would be the next selected after this is removed.
		/// </summary>
		/// <param name="childNodeToBeRemoved">The child node to be removed.</param>
		/// <returns>Next sibling node to be selected, parent if no siblings.</returns>
		private static TreeNodeBase _GetNextNodeToSelect(TreeNodeBase childNodeToBeRemoved)
		{
			TreeNodeBase newSelectedNode;
			if (childNodeToBeRemoved.NextNode == null)
			{
				if (childNodeToBeRemoved.PrevNode != null)
				{
					newSelectedNode = (TreeNodeBase)childNodeToBeRemoved.PrevNode;
				}
				else
				{
					newSelectedNode = (TreeNodeBase)childNodeToBeRemoved.Parent;
				}
			}
			else
			{
				newSelectedNode = (TreeNodeBase)childNodeToBeRemoved.NextNode;
			}
			return newSelectedNode;
		}

		#endregion Moving Nodes Into Exclusion Bin

		#region Refresh
		
		/// <summary>
		/// Recurses through all nodes that have been loaded previously and updates their display descriptions.
		/// </summary>
		/// <param name="nodeToRefresh">The node to refresh.</param>
		private void _RefreshLoadedNodeWithChildren(TreeNodeBase nodeToRefresh)
		{
			nodeToRefresh.InitialiseForFirstDisplay();
			if (nodeToRefresh.HasBeenLoaded)
			{
				foreach (TreeNodeBase childNode in nodeToRefresh.Nodes)
				{
					_RefreshLoadedNodeWithChildren(childNode);
				}
			}
		}

		#endregion Refresh

		#region Filters

		private void _ApplyFiltersToChildren(IFilterParentTreeNode filterParentTreeNode, TreeFilterStyle treeFilterStyle)
		{
			TreeNodeBase parentTreeNode = (TreeNodeBase)filterParentTreeNode;
			for (int index = parentTreeNode.Nodes.Count - 1; index >= 0; index--)
			{
				TreeNodeBase childNode = (TreeNodeBase)parentTreeNode.Nodes[index];
				if (!childNode.IsExcluded && !childNode.IsFiltered)
				{
					if ((treeFilterStyle == TreeFilterStyle.HideUnvisited) && (childNode.VisitCount == 0))
					{
						_MoveNodeToFilterParent(filterParentTreeNode, childNode);
					}
					else if ((treeFilterStyle == TreeFilterStyle.HideFullyCovered) && (childNode.UnvisitedSequencePoints == 0))
					{
						_MoveNodeToFilterParent(filterParentTreeNode, childNode);
					}
					else if (childNode is IFilterParentTreeNode)
					{
						_ApplyFiltersToChildren((IFilterParentTreeNode)childNode, treeFilterStyle);
					}
				}
			}
			if (filterParentTreeNode.HasFilteredNode)
			{
				if (parentTreeNode.IsExpanded)
				{
					parentTreeNode.Collapse();
				}
				parentTreeNode.HasBeenLoaded = false;
				filterParentTreeNode.FilteredNode.Collapse();
				filterParentTreeNode.FilteredNode.HasBeenLoaded = false;
			}
		}

		private void _MoveNodeToFilterParent(IFilterParentTreeNode filterParentTreeNode, TreeNodeBase nodeToMove)
		{
			nodeToMove.SetFilteredStatusRecursively(true);
			nodeToMove.Collapse();
			nodeToMove.HasBeenLoaded = false;
			nodeToMove.Remove();
			filterParentTreeNode.FilteredNode.Nodes.Add(nodeToMove);
		}

		private void _UndoAllFilters(IFilterParentTreeNode filterParentTreeNode)
		{
			TreeNodeBase parentTreeNode = (TreeNodeBase)filterParentTreeNode;
			foreach (TreeNodeBase childNode in parentTreeNode.Nodes)
			{
				if (!childNode.IsExcluded && childNode is IFilterParentTreeNode)
				{
					_UndoAllFilters((IFilterParentTreeNode)childNode);
				}
			}
			if (filterParentTreeNode.HasFilteredNode)
			{
				for (int index = filterParentTreeNode.FilteredNode.Nodes.Count - 1; index >= 0; index--)
				{
					TreeNodeBase nodeToUndoFilterOn = (TreeNodeBase)filterParentTreeNode.FilteredNode.Nodes[index];
					nodeToUndoFilterOn.SetFilteredStatusRecursively(false);
					nodeToUndoFilterOn.Remove();
					nodeToUndoFilterOn.Collapse();
					nodeToUndoFilterOn.HasBeenLoaded = false;
					nodeToUndoFilterOn.InitialiseForFirstDisplay();
					parentTreeNode.Nodes.Add(nodeToUndoFilterOn);
				}
				filterParentTreeNode.FilteredNode.Remove();
				filterParentTreeNode.FilteredNode = null;
			}
		}

		#endregion Filters

		#endregion Private Methods
	}
	
	#region Delegates

	/// <summary>
	/// Delegate for the BeforeSort & AfterSort event.
	/// </summary>
	public delegate void SortEventHandler(object sender, SortEventArgs e);

	#endregion Delegates

	#region SortEventArgs Class

	/// <summary>
	/// EventArgs passed with the AfterSort event.
	/// </summary>
	public class SortEventArgs : EventArgs
	{
		private Decimal _elapsedTime;
		private TreeNodeBase _selectedNode;

		/// <summary>
		/// Initializes a new instance of the <see cref="SortEventArgs"/> class.
		/// </summary>
		public SortEventArgs(TreeNodeBase selectedNode)
			: this(selectedNode,  0)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="SortEventArgs"/> class.
		/// </summary>
		public SortEventArgs(TreeNodeBase selectedNode, Decimal elapsedTime)
		{
			_selectedNode = selectedNode;
			_elapsedTime = elapsedTime;
		}

		/// <summary>
		/// Gets the selected node.
		/// </summary>
		/// <value>The selected node.</value>
		public TreeNodeBase SelectedNode
		{
			get { return _selectedNode; }
		}

		/// <summary>
		/// Gets the elapsed sort time in milliseconds.
		/// </summary>
		/// <value>The elapsed sort time in milliseconds.</value>
		public Decimal ElapsedTime
		{
			get { return _elapsedTime; }
		}
	}

	#endregion SortEventArgs Class
}
