using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// This node is the base class in the coverage tree for nodes that have special children like
	/// exclusion bins and filter parent nodes.
	/// </summary>
	public abstract class SpecialParentTreeNodeBase : TreeNodeBase, IExcludableParentTreeNode, IFilterParentTreeNode
	{
		#region Private Variables

		private ExcludedTreeNode _excludedTreeNode;
		private FilteredTreeNode _filteredTreeNode;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SpecialParentTreeNodeBase"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="nodeName">Name of the node.</param>
		protected SpecialParentTreeNodeBase(IExplorerConfiguration configuration, string nodeName)
			: base(configuration, nodeName)
		{
			_excludedTreeNode = null;
			_filteredTreeNode = null;
		}

		#endregion Constructor
		
		#region IExcludableParentTreeNode Members
		
		/// <summary>
		/// Gets or sets the excluded node containing items excluded for this class, namespace, module or coverage file.
		/// </summary>
		/// <value>The excluded node.</value>
		public ExcludedTreeNode ExcludedNode
		{
			get 
			{
				if (_excludedTreeNode == null)
				{
					_excludedTreeNode = new ExcludedTreeNode(Configuration);
					Nodes.Add(_excludedTreeNode);
					if (HasBeenLoaded)
					{
						_excludedTreeNode.InitialiseForFirstDisplay();
					}
				}
				return _excludedTreeNode; 
			}
			set { _excludedTreeNode = value; }
		}

		/// <summary>
		/// Gets or whether this tree node has an excluded node with children.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has an excluded node; otherwise, <c>false</c>.
		/// </value>
		public bool HasExcludedNode
		{
			get { return _excludedTreeNode != null; }
		}

		#endregion IExcludableParentTreeNode Members

		#region IFilterParentTreeNode Members
		
		/// <summary>
		/// Gets or sets the filter node containing items filtered for this class, namespace, module or coverage file.
		/// </summary>
		/// <value>The filtered node.</value>
		public FilteredTreeNode FilteredNode
		{
			get 
			{
				if (_filteredTreeNode == null)
				{
					_filteredTreeNode = new FilteredTreeNode(Configuration);
					Nodes.Add(_filteredTreeNode);
				}
				return _filteredTreeNode; 
			}
			set { _filteredTreeNode = value; }
		}

		/// <summary>
		/// Gets or whether this tree node has a filter node with children.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has a filter node; otherwise, <c>false</c>.
		/// </value>
		public bool HasFilteredNode
		{
			get { return _filteredTreeNode != null; }
		}

		#endregion IFilterParentTreeNode Members
	}
}
