
namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// Interface for all nodes that are able to have filtered children.
	/// </summary>
	public interface IFilterParentTreeNode
	{
		/// <summary>
		/// Gets or sets the filter node containing items filtered for this class, namespace, module or coverage file.
		/// </summary>
		/// <value>The filtered node.</value>
		FilteredTreeNode FilteredNode { get; set; }
		/// <summary>
		/// Gets or whether this tree node has a filter node with children.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has a filter node; otherwise, <c>false</c>.
		/// </value>
		bool HasFilteredNode { get; }
	}
}
