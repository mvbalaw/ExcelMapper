using System.Xml;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// Contains the details of a seqpnt node from parsing the NCover coverage output file.
	/// </summary>
	public class SequencePoint
	{
		#region Private Variables

		/// <summary>
		/// Spurious line generated in the code coverage that should be ignored.
		/// </summary>
		private const int NodeLineToIgnore = 16707566;

		private readonly string _methodName;
		private long _visitCount;
		private readonly int _startLine;
		private readonly int _startColumn;
		private readonly int _endLine;
		private readonly int _endColumn;
		private string _fileName;
		private bool _isExcluded;
		private bool _isFiltered;
		private readonly bool _hasExcludedAttribute;
		private bool _isFirstLineInMethod;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SequencePoint"/> class based on an xml seqpnt node.
		/// </summary>
		/// <param name="methodName">Name of the method.</param>
		/// <param name="reader">The &lt;seqpnt&gt; element in a reader.</param>
		public SequencePoint(string methodName, XmlTextReader reader)
		{
			_methodName = methodName;
			_visitCount = long.Parse(reader.GetAttribute("visitcount"));
			_startLine = int.Parse(reader.GetAttribute("line"));
			_startColumn = int.Parse(reader.GetAttribute("column"));
			_endLine = int.Parse(reader.GetAttribute("endline"));
			_endColumn = int.Parse(reader.GetAttribute("endcolumn"));

			_hasExcludedAttribute = false;
			string isExcludedText = reader.GetAttribute("excluded"); // Only present in NCover 1.5.4 onwards
			if (isExcludedText != null)
			{
				_hasExcludedAttribute = true; // For use when using Save functionality.
				_isExcluded = (isExcludedText == "true");
			}
			_isFiltered = false;

			_fileName = reader.GetAttribute("document");
			_isFirstLineInMethod = false;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="SequencePoint"/> class purely for unit testing purposes.
		/// </summary>
		/// <param name="methodName">Name of the method.</param>
		public SequencePoint(string methodName, long visitCount, int startLine, int startColumn, int endLine, int endColumn, string fileName)
		{
			_methodName = methodName;
			_visitCount = visitCount;
			_startLine = startLine;
			_startColumn = startColumn;
			_endLine = endLine;
			_endColumn = endColumn;
			_hasExcludedAttribute = false;
			_fileName = fileName;
			_isFirstLineInMethod = false;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the method name for the sequence point.
		/// </summary>
		/// <value>The method name for the sequence point.</value>
		public string MethodName
		{
			get { return _methodName; }
		}

		/// <summary>
		/// Gets the visit count for the sequence point.
		/// </summary>
		/// <value>The visit count for the sequence point.</value>
		public long VisitCount
		{
			get { return _visitCount; }
		}

		/// <summary>
		/// Gets the start line for the sequence point.
		/// </summary>
		/// <value>The start line for the sequence point.</value>
		public int StartLine
		{
			get { return _startLine; }
		}
		
		/// <summary>
		/// Gets the start column for the sequence point.
		/// </summary>
		/// <value>The start column for the sequence point.</value>
		public int StartColumn
		{
			get { return _startColumn; }
		}
		
		/// <summary>
		/// Gets the end line for the sequence point.
		/// </summary>
		/// <value>The end line for the sequence point.</value>
		public int EndLine
		{
			get { return _endLine; }
		}
		
		/// <summary>
		/// Gets the end column for the sequence point.
		/// </summary>
		/// <value>The end column for the sequence point.</value>
		public int EndColumn
		{
			get { return _endColumn; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether this seqpnt is excluded.
		/// May be manually excluded or as defined in coverage.xml file by NCover.
		/// </summary>
		/// <value><c>true</c> if this node is to be excluded; otherwise, <c>false</c>.</value>
		public bool IsExcluded
		{
			get { return _isExcluded; }
			set { _isExcluded = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether this seqpnt is filtered out by a UI action.
		/// </summary>
		/// <value><c>true</c> if this node is to be filtered; otherwise, <c>false</c>.</value>
		public bool IsFiltered
		{
			get { return _isFiltered; }
			set { _isFiltered = value; }
		}

		/// <summary>
		/// Gets a value indicating whether this seqpnt has an "excluded" attribute assigned to it
		/// (as per NCover v1.5.4 and higher). For use by the CoverageFileWriter when saving to ensure
		/// output is consistent with input.
		/// </summary>
		/// <value><c>true</c> if this has an excluded attribute; otherwise, <c>false</c>.</value>
		public bool HasExcludedAttribute
		{
			get { return _hasExcludedAttribute; }
		}
		
		/// <summary>
		/// Gets or sets the file name for the source code for this line.
		/// </summary>
		/// <value>The file name.</value>
		public string FileName
		{
			get { return _fileName; }
			set { _fileName = value; }
		}

		/// <summary>
		/// Gets a value indicating whether this sequence point is garbage (NCover inserts some rows with
		/// line number 16707566 that should be excluded). NCoverExplorer will throw away such rows when
		/// parsing the file (by using this property).
		/// </summary>
		/// <value><c>true</c> if this is a garbage row; otherwise, <c>false</c>.</value>
		public bool IsGarbageRow
		{
			get { return _startLine == NodeLineToIgnore; }
		}

		/// <summary>
		/// Gets a value indicating whether this sequence point is on the first source code line in the parent method.
		/// Note that multiple sequence points could be on the same "first line" potentially! 
		/// Used by the GUI to help with "intelligent scrolling" - trying to make sure the header for the method is
		/// visible in the source code window.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this sequence point is on first line in method; otherwise, <c>false</c>.
		/// </value>
		public bool IsOnFirstLineInMethod
		{
			get { return _isFirstLineInMethod; }
			set { _isFirstLineInMethod = value; }
		}

		#endregion Public Properties

        #region Public Methods

        /// <summary>
        /// Merge the VisitCount of two SequencePoints.
        /// </summary>
        /// <param name="sequencePoint">The SequencePoint to merge.</param>
        public void Merge(SequencePoint sequencePoint)
        {
            _visitCount += sequencePoint._visitCount;
		}

        #endregion Public Methods
    }
}
