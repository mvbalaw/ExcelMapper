using System;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// A node in the display treeview control that represents a method or a property and the sequence points 
	/// of coverage it contains.
	/// </summary>
	public class MethodTreeNode : TreeNodeBase
	{
		#region Private Variables / Constants

		private string _fileName;
		private string _classNamespace;
		private SequencePointCollection _sequencePoints;
		private bool _isNestedProperty;
		private bool _isParentProperty;

		#endregion Private Variables / Constants

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MethodTreeNode"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="methodName">The method name.</param>
		/// <param name="classNamespace">The class namespace.</param>
		public MethodTreeNode(IExplorerConfiguration configuration, string methodName, string classNamespace) 
			: base(configuration, methodName)
		{
			_fileName = null;
			_isNestedProperty = false;
			_isParentProperty = false;
			_sequencePoints = null;
			_classNamespace = classNamespace;
			this.FullyQualifiedName = classNamespace + "." + methodName;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the file name of the first sequence point of this method.
		/// </summary>
		/// <value>The file info for this method.</value>
		public string FileName
		{
			get 
			{
				if (_fileName == null)
				{
					_fileName = _sequencePoints[0].FileName;
				}
				return _fileName; 
			}
			set
			{
				_fileName = value;
				foreach (SequencePoint sequencePoint in _sequencePoints)
				{
					sequencePoint.FileName = value;	
				}
			}
		}

		/// <summary>
		/// Gets the class namespace for this method.
		/// </summary>
		/// <value>The class namespace for this method.</value>
		public string ClassNamespace
		{
			get { return _classNamespace; }
		}

		/// <summary>
		/// Gets the collection of sequence points associated with this method.
		/// </summary>
		/// <value>The sequence points associated with this method.</value>
		public SequencePointCollection SequencePoints
		{
			get 
			{
				if (_sequencePoints == null)
				{
					// We want the merge of the child sequence points if any - done on demand on first request.
					if (_isParentProperty)
					{
						_sequencePoints = new SequencePointCollection();
						foreach (MethodTreeNode methodTreeNode in Nodes)
						{
							foreach (SequencePoint sequencePoint in methodTreeNode.SequencePoints)
							{
								_sequencePoints.Add(sequencePoint);
							}
						}
					}
					else
					{
						_sequencePoints = new SequencePointCollection();
					}
				}
				return _sequencePoints; 
			}
		}

		/// <summary>
		/// Gets whether this method is a parent property when nesting is turned on.
		/// </summary>
		/// <value><c>true</c> if this instance is a parent property; otherwise, <c>false</c>.</value>
		public bool IsParentProperty
		{
			get { return _isParentProperty; }
			set { _isParentProperty = value; }
		}

		/// <summary>
		/// Gets whether this method is a nested child property when nesting is turned on.
		/// </summary>
		/// <value><c>true</c> if this instance is a nested child property; otherwise, <c>false</c>.</value>
		public bool IsNestedProperty
		{
			get { return _isNestedProperty; }
			set { _isNestedProperty = value; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Sets the appropriate icon and node text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost.
		/// </summary>
		public override void InitialiseForFirstDisplay()
		{
			// Set the node text and colour.
			base.InitialiseForFirstDisplay();

			this.ImageIndex = AppearanceHelper.GetImageIndexForMethod(this);
			this.SelectedImageIndex = this.ImageIndex;

			if (NodeName[0] == '.')
			{
				// This is a constructor - ensure we don't have ".." in the path displayed.
				this.FullyQualifiedName = FullyQualifiedName.Replace("..",".");
			}
		}

		/// <summary>
		/// Calculates the percent code coverage for this node and it's children.
		/// </summary>
		public override void ApplyExclusionsAndCalculateCoverage(ICoverageExclusionManager coverageExclusionManager)
		{
			if (_isParentProperty)
			{
				base.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);
				_SetFirstCodeLineNumberForParentProperty();
			}
			else
			{
				// No children so no need to try applying exclusions or recalculating child coverage.
				this.CalculateNodeCoverageStatistics();
			}
			this.VisitCount = SequencePoints.GetMethodVisitCount();
		}

		/// <summary>
		/// Populates the sequence points collection for this node.
		/// </summary>
		/// <param name="sequencePoints">The sequence points read from the file.</param>
		public void PopulateSequencePoints(SequencePointCollection sequencePoints)
		{
            int visitedSequencePointsCount = 0;

			for (int index = 0; index < sequencePoints.Count; index++)
			{
				SequencePoint sequencePoint = _CachingAddSequencePoint(sequencePoints[index], index);
				if (sequencePoint.VisitCount > 0)
				{
					visitedSequencePointsCount++;
				}
			}

			this.FirstCodeLineNumber = sequencePoints.FirstLineNumber;
			this.TotalSequencePoints = SequencePoints.CountNonExcluded;
            this.VisitedSequencePoints = visitedSequencePointsCount;
		}

		/// <summary>
		/// Merges the child sequence points into this parent property node and adjusts totals.
		/// </summary>
		public void MergeChildSequencePoints()
		{
			MethodTreeNode methodTreeNode;

			long visitCount = 0;
			int firstLineNumber = int.MaxValue;

			this.TotalSequencePoints = 0;
			this.VisitedSequencePoints = 0;
			_sequencePoints.Clear();

			for	(int index = this.Nodes.Count - 1; index >= 0; index--)
			{
				methodTreeNode = (MethodTreeNode)this.Nodes[index];
				visitCount = Math.Max(_sequencePoints.GetMethodVisitCount(), visitCount);
				if (methodTreeNode._sequencePoints.Count > 0)
				{
					SequencePoint firstSequencePoint = methodTreeNode._sequencePoints[0];
					firstLineNumber = Math.Min(firstLineNumber, firstSequencePoint.StartLine);
				}

				foreach (SequencePoint sequencePoint in methodTreeNode._sequencePoints)
				{
					_sequencePoints.Add(sequencePoint);
				}

				this.FirstCodeLineNumber = firstLineNumber;
				this.TotalSequencePoints += _sequencePoints.CountNonExcluded;
				this.VisitedSequencePoints += methodTreeNode.VisitedSequencePoints;
			}
			this.VisitCount = visitCount;
		}

		/// <summary>
		/// Override the max visit count to instead just return the value we have already calculated for this method.
		/// </summary>
		/// <returns>VisitCount</returns>
		public override long GetMaxVisitCount()
		{
			return this.VisitCount;
		}
		
		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public override bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager)
		{
			return SequencePoints.CountNonExcluded == 0;
		}

		/// <summary>
		/// Sets the visit counts to zero both for this node and any child property get_ or set_ nodes.
		/// </summary>
		public override void SetVisitCountsToZero()
		{
			base.SetVisitCountsToZero();

			if (_isParentProperty)
			{
				foreach (TreeNodeBase childNode in this.Nodes)
				{
					childNode.SetVisitCountsToZero();
				}
			}
			foreach (SequencePoint sequencePoint in SequencePoints)
			{
				sequencePoint.IsExcluded = true;
			}
		}

		/// <summary>
		/// Marks nodes as included recursively and recalculates the children coverage.
		/// </summary>
		public override void IncludeNodesRecursively()
		{
			_sequencePoints.CountNonExcluded = _sequencePoints.Count;
			foreach (SequencePoint sequencePoint in _sequencePoints)
			{
				sequencePoint.IsExcluded = false;
				if (!_isParentProperty && sequencePoint.VisitCount > 0)
				{
					VisitedSequencePoints++;
				}
			}
			if (!_isParentProperty)
			{
				this.TotalSequencePoints = _sequencePoints.Count;
			}
			else
			{
				_SetFirstCodeLineNumberForParentProperty();
			}
			this.VisitCount = SequencePoints.GetMethodVisitCount();
			base.IncludeNodesRecursively();
		}

		#endregion Public Methods

		#region Private Methods

		/// <summary>
		/// Reuse SequencePoint if already in cache. Merges together the visit counts. Necessary since NCover in the
		/// 1.5.x versions at least replicates coverage information for multiple AppDomains in the coverage file.
		/// </summary>
		/// <param name="sequencePoint">The sequence point.</param>
		/// <param name="seqpntIndex">Index of the seqpnt.</param>
		/// <returns>Merged into cache or newly added sequence point.</returns>
		private SequencePoint _CachingAddSequencePoint(SequencePoint sequencePoint, int seqpntIndex)
		{
			if (SequencePoints.Count > seqpntIndex)
			{
				SequencePoint cachedSequencePoint = _sequencePoints[seqpntIndex];
				cachedSequencePoint.Merge(sequencePoint);
				return cachedSequencePoint;
			}

			_sequencePoints.Add(sequencePoint);
			return sequencePoint;
		}

		/// <summary>
		/// Set the first line of code base on the minimum value from the get_ and set_ child nodes.
		/// </summary>
		private void _SetFirstCodeLineNumberForParentProperty()
		{
			int firstCodeLineNumber = int.MaxValue;
			foreach (MethodTreeNode childGetOrSetTreeNode in Nodes)
			{
				firstCodeLineNumber = Math.Min(childGetOrSetTreeNode.FirstCodeLineNumber, firstCodeLineNumber);
			}
			this.FirstCodeLineNumber = firstCodeLineNumber;
		}

		#endregion Private Methods
	}
}
