using System.Collections;
using System.IO;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// The root node in the treeview display representing the coverage file(s) loaded and merged.
	/// </summary>
	public class CoverageFileTreeNode : SpecialParentTreeNodeBase
	{
		#region Private Variables

		private string[] _coverageFileNames;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageFileTreeNode"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="coverageFileName">Name of the coverage file.</param>
		public CoverageFileTreeNode(IExplorerConfiguration configuration, string coverageFileName) 
			: base(configuration, Path.GetFileName(coverageFileName))
		{
			this.FullyQualifiedName = coverageFileName;	// So will display in status bar
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the name of the coverage files parsed by this model.
		/// </summary>
		/// <value>The names of the coverage files.</value>
		public string[] CoverageFileNames
		{
			get { return _coverageFileNames; }
			set { _coverageFileNames = value; }
		}

		/// <summary>
		/// Gets the tool tip text if any for this node.
		/// </summary>
		/// <value>The tool tip text.</value>
		public override string ToolTipText
		{
			get
			{
				string text = string.Empty;
				if (_coverageFileNames != null && _coverageFileNames.Length > 0)
				{
					text = _coverageFileNames[0];
					for (int index = 1; index < _coverageFileNames.Length; index++)
					{
						text += "\n" + _coverageFileNames[index];
					}
				}
				return text;
			}
		}


		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public override bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager)
		{
			return false; // Should never exclude the parent file.
		}

		/// <summary>
		/// Sets the appropriate icon and node text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost.
		/// </summary>
		public override void InitialiseForFirstDisplay()
		{
			NodeName = Path.GetFileName(_coverageFileNames[0]);
			this.FullyQualifiedName = _coverageFileNames[0];
			if (_coverageFileNames.Length > 1)
			{
				NodeName += AppearanceHelper.MergedSuffix;
				FullyQualifiedName += AppearanceHelper.MergedSuffix;
			}
			// Set the node text and colour.
			base.InitialiseForFirstDisplay();

			this.ImageIndex = AppearanceHelper.GetImageIndexForCoverageFile();
			this.SelectedImageIndex = this.ImageIndex;
		}

		/// <summary>
		/// Override the max visit count as not relevant on this node.
		/// </summary>
		/// <returns>VisitCount</returns>
		public override long GetMaxVisitCount()
		{
			return 0;
		}

		/// <summary>
		/// Merges the coverage file names into the existing names making a combined unique list..
		/// </summary>
		/// <param name="fileName">The filename.</param>
		public void AddFileName(string fileName)
		{
			ArrayList combinedNames = new ArrayList(_coverageFileNames.Length + 1);
			foreach (string existingFileName in _coverageFileNames)
			{
				combinedNames.Add(existingFileName);
			}
			combinedNames.Add(fileName);

			_coverageFileNames =(string[])combinedNames.ToArray(typeof(string));
		}

		/// <summary>
		/// Determines whether this coverage tree already has the specified file loaded in it.
		/// </summary>
		/// <param name="fileName">Name of the file.</param>
		/// <returns><c>true</c> if file is already loaded; otherwise, <c>false</c>.</returns>
		public bool HasFileLoaded(string fileName)
		{
			bool isFound = false;
			foreach (string existingFileName in _coverageFileNames)
			{
				if (existingFileName == fileName)
				{
					// Already have it in the list.
					isFound = true;
					break;
				}
			}
			return isFound;
		}

		#endregion Public Methods
	}
}
