using System;
using System.Windows.Forms;

using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// Applies custom sorting to the TreeView control.
	/// </summary>
	public sealed class TreeViewSorter
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="TreeViewSorter"/> class.
		/// </summary>
		private TreeViewSorter()
		{
		}

		#endregion Constructor

		#region Public Static Methods

		/// <summary>
		/// Sorts the tree view recursively.
		/// </summary>
		/// <param name="treeView">The tree view.</param>
		public static void SortTreeView(TreeView treeView) 
		{
			_RecurseTree(treeView.Nodes);
			_QuickSort(treeView.Nodes, 0, treeView.Nodes.Count - 1);
		}

		/// <summary>
		/// Sorts the immediate children of a particular node in a tree.
		/// </summary>
		/// <param name="parentTreeNode">The parent tree node.</param>
		public static void SortTreeNodeChildren(TreeNode parentTreeNode) 
		{
			_QuickSort(parentTreeNode.Nodes, 0, parentTreeNode.Nodes.Count - 1);
		}

		/// <summary>
		/// Sorts all the children recursively of a particular node in a tree.
		/// </summary>
		/// <param name="parentTreeNode">The parent tree node.</param>
		public static void SortTreeNodeRecursive(TreeNode parentTreeNode) 
		{
			_RecurseTree(parentTreeNode.Nodes);
			_QuickSort(parentTreeNode.Nodes, 0, parentTreeNode.Nodes.Count - 1);
		}

		#endregion Public Static Methods

		#region Private Static Methods

		/// <summary>
		/// Recurses the tree sorting as we go.
		/// </summary>
		/// <param name="nodes">The nodes.</param>
		private static void _RecurseTree(TreeNodeCollection nodes) 
		{
			if (nodes == null) 
			{
				return;
			}
			foreach (TreeNodeBase child in nodes) 
			{
				if (child.Nodes.Count > 0)
				{
					_RecurseTree(child.Nodes);
					_QuickSort(child.Nodes, 0, child.Nodes.Count - 1);
				}
			}
		}

		/// <summary>
		/// QuickSort implementation.
		/// </summary>
		/// <param name="treeNodes">The tree nodes.</param>
		/// <param name="lowerBound">The lower bound.</param>
		/// <param name="upperBound">The upper bound.</param>
		private static void _QuickSort(TreeNodeCollection treeNodes, int lowerBound, int upperBound)
		{
			// Check for non-base case
			if (lowerBound < upperBound)
			{
				// Split and sort partitions
				int splitIndex = Partition (treeNodes, lowerBound, upperBound);
				_QuickSort(treeNodes, lowerBound, splitIndex - 1);
				_QuickSort(treeNodes, splitIndex + 1, upperBound);
			}
		}

		/// <summary>
		/// QuickSort partition implementation.
		/// </summary>
		/// <param name="treeNodes">The tree nodes.</param>
		/// <param name="lowerBound">The lower bound.</param>
		/// <param name="upperBound">The upper bound.</param>
		/// <returns></returns>
		private static int Partition(TreeNodeCollection treeNodes, int lowerBound, int upperBound)
		{
			// Pivot with first element
			int leftIndex = lowerBound + 1;
			TreeNode pivotTreeNode = treeNodes[lowerBound];
			int rightIndex = upperBound;
			// Partition array elements
			while (leftIndex <= rightIndex)
			{
				// Find item out of place
				while (leftIndex <= rightIndex && ((IComparable)treeNodes[leftIndex]).CompareTo(pivotTreeNode) <= 0)
				{
					leftIndex = leftIndex + 1;
				}
				while (leftIndex <= rightIndex && ((IComparable)treeNodes[rightIndex]).CompareTo(pivotTreeNode) > 0)
				{
					rightIndex = rightIndex - 1;
				}
				// Swap values if necessary
				if (leftIndex < rightIndex)
				{
					_Swap(treeNodes, leftIndex, rightIndex);
					leftIndex = leftIndex + 1;
					rightIndex = rightIndex - 1;
				}
			}
			// Move pivot element
			_Swap(treeNodes, lowerBound, rightIndex);
			return rightIndex;
		}

		/// <summary>
		/// Swaps two nodes ain the tree.
		/// </summary>
		/// <param name="treeNodes">The tree nodes.</param>
		/// <param name="leftIndex">Index of the left node.</param>
		/// <param name="rightIndex">Index of the right node.</param>
		private static void _Swap(TreeNodeCollection treeNodes, int leftIndex, int rightIndex)
		{
			if (leftIndex != rightIndex)
			{
				TreeNode leftTreeNode = treeNodes[leftIndex];
				TreeNode rightTreeNode = treeNodes[rightIndex];
				treeNodes.RemoveAt(leftIndex);
				treeNodes.RemoveAt(rightIndex - 1);
				treeNodes.Insert(leftIndex, rightTreeNode);
				treeNodes.Insert(rightIndex, leftTreeNode);
			}
		}

		#endregion Private Static Methods
	}
}
