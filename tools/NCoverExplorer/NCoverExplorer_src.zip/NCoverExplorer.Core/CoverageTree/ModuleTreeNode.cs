using System.IO;
using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// A node in the treeview display representing a module that has child namespace nodes or class nodes with code coverage.
	/// </summary>
	public class ModuleTreeNode : SpecialParentTreeNodeBase
	{
		#region Private Variables

		private string _assemblyName;
		private string _moduleName;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleTreeNode"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="moduleName">Full path name of the module.</param>
		/// <param name="assemblyName">Name of the assembly.</param>
		public ModuleTreeNode(IExplorerConfiguration configuration, string moduleName, string assemblyName) 
			: base(configuration, assemblyName)
		{
			_assemblyName = assemblyName;
			_moduleName = moduleName;
			this.FullyQualifiedName = moduleName;	// What we will display in status bar
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the name of the assembly this module is located in.
		/// </summary>
		/// <value>The name of the assembly this module is located in.</value>
		public string AssemblyName
		{
			get { return _assemblyName; }
			set { _assemblyName = value; }
		}

		/// <summary>
		/// Gets the name of the assembly this module is located in including it's extension such as .dll including path.
		/// </summary>
		/// <value>The name of the assembly this module is located in including path.</value>
		public string AssemblyPathWithExtension
		{
			get { return _assemblyName + System.IO.Path.GetExtension(_moduleName); }
		}

		/// <summary>
		/// Gets the filename of the assembly this module is located in including it's extension such as .dll.
		/// </summary>
		/// <value>The filename of the assembly this module is located in.</value>
		public string AssemblyNameWithExtension
		{
			get { return Path.GetFileName(_assemblyName) + System.IO.Path.GetExtension(_moduleName); }
		}

		/// <summary>
		/// Gets the full module name as reported in the NCover xml file.
		/// </summary>
		/// <value>The full module name as reported in the NCover xml file.</value>
		public string ModuleName
		{
			get { return _moduleName; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Sets the appropriate icon and node text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost.
		/// </summary>
		public override void InitialiseForFirstDisplay()
		{
			// Set the node text and colour.
			base.InitialiseForFirstDisplay();

			this.ImageIndex = AppearanceHelper.GetImageIndexForModule(this);
			this.SelectedImageIndex = this.ImageIndex;
		}

		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public override bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager)
		{
			return coverageExclusionManager.IsAssemblyExclusionApplicable(this);
		}

		#endregion Public Methods
	}
}
