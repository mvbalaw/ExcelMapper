using System.Collections;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// A node in the treeview display representing a Class that has methods with code coverage.
	/// </summary>
	public class ClassTreeNode : SpecialParentTreeNodeBase
	{
		#region Private Variables

		private int _classVisitCount;
		private Hashtable _propertyNodes;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ClassTreeNode"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="className">Name of the class.</param>
		/// <param name="classNamespace">The class namespace.</param>
		public ClassTreeNode(IExplorerConfiguration configuration, string className, string classNamespace) 
			: base(configuration, className)
		{
			this.FullyQualifiedName = classNamespace;
			_classVisitCount = 0;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ClassTreeNode"/> class. This constructor provided
		/// purely to ensure that the node when created is prefixed with a # for sorting purposes (nested classes).
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="className">Name of the class.</param>
		/// <param name="classNamespace">The class namespace.</param>
		/// <param name="isNested">if set to <c>true</c> is nested. Not actually checked but forces sorting</param>
		public ClassTreeNode(IExplorerConfiguration configuration, string className, string classNamespace, bool isNested) 
			: base(configuration, "#" + className)
		{
			this.NodeName = className;
			this.FullyQualifiedName = classNamespace;
			_classVisitCount = 0;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets the class visit count.
		/// </summary>
		/// <value>The class visit count.</value>
		public int ClassVisitCount
		{
			get { return _classVisitCount; }
		}

		/// <summary>
		/// Gets the property nodes within this class. For use when populating the coverage tree and turning
		/// get_ and set_ tree nodes into proper parents.
		/// </summary>
		/// <value>The property nodes.</value>
		public Hashtable PropertyNodes
		{
			get
			{
				if (_propertyNodes == null)
				{
					_propertyNodes = new Hashtable();
				}
				return _propertyNodes;
			}
		}

		#endregion Public Properties

		#region Public Methods
		
		/// <summary>
		/// Sets the appropriate icon and node text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost.
		/// </summary>
		public override void InitialiseForFirstDisplay()
		{
			_RenameNodeIfHasGenericBrackets();

			// Set the node text and colour.
			base.InitialiseForFirstDisplay();

			this.ImageIndex = AppearanceHelper.GetImageIndexForClass(this);
			this.SelectedImageIndex = this.ImageIndex;
		}

		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public override bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager)
		{
			return coverageExclusionManager.IsClassExclusionApplicable(this);
		}

		/// <summary>
		/// Finds the child method node containing this sequence point line.
		/// </summary>
		/// <param name="lineNumber">The line number to find.</param>
		/// <returns></returns>
		public MethodTreeNode FindNodeContainingSequencePointLine(int lineNumber)
		{
			MethodTreeNode matchingMethodTreeNode = null;
			System.Windows.Forms.TreeNode childNode;
			int startLine = 0;
			int endLine = 0;

			for	(int index = this.Nodes.Count - 1; index >= 0; index--)
			{
				childNode = this.Nodes[index];
				if (childNode is MethodTreeNode)
				{
					matchingMethodTreeNode = (MethodTreeNode)childNode;
					// Only bother checking the first and last sequence points to see if it contains the line.
					startLine = matchingMethodTreeNode.SequencePoints[0].StartLine;
					endLine = matchingMethodTreeNode.SequencePoints[matchingMethodTreeNode.SequencePoints.Count - 1].EndLine;
					if (startLine <= lineNumber && endLine >= lineNumber)
					{
						// Yahoo!
						return matchingMethodTreeNode;
					}
				}
			}
			return null;
		}

		#endregion Public Methods

		#region Private Methods

		/// <summary>
		/// Renames the node if if has generic angle brackets around it on first expansion.
		/// </summary>
		private void _RenameNodeIfHasGenericBrackets()
		{
			int genericIndex = NodeName.IndexOf('>');
			if (genericIndex >= 0)
			{
				NodeName = NodeName.Substring(0, genericIndex + 1);
			}
		}

		#endregion Private Methods
	}
}
