using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// A node in the treeview display representing a parent for all the exclusions for this class/namespace/module.
	/// Each "IExcludableParentTreeNode" derived class can have of these nodes as a child containing the excluded
	/// nodes within it.
	/// </summary>
	public class ExcludedTreeNode : TreeNodeBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ExcludedTreeNode"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		public ExcludedTreeNode(IExplorerConfiguration configuration) 
			: base(configuration, "zzzzzExcluded")
		{
			this.NodeName = "Excluded";
			this.FullyQualifiedName = "Excluded nodes";
			this.IsExcluded = true;
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Sets the appropriate icon and node text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost.
		/// </summary>
		public override void InitialiseForFirstDisplay()
		{
			// Set the node text and colour.
			base.InitialiseForFirstDisplay();

			this.ImageIndex = AppearanceHelper.GetImageIndexForExcluded();
			this.SelectedImageIndex = this.ImageIndex;
			IsExcluded = true;
		}

		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public override bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager)
		{
			return false;
		}

		#endregion Public Methods
	}
}
