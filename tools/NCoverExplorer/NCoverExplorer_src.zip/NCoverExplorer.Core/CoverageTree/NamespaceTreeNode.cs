using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// A node in the treeview display representing a Namespace that has child namespace nodes or class nodes with code coverage.
	/// </summary>
	public class NamespaceTreeNode : SpecialParentTreeNodeBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="NamespaceTreeNode"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="namespaceName">Name of the namespace.</param>
		/// <param name="fullyQualifiedNamespace">The fully qualified namespace.</param>
		public NamespaceTreeNode(IExplorerConfiguration configuration, string namespaceName, string fullyQualifiedNamespace) 
			: base(configuration, "!" + namespaceName)
		{
			this.NodeName = namespaceName;
			this.FullyQualifiedName = fullyQualifiedNamespace;
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Sets the appropriate icon and node text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost.
		/// </summary>
		public override void InitialiseForFirstDisplay()
		{
			// Set the node text and colour.
			base.InitialiseForFirstDisplay();

			this.ImageIndex = AppearanceHelper.GetImageIndexForNamespace(this);
			this.SelectedImageIndex = this.ImageIndex;
		}

		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public override bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager)
		{
			return coverageExclusionManager.IsNamespaceExclusionApplicable(this);
		}

		#endregion Public Methods
	}
}
