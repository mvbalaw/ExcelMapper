using System.Collections;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// Strongly typed collection of SequencePoint objects generated from the NCover xml coverage file.
	/// </summary>
	public class SequencePointCollection : CollectionBase
	{
		#region Private Variables

		private int _countNonExcluded = 0;
		private int _firstLine = 0;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SequencePointCollection"/> class.
		/// </summary>
		public SequencePointCollection()
		{
		}

		#endregion Constructor

		#region Strongly Typed IList Methods

		/// <summary>
		/// Adds the specified sequence point.
		/// </summary>
		/// <param name="sequencePoint">The sequence point.</param>
		/// <returns></returns>
		public int Add(SequencePoint sequencePoint)
		{
			if (_IsSequencePointOnSameLineAsFirstInMethod(sequencePoint))
			{
				sequencePoint.IsOnFirstLineInMethod = true;
			}
			if (!sequencePoint.IsExcluded)
			{
				_countNonExcluded++;
			}
			return this.InnerList.Add(sequencePoint);
		}

		/// <summary>
		/// Gets the <see cref="SequencePoint"/> at the specified index.
		/// </summary>
		/// <value>The sequence point.</value>
		public SequencePoint this[int index]
		{
			get { return (SequencePoint) this.InnerList[index]; }
		}

		/// <summary>
		/// Performs additional custom processes when clearing the contents of the collection.
		/// </summary>
		protected override void OnClear()
		{
			base.OnClear ();
			_countNonExcluded = 0;
		}

		#endregion Strongly Typed IList Methods

		#region Public Properties

		/// <summary>
		/// Gets or sets the count of non excluded sequence points in this collection.
		/// </summary>
		/// <value>The count non excluded.</value>
		public int CountNonExcluded
		{
			get { return _countNonExcluded; }
			set { _countNonExcluded = value; }
		}

		/// <summary>
		/// Gets the first line number for the items in the collection.
		/// </summary>
		/// <value>The first line number.</value>
		public int FirstLineNumber
		{
			get { return _firstLine; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Gets the method visit count - calculated as the visit count of the first sequence point that is not excluded.
		/// </summary>
		/// <returns></returns>
		public long GetMethodVisitCount()
		{
			long methodVisitCount = 0;
			foreach (SequencePoint sequencePoint in this.InnerList)
			{
				if (!sequencePoint.IsExcluded)
				{
					methodVisitCount = sequencePoint.VisitCount;
					break;
				}
			}
			return methodVisitCount;
		}

		#endregion Public Methods

		#region Private Methods

		private bool _IsSequencePointOnSameLineAsFirstInMethod(SequencePoint sequencePoint)
		{
			if (this.InnerList.Count == 0)
			{
				_firstLine = sequencePoint.StartLine;
				return true;
			}
			else
			{
				SequencePoint firstSequencePoint = (SequencePoint)this.InnerList[0];
				if (firstSequencePoint.StartLine == sequencePoint.StartLine)
				{
					return true;
				}
			}
			return false;
		}

		#endregion Private Methods
	}
}