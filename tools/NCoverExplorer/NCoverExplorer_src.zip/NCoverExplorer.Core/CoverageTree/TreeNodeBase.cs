using System;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;
using NCoverExplorer.Core.Visitors;

namespace NCoverExplorer.Core.CoverageTree
{
	/// <summary>
	/// Base class for the Namespace, class and method nodes displayed in a CoverageTreeView control.
	/// </summary>
	public abstract class TreeNodeBase : TreeNode, IComparable, IVisitableNode
	{
		#region Private Variables

		private string _originalSortName;
		private int _totalSequencePoints;
		private int _visitedSequencePoints;
        private string _nodeName;
		private float _coveragePercent;
		private int _unvisitedSequencePoints;
		private bool _hasBeenLoaded;
		private string _fullyQualifiedName;
		private IExplorerConfiguration _configuration;
		private int _firstCodeLineNumber;
		private long _visitCount;
		private bool _isExcluded;
		private bool _isFiltered;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="TreeNodeBase"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		/// <param name="nodeName">Name of the node.</param>
		protected TreeNodeBase(IExplorerConfiguration configuration, string nodeName) : base(nodeName)
		{
			_configuration = configuration;
			_visitedSequencePoints = 0;
			_totalSequencePoints = 0;
			_originalSortName = nodeName;
            _nodeName = nodeName;
			_coveragePercent = -1;
			_unvisitedSequencePoints = -1;
			_hasBeenLoaded = false;
			_fullyQualifiedName = string.Empty;
			_firstCodeLineNumber = -1;
			_visitCount = -1; // Set later.
			_isExcluded = false;
			_isFiltered = false;
		}

		#endregion Constructor

		#region Public Properties

        /// <summary>
        /// Gets the name of the tree node. A property set is provided for internal use where we substitute the name during expansion for nested classes.
        /// </summary>
        public string NodeName
        {
            get { return _nodeName; }
			set { _nodeName = value; }
		}

		/// <summary>
		/// Gets the original name given to the node when first added to the tree. Stored so we can preserve sort order.
		/// </summary>
		public string OriginalSortName
		{
			get { return _originalSortName; }
		}

		/// <summary>
		/// Gets a value indicating whether there is unvisited code for this node.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has unvisited code; otherwise, <c>false</c>.
		/// </value>
		public bool HasUnvisitedCode
		{
			get { return _visitedSequencePoints < _totalSequencePoints; }
		}

		/// <summary>
		/// Gets or sets whether this tree node has been loaded previously in the tree (triggered by expansion).
		/// Used to initialise the graphics and text on demand since string comparisons etc. are so expensive.
		/// </summary>
		/// <value>The file info for this class.</value>
		public bool HasBeenLoaded
		{
			get { return _hasBeenLoaded; }
			set { _hasBeenLoaded = value; }
		}

		/// <summary>
		/// Gets or sets the fully qualified name path to get to this node - e.g. MyNamespace1.MyClass.MyMethod
		/// Note that NCover does nested classes strangely - ie. MyNamespace.MyClass1+MyInnerClass.MyMethod which
		/// we preserve via this property.
		/// </summary>
		/// <value>The fully qualified name as reported in the NCover file.</value>
		public string FullyQualifiedName
		{
			get 
			{
				if (_fullyQualifiedName.Length == 0)
				{
					throw new InvalidOperationException("Cannot retrieve value until after InitialiseForFirstDisplay has been called.");
				}
				return _fullyQualifiedName; 
			}
			set { _fullyQualifiedName = value; }
		}

		/// <summary>
		/// Gets the fully qualified name to this node with any NCover funnies like "+" replaced.
		/// </summary>
		/// <value>The name of the fully qualified.</value>
		public string FullyQualifiedDisplayName
		{
			get { return _fullyQualifiedName.Replace("+","."); }
		}

		/// <summary>
		/// Gets or sets the configuration information - used for special drawing of nodes.
		/// </summary>
		/// <value>The configuration.</value>
		public IExplorerConfiguration Configuration
		{
			get { return _configuration; }
			set { _configuration = value; }
		}

		/// <summary>
		/// Gets or sets the total of visited sequence points of code within this node and it's children.
		/// </summary>
		/// <value>The number of visited sequence points.</value>
		public int VisitedSequencePoints
		{
			get { return _visitedSequencePoints; }
			set { _visitedSequencePoints = value; }
		}
 
		/// <summary>
		/// Gets the total of unvisited (non-excluded) sequence points of code within this node and it's children.
		/// </summary>
		/// <value>The number of unvisited sequence points.</value>
		public int UnvisitedSequencePoints
		{
			get { return _unvisitedSequencePoints; }
		}

		/// <summary>
		/// Gets or sets the total of non excluded sequence points of code within this node and it's children.
		/// </summary>
		/// <value>The total number of non excluded sequence points.</value>
		public int TotalSequencePoints
		{
			get { return _totalSequencePoints; }
			set { _totalSequencePoints = value; }
		}

		/// <summary>
		/// Gets the coverge percentage of this node once it has been calculated by a call to CalculatePercent().
		/// </summary>
		/// <value>The coverage percentage.</value>
		public float CoveragePercentage
		{
			get { return _coveragePercent; }
		}

		/// <summary>
		/// Gets the selection path node separator.
		/// </summary>
		/// <value>The selection path node separator.</value>
		public char SelectionPathNodeSeparator
		{
			get { return '�'; }
		}

		/// <summary>
		/// Gets or sets the line number of the first line of code that this node may contain sequence points for.
		/// If not relevant for this node type will just return -1. For use with sorting.
		/// </summary>
		/// <value>The first code line number, -1 if not relevant.</value>
		public int FirstCodeLineNumber
		{
			get { return _firstCodeLineNumber; }
			set { _firstCodeLineNumber = value; }
		}

		/// <summary>
		/// Gets or sets the visit count for this method.
		/// </summary>
		/// <value>The visit count for this method.</value>
		public long VisitCount
		{
			get { return _visitCount; }
			set { _visitCount = value; }
		}

		/// <summary>
		/// Gets or sets whether this node is "excluded".
		/// </summary>
		/// <value><c>true</c> if this node is excluded; otherwise, <c>false</c>.</value>
		public bool IsExcluded
		{
			get { return _isExcluded; }
			set { _isExcluded = value; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether this node is filtered out by a UI action.
		/// </summary>
		/// <value><c>true</c> if this node is to be filtered; otherwise, <c>false</c>.</value>
		public bool IsFiltered
		{
			get { return _isFiltered; }
			set { _isFiltered = value; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Determines whether this node is to be excluded from coverage by applying the exclusion rules.
		/// </summary>
		/// <param name="coverageExclusionManager">The coverage exclusion manager.</param>
		/// <returns>
		/// 	<c>true</c> if node is to be excluded; otherwise, <c>false</c>.
		/// </returns>
		public abstract bool IsNodeToBeExcluded(ICoverageExclusionManager coverageExclusionManager);

		/// <summary>
		/// Sets the appropriate text based on the node type and visit count as nodes are expanded.
		/// Provides a significant performance boost performing this late bound.
		/// </summary>
		public virtual void InitialiseForFirstDisplay()
		{
			SetNodeTextAndColourBasedOnCoverage();
		}

		/// <summary>
		/// Calculates the percent code coverage for this node and it's children.
		/// </summary>
		public virtual void ApplyExclusionsAndCalculateCoverage(ICoverageExclusionManager coverageExclusionManager)
		{
			ApplyExclusionsAndCalculateCoverageInternal(coverageExclusionManager);
			CalculateNodeCoverageStatistics();
		}

		/// <summary>
		/// Recalculates the code coverage for this node and recurses up the tree correcting the parents.
		/// </summary>
		public void RecalculateAllStatisticsUpTreeBranch()
		{
			_RecalculateSequencePointTotals();
			CalculateNodeCoverageStatistics();
			SetNodeTextAndColourBasedOnCoverage();
				
			if (this.Parent != null)
			{
				((TreeNodeBase)Parent).RecalculateAllStatisticsUpTreeBranch();
			}
		}

		/// <summary>
		/// Collapses all the children of the current node.
		/// </summary>
		public void CollapseRecursive()
		{
			for	(int nodeIndex = this.Nodes.Count -1; nodeIndex >= 0; nodeIndex--)
			{
				TreeNodeBase childNode = (TreeNodeBase)this.Nodes[nodeIndex];
				if (childNode.HasBeenLoaded)
				{
					childNode.CollapseRecursive();
				}
			}
			this.Collapse();
		}

		/// <summary>
		/// Gets the full path to the current selected node selection path using node names, not the text
		/// which would have percentages etc in it.
		/// </summary>
		/// <returns>The path as a string separated by the value of SelectionPathNodeSeparator.</returns>
		public string GetNodeNamePathToSelectedNode()
		{
			string path = _nodeName;
			TreeNodeBase currentNode = this;
			while (currentNode.Parent != null)
			{
				currentNode = (TreeNodeBase)currentNode.Parent;
				path = currentNode.NodeName + SelectionPathNodeSeparator + path;
			}
			return path;
		}

		/// <summary>
		/// Gets the child node with the specified node name supplied.
		/// </summary>
		/// <param name="nodeName">The value of the NodeName property to identify.</param>
		/// <returns><c>null</c> if node not found, node otherwise.</returns>
		public TreeNodeBase GetChildNodeByName(string nodeName)
		{
			for	(int nodeIndex = this.Nodes.Count -1; nodeIndex >= 0; nodeIndex--)
			{
				TreeNodeBase childNode = (TreeNodeBase)this.Nodes[nodeIndex];
				if (childNode.NodeName == nodeName)
				{
					return childNode;
				}
			}
			return null;
		}

		/// <summary>
		/// Calculate the max visit count based as the max of all the children.
		/// </summary>
		public virtual long GetMaxVisitCount()
		{
			long maxVisitCount = 0;
			foreach (TreeNodeBase childTreeNode in this.Nodes)
			{
				if (!childTreeNode.IsExcluded)
				{
					maxVisitCount = Math.Max(maxVisitCount, childTreeNode.GetMaxVisitCount());
				}
			}
			return maxVisitCount;
		}

		/// <summary>
		/// Sets the visit counts to zero.
		/// </summary>
		public virtual void SetVisitCountsToZero()
		{
			_totalSequencePoints = 0;
			_visitedSequencePoints = 0;
			_visitCount = 0;
			_unvisitedSequencePoints = 0;
			_coveragePercent = 0;
		}

		/// <summary>
		/// Sets the visit counts to zero recursively.
		/// </summary>
		public void ExcludeNodesRecursively()
		{
			_isExcluded = true;
			SetVisitCountsToZero();
			foreach (TreeNodeBase childNode in Nodes)
			{
				childNode.ExcludeNodesRecursively();
			}
		}

		/// <summary>
		/// Marks nodes as included recursively and recalculates the children coverage.
		/// </summary>
		public virtual void IncludeNodesRecursively()
		{
			_isExcluded = false;
			_hasBeenLoaded = false;

			foreach (TreeNodeBase childNode in Nodes)
			{
				childNode.IncludeNodesRecursively();
				_totalSequencePoints += childNode.TotalSequencePoints;
				_visitedSequencePoints += childNode.VisitedSequencePoints;
			}
			CalculateNodeCoverageStatistics();
		}

		/// <summary>
		/// Sets the filtered status recursively for this node and all of it's children.
		/// </summary>
		/// <param name="isFiltered">if set to <c>true</c> [is filtered].</param>
		public void SetFilteredStatusRecursively(bool isFiltered)
		{
			_isFiltered = isFiltered;
			foreach (TreeNodeBase childNode in Nodes)
			{
				if (!childNode.IsExcluded)
				{
					childNode.SetFilteredStatusRecursively(isFiltered);
				}
			}
		}

		/// <summary>
		/// Gets the tool tip text if any for this node.
		/// </summary>
		/// <value>The tool tip text.</value>
		public virtual string ToolTipText
		{
			get { return string.Empty; }
		}

		#endregion Public Methods

		#region Protected Methods

		/// <summary>
		/// Calculates the children coverage for this node recursively.
		/// </summary>
		protected void ApplyExclusionsAndCalculateCoverageInternal(ICoverageExclusionManager coverageExclusionManager)
		{
			_totalSequencePoints = 0;
			_visitedSequencePoints = 0;
			int excludedCount = 0;
			_hasBeenLoaded = false;
			for	(int nodeIndex = this.Nodes.Count -1; nodeIndex >= 0; nodeIndex--)
			{
				TreeNodeBase childNode = (TreeNodeBase)this.Nodes[nodeIndex];
				bool isExcludedByOptionsDialogSettings = (coverageExclusionManager != null) && childNode.IsNodeToBeExcluded(coverageExclusionManager);
				if (isExcludedByOptionsDialogSettings)
				{
					// We need to ensure that the visit count is set to zero for all the children
					childNode.ExcludeNodesRecursively();
				}
				else
				{
					// Not excluded by options dialog but might be by NCover attribute - recurse to find out
					childNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);
				}

				if (isExcludedByOptionsDialogSettings || (childNode.TotalSequencePoints == 0))
				{
					childNode.IsExcluded = true;
					excludedCount++;
					continue;
				}
				
				_totalSequencePoints += childNode.TotalSequencePoints;
				_visitedSequencePoints += childNode.VisitedSequencePoints;
			}

			if (_totalSequencePoints == 0)
			{
				// All the child nodes have been excluded
				// We will let the parent node take care of putting this node in it's excluded bin
			}
			else if (excludedCount > 0 && (this is IExcludableParentTreeNode))
			{
				// At least one of the child nodes have been excluded and we can put them in an excluded bin child node.
				IExcludableParentTreeNode excludableParent = (IExcludableParentTreeNode)this;
				for	(int nodeIndex = this.Nodes.Count -1; nodeIndex >= 0; nodeIndex--)
				{
					TreeNodeBase childNode = (TreeNodeBase)this.Nodes[nodeIndex];
					if (childNode.IsExcluded && !(childNode == excludableParent.ExcludedNode))
					{
						childNode.Remove();
						excludableParent.ExcludedNode.Nodes.Insert(0, childNode);
					}
				}
			}
		}

		/// <summary>
		/// Calculate for the node description the % coverage.
		/// </summary>
		protected void CalculateNodeCoverageStatistics()
		{
			if (_totalSequencePoints == 0)
			{
				_coveragePercent = 0;
			}
			else
			{
				_coveragePercent = (((float) _visitedSequencePoints) / ((float) _totalSequencePoints)) * 100f;
			}
			_unvisitedSequencePoints = _totalSequencePoints - _visitedSequencePoints;
			_visitCount = GetMaxVisitCount();
		}

		#region SetNodeText

		/// <summary>
		/// Sets the node text and colour based on percentage coverage.
		/// </summary>
		protected void SetNodeTextAndColourBasedOnCoverage()
		{
			if (_isExcluded || _totalSequencePoints == 0)
			{
				this.Text = _nodeName;
			}
			else
			{
				switch (_configuration.CoverageTreeReportStyle)
				{
					case CoverageTreeReportStyle.SequencePointCoveragePercentage:
					case CoverageTreeReportStyle.SequencePointCoveragePercentageAndUnvisitedSeqPts:
					case CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints:
						SetNodeTextForSequencePointCoverage();
						break;

					case CoverageTreeReportStyle.FunctionCoverage:
						SetNodeTextForFunctionCoverage();
						break;
				}
			}
			this.ForeColor = AppearanceHelper.GetNodeColor(_configuration, _coveragePercent, _unvisitedSequencePoints, 
				_totalSequencePoints, _isExcluded, _isFiltered);
		}

		/// <summary>
		/// Sets the node text for sequence point coverage style of reporting.
		/// </summary>
		protected void SetNodeTextForSequencePointCoverage()
		{
			if (float.IsNaN(_coveragePercent) || _isExcluded)
			{
				this.Text = _nodeName;
			}
			else
			{
				string coveragePercentText = AppearanceHelper.GetCoveragePercentText(_coveragePercent);
				if (_unvisitedSequencePoints == 0)
				{
					// Don't display the sequence points as just makes the tree look too busy.
					switch (_configuration.CoverageTreeReportStyle)
					{
						case CoverageTreeReportStyle.SequencePointCoveragePercentage:
							this.Text = string.Format("{0} ({1})", _nodeName, coveragePercentText);
							break;

						case CoverageTreeReportStyle.SequencePointCoveragePercentageAndUnvisitedSeqPts:
							this.Text = string.Format("{0} ({1})", _nodeName, coveragePercentText);
							break;

						case CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints:
							this.Text = string.Format("{0}", _nodeName);
							break;
					}
				}
				else
				{
					switch (_configuration.CoverageTreeReportStyle)
					{
						case CoverageTreeReportStyle.SequencePointCoveragePercentage:
							this.Text = string.Format("{0} ({1})", _nodeName, coveragePercentText);
							break;

						case CoverageTreeReportStyle.SequencePointCoveragePercentageAndUnvisitedSeqPts:
							this.Text = string.Format("{0} ({1}) ({2}#)", _nodeName, coveragePercentText, _unvisitedSequencePoints);
							break;

						case CoverageTreeReportStyle.SequencePointCoverageUnvisitedSequencePoints:
							this.Text = string.Format("{0} ({1}#)", _nodeName, _unvisitedSequencePoints);
							break;
					}
				}
			}
		}

		/// <summary>
		/// Sets the node text for function coverage style of reporting (defaults to just the node name).
		/// Can be overridden in derived classes to include #visits.
		/// </summary>
		protected void SetNodeTextForFunctionCoverage()
		{
			if (_totalSequencePoints == 0)
			{
				this.Text = _nodeName;
			}
			else
			{
				if (VisitCount == 1)
				{
					this.Text = string.Format("{0} (1 visit)", NodeName);
				}
				else
				{
					this.Text = string.Format("{0} ({1} visits)", NodeName, VisitCount);
				}
			}
		}
 
		#endregion SetNodeText

		#endregion Protected Methods

		#region Private Methods
		
		/// <summary>
		/// Recalculate sequence point totals for total points and visited points from all non-excluded children.
		/// </summary>
		private void _RecalculateSequencePointTotals()
		{
			_totalSequencePoints = 0;
			_visitedSequencePoints = 0;
			for	(int nodeIndex = this.Nodes.Count -1; nodeIndex >= 0; nodeIndex--)
			{
				TreeNodeBase childNode = (TreeNodeBase)this.Nodes[nodeIndex];
				if (!childNode.IsExcluded)
				{
					_totalSequencePoints += childNode.TotalSequencePoints;
					_visitedSequencePoints += childNode.VisitedSequencePoints;
				}
			}
		}

		#endregion Private Methods

		#region IComparable

		/// <summary>
		/// Compares the current instance with another object of the same type.
		/// </summary>
		/// <param name="obj">An object to compare with this instance.</param>
		/// <returns>A 32-bit signed integer that indicates the relative order of the comparands.</returns>
		public int CompareTo(object obj)
		{
			TreeNodeBase compareToNode = (TreeNodeBase)obj;
			if (_configuration == null)
			{
				return _originalSortName.CompareTo(compareToNode.OriginalSortName);
			}
			else if (compareToNode.IsExcluded || compareToNode.IsFiltered || _isExcluded || _isFiltered)
			{
				return _originalSortName.CompareTo(compareToNode.OriginalSortName);
			}

			int compare = 0;
			switch (_configuration.TreeSortStyle)
			{
				default:
				case TreeSortStyle.Name:
					return _originalSortName.CompareTo(compareToNode.OriginalSortName);

				case TreeSortStyle.ClassLine:
				{
					if (_firstCodeLineNumber == -1)
					{
						// Sort by name
						return _originalSortName.CompareTo(compareToNode.OriginalSortName);
					}
					else
					{
						// Sort by line number
						return _CompareIntegers(_firstCodeLineNumber, compareToNode.FirstCodeLineNumber);
					}
				}

				case TreeSortStyle.CoveragePercentageAscending:
					compare = _CompareFloats(_coveragePercent, compareToNode.CoveragePercentage);
					if (compare == 0)
					{
						compare = _originalSortName.CompareTo(compareToNode.OriginalSortName);
					}
					return compare;

				case TreeSortStyle.CoveragePercentageDescending:
					compare = -1 * _CompareFloats(_coveragePercent, compareToNode.CoveragePercentage);
					if (compare == 0)
					{
						compare = _originalSortName.CompareTo(compareToNode.OriginalSortName);
					}
					return compare;

				case TreeSortStyle.UnvisitedSequencePointsAscending:
					compare = _CompareIntegers(_unvisitedSequencePoints, compareToNode.UnvisitedSequencePoints);
					if (compare == 0)
					{
						compare = _originalSortName.CompareTo(compareToNode.OriginalSortName);
					}
					return compare;

				case TreeSortStyle.UnvisitedSequencePointsDescending:
					compare = -1 * _CompareIntegers(_unvisitedSequencePoints, compareToNode.UnvisitedSequencePoints);
					if (compare == 0)
					{
						compare = _originalSortName.CompareTo(compareToNode.OriginalSortName);
					}
					return compare;

				case TreeSortStyle.VisitCountAscending:
					compare = _CompareLongs(_visitCount, compareToNode.VisitCount);
					if (compare == 0)
					{
						compare = _originalSortName.CompareTo(compareToNode.OriginalSortName);
					}
					return compare;

				case TreeSortStyle.VisitCountDescending:
					compare = -1 * _CompareLongs(_visitCount, compareToNode.VisitCount);
					if (compare == 0)
					{
						compare = _originalSortName.CompareTo(compareToNode.OriginalSortName);
					}
					return compare;
			}
		}

		/// <summary>
		/// Compares two integer columns and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstFloat">The first integer.</param>
		/// <param name="secondFloat">The second integer.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareFloats(float firstFloat, float secondFloat)
		{
			if (firstFloat < secondFloat)
			{
				return -1;
			}
			else if (firstFloat == secondFloat)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}

		/// <summary>
		/// Compares two integer columns and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstInteger">The first integer.</param>
		/// <param name="secondInteger">The second integer.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareIntegers(int firstInteger, int secondInteger)
		{
			if (firstInteger < secondInteger)
			{
				return -1;
			}
			else if (firstInteger == secondInteger)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}

		/// <summary>
		/// Compares two long columns and returns appropriate value for IComparer.
		/// </summary>
		/// <param name="firstLong">The first long.</param>
		/// <param name="secondLong">The second long.</param>
		/// <returns>0 if the same, -1 if first is less than second, 1 otherwise.</returns>
		private int _CompareLongs(long firstLong, long secondLong)
		{
			if (firstLong < secondLong)
			{
				return -1;
			}
			else if (firstLong == secondLong)
			{
				return 0;
			}
			else
			{
				return 1;
			}
		}

		#endregion IComparable

		#region IVisitableNode

		/// <summary>
		/// Accept the visitor.
		/// </summary>
		/// <param name="visitor">The visitor to accept.</param>
		/// <returns>The value the visitor returns after the visit.</returns>
		public void AcceptVisitor(ITreeNodeVisitor visitor)
		{
			visitor.Visit(this);
		}

		#endregion IVisitableNode
	}
}
