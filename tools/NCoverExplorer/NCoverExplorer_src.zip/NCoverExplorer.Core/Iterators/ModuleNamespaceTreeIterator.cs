using System;
using System.Collections;

using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Iterators
{
	/// <summary>
	/// Iterator for moving through the non-excluded Namespace nodes in the coverage tree for a particular 
	/// module node only.
	/// </summary>
	public class ModuleNamespaceTreeIterator : IEnumerator
	{
		#region Private Variables

		private ModuleTreeNode _moduleTreeNode;
		private Stack _stack;
		private TreeNodeBase _currentNode;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleNamespaceTreeIterator"/> class.
		/// </summary>
		/// <param name="moduleTreeNode">The module tree node.</param>
		public ModuleNamespaceTreeIterator(ModuleTreeNode moduleTreeNode)
		{
			_moduleTreeNode = moduleTreeNode;
			Reset();
		}

		#endregion Constructor

		#region IEnumerator Members

		/// <summary>
		/// Advances the enumerator to the next element of the tree.
		/// </summary>
		/// <returns>
		/// 	<see langword="true"/> if the enumerator was successfully advanced to the next element;
		/// <see langword="false"/> if the enumerator has passed the end of the tree.
		/// </returns>
		public bool MoveNext()
		{
			if (_stack == null)
			{
				_stack = new Stack();
				_currentNode = null;
				if (_moduleTreeNode != null)
				{
					_stack.Push(_moduleTreeNode);
				}
			}
			else if (_currentNode == null)
			{
				throw new InvalidOperationException("Out of range");
			}

			if (_stack.Count == 0)
			{
				_currentNode = null;
			}

			while (_stack.Count > 0)
			{
				_currentNode = (TreeNodeBase)_stack.Pop();
				for (int index = _currentNode.Nodes.Count - 1; index >= 0; --index)
				{
					TreeNodeBase childNode = (TreeNodeBase)_currentNode.Nodes[index];
					if (childNode is NamespaceTreeNode || childNode is FilteredTreeNode)
					{
						// What we are after
						_stack.Push(childNode);
					}
					else
					{
						// Some other sort of node, will not recurse into children
					}
				}
				if (_currentNode is NamespaceTreeNode)
				{
					break;
				}
			}
			return (_currentNode as NamespaceTreeNode) != null;
		}

		/// <summary>
		/// Sets the enumerator to its initial position, which is before
		/// the first element in the collection.
		/// </summary>
		public void Reset()
		{
			if (_stack != null)
			{
				_stack.Clear();
			}
			_stack = null;
		}

		/// <summary>
		/// Gets the current element in the tree.
		/// </summary>
		/// <value></value>
		public object Current
		{
			get { return _currentNode; }
		}

		#endregion IEnumerator Members
	}
}
