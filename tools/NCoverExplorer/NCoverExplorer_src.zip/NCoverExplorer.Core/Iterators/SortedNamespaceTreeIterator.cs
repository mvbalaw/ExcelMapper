using System;
using System.Collections;

using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Iterators
{
	/// <summary>
	/// Iterator for moving through the non-excluded Namespace nodes in the coverage tree when it has been grouped by
	/// module. We need to build a sorted list of namespaces and iterate over that instead.
	/// </summary>
	public class SortedNamespaceTreeIterator : IEnumerator
	{
		#region Private Variables

		private ArrayList _namespaceTreeNodes;
		private int _currentNodeIndex = -1;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="SortedNamespaceTreeIterator"/> class.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		public SortedNamespaceTreeIterator(CoverageFileTreeNode coverageFileTreeNode)
		{
			_namespaceTreeNodes = new ArrayList();
			
			IEnumerator moduleEnumerator = new ModuleTreeIterator(coverageFileTreeNode);
			while (moduleEnumerator.MoveNext())
			{
				IEnumerator namespaceEnumerator = new ModuleNamespaceTreeIterator((ModuleTreeNode)moduleEnumerator.Current);
				while (namespaceEnumerator.MoveNext())
				{
					_namespaceTreeNodes.Add(namespaceEnumerator.Current);
				}
			}

			_namespaceTreeNodes.Sort();

			Reset();
		}

		#endregion Constructor

		#region IEnumerator Members

		/// <summary>
		/// Advances the enumerator to the next element of the tree.
		/// </summary>
		/// <returns>
		/// 	<see langword="true"/> if the enumerator was successfully advanced to the next element;
		/// <see langword="false"/> if the enumerator has passed the end of the tree.
		/// </returns>
		public bool MoveNext()
		{
			_currentNodeIndex++;
			return _currentNodeIndex < _namespaceTreeNodes.Count;
		}

		/// <summary>
		/// Sets the enumerator to its initial position, which is before
		/// the first element in the collection.
		/// </summary>
		/// <exception cref="T:System.InvalidOperationException">The collection was modified after the enumerator was created.</exception>
		public void Reset()
		{
			_currentNodeIndex = -1;
		}

		/// <summary>
		/// Gets the current element in the tree.
		/// </summary>
		/// <value></value>
		/// <exception cref="T:System.InvalidOperationException">
		/// The enumerator is positioned before the first element of the tree or after the last element.
		/// </exception>
		public object Current
		{
			get
			{
				if (_currentNodeIndex == -1)
				{
					throw new InvalidOperationException("No current node at this position.");
				}
				return _namespaceTreeNodes[_currentNodeIndex]; 
			}
		}

		#endregion IEnumerator Members
	}
}
