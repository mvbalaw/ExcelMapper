using System;
using System.Collections;

using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Iterators
{
	/// <summary>
	/// Iterator for moving through all the Method nodes in the tree.
	/// </summary>
	public class MethodTreeIterator : IEnumerator
	{
		#region Private Variables

		private Stack _stack;
		private TreeNodeBase _currentNode;
		private CoverageFileTreeNode _coverageFileTreeNode;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MethodTreeIterator"/> class.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		public MethodTreeIterator(CoverageFileTreeNode coverageFileTreeNode)
		{
			_coverageFileTreeNode = coverageFileTreeNode;
			Reset();
		}

		#endregion Constructor

		#region IEnumerator Members

		/// <summary>
		/// Advances the enumerator to the next element of the tree.
		/// </summary>
		/// <returns>
		/// 	<see langword="true"/> if the enumerator was successfully advanced to the next element;
		///		<see langword="false"/> if the enumerator has passed the end of the tree.
		/// </returns>
		public bool MoveNext()
		{
			if (_stack == null)
			{
				_stack = new Stack();
				_currentNode = null;
				if (_coverageFileTreeNode != null)
				{
					_stack.Push(_coverageFileTreeNode);
				}
			}
			else if (_currentNode == null)
			{
				throw new InvalidOperationException("Out of range");
			}

			if (_stack.Count == 0)
			{
				_currentNode = null;
			}

			while (_stack.Count > 0)
			{
				_currentNode = (TreeNodeBase)_stack.Pop();
				for (int index = _currentNode.Nodes.Count - 1; index >= 0; --index)
				{
					TreeNodeBase childNode = (TreeNodeBase)_currentNode.Nodes[index];
					// Will iterate over every node in the tree except nested properties.
					if (childNode is MethodTreeNode)
					{
						if (((MethodTreeNode)childNode).IsNestedProperty)
						{
							continue;
						}
					}
					_stack.Push(childNode);
				}
				if (_currentNode is MethodTreeNode)
				{
					break;
				}
			}
			return (_currentNode as MethodTreeNode) != null;
		}

		/// <summary>
		/// Sets the enumerator to its initial position, which is before
		/// the first element in the collection.
		/// </summary>
		public void Reset()
		{
			if (_stack != null)
			{
				_stack.Clear();
			}
			_stack = null;
		}

		/// <summary>
		/// Gets the current element in the tree.
		/// </summary>
		/// <value></value>
		public object Current
		{
			get { return _currentNode; }
		}

		#endregion IEnumerator Members
	}
}
