using System;
using System.Collections;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Strongly typed collection of FormState objects.
	/// </summary>
	[Serializable]
	public class FormStateCollection : CollectionBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="FormStateCollection"/> class.
		/// </summary>
		public FormStateCollection()
		{
		}

		#endregion Constructor

		#region IList Interface Strongly Typed Members
		
		/// <summary>
		/// Add a <see cref="FormState"/> object to the collection.
		/// </summary>
		/// <param name="item">The item to add.</param>
		public void Add(FormState item)
		{
			this.List.Add(item);
		}

		/// <summary>
		/// Gets or sets the <see cref="FormState"/> object at this ordinal index.
		/// </summary>
		public FormState this[int index]
		{
			get { return this.List[index] as FormState; }
			set { this.List[index] = value; }
		}

		/// <summary>
		/// Gets or sets the <see cref="FormState"/> object with this string id.
		/// </summary>
		public FormState this[string formId]
		{
			get
			{
				foreach (FormState formState in this.List)
				{
					if (formState.FormId == formId)
					{
						return formState;
					}
				}

				return null;
			}
			set
			{
				int foundIndex = this.IndexOf(formId);
				if ( foundIndex < 0 ) 
				{
					throw new ArgumentOutOfRangeException("formId", formId, "This formId was not found in the collection.");
				}
				else
				{
					this.List.RemoveAt(foundIndex);
					this.List.Insert(foundIndex, value);
				}
			}
		}

		/// <summary>
		/// The remove method that takes a <see cref="FormState"/> object.
		/// </summary>
		/// <param name="value">The item to remove.</param>
		public void Remove(FormState value)
		{
			this.List.Remove(value);
		}

		/// <summary>
		/// Insert object at this position.
		/// </summary>
		/// <param name="index">Position to insert at.</param>
		/// <param name="value">Object to insert.</param>
		public void Insert(int index, FormState value)
		{
			this.List.Insert(index, value);
		}

		/// <summary>
		/// Returns index position of object matching this key.
		/// </summary>
		/// <param name="formId">Form Id of matching item to find</param>
		/// <returns>Index of matching item, -1 if not found.</returns>
		public int IndexOf(string formId)
		{
			for ( int index = 0; index < this.List.Count; index++ ) 
			{
				if ( ((FormState)this.List[index]).FormId == formId ) 
				{
					return index;
				}
			}
			return -1;
		}

		/// <summary>
		/// Returns index position of this object.
		/// </summary>
		/// <param name="value">The value.</param>
		/// <returns></returns>
		public int IndexOf(FormState value)
		{
			return this.List.IndexOf(value);
		}

		/// <summary>
		/// Returns whether this collection contains this object.
		/// </summary>
		/// <param name="value">Object to find.</param>
		/// <returns>
		/// 	<c>true</c> if contains the specified value; otherwise, <c>false</c>.
		/// </returns>
		public bool Contains(FormState value)
		{
			return this.List.Contains(value);
		}

		#endregion IList Interface Strongly Typed Members
	}
}
