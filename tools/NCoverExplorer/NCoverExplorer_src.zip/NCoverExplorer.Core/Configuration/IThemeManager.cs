namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Interface for theme collection management.
	/// </summary>
	public interface IThemeManager
	{
		/// <summary>
		/// Reads the themes file if it exists, uses the embedded resource if it does not.
		/// </summary>
		ThemeCollection Load();

		/// <summary>
		/// Persist the themes.
		/// </summary>
		/// <param name="themes">The themes.</param>
		void Persist(ThemeCollection themes);

		/// <summary>
		/// Reads the embedded resource themes as the current collection.
		/// </summary>
		/// <returns>Themes collection.</returns>
		ThemeCollection LoadDefaultThemes();
	}
}