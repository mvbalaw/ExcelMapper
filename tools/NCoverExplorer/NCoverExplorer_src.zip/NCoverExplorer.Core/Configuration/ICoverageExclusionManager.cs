using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Interface for working with coverage exclusions in an optimal fashion.
	/// </summary>
	public interface ICoverageExclusionManager
	{
		/// <summary>
		/// Determines whether an assembly exclusion applies to this node so as to remove it from coverage.
		/// </summary>
		/// <param name="moduleTreeNode">The module tree node.</param>
		/// <returns><c>true</c> if node should be removed from the coverage tree.</returns>
		bool IsAssemblyExclusionApplicable(ModuleTreeNode moduleTreeNode);
		/// <summary>
		/// Determines whether a namespace exclusion applies to this node so as to remove it from coverage.
		/// </summary>
		/// <param name="namespaceTreeNode">The namespace tree node.</param>
		/// <returns><c>true</c> if node should be removed from the coverage tree.</returns>
		bool IsNamespaceExclusionApplicable(NamespaceTreeNode namespaceTreeNode);
		/// <summary>
		/// Determines whether a class exclusion applies to this node so as to remove it from coverage.
		/// </summary>
		/// <param name="classTreeNode">The class tree node.</param>
		/// <returns><c>true</c> if node should be removed from the coverage tree.</returns>
		bool IsClassExclusionApplicable(ClassTreeNode classTreeNode);
	}
}
