
namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Interface for the configuration information for NCoverExplorer.
	/// </summary>
	public interface IExplorerConfiguration
	{
		#region Persisted Properties

		/// <summary>
		/// Gets or sets the percentage coverage considered acceptable to colour differently.
		/// </summary>
		/// <value>The satisfactory coverage threshold.</value>
		float SatisfactoryCoverageThreshold { get; set; }

		/// <summary>
		/// Gets or sets the number of unvisited sequence points considered acceptable to colour differently.
		/// </summary>
		/// <value>The satisfactory number of unvisited sequence points.</value>
		int SatisfactoryUnvisitedSequencePoints { get; set; }

		/// <summary>
		/// Gets or sets whether to group the nodes in the tree by module (alternative is by namespace).
		/// </summary>
		/// <value><c>true</c> if group by module; otherwise, <c>false</c> if group by namespace.</value>
		bool GroupByModule { get; set; }

		/// <summary>
		/// Gets or sets whether to flatten child namespaces (VS2005 style) or nest them (VS2003 style).
		/// </summary>
		/// <value><c>true</c> if flatten namespaces; otherwise, <c>false</c>.</value>
		bool FlattenNamespaces { get; set; }

		/// <summary>
		/// Gets or sets whether to restore the selected node/source code position when reloading a file.
		/// </summary>
		/// <value><c>true</c> if restore selection on reload; otherwise, <c>false</c>.</value>
		bool RestoreSelectionOnReload { get; set; }

		/// <summary>
		/// Gets or sets whether to popup a warning dialog when source code cannot be found.
		/// </summary>
		/// <value><c>true</c> if popup a warning dialog; otherwise, <c>false</c>.</value>
		bool WarnAboutMissingSourceCode { get; set; }

		/// <summary>
		/// Gets or sets the number of recent files listed in the File menu.
		/// </summary>
		/// <value>The num recent files.</value>
		int NumberOfRecentFiles { get; set; }

		/// <summary>
		/// Gets the form settings containing persisted data for each form such as size and position.
		/// </summary>
		/// <value>The form settings collection.</value>
		FormStateCollection FormStates { get; }

		/// <summary>
		/// Gets the collection of most recently used lists.
		/// </summary>
		/// <value>The mru collection.</value>
		MruStateCollection MruStates { get; }

		/// <summary>
		/// Gets or sets the appearance properties such as highlighting colours.
		/// </summary>
		/// <value>The appearance properties.</value>
		Theme Theme { get; set; }

		/// <summary>
		/// Gets or sets the coverage tree report style (sequence points or function coverage).
		/// </summary>
		/// <value>The coverage tree report style.</value>
		CoverageTreeReportStyle CoverageTreeReportStyle { get; set; }

		/// <summary>
		/// Gets or sets the collection of exclusion patterns to apply after reading a coverage.xml file.
		/// </summary>
		CoverageExclusionCollection CoverageExclusions { get; set; }

		/// <summary>
		/// Gets or sets the project name for use in generated reports.
		/// </summary>
		/// <value>The project name.</value>
		string ProjectName { get; set; }

		/// <summary>
		/// Gets or sets the collection of module specific coverage thresholds.
		/// </summary>
		ModuleThresholdCollection ModuleThresholds { get; set; }

		#endregion Persisted Properties

		/// <summary>
		/// Gets or sets the sort order to apply to the tree.
		/// </summary>
		TreeSortStyle TreeSortStyle { get; set; }

		/// <summary>
		/// Gets or sets the filter to apply to the tree.
		/// </summary>
		TreeFilterStyle TreeFilterStyle { get; set; }

		/// <summary>
		/// Gets the command line options passed in when executing the application.
		/// </summary>
		/// <value>The command line options.</value>
		CommandLineOptions CommandLineOptions { get; }

		/// <summary>
		/// Gets the available themes to choose from for appearance.
		/// </summary>
		/// <value>The themes.</value>
		ThemeCollection Themes { get; }

		/// <summary>
		/// Gets the filename of the configuration file.
		/// </summary>
		/// <value>The filename of the configuration file.</value>
		string FileName { get; }

		/// <summary>
		/// Reloads the configuration file.
		/// </summary>
		void Reload();

		/// <summary>
		/// Persists the configuration file.
		/// </summary>
		void Persist();

		/// <summary>
		/// Persists the configuration file.
		/// </summary>
		IExplorerConfiguration Clone();
	}
}