using System;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// A coverage exclusion is an optional way of automatically removing nodes from the displayed output,
	/// such as test assemblies or My namespaces.
	/// </summary>
	[Serializable]
	public class CoverageExclusion
	{
		#region Private Variables

		private ExclusionType _exclusionType;
		private string _rawPattern;
		private ExclusionPatternType _exclusionPatternType;
		private string _nonWildcardPattern;
		private bool _enabled;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageExclusion"/> class.
		/// </summary>
		public CoverageExclusion()
			: this((ExclusionType)(-1), string.Empty)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageExclusion"/> class.
		/// </summary>
		/// <param name="exclusionType">Type of the exclusion.</param>
		/// <param name="pattern">The pattern.</param>
		public CoverageExclusion(ExclusionType exclusionType, string pattern)
		{
			_exclusionType = exclusionType;
			Pattern = pattern;
			_enabled = true;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the type of the exclusion.
		/// </summary>
		/// <value>The type of the exclusion.</value>
		public ExclusionType ExclusionType
		{
			get { return _exclusionType; }
			set { _exclusionType = value; }
		}

		/// <summary>
		/// Gets or sets the pattern.
		/// </summary>
		/// <value>The pattern.</value>
		public string Pattern
		{
			get { return _rawPattern; }
			set 
			{ 
				_rawPattern = value.Trim();
				if (_rawPattern.StartsWith("*"))
				{
					if (_rawPattern.EndsWith("*"))
					{
						_exclusionPatternType = ExclusionPatternType.Contains;
						_nonWildcardPattern = _rawPattern.Substring(1, _rawPattern.Length - 2);
					}
					else
					{
						_exclusionPatternType = ExclusionPatternType.EndsWith;
						_nonWildcardPattern = _rawPattern.Substring(1);
					}
				}
				else if (_rawPattern.EndsWith("*"))
				{
					_exclusionPatternType = ExclusionPatternType.StartsWith;
					_nonWildcardPattern = _rawPattern.Substring(0, _rawPattern.Length - 1);
				}
				else
				{
					_exclusionPatternType = ExclusionPatternType.Exact;
					_nonWildcardPattern = _rawPattern;
				}
			}
		}

		/// <summary>
		/// Gets or sets a value indicating whether this <see cref="CoverageExclusion"/> is enabled.
		/// </summary>
		/// <value><c>true</c> if enabled; otherwise, <c>false</c>.</value>
		public bool Enabled
		{
			get { return _enabled; }
			set { _enabled = value; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Returns whether the text matches the pattern exclusion.
		/// </summary>
		/// <param name="textToCompare">The text to compare with the pattern.</param>
		/// <returns></returns>
		public bool IsMatchingExclusion(string textToCompare)
		{
			switch (_exclusionPatternType)
			{
				case ExclusionPatternType.Contains:
					return textToCompare.IndexOf(_nonWildcardPattern) >= 0;

				case ExclusionPatternType.StartsWith:
					return textToCompare.StartsWith(_nonWildcardPattern);

				case ExclusionPatternType.EndsWith:
					return textToCompare.EndsWith(_nonWildcardPattern);

				case ExclusionPatternType.Exact:
				default:
					return textToCompare == _nonWildcardPattern;
			}
		}

		/// <summary>
		/// Serves as a hash function for a particular type, suitable for use in hashing algorithms and
		/// data structures like a hash table.
		/// </summary>
		/// <returns>A hash code for the current exclusion.</returns>
		public override int GetHashCode()
		{
			return _exclusionType.GetHashCode() 
				+ _rawPattern.GetHashCode();
		}

		/// <summary>
		/// Determines whether two PropertyKey instances are equal, or if the result of PropertyKey.ToString()
		/// equals the supplied object string.
		/// </summary>
		/// <param name="obj">The PropertyKey or ToString() to compare with this object.</param>
		/// <returns>
		/// <c>true</c> if the specified Object is equal to the current Object; otherwise, <c>false</c>.
		/// </returns>
		public override bool Equals(object obj)
		{
			CoverageExclusion coverageExclusion = obj as CoverageExclusion;

			if ( coverageExclusion != null ) 
			{
				// We were supplied a CoverageExclusion object
				if ( coverageExclusion.ExclusionType == _exclusionType
					&& coverageExclusion.Pattern == _rawPattern)
				{
					return true;
				}
			}
			return false;
		}

		#endregion Public Methods
	}
}
