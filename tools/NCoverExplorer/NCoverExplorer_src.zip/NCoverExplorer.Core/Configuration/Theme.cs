using System;
using System.ComponentModel;
using System.Drawing;
using System.Xml.Serialization;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Contains the theme colour and font settings for the appearance of NCoverExplorer.
	/// </summary>
	[Serializable]
	public class Theme
	{
		#region Public Constants

		/// <summary>
		/// Theme name for the default appearance built-in theme for NCoverExplorer.
		/// </summary>
		public const string DefaultThemeName = "Neutral";

		#endregion Public Constants

		#region Private Static Variables
		
		private static Color DefaultColorSourceCodeVisitedVSTS = Color.FromArgb(224, 237, 253);
		private static Color DefaultColorSourceCodeNotVisitedVSTS = Color.FromArgb(230, 176, 165);
		private static Color DefaultColorSourceCodeExcluded = Color.LightGray;
		private static Color DefaultColorTreeNotVisited = Color.Gray;
		private static Color DefaultColorTreePartiallyCovered = Color.Red;
		private static Color DefaultColorTreeSatisfactory = Color.Blue;
		private static Color DefaultColorTreeFullCoverage = Color.Black;
		private static Color DefaultColorTreeExcluded = Color.Gray;

		#endregion Private Static Variables

		#region Private Variables

		private string _themeName;

		private HighlightVisitedCodeStyle _highlightVisitedCodeStyle;
		private HighlightUnvisitedCodeStyle _highlightUnvisitedCodeStyle;
		private HighlightVisitedCodeStyle _highlightExcludedCodeStyle;
		private Color _highlightVisitedCodeColor;
		private Color _highlightUnvisitedCodeColor;
		private Color _highlightExcludedCodeColor;

		private Color _treeNodeNotVisitedColor;
		private Color _treeNodePartiallyCoveredColor;
		private Color _treeNodeSatisfactoryColor;
		private Color _treeNodeFullCoverageColor;
		private Color _treeNodeExcludedCoverageColor;

		private Color _coverageTreeBackgroundColor;
		private Font _coverageTreeFont;

		private Color _statisticsPaneBackgroundColor;
		private Font _statisticsPaneFont;

		private Font _sourceCodeFont;
		private Color _sourceCodeBackgroundColor;
		private Color _sourceCodeLineNumbersColor;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="Theme"/> class.
		/// </summary>
		public Theme() 
			: this(DefaultThemeName)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="Theme"/> class.
		/// </summary>
		/// <param name="themeName">Name of the theme.</param>
		public Theme(string themeName)
		{
			_themeName = themeName;
			RestoreDefaults();
		}

		#endregion Constructor

		#region Public Properties

		#region Name

		/// <summary>
		/// Gets or sets the theme name.
		/// </summary>
		/// <value>The theme name.</value>
		[XmlAttribute("Name")]
		public string Name
		{
			get { return _themeName; }
			set { _themeName = value; }
		}

		#endregion Name

		#region Source Code Highlighting

		/// <summary>
		/// Gets or sets the highlight style to apply to source code that is covered.
		/// </summary>
		/// <value>The highlight visited code style.</value>
		public HighlightVisitedCodeStyle HighlightVisitedCodeStyle
		{
			get { return _highlightVisitedCodeStyle; }
			set 
			{
				if (value != _highlightVisitedCodeStyle)
				{
					if (!Enum.IsDefined(typeof(HighlightVisitedCodeStyle), value))
					{
						throw new InvalidEnumArgumentException("HighlightVisitedCodeStyle", (int)value, typeof(HighlightVisitedCodeStyle));
					}
					_highlightVisitedCodeStyle = value; 
				}
			}
		}

		/// <summary>
		/// Gets or sets the highlight style to apply to source code that has no coverage.
		/// </summary>
		/// <value>The highlight unvisited code style.</value>
		public HighlightUnvisitedCodeStyle HighlightUnvisitedCodeStyle
		{
			get { return _highlightUnvisitedCodeStyle; }
			set 
			{
				if (value != _highlightUnvisitedCodeStyle)
				{
					if (!Enum.IsDefined(typeof(HighlightUnvisitedCodeStyle), value))
					{
						throw new InvalidEnumArgumentException("HighlightUnvisitedCodeStyle", (int)value, typeof(HighlightUnvisitedCodeStyle));
					}
					_highlightUnvisitedCodeStyle = value; 
				}
			}
		}

		/// <summary>
		/// Gets or sets the highlight style to apply to source code that is excluded according to NCover using attributes.
		/// </summary>
		/// <value>The highlight visited code style.</value>
		public HighlightVisitedCodeStyle HighlightExcludedCodeStyle
		{
			get { return _highlightExcludedCodeStyle; }
			set 
			{
				if (value != _highlightExcludedCodeStyle)
				{
					if (!Enum.IsDefined(typeof(HighlightVisitedCodeStyle), value))
					{
						throw new InvalidEnumArgumentException("HighlightExcludedCodeStyle", (int)value, typeof(HighlightVisitedCodeStyle));
					}
					_highlightExcludedCodeStyle = value; 
				}
			}
		}

		/// <summary>
		/// Gets or sets the highlight color to apply to source code that is covered when set to a style other than "None".
		/// </summary>
		/// <value>The color of the highlight visited code.</value>
		[XmlIgnore]
		public Color HighlightVisitedCodeColor
		{
			get { return _highlightVisitedCodeColor; }
			set { _highlightVisitedCodeColor = value; }
		}

		/// <summary>
		/// Gets or sets the Xml serializable version of the highlight visited color value.
		/// </summary>
		[XmlElement("HighlightVisitedCodeColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlHighlightVisitedCodeColor
		{
			get { return SerializeColor(_highlightVisitedCodeColor); }
			set { _highlightVisitedCodeColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the highlight color to apply to source code that has no coverage when set to a style other than "Underlined".
		/// </summary>
		/// <value>The color of the highlight unvisited code.</value>
		[XmlIgnore]
		public Color HighlightUnvisitedCodeColor
		{
			get { return _highlightUnvisitedCodeColor; }
			set { _highlightUnvisitedCodeColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the highlight uncovered color value.
		/// </summary>
		[XmlElement("HighlightUnvisitedCodeColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlHighlightUnvisitedCodeColor
		{
			get { return SerializeColor(HighlightUnvisitedCodeColor); }
			set { HighlightUnvisitedCodeColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the highlight color to apply to source code that is excluded when set to a style other than "None".
		/// </summary>
		/// <value>The color of the highlight visited code.</value>
		[XmlIgnore]
		public Color HighlightExcludedCodeColor
		{
			get { return _highlightExcludedCodeColor; }
			set { _highlightExcludedCodeColor = value; }
		}

		/// <summary>
		/// Gets or sets the Xml serializable version of the highlight excluded color value.
		/// </summary>
		[XmlElement("HighlightExcludedCodeColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlHighlightExcludedCodeColor
		{
			get { return SerializeColor(_highlightExcludedCodeColor); }
			set { _highlightExcludedCodeColor = DeserializeColor(value); }
		}

		#endregion Source Code Highlighting

		#region Tree Appearance

		/// <summary>
		/// Gets or sets the color to apply to treeview node for when it has no coverage.
		/// </summary>
		/// <value>The color of the unvisited tree node.</value>
		[XmlIgnore]
		public Color TreeNodeUnvisitedColor
		{
			get { return _treeNodeNotVisitedColor; }
			set { _treeNodeNotVisitedColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the treeview node unvisited color value.
		/// </summary>
		[XmlElement("TreeNodeUnvisitedColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlTreeNodeUnvisitedColor
		{
			get { return SerializeColor(_treeNodeNotVisitedColor); }
			set { _treeNodeNotVisitedColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the color to apply to treeview node for when it has partial coverage.
		/// </summary>
		/// <value>The color of the partially covered tree node.</value>
		[XmlIgnore]
		public Color TreeNodePartiallyVisitedColor
		{
			get { return _treeNodePartiallyCoveredColor; }
			set { _treeNodePartiallyCoveredColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the treeview node unvisited color value.
		/// </summary>
		[XmlElement("TreeNodePartiallyVisitedColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlTreeNodePartiallyVisitedColor
		{
			get { return SerializeColor(_treeNodePartiallyCoveredColor); }
			set { _treeNodePartiallyCoveredColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the color to apply to treeview node for when it has satisfactory coverage.
		/// </summary>
		/// <value>The color of the satisfactory covered tree node.</value>
		[XmlIgnore]
		public Color TreeNodeSatisfactoryCoverageColor
		{
			get { return _treeNodeSatisfactoryColor; }
			set { _treeNodeSatisfactoryColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the treeview node satisfactory color value.
		/// </summary>
		[XmlElement("TreeNodeSatisfactoryCoverageColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlTreeNodeSatisfactoryCoverageColor
		{
			get { return SerializeColor(_treeNodeSatisfactoryColor); }
			set { _treeNodeSatisfactoryColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the color to apply to treeview node for when it has full coverage.
		/// </summary>
		/// <value>The color of the fully covered tree node.</value>
		[XmlIgnore]
		public Color TreeNodeFullCoverageColor
		{
			get { return _treeNodeFullCoverageColor; }
			set { _treeNodeFullCoverageColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the treeview node full coverage color value.
		/// </summary>
		[XmlElement("TreeNodeFullCoverageColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlTreeNodeFullCoverageColor
		{
			get { return SerializeColor(_treeNodeFullCoverageColor); }
			set { _treeNodeFullCoverageColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the color to apply to treeview node for when it was excluded from coverage.
		/// </summary>
		/// <value>The color of the fully covered tree node.</value>
		[XmlIgnore]
		public Color TreeNodeExcludedCoverageColor
		{
			get { return _treeNodeExcludedCoverageColor; }
			set { _treeNodeExcludedCoverageColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the treeview node exluded from coverage color value.
		/// </summary>
		[XmlElement("TreeNodeExcludedCoverageColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlTreeNodeExcludedCoverageColor
		{
			get { return SerializeColor(_treeNodeExcludedCoverageColor); }
			set { _treeNodeExcludedCoverageColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the color to apply to treeview background color.
		/// </summary>
		/// <value>The background color of treeview.</value>
		[XmlIgnore]
		public Color CoverageTreeBackgroundColor
		{
			get { return _coverageTreeBackgroundColor; }
			set { _coverageTreeBackgroundColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the treeview background color value.
		/// </summary>
		[XmlElement("CoverageTreeBackgroundColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlCoverageTreeBackgroundColor
		{
			get { return SerializeColor(_coverageTreeBackgroundColor); }
			set { _coverageTreeBackgroundColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the coverage tree font.
		/// </summary>
		/// <value>The coverage tree font.</value>
		[XmlIgnore]
		public Font CoverageTreeFont
		{
			get { return _coverageTreeFont; }
			set { _coverageTreeFont = value; }
		}

		/// <summary>
		/// Gets or sets the Xml serializable version of the coverage tree font.
		/// </summary>
		[Browsable(false)]
		[XmlElement("CoverageTreeFont")]
		public XmlFont XmlCoverageTreeFont
		{
			get { return SerializeFont(_coverageTreeFont); }
			set { _coverageTreeFont = DeserializeFont(value); }
		}

		#endregion Tree Appearance

		#region Statistics Pane Appearance

		/// <summary>
		/// Gets or sets the color to apply to statistics pane background color.
		/// </summary>
		/// <value>The background color of statistics pane.</value>
		[XmlIgnore]
		public Color StatisticsPaneBackgroundColor
		{
			get { return _statisticsPaneBackgroundColor; }
			set { _statisticsPaneBackgroundColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the statistics pane background color value.
		/// </summary>
		[XmlElement("StatisticsPaneBackgroundColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlStatisticsPaneBackgroundColor
		{
			get { return SerializeColor(_statisticsPaneBackgroundColor); }
			set { _statisticsPaneBackgroundColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the statistics pane  font.
		/// </summary>
		/// <value>The statistics pane font.</value>
		[XmlIgnore]
		public Font StatisticsPaneFont
		{
			get { return _statisticsPaneFont; }
			set { _statisticsPaneFont = value; }
		}

		/// <summary>
		/// Gets or sets the Xml serializable version of the statistics pane font.
		/// </summary>
		[Browsable(false)]
		[XmlElement("StatisticsPaneFont")]
		public XmlFont XmlStatisticsPaneFont
		{
			get { return SerializeFont(_statisticsPaneFont); }
			set { _statisticsPaneFont = DeserializeFont(value); }
		}

		#endregion Statistics Pane Appearance

		#region Source Code Appearance

		/// <summary>
		/// Gets or sets the source code pane font.
		/// </summary>
		/// <value>The source code pane font.</value>
		[XmlIgnore]
		public Font SourceCodeFont
		{
			get { return _sourceCodeFont; }
			set { _sourceCodeFont = value; }
		}

		/// <summary>
		/// Gets or sets the Xml serializable version of the source code pane font.
		/// </summary>
		[Browsable(false)]
		[XmlElement("SourceCodeFont")]
		public XmlFont XmlSourceCodeFont
		{
			get { return SerializeFont(_sourceCodeFont); }
			set { _sourceCodeFont = DeserializeFont(value); }
		}

		/// <summary>
		/// Gets or sets the color to apply to source code background color.
		/// </summary>
		/// <value>The background color of source code.</value>
		[XmlIgnore]
		public Color SourceCodeBackgroundColor
		{
			get { return _sourceCodeBackgroundColor; }
			set { _sourceCodeBackgroundColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the source code background color value.
		/// </summary>
		[XmlElement("SourceCodeBackgroundColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlSourceCodeBackgroundColor
		{
			get { return SerializeColor(_sourceCodeBackgroundColor); }
			set { _sourceCodeBackgroundColor = DeserializeColor(value); }
		}

		/// <summary>
		/// Gets or sets the color to apply to source code line numbers color.
		/// </summary>
		/// <value>The line numbers color of source code.</value>
		[XmlIgnore]
		public Color SourceCodeLineNumbersColor
		{
			get { return _sourceCodeLineNumbersColor; }
			set { _sourceCodeLineNumbersColor = value; }
		}

		/// <summary>
		/// Gets or sets Xml serializable version of the source code line numbers color value.
		/// </summary>
		[XmlElement("SourceCodeLineNumbersColor")]
		[Browsable(false)]
		[EditorBrowsable(EditorBrowsableState.Never)]
		public string XmlSourceCodeColor
		{
			get { return SerializeColor(_sourceCodeLineNumbersColor); }
			set { _sourceCodeLineNumbersColor = DeserializeColor(value); }
		}

		#endregion Source Code Appearance

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Restores the default colors.
		/// </summary>
		public void RestoreDefaults()
		{
			_highlightVisitedCodeStyle = HighlightVisitedCodeStyle.Block;
			_highlightUnvisitedCodeStyle = HighlightUnvisitedCodeStyle.Block;
			_highlightExcludedCodeStyle = HighlightVisitedCodeStyle.Block;
			_highlightVisitedCodeColor = DefaultColorSourceCodeVisitedVSTS;
			_highlightUnvisitedCodeColor = DefaultColorSourceCodeNotVisitedVSTS;
			_highlightExcludedCodeColor = DefaultColorSourceCodeExcluded;

			_treeNodeNotVisitedColor = DefaultColorTreeNotVisited;
			_treeNodePartiallyCoveredColor = DefaultColorTreePartiallyCovered;
			_treeNodeSatisfactoryColor = DefaultColorTreeSatisfactory;
			_treeNodeFullCoverageColor = DefaultColorTreeFullCoverage;
			_treeNodeExcludedCoverageColor = DefaultColorTreeExcluded;

			_coverageTreeBackgroundColor = SystemColors.Window;
			_coverageTreeFont = new Font("Tahoma", 8.25f);

			_statisticsPaneBackgroundColor = SystemColors.Window;
			_statisticsPaneFont = new Font("Tahoma", 8.25f);

			_sourceCodeFont = new Font("Courier New", 10f);
			_sourceCodeBackgroundColor = SystemColors.Window;
			_sourceCodeLineNumbersColor = SystemColors.ControlDark;
		}

		/// <summary>
		/// Gets the default custom colors for color picker dialog.
		/// </summary>
		/// <returns>Array of ARGB values.</returns>
		public int[] GetDefaultCustomColorsForPicker()
		{
			int[] colors = new int[16];
			colors[0] = _ConvertColorToColorDialogInt(DefaultColorTreeNotVisited);
			colors[1] = _ConvertColorToColorDialogInt(DefaultColorTreePartiallyCovered);
			colors[2] = _ConvertColorToColorDialogInt(DefaultColorTreeSatisfactory);
			colors[3] = _ConvertColorToColorDialogInt(DefaultColorTreeFullCoverage);
			colors[4] = _ConvertColorToColorDialogInt(DefaultColorTreeExcluded);
			colors[5] = _ConvertColorToColorDialogInt(_coverageTreeBackgroundColor);
			colors[6] = _ConvertColorToColorDialogInt(DefaultColorSourceCodeVisitedVSTS);
			colors[7] = _ConvertColorToColorDialogInt(DefaultColorSourceCodeNotVisitedVSTS);

			colors[8] = _ConvertColorToColorDialogInt(_treeNodeNotVisitedColor);
			colors[9] = _ConvertColorToColorDialogInt(_treeNodePartiallyCoveredColor);
			colors[10] = _ConvertColorToColorDialogInt(_treeNodeSatisfactoryColor);
			colors[11] = _ConvertColorToColorDialogInt(_treeNodeFullCoverageColor);
			colors[12] = _ConvertColorToColorDialogInt(_statisticsPaneBackgroundColor);
			colors[13] = _ConvertColorToColorDialogInt(_sourceCodeBackgroundColor);
			colors[14] = _ConvertColorToColorDialogInt(_highlightVisitedCodeColor);
			colors[15] = _ConvertColorToColorDialogInt(_highlightUnvisitedCodeColor);

			return colors;
		}

		/// <summary>
		/// Returns name of theme for use in combo boxes.
		/// </summary>
		public override string ToString()
		{
			return _themeName;
		}

		/// <summary>
		/// Clones the specified theme to a new object.
		/// </summary>
		/// <returns>Clone of theme.</returns>
		public Theme Clone()
		{
			string serialized = SerializationUtilities.SerializeToXml(this);
			return (Theme)SerializationUtilities.DeserializeFromXml(serialized, typeof(Theme));
		}

		#endregion Public Methods

		#region Private Methods

		/// <summary>
		/// Function to convert to BGR rather than ARGB that .Net Color function does.
		/// </summary>
		private int _ConvertColorToColorDialogInt(Color color)
		{
			return (color.R + (color.G << 8) + (color.B << 16));
		}

		#endregion Private Methods

		#region Serialization Helpers

		/// <summary>
		/// Enumeration for the types of colours we know how to serialize/deserialize to string.
		/// </summary>
		protected enum ColorFormatType
		{
			/// <summary>A named colors.</summary>
			NamedColor,
			/// <summary>a color made of alpha and RGB components.</summary>
			ARGBColor
		}

		/// <summary>
		/// Serializes the color object into a string.
		/// </summary>
		/// <param name="color">The color.</param>
		/// <returns></returns>
		protected static string SerializeColor(Color color)
		{
			if (color.IsNamedColor)
			{
				return string.Format("{0}:{1}", ColorFormatType.NamedColor, color.Name);
			}
			else
			{
				return string.Format("{0}:{1}:{2}:{3}:{4}", ColorFormatType.ARGBColor, color.A, color.R, color.G, color.B);
			}
		}

		/// <summary>
		/// Deserializes a color from a special string format into a Color object.
		/// </summary>
		/// <param name="colorText">The color text description as serialized.</param>
		/// <returns>Color object.</returns>
		protected static Color DeserializeColor(string colorText)
		{
			string[] pieces = colorText.Split(new char[] {':'});

			ColorFormatType colorType = (ColorFormatType)Enum.Parse(typeof(ColorFormatType), pieces[0], true);

			switch (colorType)
			{
				default:	// Enum will throw error above if invalid
				case ColorFormatType.NamedColor:
					return Color.FromName(pieces[1]);

				case ColorFormatType.ARGBColor:
					byte a = byte.Parse(pieces[1]);
					byte r = byte.Parse(pieces[2]);
					byte g = byte.Parse(pieces[3]);
					byte b = byte.Parse(pieces[4]);

					return Color.FromArgb(a, r, g, b);
			}
		}

		/// <summary>
		/// Serializes the font into a serializable class format.
		/// </summary>
		/// <param name="font">The font.</param>
		/// <returns></returns>
		protected static XmlFont SerializeFont(Font font)
		{
			return new XmlFont(font);
		}

		/// <summary>
		/// Deserializes the font from a serialized class format into a Font object.
		/// </summary>
		/// <param name="font">The font.</param>
		/// <returns></returns>
		protected static Font DeserializeFont(XmlFont font)
		{
			return font.ToFont();
		}

		#endregion Serialization Helpers
	}
}
