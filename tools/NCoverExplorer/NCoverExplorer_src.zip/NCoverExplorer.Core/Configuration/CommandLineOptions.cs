using System;
using System.Collections;
using System.Text.RegularExpressions;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Parse the command line passed into NCoverExplorer.
	/// </summary>
	[Serializable]
	public class CommandLineOptions
	{
		#region Private Variables

		private string[] _coverageFileNames;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CommandLineOptions"/> class.
		/// </summary>
		/// <param name="args">The args.</param>
		public CommandLineOptions(string[] args)
		{
			_ParseStartupArguments(args);
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets a value indicating whether a coverage file name was passed in.
		/// </summary>
		/// <value>
		/// 	<c>true</c> if this instance has coverage file name; otherwise, <c>false</c>.
		/// </value>
		public bool HasCoverageFileName
		{
			get { return _coverageFileNames != null && _coverageFileNames.Length > 0; }
		}

		/// <summary>
		/// Gets the name of the coverage files to load on startup.
		/// </summary>
		/// <value>The name of the coverage files.</value>
		public string[] CoverageFileNames
		{
			get { return _coverageFileNames; }
		}

		#endregion Public Properties

		#region Protected Methods
		
		/// <summary>
		/// Validates the command line argument and assigns to the class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="value">The value.</param>
		protected virtual void ValidateAndAssignArgument(string name, string value)
		{
			switch (name.ToLower())
			{
				default:
					// Unknown parameter - just ignore it.
					break;
			}
		}

		#endregion Protected Methods

		#region Private Methods

		/// <summary>
		/// Parse the startup arguments - currently only supports a filename.
		/// </summary>
		/// <param name="args">The args.</param>
		private void _ParseStartupArguments(string[] args)
		{
			ArrayList fileNames = new ArrayList();

			foreach (string arg in args)
			{
				Match match = Regex.Match(arg, @"^/(?<name>\w+)(?::(?<value>.+))?$");
				if (match.Success)
				{
					string name = match.Groups["name"].Value;
					string value = match.Groups["value"].Value;
					ValidateAndAssignArgument(name, value);
				}
				else 
				{ 
					fileNames.Add(arg);
				}
			}

			_coverageFileNames = (string[])fileNames.ToArray(typeof(string));
		}

		#endregion Private Methods
	}
}
