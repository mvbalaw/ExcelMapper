using System;
using System.Xml.Serialization;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// A module threshold is used by the console application (only currently) to set coverage thresholds
	/// at a more granular level than just at project level.
	/// </summary>
	[Serializable]
	public class ModuleThreshold
	{
		#region Private Variables

		private string _moduleName;
		private float _satisfactoryCoverage;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleThreshold"/> class.
		/// </summary>
		public ModuleThreshold()
			: this(string.Empty, 100f)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleThreshold"/> class.
		/// </summary>
		/// <param name="moduleName">Name of the module.</param>
		/// <param name="satisfactoryCoverage">The coverage threshold.</param>
		public ModuleThreshold(string moduleName, float satisfactoryCoverage)
		{
			_moduleName = moduleName;
			_satisfactoryCoverage = satisfactoryCoverage;
		}

		#endregion Constructors

		#region Public Properties

		/// <summary>
		/// Gets or sets the name of the module.
		/// </summary>
		/// <value>The name of the module.</value>
		[XmlAttribute("moduleName")]
		public string ModuleName
		{
			get { return _moduleName; }
			set { _moduleName = value; }
		}

		/// <summary>
		/// Gets or sets the coverage threshold for this module.
		/// </summary>
		/// <value>The coverage threshold.</value>
		[XmlAttribute("satisfactoryCoverage")]
		public float SatisfactoryCoverage
		{
			get { return _satisfactoryCoverage; }
			set { _satisfactoryCoverage = value; }
		}

		#endregion Public Properties
	}
}
