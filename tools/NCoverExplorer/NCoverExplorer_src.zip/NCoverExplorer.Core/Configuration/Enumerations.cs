
namespace NCoverExplorer.Core.Configuration
{
	#region Highlight Styles

	/// <summary>
	/// Highlighting style for source code that was covered.
	/// </summary>
	public enum HighlightVisitedCodeStyle
	{
		/// <summary>Apply block background highlighting.</summary>
		Block = 0,
		/// <summary>Apply no highlighting.</summary>
		None = 1,
	}

	/// <summary>
	/// Highlighting style for source code that was covered.
	/// </summary>
	public enum HighlightUnvisitedCodeStyle
	{
		/// <summary>Apply block background highlighting.</summary>
		Block = 0,
		/// <summary>Display wavy line underneath code.</summary>
		Underlined = 1
	}

	#endregion Highlight Styles

	#region TreeSortStyle

	/// <summary>
	/// Sort order for displaying the coverage results in the tree.
	/// </summary>
	public enum TreeSortStyle
	{
		/// <summary>Sort by name (default).</summary>
		Name = 0,
		/// <summary>Sort by name( down to class level) then by line within the class.</summary>
		ClassLine = 1,
		/// <summary>Sort by coverage percentage ascending.</summary>
		CoveragePercentageAscending = 2,
		/// <summary>Sort by coverage percentage descending.</summary>
		CoveragePercentageDescending = 3,
		/// <summary>Sort by unvisited lines ascending.</summary>
		UnvisitedSequencePointsAscending = 4,
		/// <summary>Sort by unvisited lines descending.</summary>
		UnvisitedSequencePointsDescending = 5,
		/// <summary>Sort by visit count ascending.</summary>
		VisitCountAscending = 6,
		/// <summary>Sort by visit count descending.</summary>
		VisitCountDescending = 7
	}

	#endregion TreeSortStyle

	#region Exclusions

	/// <summary>
	/// Exclusion types for automatically suppressing coverage nodes from the output.
	/// </summary>
	public enum ExclusionType
	{
		/// <summary>Exclude assemblies matching this pattern.</summary>
		Assembly = 0,
		/// <summary>Exclude namespaces matching this pattern.</summary>
		Namespace = 1,
		/// <summary>Exclude classes matching this pattern.</summary>
		Class = 2
	}

	/// <summary>
	/// The type of pattern matching to be applied to a coverage exclusion
	/// </summary>
	public enum ExclusionPatternType
	{
		/// <summary>Must be an exact match on the entire name.</summary>
		Exact = 0,
		/// <summary>Name must start with this pattern (e.g. Test*).</summary>
		StartsWith = 1,
		/// <summary>Name must end with this pattern (e.g. *Test).</summary>
		EndsWith = 2,
		/// <summary>Name must contain this pattern (e.g. *Test*).</summary>
		Contains = 3
	}

	#endregion Exclusions

	#region TreeFilterStyle

	/// <summary>
	/// Filter styles that can be applied to the results. Filtered nodes are not excluded from the coverage
	/// statistics.
	/// </summary>
	public enum TreeFilterStyle
	{
		/// <summary>No filter applied.</summary>
		None = 0,
		/// <summary>Hide unvisited nodes.</summary>
		HideUnvisited = 1,
		/// <summary>Hide 100% fully covered nodes.</summary>
		HideFullyCovered = 2
}

	#endregion TreeFilterStyle

	#region CoverageTreeReportStyle

	/// <summary>
	/// Styles of reporting being displayed by the coverage tree (affects the coloring/node text).
	/// </summary>
	public enum CoverageTreeReportStyle
	{
		/// <summary>Default report style showing sequence point percentages/thresholds.</summary>
		SequencePointCoveragePercentage = 0,
		/// <summary>Default report style showing sequence point percentages/thresholds.</summary>
		SequencePointCoveragePercentageAndUnvisitedSeqPts = 1,
		/// <summary>Default report style showing sequence point percentages/thresholds.</summary>
		SequencePointCoverageUnvisitedSequencePoints = 2,
		/// <summary>Alternate report style showing function coverage (visit counts).</summary>
		FunctionCoverage = 3
	}

	#endregion CoverageTreeReportStyle
}
