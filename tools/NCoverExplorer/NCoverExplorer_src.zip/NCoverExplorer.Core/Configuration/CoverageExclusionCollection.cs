using System;
using System.Collections;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Strongly typed collection of CoverageExclusion objects.
	/// </summary>
	[Serializable]
	public class CoverageExclusionCollection : CollectionBase
	{
		#region Private Variables

		private bool _isDirty;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageExclusionCollection"/> class.
		/// </summary>
		public CoverageExclusionCollection()
		{
			_isDirty = false;
		}

		#endregion Constructor

		#region IList Interface Strongly Typed Members
		
		/// <summary>
		/// Add a <see cref="CoverageExclusion"/> object to the collection.
		/// </summary>
		/// <param name="item">The item to add.</param>
		public void Add(CoverageExclusion item)
		{
			this.List.Add(item);
		}

		/// <summary>
		/// Gets or sets the <see cref="CoverageExclusion"/> object at this ordinal index.
		/// </summary>
		public CoverageExclusion this[int index]
		{
			get { return this.List[index] as CoverageExclusion; }
			set { this.List[index] = value; }
		}

		/// <summary>
		/// The remove method that takes a <see cref="CoverageExclusion"/> object.
		/// </summary>
		/// <param name="value">The item to remove.</param>
		public void Remove(CoverageExclusion value)
		{
			this.List.Remove(value);
		}

		/// <summary>
		/// Insert object at this position.
		/// </summary>
		/// <param name="index">Position to insert at.</param>
		/// <param name="value">Object to insert.</param>
		public void Insert(int index, CoverageExclusion value)
		{
			this.List.Insert(index, value);
		}

		/// <summary>
		/// Returns index position of this object.
		/// </summary>
		/// <param name="value">The value.</param>
		/// <returns></returns>
		public int IndexOf(CoverageExclusion value)
		{
			return this.List.IndexOf(value);
		}

		/// <summary>
		/// Returns whether this collection contains this object.
		/// </summary>
		/// <param name="value">Object to find.</param>
		/// <returns>
		/// 	<c>true</c> if contains the specified value; otherwise, <c>false</c>.
		/// </returns>
		public bool Contains(CoverageExclusion value)
		{
			return this.List.Contains(value);
		}

		/// <summary>
		/// Performs additional custom processes after removing an
		/// element from the <see cref="T:System.Collections.CollectionBase"/> instance.
		/// </summary>
		/// <param name="index">The zero-based index at which <paramref name="value"/> can be found.</param>
		/// <param name="value">The value of the element to remove from <paramref name="index"/>.</param>
		protected override void OnRemoveComplete(int index, object value)
		{
			_isDirty = true;
			base.OnRemoveComplete (index, value);
		}

		/// <summary>
		/// Performs additional custom processes after inserting a
		/// new element into the <see cref="T:System.Collections.CollectionBase"/> instance.
		/// </summary>
		/// <param name="index"></param>
		/// <param name="value"></param>
		protected override void OnInsertComplete(int index, object value)
		{
			_isDirty = true;
			base.OnInsertComplete (index, value);
		}

		/// <summary>
		/// Performs additional custom processes after setting a value in the
		/// <see cref="T:System.Collections.CollectionBase"/> instance.
		/// </summary>
		/// <param name="index">The zero-based index at which <paramref name="oldValue"/> can be found.</param>
		/// <param name="oldValue">The value to replace with <paramref name="newValue"/>.</param>
		/// <param name="newValue">The new value of the element at <paramref name="index"/>.</param>
		protected override void OnSetComplete(int index, object oldValue, object newValue)
		{
			_isDirty = true;
			base.OnSetComplete (index, oldValue, newValue);
		}

		#endregion IList Interface Strongly Typed Members

		#region Public Properties

		/// <summary>
		/// Gets or sets a value indicating whether collection has been changed.
		/// </summary>
		/// <value><c>true</c> if this instance is dirty; otherwise, <c>false</c>.</value>
		public bool IsDirty
		{
			get { return _isDirty; }
			set { _isDirty = value; }
		}

		#endregion Public Properties

		#region Clone
		
		/// <summary>
		/// Implements a clone of this collection using serialization into a memory stream.
		/// </summary>
		/// <returns>Clone of object using serialization.</returns>
		public CoverageExclusionCollection Clone()
		{
			using (MemoryStream stream = new MemoryStream())
			{
				try
				{
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					binaryFormatter.Serialize(stream, this);
					stream.Position = 0;
					return (CoverageExclusionCollection)binaryFormatter.Deserialize(stream);
				}
				finally
				{
					stream.Close();
				}
			}
		}

		#endregion ICloneable Interface
	}
}
