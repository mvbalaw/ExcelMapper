using System;
using System.Collections;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Strongly typed collection of MruState objects.
	/// </summary>
	[Serializable]
	public class MruStateCollection : CollectionBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="MruStateCollection"/> class.
		/// </summary>
		public MruStateCollection()
		{
		}

		#endregion Constructor

		#region IList Interface Strongly Typed Members
		
		/// <summary>
		/// Add a <see cref="MruState"/> object to the collection.
		/// </summary>
		/// <param name="item">The item to add.</param>
		public void Add(MruState item)
		{
			this.List.Add(item);
		}

		/// <summary>
		/// Gets or sets the <see cref="MruState"/> object at this ordinal index.
		/// </summary>
		public MruState this[int index]
		{
			get { return this.List[index] as MruState; }
			set { this.List[index] = value; }
		}

		/// <summary>
		/// Gets or sets the <see cref="MruState"/> object with this string id.
		/// </summary>
		public MruState this[string menuId]
		{
			get
			{
				foreach (MruState mruState in this.List)
				{
					if (mruState.MenuId == menuId)
					{
						return mruState;
					}
				}

				return null;
			}
			set
			{
				int foundIndex = this.IndexOf(menuId);
				if ( foundIndex < 0 ) 
				{
					throw new ArgumentOutOfRangeException("menuId", menuId, "This menuId was not found in the collection.");
				}
				else
				{
					this.List.RemoveAt(foundIndex);
					this.List.Insert(foundIndex, value);
				}
			}
		}

		/// <summary>
		/// The remove method that takes a <see cref="MruState"/> object.
		/// </summary>
		/// <param name="value">The item to remove.</param>
		public void Remove(MruState value)
		{
			this.List.Remove(value);
		}

		/// <summary>
		/// Insert object at this position.
		/// </summary>
		/// <param name="index">Position to insert at.</param>
		/// <param name="value">Object to insert.</param>
		public void Insert(int index, MruState value)
		{
			this.List.Insert(index, value);
		}

		/// <summary>
		/// Returns index position of object matching this key.
		/// </summary>
		/// <param name="menuId">Menu Id of matching item to find.</param>
		/// <returns>Index of matching item, -1 if not found.</returns>
		public int IndexOf(string menuId)
		{
			for ( int index = 0; index < this.List.Count; index++ ) 
			{
				if ( ((MruState)this.List[index]).MenuId == menuId ) 
				{
					return index;
				}
			}
			return -1;
		}

		/// <summary>
		/// Returns index position of this object.
		/// </summary>
		/// <param name="value">The value.</param>
		/// <returns></returns>
		public int IndexOf(MruState value)
		{
			return this.List.IndexOf(value);
		}

		/// <summary>
		/// Returns whether this collection contains this object.
		/// </summary>
		/// <param name="value">Object to find.</param>
		/// <returns>
		/// 	<c>true</c> if contains the specified value; otherwise, <c>false</c>.
		/// </returns>
		public bool Contains(MruState value)
		{
			return this.List.Contains(value);
		}

		#endregion IList Interface Strongly Typed Members
	}
}
