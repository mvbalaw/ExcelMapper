using System;
using System.Collections.Specialized;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Persisted settings for a form for later serialization into XML.
	/// </summary>
	[Serializable]
	public class FormState : IXmlSerializable
	{
		#region Private Variables

		private string _formId;
		private StringDictionary _settings;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="FormState"/> class.
		/// </summary>
		public FormState() : this(string.Empty)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="FormState"/> class.
		/// </summary>
		/// <param name="formId">The form id.</param>
		public FormState(string formId)
		{
			_formId = formId;
			_settings = new StringDictionary();

		}

		#endregion Constructors

		#region Public Properties

		/// <summary>
		/// Gets the form id.
		/// </summary>
		/// <value>The form id.</value>
		public string FormId
		{
			get { return _formId; }
		}

		/// <summary>
		/// Gets the count of state settings contained.
		/// </summary>
		/// <value>The count.</value>
		public int Count
		{
			get { return _settings.Count; }
		}

		#endregion Public Properties

		#region	Public Methods

		#region GetString

		/// <summary>
		/// Gets a string setting with the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>Empty string if setting with this key is not found.</returns>
		public string GetString(string key)
		{
			return GetString(key, string.Empty);
		}

		/// <summary>
		/// Gets a string setting with the specified key.
		/// If it does not exist, returns the <c>defaultValue</c>.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="defaultValue">The default value.</param>
		/// <returns>Default value if setting with this key is not found.</returns>
		public string GetString(string key, string defaultValue)
		{
			if (_settings.ContainsKey(key))
			{
				return _settings[key];
			}
			else
			{
				return defaultValue;
			}
		}

		#endregion GetString

		#region GetBoolean

		/// <summary>
		/// Gets a boolean setting with the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>False if setting with this key is not found.</returns>
		public bool GetBoolean(string key)
		{
			return GetBoolean(key, false);
		}

		/// <summary>
		/// Gets a boolean setting with the specified key.
		/// If it does not exist, returns the <c>defaultValue</c>.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="defaultValue">The default value.</param>
		/// <returns>Default value if setting with this key is not found.</returns>
		public bool GetBoolean(string key, bool defaultValue)
		{
			if (_settings.ContainsKey(key))
			{
				return bool.Parse(_settings[key]);
			}
			else
			{
				return defaultValue;
			}
		}

		#endregion GetBoolean

		#region GetInt32

		/// <summary>
		/// Gets an integer setting with the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>0 if setting with this key is not found.</returns>
		public int GetInt32(string key)
		{
			return GetInt32(key, 0);
		}

		/// <summary>
		/// Gets an integer setting with the specified key.
		/// If it does not exist, returns the <c>defaultValue</c>.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="defaultValue">The default value.</param>
		/// <returns>Default value if setting with this key is not found.</returns>
		public int GetInt32(string key, int defaultValue)
		{
			if (_settings.ContainsKey(key))
			{
				return int.Parse(_settings[key]);
			}
			else
			{
				return defaultValue;
			}
		}

		#endregion GetInt32

		#region GetSingle

		/// <summary>
		/// Gets a float setting with the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>0 if setting with this key is not found.</returns>
		public float GetSingle(string key)
		{
			return GetSingle(key, 0);
		}

		/// <summary>
		/// Gets a float setting with the specified key.
		/// If it does not exist, returns the <c>defaultValue</c>.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="defaultValue">The default value.</param>
		/// <returns>Default value if setting with this key is not found.</returns>
		public float GetSingle(string key, float defaultValue)
		{
			if (_settings.ContainsKey(key))
			{
				return float.Parse(_settings[key]);
			}
			else
			{
				return defaultValue;
			}
		}

		#endregion GetSingle

		#region GetDouble

		/// <summary>
		/// Gets a double setting with the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>0 if setting with this key is not found.</returns>
		public double GetDouble(string key)
		{
			return GetDouble(key, 0);
		}

		/// <summary>
		/// Gets a double setting with the specified key.
		/// If it does not exist, returns the <c>defaultValue</c>.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="defaultValue">The default value.</param>
		/// <returns>Default value if setting with this key is not found.</returns>
		public double GetDouble(string key, double defaultValue)
		{
			if (_settings.ContainsKey(key))
			{
				return double.Parse(_settings[key]);
			}
			else
			{
				return defaultValue;
			}
		}

		#endregion GetDouble

		#region GetDecimal

		/// <summary>
		/// Gets a decimal setting with the specified key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>0 if setting with this key is not found.</returns>
		public decimal GetDecimal(string key)
		{
			return GetDecimal(key, 0);
		}

		/// <summary>
		/// Gets a decimal setting with the specified key.
		/// If it does not exist, returns the <c>defaultValue</c>.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="defaultValue">The default value.</param>
		/// <returns>Default value if setting with this key is not found.</returns>
		public decimal GetDecimal(string key, decimal defaultValue)
		{
			if (_settings.ContainsKey(key))
			{
				return decimal.Parse(_settings[key]);
			}
			else
			{
				return defaultValue;
			}
		}

		#endregion GetDecimal

		#region SetValue

		/// <summary>
		/// Sets the state value for this key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		public void SetValue(string key, string value)
		{
			_settings[key] = value;
		}

		/// <summary>
		/// Sets the state value for this key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		public void SetValue(string key, int value)
		{
			_settings[key] = value.ToString();
		}

		/// <summary>
		/// Sets the state value for this key.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <param name="value">The value.</param>
		public void SetValue(string key, object value)
		{
			_settings[key] = value.ToString();
		}

		#endregion SetValue

		#region StringDictionary Wrappers

		/// <summary>
		/// Clears the settings for this form.
		/// </summary>
		public void Clear()
		{
			_settings.Clear();
		}

		/// <summary>
		/// Determines whether the specified key exists.
		/// </summary>
		/// <param name="key">The key.</param>
		/// <returns>
		/// 	<c>true</c> if the specified key exists; otherwise, <c>false</c>.
		/// </returns>
		public bool ContainsKey(string key)
		{
			return _settings.ContainsKey(key);
		}

		/// <summary>
		/// Determines whether the specified value exists.
		/// </summary>
		/// <param name="value">The value.</param>
		/// <returns>
		/// 	<c>true</c> if the specified value exists; otherwise, <c>false</c>.
		/// </returns>
		public bool ContainsValue(string value)
		{
			return _settings.ContainsValue(value);
		}

		#endregion StringDictionary Wrappers

		#endregion Public Methods

		#region IXmlSerializable

		/// <summary>
		/// Obsoleted in .Net 2.0 so no implementation.
		/// </summary>
		/// <returns>null</returns>
		XmlSchema IXmlSerializable.GetSchema()
		{
			return null;
		}

		/// <summary>
		/// Perform manual deserialization of this object when used with an XmlSerializer, required to
		/// deserialize the dictionary of settings.
		/// </summary>
		/// <param name="reader">XmlReader stream processing the data.</param>
		void IXmlSerializable.ReadXml(XmlReader reader)
		{
			_formId = reader.GetAttribute("FormId"); 
			reader.Read();	// Move to next node.
			reader.Read();	// Settings node

			string key;
			string value;

			if (reader.HasAttributes)
			{
				while (reader.HasAttributes)
				{
					key = reader.GetAttribute("Key"); 
					value = reader.GetAttribute("Value");
					_settings[key] = value;
					reader.Read();
				}
				reader.Read();
			}

			// Make sure we also read the closing element for this object (makes collections work!)
			reader.Read();
		}

		/// <summary>
		/// Perform manual serialization of this object when used with an XmlSerializer, required to
		/// serialize the dictionary of settings.
		/// </summary>
		/// <param name="writer">XmlWriter stream to add the data into.</param>
		void IXmlSerializable.WriteXml(XmlWriter writer)
		{
			writer.WriteAttributeString("FormId", _formId);
			writer.WriteStartElement("Settings");
			foreach (string key in _settings.Keys)
			{
				writer.WriteStartElement("Setting");
				writer.WriteAttributeString("Key", key);
				writer.WriteAttributeString("Value", _settings[key]);
				writer.WriteEndElement();
			}
			writer.WriteEndElement();
		}

		#endregion IXmlSerializable
	}
}
