using System;
using System.Xml.Serialization;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Configuration information that is serialized to/from an xml file.
	/// </summary>
	[XmlRoot(Namespace="", IsNullable=false, ElementName="NCoverExplorer")]
	[Serializable]
	public class PersistentConfiguration
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="PersistentConfiguration"/> class.
		/// </summary>
		public PersistentConfiguration()
		{
			SatisfactoryCoverageThreshold = 95;
			SatisfactoryUnvisitedSequencePoints = 0;
			GroupByModule = true;
			FlattenNamespaces = true;
			RestoreSelectionOnReload = true;
			NumberOfRecentFiles = 10;
			FormStates = new FormStateCollection();
			MruStates = new MruStateCollection();
			CoverageTreeReportStyle = CoverageTreeReportStyle.SequencePointCoveragePercentage;
			Theme = new Theme();
			ProjectName = string.Empty;

			CoverageExclusions = new CoverageExclusionCollection();
			ModuleThresholds = new ModuleThresholdCollection();
		}

		#endregion Constructor

		#region Properties

		/// <summary>
		/// Gets or sets the percentage coverage considered acceptable to colour differently.
		/// </summary>
		public float SatisfactoryCoverageThreshold;

		/// <summary>
		/// Gets or sets the number of unvisited lines considered acceptable to colour differently.
		/// </summary>
		public int SatisfactoryUnvisitedSequencePoints;

		/// <summary>
		/// Gets or sets whether to group the nodes in the tree by assembly (alternative is by namespace).
		/// </summary>
		public bool GroupByModule;

		/// <summary>
		/// Gets or sets whether to flatten child namespaces (VS2005 style) or nest them (VS2003 style).
		/// </summary>
		public bool FlattenNamespaces;

		/// <summary>
		/// Gets or sets whether to restore the selected node/source code position when reloading a file.
		/// </summary>
		public bool RestoreSelectionOnReload;

		/// <summary>
		/// Gets or sets the number of recent files listed in the File menu.
		/// </summary>
		public int NumberOfRecentFiles;

		/// <summary>
		/// Gets or sets the current theme settings applied.
		/// </summary>
		public Theme Theme;

		/// <summary>
		/// Gets or sets the project name for use in generated reports.
		/// </summary>
		public string ProjectName;

		/// <summary>
		/// Gets the collection of form data persistence data such as position and size for each form.
		/// </summary>
		public readonly FormStateCollection FormStates;

		/// <summary>
		/// Gets the collection of most recently used lists.
		/// </summary>
		public readonly MruStateCollection MruStates;

		/// <summary>
		/// Gets or sets the coverage tree report style (sequence points or function coverage).
		/// </summary>
		public CoverageTreeReportStyle CoverageTreeReportStyle;

		/// <summary>
		/// Gets or sets the collection of exclusion patterns to apply after reading a coverage.xml file.
		/// </summary>
		public CoverageExclusionCollection CoverageExclusions;

		/// <summary>
		/// Gets or sets the collection of module specific coverage thresholds.
		/// </summary>
		public ModuleThresholdCollection ModuleThresholds;

		#endregion Properties
	}
}
