using System.Drawing;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Serialized to string version of a Font object for storing in xml files.
	/// </summary>
	public struct XmlFont
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="XmlFont"/> class.
		/// </summary>
		/// <param name="font">The font.</param>
		public XmlFont(Font font)
		{
			FontFamily = font.FontFamily.Name;
			GraphicsUnit = font.Unit;
			Size = font.Size;
			Style = font.Style;
		}

		#endregion Constructor

		#region Public Properties

		public string FontFamily;
		public GraphicsUnit GraphicsUnit;
		public float Size;
		public FontStyle Style;

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Converts this object into a Font object.
		/// </summary>
		/// <returns>Font object.</returns>
		public Font ToFont()
		{
			return new Font(FontFamily, Size, Style, GraphicsUnit);
		}

		#endregion Public Methods
	}
}
