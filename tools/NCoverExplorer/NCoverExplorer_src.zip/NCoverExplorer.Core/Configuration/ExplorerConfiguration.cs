using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Xml.Serialization;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Container instance for configuration options for NCoverExplorer.
	/// </summary>
	[Serializable]
	public class ExplorerConfiguration : IExplorerConfiguration
	{
		#region Private Variables

		private IThemeManager _themeManager;
		private ThemeCollection _themes;
		private PersistentConfiguration _persistentConfiguration;
		private CommandLineOptions _commandLineOptions;
		private bool _warnAboutMissingSourceCode;
		private readonly string _configFileName;
		private TreeSortStyle _treeSortStyle;
		private TreeFilterStyle _treeFilterStyle;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ExplorerConfiguration"/> class.
		/// </summary>
		/// <param name="commandLineOptions">The command line options.</param>
		public ExplorerConfiguration(CommandLineOptions commandLineOptions)
			: this(commandLineOptions, _GetDefaultThemeManager(), _GetDefaultSettingsFileName())
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ExplorerConfiguration"/> class.
		/// </summary>
		/// <param name="commandLineOptions">The command line options.</param>
		/// <param name="themeManager">The theme manager.</param>
		public ExplorerConfiguration(CommandLineOptions commandLineOptions, IThemeManager themeManager)
			: this(commandLineOptions, themeManager, _GetDefaultSettingsFileName())
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="ExplorerConfiguration"/> class.
		/// </summary>
		/// <param name="commandLineOptions">The command line options.</param>
		/// <param name="themeManager">The theme manager.</param>
		/// <param name="configFileName">Name of the configuration file.</param>
		public ExplorerConfiguration(CommandLineOptions commandLineOptions, IThemeManager themeManager, string configFileName)
		{
			_commandLineOptions = commandLineOptions;
			_configFileName = configFileName;
			_themeManager = themeManager;
			_treeSortStyle = TreeSortStyle.Name;
			_treeFilterStyle = Configuration.TreeFilterStyle.None;
			_warnAboutMissingSourceCode = true;

			_ReadConfigurationFile();
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the percentage coverage considered acceptable to colour differently.
		/// </summary>
		/// <value>The satisfactory coverage threshold.</value>
		public float SatisfactoryCoverageThreshold
		{
			get { return _persistentConfiguration.SatisfactoryCoverageThreshold; }
			set { _persistentConfiguration.SatisfactoryCoverageThreshold = value; }
		}

		/// <summary>
		/// Gets or sets the number of unvisited sequence points considered acceptable to colour differently.
		/// </summary>
		/// <value>The satisfactory number of unvisited sequence points.</value>
		public int SatisfactoryUnvisitedSequencePoints
		{
			get { return _persistentConfiguration.SatisfactoryUnvisitedSequencePoints; }
			set { _persistentConfiguration.SatisfactoryUnvisitedSequencePoints = value; }
		}

		/// <summary>
		/// Gets or sets whether to group the nodes in the tree by module (alternative is by namespace).
		/// </summary>
		/// <value>
		/// 	<c>true</c> if group by module; otherwise, <c>false</c> if group by namespace.
		/// </value>
		public bool GroupByModule
		{
			get { return _persistentConfiguration.GroupByModule; }
			set { _persistentConfiguration.GroupByModule = value; }
		}

		/// <summary>
		/// Gets or sets whether to flatten child namespaces (VS2005 style) or nest them (VS2003 style).
		/// </summary>
		/// <value><c>true</c> if flatten namespaces; otherwise, <c>false</c>.</value>
		public bool FlattenNamespaces 
		{ 
			get { return _persistentConfiguration.FlattenNamespaces; }
			set { _persistentConfiguration.FlattenNamespaces = value; }
		}

		/// <summary>
		/// Gets or sets whether to restore the selected node/source code position when reloading a file.
		/// </summary>
		/// <value><c>true</c> if restore selection on reload; otherwise, <c>false</c>.</value>
		public bool RestoreSelectionOnReload
		{
			get { return _persistentConfiguration.RestoreSelectionOnReload; }
			set { _persistentConfiguration.RestoreSelectionOnReload = value; }
		}

		/// <summary>
		/// Gets or sets whether to popup a warning dialog when source code cannot be found.
		/// </summary>
		/// <value><c>true</c> if popup a warning dialog; otherwise, <c>false</c>.</value>
		public bool WarnAboutMissingSourceCode
		{
			get { return _warnAboutMissingSourceCode; }
			set { _warnAboutMissingSourceCode = value; }
		}

		/// <summary>
		/// Gets or sets the number of recent files listed in the File menu.
		/// </summary>
		public int NumberOfRecentFiles
		{
			get { return _persistentConfiguration.NumberOfRecentFiles; }
			set { _persistentConfiguration.NumberOfRecentFiles = value; }
		}

		/// <summary>
		/// Gets the form settings containing persisted data for each form such as size and position.
		/// </summary>
		/// <value>The form settings collection.</value>
		public FormStateCollection FormStates
		{
			get { return _persistentConfiguration.FormStates; }
		}

		/// <summary>
		/// Gets the collection of most recently used lists.
		/// </summary>
		/// <value>The mru collection.</value>
		public MruStateCollection MruStates
		{
			get { return _persistentConfiguration.MruStates; }
		}

		/// <summary>
		/// Gets the coverage tree report style (sequence points or function coverage).
		/// </summary>
		/// <value>The coverage tree report style.</value>
		public CoverageTreeReportStyle CoverageTreeReportStyle
		{
			get { return _persistentConfiguration.CoverageTreeReportStyle; }
			set { _persistentConfiguration.CoverageTreeReportStyle = value; }
		}

		/// <summary>
		/// Gets the collection of exclusion patterns to apply after reading a coverage.xml file.
		/// </summary>
		public CoverageExclusionCollection CoverageExclusions 
		{ 
			get { return _persistentConfiguration.CoverageExclusions; }
			set { _persistentConfiguration.CoverageExclusions = value; }
		}

		/// <summary>
		/// Gets or sets the theme appearance properties such as highlighting colours.
		/// </summary>
		/// <value>The theme.</value>
		public Theme Theme
		{
			get { return _persistentConfiguration.Theme; }
			set { _persistentConfiguration.Theme = value; }
		}

		/// <summary>
		/// Gets the available themes to choose from for appearance.
		/// </summary>
		/// <value>The themes.</value>
		public ThemeCollection Themes 
		{ 
			get 
			{
				if (_themes == null && _themeManager != null)
				{
					_themes = _themeManager.Load();
				}
				return _themes; 
			}
		}

		/// <summary>
		/// Gets or sets the project name for use in generated reports.
		/// </summary>
		/// <value>The theme.</value>
		public string ProjectName
		{
			get { return _persistentConfiguration.ProjectName; }
			set { _persistentConfiguration.ProjectName = value; }
		}

		/// <summary>
		/// Gets or sets the collection of module specific coverage thresholds.
		/// </summary>
		public ModuleThresholdCollection ModuleThresholds 
		{ 
			get { return _persistentConfiguration.ModuleThresholds; }
			set { _persistentConfiguration.ModuleThresholds = value; }
		}

		/// <summary>
		/// Gets or sets the sort order to apply to the tree.
		/// </summary>
		public TreeSortStyle TreeSortStyle
		{
			get { return _treeSortStyle; }
			set { _treeSortStyle = value; }
		}

		/// <summary>
		/// Gets or sets the filter to apply to the tree.
		/// </summary>
		public TreeFilterStyle TreeFilterStyle
		{
			get { return _treeFilterStyle; }
			set { _treeFilterStyle = value; }
		}

		/// <summary>
		/// Gets the command line options passed in when executing the application.
		/// </summary>
		public CommandLineOptions CommandLineOptions
		{
			get { return _commandLineOptions; }
		}

		/// <summary>
		/// Gets the filename of the configuration file.
		/// </summary>
		/// <value>The filename of the configuration file.</value>
		public string FileName
		{
			get { return _configFileName; }
		}

		#endregion Public Properties

		#region Public Methods

		/// <summary>
		/// Reloads the configuration file.
		/// </summary>
		public void Reload()
		{
			_ReadConfigurationFile();
		}

		/// <summary>
		/// Persists the configuration file.
		/// </summary>
		public void Persist()
		{
			_WriteConfigurationFile();
		}

		/// <summary>
		/// Clones the configuration information.
		/// </summary>
		public IExplorerConfiguration Clone()
		{
			using (MemoryStream stream = new MemoryStream())
			{
				try
				{
					BinaryFormatter binaryFormatter = new BinaryFormatter();
					binaryFormatter.Serialize(stream, this);
					stream.Position = 0;
					return (IExplorerConfiguration)binaryFormatter.Deserialize(stream);
				}
				finally
				{
					stream.Close();
				}
			}		
		}

		#endregion Public Methods

		#region Private Methods

		/// <summary>
		/// Gets the configuration settings file name. Will reside in user local profile directory.
		/// </summary>
		/// <returns>File name.</returns>
		private static string _GetDefaultSettingsFileName()
		{
			return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), 
				@"KiwiDevelopment\NCoverExplorer\NCoverExplorer.config");
		}

		/// <summary>
		/// Gets the themes file name. Will reside in use local profile directory.
		/// </summary>
		/// <returns></returns>
		private static IThemeManager _GetDefaultThemeManager()
		{
			string themeFileName = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), 
				@"KiwiDevelopment\NCoverExplorer\NCoverExplorer.Themes.xml");
			return new FileThemeManager(themeFileName);
		}

		/// <summary>
		/// Reads the configuration file if it exists.
		/// </summary>
		private void _ReadConfigurationFile()
		{
			if (!File.Exists(_configFileName))
			{
				_persistentConfiguration = new PersistentConfiguration();
			}
			else
			{
				XmlSerializer serializer = new XmlSerializer(typeof (PersistentConfiguration));

				try
				{
					using (StreamReader configFile = File.OpenText(_configFileName))
					{
						_persistentConfiguration = (PersistentConfiguration) serializer.Deserialize(configFile);
					}
				}
				catch (Exception)
				{
					// Some problem with retrieving the serialized configuration - revert to defaults.
					_persistentConfiguration = new PersistentConfiguration();
				}
			}

			// Grant - added to ensure everyone upgrading from 1.3.2 betas to the real release.
			// This does create an issue - if someone does NOT want it then they must add some other sort of
			// exclusion so that the count is zero. Perhaps this can be removed in a future release by which
			// time either people will have upgraded or they will be forced to add the exclusion themselves.
			if (_persistentConfiguration.CoverageExclusions.Count == 0)
			{
				CoverageExclusions.Add(new CoverageExclusion(ExclusionType.Assembly, "*.Tests"));
				CoverageExclusions.Add(new CoverageExclusion(ExclusionType.Namespace, "*.My*"));
			}
			CoverageExclusions.IsDirty = false;
		}

		/// <summary>
		/// Overwrite the configuration file.
		/// </summary>
		private void _WriteConfigurationFile()
		{
			XmlSerializer serializer = new XmlSerializer(typeof (PersistentConfiguration));

			string directory = Path.GetDirectoryName(_configFileName);
			if (!Directory.Exists(directory))
			{
				Directory.CreateDirectory(directory);
			}

			using (StreamWriter configFile = File.CreateText(_configFileName))
			{
				serializer.Serialize(configFile, _persistentConfiguration);
				configFile.Flush();
				configFile.Close();
			}
			CoverageExclusions.IsDirty = false;

			// Now try saving the themes if we have specified some.
			if (_themeManager != null && _themes != null)
			{
				_themeManager.Persist(_themes);
			}
		}

		#endregion Private Methods
	}
}
