using NCoverExplorer.Core.CoverageTree;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Summary description for CoverageExclusionManager.
	/// </summary>
	public class CoverageExclusionManager : ICoverageExclusionManager
	{
		#region Private Variables

		private CoverageExclusionCollection _assemblyExclusions;
		private CoverageExclusionCollection _namespaceExclusions;
		private CoverageExclusionCollection _classExclusions;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageExclusionManager"/> class.
		/// </summary>
		public CoverageExclusionManager(CoverageExclusionCollection coverageExclusions)
		{
			_assemblyExclusions = new CoverageExclusionCollection();
			_namespaceExclusions = new CoverageExclusionCollection();
			_classExclusions = new CoverageExclusionCollection();

			_SplitEnabledExclusionsIntoCollections(coverageExclusions);
		}

		#endregion Constructor

		#region ICoverageExclusionManager Members

		/// <summary>
		/// Determines whether an assembly exclusion applies to this node so as to remove it from coverage.
		/// </summary>
		/// <param name="moduleTreeNode">The module tree node.</param>
		/// <returns>
		/// 	<c>true</c> if node should be removed from the coverage tree.
		/// </returns>
		public bool IsAssemblyExclusionApplicable(ModuleTreeNode moduleTreeNode)
		{
			foreach (CoverageExclusion coverageExclusion in _assemblyExclusions)
			{
				if (coverageExclusion.IsMatchingExclusion(moduleTreeNode.AssemblyName))
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Determines whether a namespace exclusion applies to this node so as to remove it from coverage.
		/// </summary>
		/// <param name="namespaceTreeNode">The namespace tree node.</param>
		/// <returns>
		/// 	<c>true</c> if node should be removed from the coverage tree.
		/// </returns>
		public bool IsNamespaceExclusionApplicable(NamespaceTreeNode namespaceTreeNode)
		{
			foreach (CoverageExclusion coverageExclusion in _namespaceExclusions)
			{
				if (coverageExclusion.IsMatchingExclusion(namespaceTreeNode.FullyQualifiedName))
				{
					return true;
				}
			}
			return false;
		}

		/// <summary>
		/// Determines whether a class exclusion applies to this node so as to remove it from coverage.
		/// </summary>
		/// <param name="classTreeNode">The class tree node.</param>
		/// <returns>
		/// 	<c>true</c> if node should be removed from the coverage tree.
		/// </returns>
		public bool IsClassExclusionApplicable(ClassTreeNode classTreeNode)
		{
			foreach (CoverageExclusion coverageExclusion in _classExclusions)
			{
				if (coverageExclusion.IsMatchingExclusion(classTreeNode.FullyQualifiedName))
				{
					return true;
				}
			}
			return false;
		}

		#endregion ICoverageExclusionManager Members

		#region Private Methods
		
		private void _SplitEnabledExclusionsIntoCollections(CoverageExclusionCollection coverageExclusions)
		{
			foreach (CoverageExclusion coverageExclusion in coverageExclusions)
			{
				if (coverageExclusion.Enabled)
				{
					switch (coverageExclusion.ExclusionType)
					{
						case ExclusionType.Assembly:
							_assemblyExclusions.Add(coverageExclusion);
							break;

						case ExclusionType.Namespace:
							_namespaceExclusions.Add(coverageExclusion);
							break;

						case ExclusionType.Class:
							_classExclusions.Add(coverageExclusion);
							break;
					}
				}
			}
		}

		#endregion Private Methods
	}
}