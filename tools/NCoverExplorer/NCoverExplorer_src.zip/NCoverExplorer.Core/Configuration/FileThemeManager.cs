using System;
using System.IO;
using System.Reflection;
using System.Xml.Serialization;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Class with responsibility for persisting and restoring the available themes.
	/// </summary>
	[Serializable]
	public class FileThemeManager : IThemeManager
	{
		#region Private Variables

		private readonly string _themesFileName;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="FileThemeManager"/> class.
		/// </summary>
		public FileThemeManager()
		{
			_themesFileName = null;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="FileThemeManager"/> class.
		/// </summary>
		/// <param name="themeFileName">Name of the theme file.</param>
		public FileThemeManager(string themeFileName)
		{
			_themesFileName = themeFileName;
		}

		#endregion Constructors

		#region Public Methods

		/// <summary>
		/// Reads the themes file if it exists, uses the embedded resource if it does not.
		/// </summary>
		public ThemeCollection Load()
		{
			ThemeCollection themes;

			XmlSerializer serializer = new XmlSerializer(typeof(ThemeCollection));

			if ((_themesFileName != null) && (_themesFileName.Length > 0) && File.Exists(_themesFileName))
			{
				// Use the physical file as the source
				try
				{
					using (StreamReader themeFile = File.OpenText(_themesFileName))
					{
						themes = (ThemeCollection)serializer.Deserialize(themeFile);
					}
				}
				catch (Exception)
				{
					themes = LoadDefaultThemes();
				}
			}
			else
			{
				themes = LoadDefaultThemes();
			}

			return themes;
		}

		/// <summary>
		/// Overwrite/create the themes file.
		/// </summary>
		/// <param name="themes">The themes.</param>
		public void Persist(ThemeCollection themes)
		{
			if ((_themesFileName == null) || (_themesFileName.Length == 0))
			{
				throw new ArgumentNullException("themesFileName", "You must specify a valid filename for persisting themes.");
			}
			if (themes == null)
			{
				throw new ArgumentNullException("themes", "You must have a themes collection to persist.");
			}

			string directory = Path.GetDirectoryName(_themesFileName);
			if (!Directory.Exists(directory))
			{
				Directory.CreateDirectory(directory);
			}

			XmlSerializer serializer = new XmlSerializer(typeof (ThemeCollection));
			using (StreamWriter themeFile = File.CreateText(_themesFileName))
			{
				serializer.Serialize(themeFile, themes);
				themeFile.Flush();
			}
		}

		/// <summary>
		/// Reads the embedded resource themes as the current collection.
		/// </summary>
		/// <returns>Themes collection.</returns>
		public ThemeCollection LoadDefaultThemes()
		{
			ThemeCollection themes;
			// Use the embedded file as the source.
			Assembly assembly = Assembly.GetExecutingAssembly();
			XmlSerializer serializer = new XmlSerializer(typeof (ThemeCollection));
			using (Stream stream = assembly.GetManifestResourceStream("NCoverExplorer.Core.Configuration.DefaultThemes.xml"))
			{
				themes = (ThemeCollection) serializer.Deserialize(stream);
			}
			return themes;
		}

		#endregion Public Methods
	}
}
