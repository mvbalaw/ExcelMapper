using System;
using System.Collections;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Strongly typed collection of ModuleThreshold objects.
	/// </summary>
	[Serializable]
	public class ModuleThresholdCollection : CollectionBase
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ModuleThresholdCollection"/> class.
		/// </summary>
		public ModuleThresholdCollection()
		{
		}

		#endregion Constructor

		#region IList Interface Strongly Typed Members
		
		/// <summary>
		/// Add a <see cref="ModuleThreshold"/> object to the collection.
		/// </summary>
		/// <param name="item">The item to add.</param>
		public void Add(ModuleThreshold item)
		{
			this.List.Add(item);
		}

		/// <summary>
		/// Gets or sets the <see cref="ModuleThreshold"/> object at this ordinal index.
		/// </summary>
		public ModuleThreshold this[int index]
		{
			get { return this.List[index] as ModuleThreshold; }
			set { this.List[index] = value; }
		}

		/// <summary>
		/// Gets or sets the <see cref="ModuleThreshold"/> object with this module name.
		/// </summary>
		public ModuleThreshold this[string moduleName]
		{
			get 
			{ 
				foreach (ModuleThreshold moduleThreshold in this.List)
				{
					if (moduleThreshold.ModuleName == moduleName)
					{
						return moduleThreshold;
					}
				}
				return null; 
			}
		}

		/// <summary>
		/// The remove method that takes a <see cref="ModuleThreshold"/> object.
		/// </summary>
		/// <param name="value">The item to remove.</param>
		public void Remove(ModuleThreshold value)
		{
			this.List.Remove(value);
		}

		/// <summary>
		/// Insert object at this position.
		/// </summary>
		/// <param name="index">Position to insert at.</param>
		/// <param name="value">Object to insert.</param>
		public void Insert(int index, ModuleThreshold value)
		{
			this.List.Insert(index, value);
		}

		/// <summary>
		/// Returns index position of this object.
		/// </summary>
		/// <param name="value">The value.</param>
		/// <returns></returns>
		public int IndexOf(ModuleThreshold value)
		{
			return this.List.IndexOf(value);
		}

		/// <summary>
		/// Returns whether this collection contains this object.
		/// </summary>
		/// <param name="value">Object to find.</param>
		/// <returns>
		/// 	<c>true</c> if contains the specified value; otherwise, <c>false</c>.
		/// </returns>
		public bool Contains(ModuleThreshold value)
		{
			return this.List.Contains(value);
		}

		/// <summary>
		/// Returns whether this collection contains this object.
		/// </summary>
		/// <param name="moduleName">Name of the module.</param>
		/// <returns>
		/// 	<c>true</c> if contains the specified value; otherwise, <c>false</c>.
		/// </returns>
		public bool Contains(string moduleName)
		{
			foreach (ModuleThreshold moduleThreshold in this.List)
			{
				if (moduleThreshold.ModuleName == moduleName)
				{
					return true;
				}
			}
			return false;
		}

		#endregion IList Interface Strongly Typed Members
	}
}
