using System;
using System.Collections.Specialized;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Persisted settings for a most recently used item for later serialization into XML.
	/// </summary>
	[Serializable]
	public class MruState : StringCollection, IXmlSerializable
	{
		#region Private Variables

		private string _menuId;

		#endregion Private Variables

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="MruState"/> class.
		/// </summary>
		public MruState() : this(string.Empty)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MruState"/> class.
		/// </summary>
		/// <param name="menuId">The menu id.</param>
		public MruState(string menuId)
		{
			_menuId = menuId;
		}

		#endregion Constructors

		#region Public Properties

		/// <summary>
		/// Gets the menu id.
		/// </summary>
		/// <value>The menu id.</value>
		public string MenuId
		{
			get { return _menuId; }
		}

		#endregion Public Properties

		#region IXmlSerializable

		/// <summary>
		/// Obsoleted in .Net 2.0 so no implementation.
		/// </summary>
		/// <returns>null</returns>
		XmlSchema IXmlSerializable.GetSchema()
		{
			return null;
		}

		/// <summary>
		/// Perform manual deserialization of this object when used with an XmlSerializer, required to
		/// deserialize the arraylist of settings.
		/// </summary>
		/// <param name="reader">XmlReader stream processing the data.</param>
		void IXmlSerializable.ReadXml(XmlReader reader)
		{
			_menuId = reader.GetAttribute("MenuId"); 
			reader.Read();	// Move to next node.
			reader.Read();	// Items node

			string item;

			if (reader.HasAttributes)
			{
				while (reader.HasAttributes)
				{
					item = reader.GetAttribute("Name");
					this.Add(item);
					reader.Read();
				}
				reader.Read();
			}

			// Make sure we also read the closing element for this object (makes collections work!)
			reader.Read();
		}

		/// <summary>
		/// Perform manual serialization of this object when used with an XmlSerializer, required to
		/// serialize the arraylist of settings.
		/// </summary>
		/// <param name="writer">XmlWriter stream to add the data into.</param>
		void IXmlSerializable.WriteXml(XmlWriter writer)
		{
			writer.WriteAttributeString("MenuId", _menuId);
			writer.WriteStartElement("Items");
			foreach (string item in this)
			{
				writer.WriteStartElement("Item");
				writer.WriteAttributeString("Name", item);
				writer.WriteEndElement();
			}
			writer.WriteEndElement();
		}

		#endregion IXmlSerializable
	}
}
