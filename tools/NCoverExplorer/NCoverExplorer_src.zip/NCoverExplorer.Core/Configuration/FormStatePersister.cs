using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Gets and sets form size, position and custom properties from the persistent configuration store (xml file).
	/// </summary>
	public class FormStatePersister
	{
		#region Events

		public event FormStateEventHandler LoadState;
		public event FormStateEventHandler SaveState;

		#endregion Events

		#region Private Variables

		private string _formId;
		private FormStateCollection _formStates;

		private Form _form;
		private int _normalLeft;
		private int _normalTop;
		private int _normalWidth;
		private int _normalHeight;
		private FormWindowState _windowState;
		private bool _allowSaveMinimized = false;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="FormStatePersister"/> class.
		/// </summary>
		/// <param name="parent">The parent form.</param>
		/// <param name="formId">The form id.</param>
		/// <param name="formStates">The form states.</param>
		public FormStatePersister(Form parent, string formId, FormStateCollection formStates)
		{
			_form = parent;
			_formId = formId;
			_formStates = formStates;

			// subscribe to parent form's events
			_form.Load += new EventHandler(_OnLoad);
			_form.Closing += new CancelEventHandler(_OnClosing);
			_form.Move += new EventHandler(_OnMove);
			_form.Resize += new EventHandler(_OnResize);

			// get initial width and height in case form is never resized
			_normalWidth = _form.Width;
			_normalHeight = _form.Height;
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets or sets the form this persistence class is associated with.
		/// </summary>
		/// <value>The parent.</value>
		public Form Form
		{
			get { return _form; }
		}

		/// <summary>
		/// Gets or sets a value indicating whether allow save of state when form is minimized.
		/// </summary>
		/// <value><c>true</c> if allow save minimized; otherwise, <c>false</c>.</value>
		public bool AllowSaveMinimized
		{
			get { return _allowSaveMinimized; }
			set { _allowSaveMinimized = value; }
		}

		#endregion Public Properties

		#region Private Methods

		/// <summary>
		/// Called when the form is loading to retrieve state information.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnLoad(object sender, EventArgs e)
		{
			// attempt to read state from registry
			FormState formState = _formStates[_formId];
			if (formState != null)
			{
				int left = formState.GetInt32("Left", _form.Left);
				int top = formState.GetInt32("Top", _form.Top);
				_form.Location = new Point(left, top);

				if (_form.FormBorderStyle == FormBorderStyle.Sizable)
				{
					int width = formState.GetInt32("Width", _form.Width);
					int height = formState.GetInt32("Height", _form.Height);
					_form.Size = new Size(width, height);
				}

				FormWindowState windowState = (FormWindowState)formState.GetInt32("WindowState", (int)_form.WindowState);
				_form.WindowState = windowState;

				// fire LoadState event
				if (LoadState != null)
				{
					LoadState(this, new FormStateEventArgs(formState));
				}
			}
		}

		/// <summary>
		/// Called when the form is closing to persist state information.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.ComponentModel.CancelEventArgs"/> instance containing the event data.</param>
		private void _OnClosing(object sender, CancelEventArgs e)
		{
			// Save position, size and state
			FormState formState = _formStates[_formId];
			if (formState == null)
			{
				formState = new FormState(_formId);
				_formStates.Add(formState);
			}
			else
			{
				// Ensure we do not carry forward anything from a previous use of this form.
				formState.Clear();
			}
			formState.SetValue("Left", _normalLeft);
			formState.SetValue("Top", _normalTop);
			if (_form.FormBorderStyle == FormBorderStyle.Sizable)
			{
				formState.SetValue("Width", _normalWidth);
				formState.SetValue("Height", _normalHeight);
			}

			// Check if we are allowed to save the state as minimized (not normally)
			if (!_allowSaveMinimized)
			{
				if (_windowState == FormWindowState.Minimized)
				{
					_windowState = FormWindowState.Normal;
				}
			}

			formState.SetValue("WindowState", (int) _windowState);

			// Fire SaveState event
			if (SaveState != null)
			{
				SaveState(this, new FormStateEventArgs(formState));
			}
		}

		/// <summary>
		/// Called when the form is moved.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnMove(object sender, EventArgs e)
		{
			// save position
			if (_form.WindowState == FormWindowState.Normal)
			{
				_normalLeft = _form.Left;
				_normalTop = _form.Top;
			}
			// save state
			_windowState = _form.WindowState;
		}

		/// <summary>
		/// Called when the form is resized.
		/// </summary>
		/// <param name="sender">The sender.</param>
		/// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
		private void _OnResize(object sender, EventArgs e)
		{
			// save width and height
			if (_form.WindowState == FormWindowState.Normal)
			{
				_normalWidth = _form.Width;
				_normalHeight = _form.Height;
			}
		}

		#endregion Private Methods
	}

	#region Delegates

	/// <summary>
	/// Event info that allows form to persist extra form state data.
	/// </summary>
	public delegate void FormStateEventHandler(object sender, FormStateEventArgs e);

	#endregion Delegates

	#region FormStateEventArgs Class

	/// <summary>
	/// Event arguments for events raised to the form allowing it to persist and load settings.
	/// </summary>
	public class FormStateEventArgs : EventArgs
	{
		public readonly FormState FormState;

		/// <summary>
		/// Initializes a new instance of the <see cref="FormStateEventArgs"/> class.
		/// </summary>
		/// <param name="formState">State of the form.</param>
		public FormStateEventArgs( FormState formState )
		{
			FormState = formState;
		}
	}

	#endregion FormStateEventArgs Class
}