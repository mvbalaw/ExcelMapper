using System;
using NCoverExplorer.Core.Reporting;

namespace NCoverExplorer.Core.Configuration
{
	/// <summary>
	/// Command line arguments specific to the console executable.
	/// </summary>
	[Serializable]
	public class ConsoleOptions : CommandLineOptions
	{
		#region Private Variables

		private string _configFileName = "";
		private bool _failIfBelowMinimum = false;
		private float _minimumCoverage = 100;
		private string _projectName = "";
		private ReportType _reportType = ReportType.ModuleSummary;
		private string _xmlReportFileName = "";
		private string _htmlReportFileName = "";
		private string _mergeFileName = "";
		private bool _showExcludedFooter = false;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ConsoleOptions"/> class.
		/// </summary>
		/// <param name="args">The args.</param>
		public ConsoleOptions(string[] args) : base(args)
		{
			if (args.Length == 0 || args[0] == "/?" || !HasCoverageFileName)
			{
				Help();
			}
		}

		#endregion Constructor

		#region Public Properties

		/// <summary>
		/// Gets a value indicating the name of the config file.
		/// </summary>
		/// <value>The name of the config file.</value>
		public string ConfigFileName
		{
			get { return _configFileName; }
		}

		/// <summary>
		/// Gets a value indicating whether to fail the build if minimum coverage is not met.
		/// </summary>
		/// <value>Whether to fail the build if minimum coverage is not met.</value>
		public bool FailIfBelowMinimum
		{
			get { return _failIfBelowMinimum; }
		}

		/// <summary>
		/// Gets a value indicating the minimum percentage threshold. Can be used by the console application which will
		/// return a non-zero exit code.
		/// </summary>
		/// <value>The minimum coverage percentage to force an exit code when run via the console.</value>
		public float MinimumCoverage
		{
			get { return _minimumCoverage; }
		}

		/// <summary>
		/// Gets a value indicating the name of the project.
		/// </summary>
		/// <value>The name of the project.</value>
		public string ProjectName
		{
			get { return _projectName; }
		}

		/// <summary>
		/// Gets or sets a value indicating the type of report to generate (such as module or nanespace summary).
		/// </summary>
		/// <value>The type of report to generate.</value>
		public ReportType ReportType
		{
			get { return _reportType; }
			set { _reportType = value; }
		}

		/// <summary>
		/// Gets a value indicating the html filename of the report.
		/// </summary>
		/// <value>The name of the html report.</value>
		public string HtmlReportFileName
		{
			get { return _htmlReportFileName; }
		}

		/// <summary>
		/// Gets a value indicating the xml filename of the report.
		/// </summary>
		/// <value>The name of the xml report.</value>
		public string XmlReportFileName
		{
			get { return _xmlReportFileName; }
		}

		/// <summary>
		/// Gets a value indicating the filename for the merge of the coverage xml files.
		/// </summary>
		/// <value>The name of the file to contain the merged coverage xml files.</value>
		public string MergeFileName
		{
			get { return _mergeFileName; }
		}

		/// <summary>
		/// Gets a value indicating whether to show a footer for excluded nodes.
		/// </summary>
		/// <value>Whether to show a footer for excluded nodes.</value>
		public bool ShowExcludedFooter
		{
			get { return _showExcludedFooter; }
		}

		#endregion Public Properties

		#region Protected Methods

		/// <summary>
		/// Validates the command line argument and assigns to the class.
		/// </summary>
		/// <param name="name">The name.</param>
		/// <param name="value">The value.</param>
		protected override void ValidateAndAssignArgument(string name, string value)
		{
			switch (name.ToLower())
			{
				case "c":
				case "config":
					_configFileName = value;
					break;

				case "e":
				case "excluded":
					_showExcludedFooter = true;
					break;

				case "f":
				case "failminimum":
					_failIfBelowMinimum = true;
					break;

				case "m":
				case "mincoverage":
					_minimumCoverage = float.Parse(value);
					break;

				case "p":
				case "project":
					_projectName = value;
					break;

				case "h":
				case "html":
					if (value.Length == 0)
					{
						_htmlReportFileName = "CoverageReport.html";
					}
					else
					{
						_htmlReportFileName = value;
					}
					break;

				case "x":
				case "xml":
					if (value.Length == 0)
					{
						_xmlReportFileName = "CoverageReport.xml";
					}
					else
					{
						_xmlReportFileName = value;
					}
					break;

				case "r":
				case "report":
					if (value.Length == 0)
					{
						throw new ArgumentException("You must specify a report type for /r switch (0-4).");
					}
					_reportType = (ReportType)int.Parse(value);
					if (!Enum.IsDefined(typeof(ReportType), _reportType))
					{
						throw new InvalidOperationException("Not a valid report type.");
					}
					break;

				case "s":
				case "save":
					if (value.Length == 0)
					{
						_mergeFileName = "CoverageMerge.xml";
					}
					else
					{
						_mergeFileName = value;
					}
					break;

				default:
					base.ValidateAndAssignArgument(name, value);
					break;
			}
		}

		/// <summary>
		/// Displays a help message.
		/// </summary>
		protected void Help()
		{
			System.Console.WriteLine();
			System.Console.WriteLine( "NCoverExplorer.Console [inputfiles] [options]" );
			System.Console.WriteLine();
			System.Console.WriteLine( "Processes a set of NCover coverage xml files from the console." );
			System.Console.WriteLine( "Intended for usage in automated builds." );
			System.Console.WriteLine();
			System.Console.WriteLine( "Options:" );
			System.Console.WriteLine( " /c[onfig]:       Path to an alternative .config file." );
			System.Console.WriteLine( "                  Defaults to that used by NCoverExplorer.exe" );
			System.Console.WriteLine();
			System.Console.WriteLine( " /h[tml]:         Specify to generate a report in html format." );
			System.Console.WriteLine( "                  If no name defaults to CoverageReport.html" );
			System.Console.WriteLine( " /x[ml]:          Specify to generate a report in xml format." );
			System.Console.WriteLine( "                  If no name defaults to CoverageReport.xml" );
			System.Console.WriteLine( " /r[eport]:       Type of report to produce:" );
			System.Console.WriteLine( "                  0 = None" );
			System.Console.WriteLine( "                  1 = Module summary (default)" );
			System.Console.WriteLine( "                  2 = Namespace summary" );
			System.Console.WriteLine( "                  3 = Module and Namespace summary" );
			System.Console.WriteLine( "                  4 = Module and Class summary" );
			System.Console.WriteLine( " /s[ave]:         Specify the filename for the merged coverage xml." );
			System.Console.WriteLine( "                  If no name defaults to CoverageMerge.xml" );
			System.Console.WriteLine( " /e[xcluded]:     Whether to show excluded nodes in report footer." );
			System.Console.WriteLine( " /p[roject]:      Name of the project to appear in the report." );
			System.Console.WriteLine();
			System.Console.WriteLine( " /m[inCoverage]:  Specifies the minimum coverage %" );
			System.Console.WriteLine( " /f[ailMinimum]:  Fail the build if coverage below minimum." );
			System.Console.WriteLine( " /?               Displays this help." );
			System.Console.WriteLine();
			System.Console.WriteLine( "Exit Codes:" );
			System.Console.WriteLine( " 0 - OK." );
			System.Console.WriteLine( " 2 - Exception." );
			System.Console.WriteLine( " 3 - Failed minimum coverage threshold check." );
			System.Console.WriteLine();

			Environment.Exit(0);
		}

		#endregion Protected Methods
	}
}
