using System;
using System.Collections;
using System.IO;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.CoverageTree;
using NCoverExplorer.Core.Iterators;
using NCoverExplorer.Core.Parser;
using NCoverExplorer.Core.Reporting;
using NCoverExplorer.Core.Utilities;

namespace NCoverExplorer.Console
{
	/// <summary>
	/// Controls execution of NCoverExplorer-Console to load the coverage files and perform whatever command line tasks were requested.
	/// </summary>
	public class ConsoleController : IStatusMessageRecipient
	{
		#region Private Variables

		private IExplorerConfiguration _configuration;
		private CoverageXmlParser _coverageXmlParser;

		#endregion Private Variables

		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="ConsoleController"/> class.
		/// </summary>
		/// <param name="configuration">The configuration.</param>
		public ConsoleController(IExplorerConfiguration configuration)
		{
			StatusPublisher.Initialise(this);

			_configuration = configuration;
			_coverageXmlParser = new CoverageXmlParser(_configuration);
		}

		#endregion Constructor

		#region Public Methods

		/// <summary>
		/// Executes the controller by loading coverage files and executing desired task(s).
		/// </summary>
		public void Execute(ConsoleOptions consoleOptions)
		{
			_ApplyConsoleOptionOverrides(consoleOptions);
			_DisplayConsoleOptions(consoleOptions);

			CoverageFileTreeNode coverageFileTreeNode = _LoadCoverageFiles(_configuration.CommandLineOptions.CoverageFileNames);
			
			_DisplayStatisticsSummary(coverageFileTreeNode);

			StatusPublisher.Display("-- Applying command line options ...");

			if (consoleOptions.MergeFileName.Length > 0)
			{
				_SaveMergedCoverageFile(coverageFileTreeNode, consoleOptions.MergeFileName);
			}
			_GenerateSummaryReport(coverageFileTreeNode, consoleOptions);

			if (consoleOptions.FailIfBelowMinimum)
			{
				_ExitIfMinimumCoverageNotReached(
					coverageFileTreeNode.CoveragePercentage, 
					_configuration.SatisfactoryCoverageThreshold,
					coverageFileTreeNode,
					_configuration.ModuleThresholds);
			}

			// Console application does nothing else currently.
			StatusPublisher.Display("-- Done.");
		}

		#endregion Public Methods

		#region Private Methods

		#region Display Console Options / Statistics

		/// <summary>
		/// Display console options header message.
		/// </summary>
		/// <param name="consoleOptions">The console options.</param>
		private void _DisplayConsoleOptions(ConsoleOptions consoleOptions)
		{
			StatusPublisher.Display("-- Options:");
			StatusPublisher.Display("     Project Name: " + _configuration.ProjectName);
			StatusPublisher.Display("     Acceptance%:  " + _configuration.SatisfactoryCoverageThreshold + "%");
			if (consoleOptions.XmlReportFileName.Length > 0)
			{
				StatusPublisher.Display("     Xml Report:   " + consoleOptions.XmlReportFileName.ToString());
			}
			else
			{
				StatusPublisher.Display("     Xml Report:   N/A");
			}
			if (consoleOptions.HtmlReportFileName.Length > 0)
			{
				StatusPublisher.Display("     Html Report:  " + consoleOptions.HtmlReportFileName.ToString());
			}
			else
			{
				StatusPublisher.Display("     Html Report:  N/A");
			}
			StatusPublisher.Display("     Report Type:  " + consoleOptions.ReportType.ToString() + "(" + (int)consoleOptions.ReportType + ")");
			if (consoleOptions.MergeFileName.Length > 0)
			{
				StatusPublisher.Display("     Merge To:     " + consoleOptions.MergeFileName.ToString());
			}
			else
			{
				StatusPublisher.Display("     Merge To:     N/A");
			}
			StatusPublisher.Display("     Min Coverage: " + _configuration.SatisfactoryCoverageThreshold);
			if (consoleOptions.ShowExcludedFooter)
			{
				StatusPublisher.Display("     Exclusions:   (Included in report footer section)");
			}
			else
			{
				StatusPublisher.Display("     Exclusions:   (No report footer section)");
			}
			foreach (CoverageExclusion coverageExclusion in _configuration.CoverageExclusions)
			{
				if (coverageExclusion.Enabled)
				{
					StatusPublisher.Display("     - any " + coverageExclusion.ExclusionType.ToString() + " matching " + coverageExclusion.Pattern);
				}
			}
			StatusPublisher.Display("");
		}

		/// <summary>
		/// Display a statistics coverage summary.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		private void _DisplayStatisticsSummary(CoverageFileTreeNode coverageFileTreeNode)
		{
			StatusPublisher.Display("");
			string message = string.Format("     {0}% coverage, {1} unvisited sequence points in {2} coverage file(s).",
			                               coverageFileTreeNode.CoveragePercentage,
			                               coverageFileTreeNode.UnvisitedSequencePoints,
			                               coverageFileTreeNode.CoverageFileNames.Length
				);
			StatusPublisher.Display(message);
			StatusPublisher.Display("");
		}

		#endregion Display Console Options / Statistics

		#region Apply Console Option Overrides

		/// <summary>
		/// We force the tree to be loaded with a particular style of grouping to match the desired reporting type.
		/// Very difficult to report by module when user's default configuration may be group by namespace!
		/// Note these configuration changes are not persisted so next time they start NCoverExplorer all will be the same.
		/// </summary>
		/// <param name="consoleOptions">The console options.</param>
		private void _ApplyConsoleOptionOverrides(ConsoleOptions consoleOptions)
		{
			if (consoleOptions.ProjectName.Length > 0)
			{
				_configuration.ProjectName = consoleOptions.ProjectName;
			}
			if (_configuration.ProjectName.Length == 0)
			{
				_configuration.ProjectName = "Unknown";
			}
			if (consoleOptions.MinimumCoverage != 100)
			{
				_configuration.SatisfactoryCoverageThreshold = consoleOptions.MinimumCoverage;
			}

			_configuration.FlattenNamespaces = true;	// So any namespace reports will work.

			switch (consoleOptions.ReportType)
			{
				case ReportType.ModuleSummary:
				case ReportType.ModuleNamespaceSummary:
					_configuration.GroupByModule = true;
					break;

				case ReportType.NamespaceSummary:
					_configuration.GroupByModule = false;
					break;

				default:
					break;
			}
			// Don't try to produce a report if none requested.
			if (consoleOptions.HtmlReportFileName.Length == 0 && consoleOptions.XmlReportFileName.Length == 0)
			{
				consoleOptions.ReportType = ReportType.None;
			}
		}

		#endregion Apply Console Option Overrides

		#region Load/Merge Coverage Files

		/// <summary>
		/// Loads and merges the coverage files.
		/// </summary>
		/// <param name="fileNames">The file names.</param>
		/// <returns>Populated coverage tree.</returns>
		private CoverageFileTreeNode _LoadCoverageFiles(string[] fileNames)
		{
			fileNames = _ExpandFileNameWildcardsIfRequired(fileNames);

			string firstFileName = fileNames[0];

			// Not merging with existing coverage tree for first file - instead are completely replacing it.
			StatusPublisher.Display(string.Format("-- Loading file: {0}...", firstFileName));
			CoverageFileTreeNode coverageFileTreeNode = _coverageXmlParser.LoadFile(firstFileName);
			coverageFileTreeNode.CoverageFileNames = new string[] { firstFileName };

			_MergeCoverageXmlFiles(coverageFileTreeNode, fileNames, 1);

			StatusPublisher.Display("-- Sorting...");
			TreeViewSorter.SortTreeNodeRecursive(coverageFileTreeNode);

			StatusPublisher.Display("-- Coverage file parsing complete.");

			return coverageFileTreeNode;
		}

		/// <summary>
		/// Given an array of filenames, convert any with wildcards to actual matching filenames.
		/// All filenames returned with full paths.
		/// </summary>
		/// <param name="fileNames">The file names.</param>
		/// <returns>File names</returns>
		private string[] _ExpandFileNameWildcardsIfRequired(string[] fileNames)
		{
			ArrayList expandedFileNames = new ArrayList();
			
			for (int index = 0; index < fileNames.Length; index++)
			{
				string fileName = fileNames[index];
				if (fileName.IndexOf('*') >= 0)
				{
					string directory = Path.GetDirectoryName(fileName);
					if (!Path.IsPathRooted(fileName))
					{
						directory = Path.GetFullPath(".");
					}
					string pattern = Path.GetFileName(fileName);
					string[] matchingFileNames = Directory.GetFiles(directory, pattern);
					for (int matchingIndex = 0; matchingIndex < matchingFileNames.Length; matchingIndex++)
					{
						expandedFileNames.Add(Path.Combine(directory, matchingFileNames[matchingIndex]));
					}
				}
				else
				{
					if (!Path.IsPathRooted(fileName))
					{
						fileName = Path.GetFullPath(fileName);
					}
					expandedFileNames.Add(fileName);
				}
			}

			return (string[])expandedFileNames.ToArray(typeof(string));
		}

		/// <summary>
		/// Merging all the files with the current loaded coverage tree.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="fileNames">Array of files to be merged.</param>
		/// <param name="startIndex">The first file index in the array to start at.</param>
		private void _MergeCoverageXmlFiles(CoverageFileTreeNode coverageFileTreeNode, string[] fileNames, int startIndex)
		{
			string currentFileName = string.Empty;
			for (int index = startIndex; index < fileNames.Length; index++)
			{
				currentFileName = fileNames[index];
				if (coverageFileTreeNode.HasFileLoaded(currentFileName))
				{
					StatusPublisher.Display("[WARNING] File " + currentFileName + " already loaded. Duplicate ignored.");
				}
				else
				{
					coverageFileTreeNode.AddFileName(currentFileName);
					StatusPublisher.Display(string.Format("-- Loading file: {0}...", currentFileName));
					_coverageXmlParser.MergeFile(coverageFileTreeNode, currentFileName);
				}
			}

			StatusPublisher.Display("-- Calculating coverage and applying exclusions...");
			ICoverageExclusionManager coverageExclusionManager = new CoverageExclusionManager(_configuration.CoverageExclusions);
			coverageFileTreeNode.ApplyExclusionsAndCalculateCoverage(coverageExclusionManager);
		}

		#endregion Load/Merge Coverage Files

		#region Save Merged Coverage

		/// <summary>
		/// Saves the merged coverage file.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		private void _SaveMergedCoverageFile(CoverageFileTreeNode coverageFileTreeNode, string mergeFileName)
		{
			if (File.Exists(mergeFileName))
			{
				File.Delete(mergeFileName);
			}
			StatusPublisher.Display("-- Saving merge file: " + mergeFileName);
			CoverageFileWriter writer = new CoverageFileWriter(_configuration);
			writer.WriteCoverageXmlFile(mergeFileName, coverageFileTreeNode);
		}

		#endregion Save Merged Coverage

		#region Generate Summary Report

		/// <summary>
		/// Generates the coverage summary report (xml or html).
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="consoleOptions">The console options.</param>
		private void _GenerateSummaryReport(CoverageFileTreeNode coverageFileTreeNode, ConsoleOptions consoleOptions)
		{
			if (consoleOptions.ReportType == ReportType.None ||
				(consoleOptions.HtmlReportFileName.Length == 0 && consoleOptions.XmlReportFileName.Length == 0))
			{
				StatusPublisher.Display("-- Report not generated.");
				return;
			}

			StatusPublisher.Display("-- Generating summary report...");
			string xmlReportFileName = _EnsureFileNameHasPath(coverageFileTreeNode, consoleOptions.XmlReportFileName);
			string htmlReportFileName = _EnsureFileNameHasPath(coverageFileTreeNode, consoleOptions.HtmlReportFileName);
			
			ReportHelper.CreateReport(
				consoleOptions.ReportType, 
				xmlReportFileName, 
				htmlReportFileName, 
				coverageFileTreeNode,
				consoleOptions.ShowExcludedFooter);

			if (xmlReportFileName.Length > 0)
			{
				StatusPublisher.Display("[OK] - Xml report created: " + xmlReportFileName);
			}
			if (htmlReportFileName.Length > 0)
			{
				StatusPublisher.Display("[OK] - Html report created: " + htmlReportFileName);
			}
		}

		/// <summary>
		/// Ensure the file name has a path - if not then default to the same folder as the first coverage file. If
		/// no path in that just uses Environment.CurrentDirectory.
		/// </summary>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="fileName">Name of the file.</param>
		/// <returns>Filename with path prepended.</returns>
		private static string _EnsureFileNameHasPath(CoverageFileTreeNode coverageFileTreeNode, string fileName)
		{
			if (fileName.Length > 0 && !Path.IsPathRooted(fileName))
			{
				string reportFolder = Path.GetDirectoryName(coverageFileTreeNode.CoverageFileNames[0]);
				if (reportFolder.Length == 0)
				{
					reportFolder = Environment.CurrentDirectory;
				}
				fileName = Path.Combine(reportFolder, fileName);
			}
			return fileName;
		}

		#endregion Generate Summary Report

		#region Exit If Minimum Coverage Not Reached

		/// <summary>
		/// Exits if the minimum coverage threshold is not reached.
		/// </summary>
		/// <param name="coveragePercentage">The coverage percentage.</param>
		/// <param name="acceptableProjectCoverage">The acceptable project coverage.</param>
		/// <param name="coverageFileTreeNode">The coverage file tree node.</param>
		/// <param name="moduleThresholds">The module thresholds.</param>
		private void _ExitIfMinimumCoverageNotReached(float coveragePercentage, float acceptableProjectCoverage,
			CoverageFileTreeNode coverageFileTreeNode, ModuleThresholdCollection moduleThresholds)
		{
			StatusPublisher.Display("-- Checking Minimum Coverage Threshold...");
			if (coveragePercentage < acceptableProjectCoverage)
			{
				throw new CoverageThresholdException(coveragePercentage, acceptableProjectCoverage);
			}
			else
			{
				StatusPublisher.Display(string.Format("[OK] - Exceeds minimum project coverage threshold of {0}%", acceptableProjectCoverage));
			}
			if (moduleThresholds.Count > 0)
			{
				IEnumerator moduleIterator = new ModuleTreeIterator(coverageFileTreeNode);
				while (moduleIterator.MoveNext())
				{
					ModuleTreeNode moduleTreeNode = (ModuleTreeNode)moduleIterator.Current;
					if (moduleThresholds.Contains(moduleTreeNode.AssemblyNameWithExtension))
					{
						float moduleThreshold = moduleThresholds[moduleTreeNode.AssemblyNameWithExtension].SatisfactoryCoverage;
						if (moduleTreeNode.CoveragePercentage < moduleThreshold)
						{
							throw new CoverageThresholdException(moduleTreeNode.CoveragePercentage, moduleThreshold, moduleTreeNode.AssemblyNameWithExtension);
						}
						else
						{
							StatusPublisher.Display(string.Format("[OK] - {0} coverage of {1}% exceeds threshold of {2}%", 
								moduleTreeNode.AssemblyNameWithExtension, moduleTreeNode.CoveragePercentage, moduleThreshold));
						}
					}
				}
			}
		}

		#endregion Exit If Minimum Coverage Not Reached

		#endregion Private Methods
	
		#region IStatusMessageRecipient

		/// <summary>
		/// Publishes the specified message.
		/// </summary>
		/// <param name="message">The message.</param>
		public void Publish(string message)
		{
			System.Console.WriteLine(message);
		}

		/// <summary>
		/// Publishes the specified exception.
		/// </summary>
		/// <param name="ex">The exception.</param>
		public void Publish(Exception ex)
		{
			System.Console.WriteLine(ex.ToString());
		}

		#endregion IStatusMessageRecipient
	}
}
