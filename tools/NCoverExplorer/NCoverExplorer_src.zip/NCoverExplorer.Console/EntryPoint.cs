using System;
using System.IO;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;

namespace NCoverExplorer.Console
{
	/// <summary>
	/// Entry point for the NCoverExplorer-Console application.
	/// </summary>
	public sealed class EntryPoint
	{
		#region Constructor

		/// <summary>
		/// Initializes a new instance of the <see cref="EntryPoint"/> class.
		/// </summary>
		private EntryPoint()
		{
		}

		#endregion Constructor

		/// <summary>
		/// The main entry point for the console application.
		/// </summary>
		/// <param name="args">The command-line args.</param>
		[STAThread]
		public static int Main(string[] args)
		{
			try
			{
				_DisplayConsoleHeader();
				ConsoleOptions consoleOptions = new ConsoleOptions(args);
				IExplorerConfiguration configuration = _LoadConfigurationFile(consoleOptions);

				ConsoleController consoleController = new ConsoleController(configuration);
				consoleController.Execute(consoleOptions);

				return 0;
			}
			catch (CoverageThresholdException ex)
			{
				System.Console.WriteLine(ex.Message);
				return ex.ExitCode;
			}
			catch (Exception ex)
			{
				System.Console.WriteLine(ex.Message);
				return 2;
			}
		}

		/// <summary>
		/// Display a header message.
		/// </summary>
		private static void _DisplayConsoleHeader()
		{
			System.Console.WriteLine("-----------------------------------------");
			System.Console.WriteLine("    NCoverExplorer.Console " + Application.ProductVersion.ToString());
			System.Console.WriteLine("-----------------------------------------");
		}

		/// <summary>
		/// Loads a configuration file - either from the command line options if specified or the
		/// default for NCoverExplorer.exe located in Documents and Local Settings.
		/// </summary>
		/// <param name="consoleOptions">The console options parsed.</param>
		/// <returns>Configuration.</returns>
		private static IExplorerConfiguration _LoadConfigurationFile(ConsoleOptions consoleOptions)
		{
			IExplorerConfiguration configuration;
			if (consoleOptions.ConfigFileName.Length > 0)
			{
				System.Console.WriteLine("Using .config file: " + consoleOptions.ConfigFileName);
				if (!File.Exists(consoleOptions.ConfigFileName))
				{
					throw new FileNotFoundException("Cannot find configuration file specified: " + consoleOptions.ConfigFileName);
				}
				else
				{
					configuration = new ExplorerConfiguration(consoleOptions, null, consoleOptions.ConfigFileName);
				}
			}
			else
			{
				configuration = new ExplorerConfiguration(consoleOptions);
				System.Console.WriteLine("Using default .config file: " + configuration.FileName);
			}
			return configuration;
		}
	}
}
