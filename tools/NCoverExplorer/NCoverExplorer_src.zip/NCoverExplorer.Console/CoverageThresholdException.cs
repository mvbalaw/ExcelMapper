using System;

namespace NCoverExplorer.Console
{
	/// <summary>
	/// Exception thrown when fail to meet minimum coverage.
	/// </summary>
	public class CoverageThresholdException : Exception
	{
		private float _actualCoveragePercentage;
		private float _minimumCoverageThreshold;
		private string _moduleName;

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageThresholdException"/> class.
		/// </summary>
		/// <param name="actualCoveragePercentage">The actual coverage percentage.</param>
		/// <param name="minimumCoverageThreshold">The minimum coverage threshold.</param>
		public CoverageThresholdException(float actualCoveragePercentage, float minimumCoverageThreshold)
		{
			_actualCoveragePercentage = actualCoveragePercentage;
			_minimumCoverageThreshold = minimumCoverageThreshold;
			_moduleName = string.Empty;
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="CoverageThresholdException"/> class.
		/// </summary>
		/// <param name="actualCoveragePercentage">The actual coverage percentage.</param>
		/// <param name="minimumCoverageThreshold">The minimum coverage threshold.</param>
		/// <param name="moduleName">Name of the module.</param>
		public CoverageThresholdException(float actualCoveragePercentage, float minimumCoverageThreshold, string moduleName)
		{
			_actualCoveragePercentage = actualCoveragePercentage;
			_minimumCoverageThreshold = minimumCoverageThreshold;
			_moduleName = moduleName;
		}

		/// <summary>
		/// Gets the exit code.
		/// </summary>
		/// <value>The exit code.</value>
		public int ExitCode
		{
			get { return 3; }
		}

		/// <summary>
		/// Creates and returns a string representation of the current exception.
		/// </summary>
		/// <returns>
		/// A string representation of the current exception.
		/// </returns>
		public override string Message
		{
			get 
			{
				if (_moduleName.Length == 0)
				{
					return string.Format("[FAIL] - Coverage of {0}% is less than project threshold specified of {1}%.",
						_actualCoveragePercentage, _minimumCoverageThreshold);
				}
				else
				{
					return string.Format("[FAIL] - Coverage of {0}% is less than threshold specified of {1}% for module {2}.",
						_actualCoveragePercentage, _minimumCoverageThreshold, _moduleName);
				}
			}
		}

	}
}
