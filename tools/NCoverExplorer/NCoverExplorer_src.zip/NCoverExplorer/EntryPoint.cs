using System;
using System.Diagnostics;
using System.Windows.Forms;

using NCoverExplorer.Core.Configuration;
using NCoverExplorer.Core.Presentation;

namespace NCoverExplorer
{
	/// <summary>
	/// Entry point for the NCoverExplorer application.
	/// </summary>
	public class EntryPoint
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		/// <param name="args">The command-line args.</param>
		[STAThread]
		public static void Main(string[] args)
		{
			if (!Debugger.IsAttached)
			{
				Application.ThreadException += new System.Threading.ThreadExceptionEventHandler(Application_ThreadException);
				AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
			}

			CommandLineOptions commandLineOptions = new CommandLineOptions(args);
			IExplorerConfiguration configuration = new ExplorerConfiguration(commandLineOptions);

			MainForm mainForm = new MainForm(configuration);

			Application.Run(mainForm);
		}

		/// <summary>
		/// Handles the ThreadException event of the Application component.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.Threading.ThreadExceptionEventArgs"/> instance containing the event data.</param>
		private static void Application_ThreadException(object sender, System.Threading.ThreadExceptionEventArgs e)
		{
			_ShowExceptionDialog(e.Exception, false);
		}

		/// <summary>
		/// Handles the UnhandledException event of the CurrentDomain component.
		/// </summary>
		/// <param name="sender">The source of the event.</param>
		/// <param name="e">The <see cref="System.UnhandledExceptionEventArgs"/> instance containing the event data.</param>
		private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception ex = e.ExceptionObject as Exception;
			_ShowExceptionDialog(ex, e.IsTerminating);
		}

		/// <summary>
		/// Shows a basic message box with the error.
		/// </summary>
		/// <param name="ex">The exception.</param>
		/// <param name="mustTerminate">if set to <c>true</c> the application must terminate after display.</param>
		private static void _ShowExceptionDialog(Exception ex, bool mustTerminate)
		{
			// TODO: Create and hook up a "nice" exception dialog to be displayed
			Version version = new Version(Application.ProductVersion);
			string message = "An unexpected error has occurred in NCoverExplorer " + version.ToString() + "."
				+ "\nFramework loaded: " + Environment.Version
				+ "\nOperating system: " + Environment.OSVersion
				+ "\nIf you are able to replicate it please send an e-mail to: "
				+ "\n   support@ncoverexplorer.org"
				+ "\n\n(You can copy and paste the text from the dialog using Ctrl+C)\n";

			if (mustTerminate)
			{
				message += "\nSadly this is too severe to continue... please restart and try again.\n";
			}
			message += "\n" + ex.ToString().Replace(Environment.NewLine, "\n");
			MessageBox.Show(message, "NCoverExplorer " + version + " Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			if (mustTerminate)
			{
				Application.Exit();
			}
		}
	}
}
