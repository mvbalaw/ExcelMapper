#region Copyright � 2006 Grant Drake. All rights reserved.
/*
Copyright � 2006 Grant Drake. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;
using Microsoft.Win32;
using System.Xml;

// $Id$

namespace MSBuild.NCoverExplorer.Tasks
{
	/// <summary>
    /// MSBuild task for automating NCover.Console.exe, with NCover 1.5.x support. Note that this task
    /// relies on CoverLib.dll being COM registered at the relevant NCover folder path location prior to being called.
	/// </summary>
	/// <example>
	/// This example shows the standard profiling using NCover 1.5.4 for standard nunit tests with minimal arguments.
	/// Defaults are with logging to coverage.log, profiling all assemblies, output filename of coverage.xml and this 
	/// example specifies a path to where to find ncover.console.exe.
	///        <code>
	///            <![CDATA[
    ///            <NCover  ToolPath="Tool\NCover\"
    ///                     CommandLineExe="$(nunit.path)\nunit-console.exe" 
	///						CommandLineArgs="$(MSBuildProjectDirectory)\myapp.tests.dll" />
	///            ]]>
	///        </code>
	/// </example>
	/// <example>
	/// This example shows the standard profiling using NCover 1.5.4 for a Windows application, specifying a coverage
	/// exclusion, verbose logging to a named file, specifically named log and output xml files. It also shows
	/// coverage exclusion attributes, overriding the NCover location to run from and a way of listing assemblies
	/// to be included in the profiled NCover results.
	///        <code>
	///            <![CDATA[
	///			   <ItemGroup>
    ///				   <Assembly Include="$(MSBuildProjectDirectory)\MyApp.MyCode.dll" />
	///			   </ItemGroup>
    /// 
	///            <NCover  ToolPath="Tool\NCover\"
    ///                     CommandLineExe="$(nunit.path)\nunit-console.exe" 
	///						CommandLineArgs="myapp.tests.dll"
	///						CoverageFile="myapp.coverage.xml"
	///						LogLevel="Verbose"
	///						LogFile="myapp.coverage.log"
	///						WorkingDirectory="$(MSBuildProjectDirectory)"
	///						ExcludeAttributes="CoverageExcludeAttribute"
	///                     Assemblies="@(Assembly)" />
	///            ]]>
	///        </code>
	/// </example>
	public class NCover : ToolTask
	{
		#region Private Variables / Constants

		private const string DefaultApplicationName = "NCover.Console.exe";

		private string _commandLineExe;
		private string _commandLineArgs;
		private string _coverageFile;
		private string _logLevel;
		private string _logFile;
		private string _workingDirectory;
		private ITaskItem[] _assemblyFiles;	
		
		private string _excludeAttributes;
		private bool _profileIIS;
		private string _profileService;

		private string _settingsFile;
		private StringBuilder _programArguments;

		#endregion Private Variables / Constants

		#region Constructors

		/// <summary>
		/// Initializes a new instance of the <see cref="NCover"/> class.
		/// </summary>
        public NCover()
		{
			_commandLineExe = string.Empty;
			_commandLineArgs = string.Empty;
			_workingDirectory = string.Empty;
            _coverageFile = "coverage.xml";
			_logLevel = "Normal";   // Since Quiet and Normal are same until Peter fixes bug.
			_logFile = "coverage.log";

			_assemblyFiles = new ITaskItem[0];
			_settingsFile = string.Empty;

			_excludeAttributes = string.Empty;
			_profileIIS = false;
			_profileService = string.Empty;

			_programArguments = new StringBuilder();
		}

		#endregion Constructors

		#region Properties

		/// <summary>
		/// The command line executable to be launched by NCover (such as nunit-console.exe).
		/// </summary>
		[Required]
		public string CommandLineExe
		{
			get { return _commandLineExe; }
			set { _commandLineExe = value; }
		}

		/// <summary>
		/// The arguments to pass to the command line executable to be launched by NCover (such as nunit-console.exe).
		/// </summary>
		public string CommandLineArgs
		{
			get { return _commandLineArgs; }
			set { _commandLineArgs = value; }
		}

		/// <summary>
		/// The filename for the output coverage.xml file (default).
		/// </summary>
		public string CoverageFile
		{
			get { return _coverageFile; }
			set { _coverageFile = value; }
		}

		/// <summary>
        /// What level of NCover logging to provide. Values are "Normal" (default) and "Verbose".
        /// Due to a bug in NCover 1.5.4 "Quiet" will result in NCover stopping abnormally - hence has been
        /// defaulted to be "Normal" until the bug is fixed.
		/// </summary>
		public string LogLevel
		{
			get { return _logLevel; }
			set { _logLevel = value; }
		}

		/// <summary>
		/// Gets or sets the logfile name to write to if logLevel is set to anything other than "Quiet". The default
		/// is "coverage.log".
		/// </summary>
		public string LogFile
		{
			get { return _logFile; }
			set { _logFile = value; }
		}

		/// <summary>
		/// Gets or sets the working directory for the command line executable.
		/// </summary>
		public string WorkingDirectory
		{
			get { return _workingDirectory; }
			set { _workingDirectory = value; }
		}

		/// <summary>
		/// If coverage exclusion attributes have been applied (NCover 1.5.4 onwards) specify the attribute.
		/// </summary>
		public string ExcludeAttributes
		{
			get { return _excludeAttributes; }
			set { _excludeAttributes = value; }
		}

		/// <summary>
		/// Determines whether to profile under IIS. Default value is <see langword="false" />.
		/// </summary>
		public bool ProfileIIS
		{
			get { return _profileIIS; }
			set { _profileIIS = value; }
		}

		/// <summary>
		/// The service name.
		/// </summary>
		public string ProfileService
		{
			get { return _profileService; }
			set { _profileService = value; }
		}

		/// <summary>
		/// Used to specify the assemblies to be profiled.
		/// </summary>
		public ITaskItem[] Assemblies
		{
			get { return _assemblyFiles; }
			set { _assemblyFiles = value; }
		}

		#endregion Properties

		#region Override ToolTask

		/// <summary>
		/// Executes the task.
		/// </summary>
		/// <returns><see langword="true"/> if the task ran successfully; otherwise <see langword="false"/>.</returns>
		public override bool Execute()
		{
			bool success = base.Execute();

			_CleanupSettingsFile();
			
			return success;
		}
        
		/// <summary>
		/// Returns a string value containing the command line arguments to pass directly to the executable file.
		/// </summary>
		/// <returns>
		/// A string value containing the command line arguments to pass directly to the executable file.
		/// </returns>
		protected override string GenerateCommandLineCommands()
		{
			_settingsFile = Path.GetTempFileName() + ".ncoversettings";
            Log.LogMessage(MessageImportance.Low, "Creating settings file: {0}", _settingsFile);

            StringBuilder builder = new StringBuilder();

            _BuildTempSettingsXmlFileForNCover15();
            builder.AppendFormat("//r \"{0}\" ", _settingsFile);

            Log.LogMessage(MessageImportance.Low, "Arguments: {0}", builder.ToString());

            // Dump out the contents of the settings file.
			string fileContents = _GetFileContents(_settingsFile);
			Log.LogMessage(MessageImportance.Low, fileContents);

            return builder.ToString();
		}

		/// <summary>
		/// Returns the fully qualified path to the executable file.
		/// </summary>
		/// <returns>
		/// The fully qualified path to the executable file.
		/// </returns>
		protected override string GenerateFullPathToTool()
		{
			_CheckToolPath();
			return Path.Combine(ToolPath, ToolName);
		}

		/// <summary>
		/// Logs the starting point of the run to all registered loggers.
		/// </summary>
		/// <param name="message">A descriptive message to provide loggers, usually the command line and switches.</param>
		protected override void LogToolCommand(string message)
		{
			Log.LogCommandLine(MessageImportance.Low, message);
		}

		/// <summary>
		/// Gets the name of the executable file to run.
		/// </summary>
		/// <value></value>
		/// <returns>The name of the executable file to run.</returns>
		protected override string ToolName
		{
			get { return DefaultApplicationName; }
		}

		/// <summary>
		/// Gets the <see cref="T:Microsoft.Build.Framework.MessageImportance"></see> with which to log errors.
		/// </summary>
		/// <value></value>
		/// <returns>The <see cref="T:Microsoft.Build.Framework.MessageImportance"></see> with which to log errors.</returns>
		protected override MessageImportance StandardOutputLoggingImportance
		{
			get { return MessageImportance.Normal; }
		}

		#endregion Override ToolTask

		#region Private Methods
        
        /// <summary>
        /// Check that we have a valid path to NCover.
        /// </summary>
		private void _CheckToolPath()
		{
			string ncoverPath = (ToolPath == null) ? String.Empty : ToolPath.Trim();
			if (string.IsNullOrEmpty(ncoverPath))
			{
				// Not specified in the task arguments so might be in trouble if the user has not
				// installed it in the default NCover folder.
				ncoverPath = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
				ncoverPath = Path.Combine(ncoverPath, @"NCover");
                if (!Directory.Exists(ncoverPath))
	            {
					Log.LogError(Properties.Resources.NCoverNotFound);
	            }
				ToolPath = ncoverPath;
			}
		}

		/// <summary>
		/// Build the Xml .ncoversettings file to pass to the NCover.Console executable using NCover 1.5 syntax.
		/// </summary>
		private void _BuildTempSettingsXmlFileForNCover15()
		{
			// Build the list of assembly names that will be included in the NCover results.
			string assemblyNames = _BuildAssemblyNameList();

			using (Stream fileStream = File.Create(_settingsFile))
			{
				XmlTextWriter xmlTextWriter = new XmlTextWriter(fileStream, Encoding.UTF8);
				xmlTextWriter.Indentation = 2;
				xmlTextWriter.Formatting = Formatting.Indented;

				xmlTextWriter.WriteStartDocument();
				xmlTextWriter.WriteStartElement("ProfilerSettings");
				xmlTextWriter.WriteElementString("CommandLineExe", _commandLineExe);
				xmlTextWriter.WriteElementString("CommandLineArgs", _commandLineArgs);
                if (!String.IsNullOrEmpty(_workingDirectory))
                {
                    xmlTextWriter.WriteElementString("WorkingDirectory", _workingDirectory);
                }
                if (!String.IsNullOrEmpty(assemblyNames))
                {
                    xmlTextWriter.WriteElementString("Assemblies", assemblyNames);
                }
                if (!String.IsNullOrEmpty(_coverageFile))
                {
			        xmlTextWriter.WriteElementString("CoverageXml", _coverageFile);
                }
                if (_logLevel.ToLower() == "quiet")
                {
                    // HACK: Setting NoLog to "true" results in NCover hanging in the NCover 1.5.4 release
                    // For now we will just leave at false and always write a log file until Peter fixes it.
                    //xmlTextWriter.WriteElementString("LogFile", string.Empty);
                    //xmlTextWriter.WriteElementString("VerboseLog", "false");
                    //xmlTextWriter.WriteElementString("NoLog", "true");
                    xmlTextWriter.WriteElementString("LogFile", _logFile);
                    xmlTextWriter.WriteElementString("VerboseLog", "false");
                    xmlTextWriter.WriteElementString("NoLog", "false");
                }
				else
				{
					xmlTextWriter.WriteElementString("LogFile", _logFile);
                    xmlTextWriter.WriteElementString("VerboseLog", (_logLevel.ToLower() == "verbose").ToString().ToLower());
					xmlTextWriter.WriteElementString("NoLog", "false");
				}
				if (!String.IsNullOrEmpty(_excludeAttributes))
				{
					xmlTextWriter.WriteElementString("ExclusionAttributes", _excludeAttributes);
				}
				if (_profileIIS)
				{
					xmlTextWriter.WriteElementString("ProfileIIS", "true");
				}
				if (!String.IsNullOrEmpty(_profileService))
				{
					xmlTextWriter.WriteElementString("ProfileService", _profileService);
				}
				xmlTextWriter.WriteElementString("DumpOnErrorNormal", "false");
				xmlTextWriter.WriteElementString("DumpOnErrorFull", "false");

				xmlTextWriter.WriteEndElement(); // ProfilerSettings
				xmlTextWriter.WriteEndDocument();
				xmlTextWriter.Flush();

				fileStream.Close();
			}
		}

		/// <summary>
		/// Builds a semi-colon delimited assembly name list.
		/// </summary>
		private string _BuildAssemblyNameList()
		{
			string assemblyNames = string.Empty;
            foreach (ITaskItem fileName in _assemblyFiles)
            {
                assemblyNames += ";" + Path.GetFileNameWithoutExtension(fileName.ItemSpec);
            }
			if (assemblyNames.Length > 0)
			{
				assemblyNames = assemblyNames.Substring(1);
			}
			return assemblyNames;
		}

		/// <summary>
		/// Reads the file contents and returns as a string.
		/// </summary>
		private string _GetFileContents(string fileName)
		{
			using (StreamReader streamReader = File.OpenText(fileName))
			{
				return streamReader.ReadToEnd();
			}
		}

		/// <summary>
		/// Removes generated settings file after process has run.
		/// </summary>
		private void _CleanupSettingsFile()
		{
			if ( File.Exists( _settingsFile ) )
			{
			    Log.LogMessage(MessageImportance.Low, "Deleting settings file: {0}", _settingsFile);
				File.Delete( _settingsFile );
			}
		}

		#endregion Private Methods
	}
}
