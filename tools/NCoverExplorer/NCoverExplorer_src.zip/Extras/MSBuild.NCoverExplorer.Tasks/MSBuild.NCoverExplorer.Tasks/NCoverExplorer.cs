#region Copyright � 2006 Grant Drake. All rights reserved.
/*
Copyright � 2006 Grant Drake. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#endregion

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

using Microsoft.Build.Framework;
using Microsoft.Build.Utilities;
using Microsoft.Win32;
using System.Xml;

// $Id$

namespace MSBuild.NCoverExplorer.Tasks
{
	/// <summary>
	/// MSBuild task for automating NCoverExplorer.Console.
	/// </summary>
	/// <example>
	///        <code>
	///            <![CDATA[
	///			   <ItemGroup>
    ///				   <CoverageFile Include="$(MSBuildProjectDirectory)\Test\Coverage\Coverage.xml" />
	///			   </ItemGroup>
	///			   <!-- Use an ItemGroup of the ModuleThresholds attribute below -->
	///			   <ItemGroup>
	///				   <ModuleThreshold Include="MyProject.1.dll=75" />
	///				   <ModuleThreshold Include="MyProject.2.dll=85" />
	///			   </ItemGroup>
	/// 
	///            <NCoverExplorer ProjectName="My Project" 
	///							   ReportType="3"
	///							   OutputDir="$(MSBuildProjectDirectory)\Test\Coverage"
	///							   XmlReportName="CoverageSummary.xml"
	///							   HtmlReportName="CoverageSummary.html"
    ///							   MergeFileName="CoverageMerge.xml"
    ///							   ShowExcluded="True"
	///							   SatisfactoryCoverage="80"
	///							   FailMinimum="True"
	///							   CoverageFiles="@(CoverageFile)"
	///							   Exclusions="Assembly=*.Tests;Namespace=*.Tests*"
	///							   ModuleThresholds="@(ModuleThreshold)"
	///			   />
	///            ]]>
	///        </code>
	/// </example>
	public class NCoverExplorer : ToolTask
	{
		#region Private Variables / Constants

		private const string DefaultApplicationName = "NCoverExplorer.Console.exe";
		private const string DefaultConfigName = "MSBuild.NCoverExplorer.config";

		private string _projectName;
		private string _outputDir;
		private string _configName;
		private string _xmlReportName;
		private string _htmlReportName;
        private string _mergeFileName;
        private bool _showExcluded;
		private bool _failMinimum;
		private float _satisfactoryCoverage;
		private int _reportType;
		private ITaskItem[] _coverageFiles;
		private ITaskItem[] _coverageExclusions;
		private ITaskItem[] _moduleThresholds;

		private StringBuilder _programArguments;

		#endregion Private Variables / Constants

		#region Constructors

		/// <summary>
		/// Default constructor
		/// </summary>
		public NCoverExplorer()
		{
			_configName = DefaultConfigName;
			_satisfactoryCoverage = 100;
			_reportType = 1;
			_programArguments = new StringBuilder();
		}

		#endregion Constructors

		#region Properties

		/// <summary>
		/// Gets or sets the output directory for the reports.
		/// </summary>
		/// <value>The output dir.</value>
		public string OutputDir
		{
			get { return _outputDir; }
			set { _outputDir = value; }
		}

		/// <summary>
		/// Whether to fail the task if the satisfactory coverage threshold is not reached. 
		/// NCoverExplorer console application will return exit code 3.
		/// </summary>
		public bool FailMinimum
		{
			get { return _failMinimum; }
			set { _failMinimum = value; }
		}

		/// <summary>
		/// Gets or sets the name of the temporary XML config file being generated for coverage.
		/// </summary>
		/// <value>The name of the XML config.</value>
		public string ConfigName
		{
			get { return _configName; }
			set { _configName = value; }
		}

		/// <summary>
		/// The satisfactory coverage percentage for display in the reports.
		/// </summary>
		public float SatisfactoryCoverage
		{
			get { return _satisfactoryCoverage; }
			set { _satisfactoryCoverage = value; }
		}

		/// <summary>
		/// The .config filename for containing any custom exclusions and parameters.
		/// </summary>
		public string ProjectName
		{
			get { return _projectName; }
			set { _projectName = value; }
		}

		/// <summary>
		/// The type of report to produce. 1 = Module summary (default), 2 = Namespace, 3 = Module/Namespace.
		/// </summary>
		public int ReportType
		{
			get { return _reportType; }
			set { _reportType = value; }
		}

		/// <summary>
		/// The filename for generating an xml report.
		/// </summary>
		public string XmlReportName
		{
			get { return _xmlReportName; }
			set { _xmlReportName = value; }
		}

		/// <summary>
		/// The filename for generating an html report.
		/// </summary>
		public string HtmlReportName
		{
			get { return _htmlReportName; }
			set { _htmlReportName = value; }
		}

        /// <summary>
        /// The filename for the merge of the coverage xml files.
        /// </summary>
        public string MergeFileName
        {
            get { return _mergeFileName; }
            set { _mergeFileName = value; }
        }

		/// <summary>
		/// Determines whether to include the coverage exclusions in the report. The default is 
		/// <see langword="true" />.
		/// </summary>
		public bool ShowExcluded
		{
			get { return _showExcluded; }
			set { _showExcluded = value; }
		}

		/// <summary>
		/// Used to select the coverage xml files to merge into the report.
		/// </summary>
		[Required]
		public ITaskItem[] CoverageFiles
		{
			get { return _coverageFiles; }
			set { _coverageFiles = value; }
		}

		/// <summary>
		/// Coverage exclusions to apply, in format "Type=Pattern", e.g. "Assembly=*.Tests"
		/// </summary>
		public ITaskItem[] Exclusions
		{
			get { return _coverageExclusions; }
			set { _coverageExclusions = value; }
		}

		/// <summary>
		/// Module thresholds to apply, in format "AssemblyName=Percentage", e.g. "MyApp.Core=75"
		/// </summary>
		public ITaskItem[] ModuleThresholds
		{
			get { return _moduleThresholds; }
			set { _moduleThresholds = value; }
		}

		#endregion Properties

		#region Override ToolTask

		/// <summary>
		/// Executes the task.
		/// </summary>
		/// <returns><see langword="true"/> if the task ran successfully; otherwise <see langword="false"/>.</returns>
		public override bool Execute()
		{
			bool success = base.Execute();

			_CleanupConfigFile();
			
			return success;
		}

		/// <summary>
		/// Returns a string value containing the command line arguments to pass directly to the executable file.
		/// </summary>
		/// <returns>
		/// A string value containing the command line arguments to pass directly to the executable file.
		/// </returns>
		protected override string GenerateCommandLineCommands()
		{
			_BuildTempConfigXmlFile();

			StringBuilder builder = new StringBuilder();

			builder.AppendFormat(" /r:{0}", _reportType.ToString());
			if (!string.IsNullOrEmpty(_htmlReportName))
			{
				if (!Path.IsPathRooted(_htmlReportName) && !string.IsNullOrEmpty(_outputDir))
				{
					_htmlReportName = Path.Combine(_outputDir, _htmlReportName);
				}
				builder.AppendFormat(" /h:\"{0}\"", _htmlReportName);
			}
			if (!string.IsNullOrEmpty(_xmlReportName))
			{
				if (!Path.IsPathRooted(_xmlReportName) && !string.IsNullOrEmpty(_outputDir))
				{
					_xmlReportName = Path.Combine(_outputDir, _xmlReportName);
				}
				builder.AppendFormat(" /x:\"{0}\"", _xmlReportName);
			}
            if (!string.IsNullOrEmpty(_mergeFileName))
            {
                if (!Path.IsPathRooted(_mergeFileName) && !string.IsNullOrEmpty(_outputDir))
                {
                    _mergeFileName = Path.Combine(_outputDir, _mergeFileName);
                }
                builder.AppendFormat(" /s:\"{0}\" ", _mergeFileName);
            }
            if (_showExcluded)
			{
				builder.Append(" /e");
			}
			if (_failMinimum)
			{
				builder.Append(" /f");
			}
			builder.AppendFormat(" /c:\"{0}\"", _GetConfigFilename());

			foreach (ITaskItem fileName in _coverageFiles)
			{
				builder.AppendFormat(" \"{0}\"", fileName.ItemSpec);
			}

			return builder.ToString();
		}

		/// <summary>
		/// Returns the fully qualified path to the executable file.
		/// </summary>
		/// <returns>
		/// The fully qualified path to the executable file.
		/// </returns>
		protected override string GenerateFullPathToTool()
		{
			_CheckToolPath();
			return Path.Combine(ToolPath, ToolName);
		}

		/// <summary>
		/// Logs the starting point of the run to all registered loggers.
		/// </summary>
		/// <param name="message">A descriptive message to provide loggers, usually the command line and switches.</param>
		protected override void LogToolCommand(string message)
		{
			Log.LogCommandLine(MessageImportance.Low, message);
		}

		/// <summary>
		/// Gets the name of the executable file to run.
		/// </summary>
		/// <value></value>
		/// <returns>The name of the executable file to run.</returns>
		protected override string ToolName
		{
			get { return DefaultApplicationName; }
		}

		/// <summary>
		/// Gets the <see cref="T:Microsoft.Build.Framework.MessageImportance"></see> with which to log errors.
		/// </summary>
		/// <value></value>
		/// <returns>The <see cref="T:Microsoft.Build.Framework.MessageImportance"></see> with which to log errors.</returns>
		protected override MessageImportance StandardOutputLoggingImportance
		{
			get { return MessageImportance.Normal; }
		}

		#endregion Override ToolTask

		#region Private Methods

		private void _CheckToolPath()
		{
			string ncoverExplorerPath = (ToolPath == null) ? String.Empty : ToolPath.Trim();
			if (string.IsNullOrEmpty(ncoverExplorerPath))
			{
				// Not specified in the task arguments so might be in trouble if the user has not
				// installed it using TD.Net (which will have registry entry).
				// Let's hope the user installed it to under Program Files if not installed with TestDriven.Net
				ncoverExplorerPath = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
				ncoverExplorerPath = Path.Combine(ncoverExplorerPath, @"NCoverExplorer");
				try
				{
					using (RegistryKey buildKey = Registry.CurrentUser.OpenSubKey(@"Software\KiwiDevelopment\NCoverExplorer"))
					{
						if (buildKey == null)
						{
							Log.LogError(Properties.Resources.NCoverExplorerNotFound);
						}
						else
						{
							ncoverExplorerPath = buildKey.GetValue("InstallDir").ToString();
						}
					}
				}
				catch (Exception ex)
				{
					Log.LogErrorFromException(ex);
				}
				ToolPath = ncoverExplorerPath;
			}
		}

		private string _GetConfigFilename()
		{
			if (_outputDir != null && _outputDir.Length > 0)
			{
				if (!Directory.Exists(_outputDir))
				{
					Directory.CreateDirectory(_outputDir);
				}
				return Path.Combine(_outputDir, _configName);
			}
			else
			{
				return _configName;
			}
		}

		private void _BuildTempConfigXmlFile()
		{
			using (Stream fileStream = File.Create(_GetConfigFilename()))
			{
				XmlTextWriter xmlTextWriter = new XmlTextWriter(fileStream, Encoding.UTF8);
				xmlTextWriter.Indentation = 2;
				xmlTextWriter.Formatting = Formatting.Indented;

				xmlTextWriter.WriteStartDocument();
				xmlTextWriter.WriteStartElement("NCoverExplorer");

				if (!string.IsNullOrEmpty(_projectName))
				{
					xmlTextWriter.WriteElementString("ProjectName", _projectName);
				}

				xmlTextWriter.WriteElementString("SatisfactoryCoverageThreshold", _satisfactoryCoverage.ToString());

				xmlTextWriter.WriteStartElement("CoverageExclusions");
				if (_coverageExclusions != null)
				{
					foreach (ITaskItem coverageExclusion in _coverageExclusions)
					{
						xmlTextWriter.WriteStartElement("CoverageExclusion");
						string[] exclusionElements = coverageExclusion.ItemSpec.Split('=');
						if (exclusionElements.Length != 2)
						{
							Log.LogError(Properties.Resources.NCoverExplorerInvalidExclusion, coverageExclusion.ItemSpec);
							throw new InvalidDataException(string.Format(Properties.Resources.NCoverExplorerInvalidExclusion,
								coverageExclusion.ItemSpec));
						}
						xmlTextWriter.WriteElementString("ExclusionType", exclusionElements[0].ToString());
						xmlTextWriter.WriteElementString("Pattern", exclusionElements[1].ToString());
						xmlTextWriter.WriteEndElement();
					}
				}
				xmlTextWriter.WriteEndElement();

				xmlTextWriter.WriteStartElement("ModuleThresholds");
				if (_moduleThresholds != null)
				{
					foreach (ITaskItem moduleThreshold in _moduleThresholds)
					{
						xmlTextWriter.WriteStartElement("ModuleThreshold");
						string[] thresholdElements = moduleThreshold.ItemSpec.Split('=');
						if (thresholdElements.Length != 2)
						{
							Log.LogError(Properties.Resources.NCoverExplorerInvalidExclusion, moduleThreshold.ItemSpec);
							throw new InvalidDataException(string.Format(Properties.Resources.NCoverExplorerInvalidExclusion,
								moduleThreshold.ItemSpec));
						}
						xmlTextWriter.WriteAttributeString("moduleName", thresholdElements[0].ToString());
						xmlTextWriter.WriteAttributeString("satisfactoryCoverage", thresholdElements[1].ToString());
						xmlTextWriter.WriteEndElement();
					}
				}
				xmlTextWriter.WriteEndElement();

				xmlTextWriter.WriteEndElement(); // NCoverExplorer
				xmlTextWriter.WriteEndDocument();
				xmlTextWriter.Flush();

				fileStream.Close();
			}
		}

		/// <summary>
		/// Removes generated config file after process has run.
		/// </summary>
		private void _CleanupConfigFile()
		{
			string filename = _GetConfigFilename();
			if (File.Exists(filename))
			{
				Log.LogMessage(MessageImportance.Low, Properties.Resources.NCoverExplorerDeletingConfig, filename);
				File.Delete(filename);
			}
		}

		#endregion Private Methods
	}
}
