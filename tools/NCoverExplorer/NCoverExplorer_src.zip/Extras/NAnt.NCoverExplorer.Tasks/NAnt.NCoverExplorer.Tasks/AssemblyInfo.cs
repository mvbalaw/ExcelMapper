using System.Reflection;

[assembly: AssemblyTitle("NAnt.NCoverExplorer.Tasks")]
[assembly: AssemblyDescription("NAnt tasks for executing NCoverExplorer.Console in continuous build processes.")]
[assembly: AssemblyCompany("Kiwi Development Ltd")]
[assembly: AssemblyCopyright("Copyright � 2006 Kiwi Development Ltd.")]
[assembly: AssemblyProduct("NCoverExplorer")]
[assembly: AssemblyVersion("1.3.4.1679")]
