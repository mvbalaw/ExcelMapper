#region Copyright � 2006 Grant Drake. All rights reserved.
/*
Copyright � 2006 Grant Drake. All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. The name of the author may not be used to endorse or promote products
   derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR "AS IS" AND ANY EXPRESS OR
IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#endregion

using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml;

using NAnt.Core;
using NAnt.Core.Attributes;
using NAnt.Core.Types;
using NAnt.Core.Util;

using NAnt.NCoverExplorer.Tasks.Types;

namespace NAnt.NCoverExplorer.Tasks
{
	/// <summary>
	/// NAnt task for automating NCoverExplorer.Console.
	/// </summary>
	/// <example>
	///        <code>
	///            <![CDATA[
	///            <ncoverexplorer program="tools\ncoverexplorer\ncoverexplorer.console.exe� 
	///							   projectName="MyProject" 
	///							   reportType="3"
	///							   outputDir="${build.reports}"
	///							   xmlReportName="CoverageSummary.xml"
	///							   htmlReportName="CoverageSummary.html"
	///							   mergeFileName="CoverageMerged.xml"
	///							   showExcluded="True"
	///							   satisfactoryCoverage="80"
	///							   failMinimum="False">
	///                <fileset>
	///                    <include name="coverage.xml" />
	///                </fileset>
	///                <exclusions>
	///                    <exclusion type="Assembly" pattern="*.Tests" />
	///                    <exclusion type="Namespace" pattern="MyApp.SomeNamespace" />
	///                    <exclusion type="Class" pattern="MyApp.SomeNamespace.SomeClass" />
	///                </exclusions>
	///                <moduleThresholds>
	///                    <moduleThreshold moduleName="MyApp.1.dll" satisfactoryCoverage="75" />
	///                    <moduleThreshold moduleName="MyApp.2.dll" satisfactoryCoverage="85" />
	///                </moduleThresholds>
	///            </ncoverexplorer>
	///            ]]>
	///        </code>
	/// </example>
	[TaskName("ncoverexplorer")]
	public class NCoverExplorerTask : NAnt.Core.Tasks.ExternalProgramBase
	{
		#region Private Variables / Constants

		private const string DefaultApplicationName = "NCoverExplorer.Console.exe";
		private const string DefaultConfigName = "NAnt.NCoverExplorer.config";

		private string _projectName;
		private string _outputDir;
		private string _configName;
		private string _xmlReportName;
		private string _htmlReportName;
		private string _mergeFileName;
		private bool _showExcluded;
		private bool _failMinimum;
		private float _satisfactoryCoverage;
		private int _reportType;
		private FileSet _coverageFiles;
		private CoverageExclusionCollection _coverageExclusions;
		private ModuleThresholdCollection _moduleThresholds;

		private StringBuilder _programArguments;

		#endregion Private Variables / Constants

		#region Constructors

		/// <summary>
		/// Default constructor
		/// </summary>
		public NCoverExplorerTask()
		{
			_coverageFiles = new FileSet();
			_configName = DefaultConfigName;
			_satisfactoryCoverage = 100;
			_reportType = 1;
			_programArguments = new StringBuilder();
			_coverageExclusions = new CoverageExclusionCollection();
			_moduleThresholds = new ModuleThresholdCollection();

			ExeName = DefaultApplicationName;
		}

		#endregion Constructors

		#region Properties

		/// <summary>
		/// The name of the executable that should be used to launch the
		/// external program.
		/// </summary>
		/// <value>
		/// The name of the executable that should be used to launch the external
		/// program, or <see langword="null"/> if no name is specified.
		/// </value>
		/// <remarks>
		/// If available, the configured value in the NAnt configuration
		/// file will be used if no name is specified.
		/// </remarks>
		[TaskAttribute("program", Required=false)]
		[StringValidator(AllowEmpty=false)]
		public override string ExeName
		{
			get { return base.ExeName; }
			set { base.ExeName = value; }
		}

		/// <summary>
		/// Gets or sets the output directory for the reports.
		/// </summary>
		/// <value>The output dir.</value>
		[TaskAttribute("outputDir", Required=false)]
		[StringValidator(AllowEmpty=false)]
		public string OutputDir
		{
			get { return _outputDir; }
			set { _outputDir = value; }
		}

		/// <summary>
		/// Whether to fail the task if the satisfactory coverage threshold is not reached. 
		/// NCoverExplorer console application will return exit code 3.
		/// </summary>
		[TaskAttribute("failMinimum")]
		public bool FailMinimum
		{
			get { return _failMinimum; }
			set { _failMinimum = value; }
		}

		/// <summary>
		/// The satisfactory coverage percentage for display in the reports.
		/// </summary>
		[TaskAttribute("satisfactoryCoverage")]
		public float SatisfactoryCoverage
		{
			get { return _satisfactoryCoverage; }
			set { _satisfactoryCoverage = value; }
		}

		/// <summary>
		/// The project name to appear in the report.
		/// </summary>
		[TaskAttribute("projectName")]
		public string ProjectName
		{
			get { return _projectName; }
			set { _projectName = value; }
		}

		/// <summary>
		/// The type of report to produce. 0 = None, 1 = Module summary (default), 2 = Namespace, 
		/// 3 = Module/Namespace, 4 = Module/Class
		/// </summary>
		[TaskAttribute("reportType")]
		public int ReportType
		{
			get { return _reportType; }
			set { _reportType = value; }
		}

		/// <summary>
		/// The filename for generating an xml report.
		/// </summary>
		[TaskAttribute("xmlReportName")]
		public string XmlReportName
		{
			get { return _xmlReportName; }
			set { _xmlReportName = value; }
		}

		/// <summary>
		/// The filename for generating an html report.
		/// </summary>
		[TaskAttribute("htmlReportName")]
		public string HtmlReportName
		{
			get { return _htmlReportName; }
			set { _htmlReportName = value; }
		}

		/// <summary>
		/// The filename for the merge of the coverage xml files.
		/// </summary>
		[TaskAttribute("mergeFileName")]
		public string MergeFileName
		{
			get { return _mergeFileName; }
			set { _mergeFileName = value; }
		}

		/// <summary>
		/// Determines whether to include the coverage exclusions in the report. The default is 
		/// <see langword="true" />.
		/// </summary>
		[TaskAttribute("showExcluded")]
		[BooleanValidator()]
		public bool ShowExcluded 
		{
			get { return _showExcluded; }
			set { _showExcluded = value; }
		}

		/// <summary>
		/// Coverage exclusions to apply.
		/// </summary>
		[BuildElementCollection("exclusions", "exclusion")]
		public CoverageExclusionCollection CoverageExclusions 
		{
			get { return _coverageExclusions; }
		}

		/// <summary>
		/// Coverage exclusions to apply.
		/// </summary>
		[BuildElementCollection("moduleThresholds", "moduleThreshold")]
		public ModuleThresholdCollection ModuleThresholds 
		{
			get { return _moduleThresholds; }
		}

		/// <summary>
		/// Used to select the coverage xml files to merge into the report. To use a <see cref="FileSet" />.
		/// </summary>
		[BuildElement("fileset")]
		public FileSet CoverageFiles 
		{
			get { return _coverageFiles; }
			set { _coverageFiles = value; }
		}

		#endregion Properties

		#region Override implementation of ExternalProgramBase

		/// <summary>
		/// The command-line arguments for the external program.
		/// </summary>
		public override string ProgramArguments
		{
			get	{ return _programArguments.ToString(); }
		}

		/// <summary>
		/// Performs logic before the external process is started.
		/// </summary>
		/// <param name="process">Process.</param>
		protected override void PrepareProcess(Process process) 
		{
			_BuildTempConfigXmlFile();
			_BuildArguments();

			Log(Level.Verbose, "Working directory: {0}", BaseDirectory);
			Log(Level.Verbose, "Arguments: {0}", ProgramArguments);

			base.PrepareProcess(process);
		}

		/// <summary>
		/// Starts the process and handles errors.
		/// </summary>
		/// <returns>
		/// The <see cref="T:System.Diagnostics.Process"/> that was started.
		/// </returns>
		protected override Process StartProcess()
		{
			Process process = base.StartProcess();
			process.Exited += new System.EventHandler(_OnProcessExited);
			return process;
		}


		#endregion Override implementation of ExternalProgramBase

		#region Private Methods

		/// <summary>
		/// Removes generated config file after process has run.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void _OnProcessExited(object sender, System.EventArgs e)
		{
			string filename = _GetConfigFilename();
			if ( File.Exists( filename ) )
			{
				Log( Level.Verbose, "Deleting config file: " + filename );
				File.Delete( filename );
			}
		}

		/// <summary>
		/// Concatenates variables for complete filename.
		/// </summary>
		/// <returns>Configuration filename.</returns>
		private string _GetConfigFilename()
		{
			if ( _outputDir != null && _outputDir.Length > 0 )
			{
				if ( !Directory.Exists(_outputDir) )
				{
					Directory.CreateDirectory( _outputDir );
				}
				return Path.Combine( _outputDir, _configName );
			}
			else
			{
				return _configName;
			}
		}

		/// <summary>
		/// Builds the arguments to pass to the exe.
		/// </summary>
		private void _BuildArguments() 
		{
			_programArguments.AppendFormat("/r:{0} ", _reportType.ToString());
			if (!StringUtils.IsNullOrEmpty(_htmlReportName)) 
			{
				if (!Path.IsPathRooted(_htmlReportName) && !StringUtils.IsNullOrEmpty(_outputDir))
				{
					_htmlReportName = Path.Combine(_outputDir, _htmlReportName);
				}
				_programArguments.AppendFormat("/h:\"{0}\" ", _htmlReportName);
			}
			if (!StringUtils.IsNullOrEmpty(_xmlReportName)) 
			{
				if (!Path.IsPathRooted(_xmlReportName) && !StringUtils.IsNullOrEmpty(_outputDir))
				{
					_xmlReportName = Path.Combine(_outputDir, _xmlReportName);
				}
				_programArguments.AppendFormat("/x:\"{0}\" ", _xmlReportName);
			}
			if (!StringUtils.IsNullOrEmpty(_mergeFileName)) 
			{
				if (!Path.IsPathRooted(_mergeFileName) && !StringUtils.IsNullOrEmpty(_outputDir))
				{
					_mergeFileName = Path.Combine(_outputDir, _mergeFileName);
				}
				_programArguments.AppendFormat("/s:\"{0}\" ", _mergeFileName);
			}
			if (_showExcluded)
			{
				_programArguments.Append("/e ");
			}
			if (_failMinimum)
			{
				_programArguments.Append("/f ");
			}
			_programArguments.AppendFormat("/c:\"{0}\" ", _GetConfigFilename());

			foreach (string fileName in _coverageFiles.FileNames) 
			{
				_programArguments.AppendFormat("\"{0}\" ", fileName);
			}
		}

		/// <summary>
		/// Build the Xml config file to pass to the NCoverExplorer.Console executable.
		/// </summary>
		private void _BuildTempConfigXmlFile()
		{
			using (Stream fileStream = File.Create(_GetConfigFilename()))
			{
				XmlTextWriter xmlTextWriter = new XmlTextWriter(fileStream, Encoding.UTF8);
				xmlTextWriter.Indentation = 2;
				xmlTextWriter.Formatting = Formatting.Indented;

				xmlTextWriter.WriteStartDocument();
				xmlTextWriter.WriteStartElement("NCoverExplorer");

				if (!StringUtils.IsNullOrEmpty(_projectName))
				{
					xmlTextWriter.WriteElementString("ProjectName", _projectName);
				}

				xmlTextWriter.WriteElementString("SatisfactoryCoverageThreshold", XmlConvert.ToString(_satisfactoryCoverage));
	
				xmlTextWriter.WriteStartElement("CoverageExclusions");
				foreach (CoverageExclusion coverageExclusion in _coverageExclusions)
				{
					xmlTextWriter.WriteStartElement("CoverageExclusion");
					xmlTextWriter.WriteElementString("ExclusionType", coverageExclusion.ExclusionType);
					xmlTextWriter.WriteElementString("Pattern", coverageExclusion.Pattern);
					xmlTextWriter.WriteElementString("Enabled", XmlConvert.ToString(coverageExclusion.Enabled));
					xmlTextWriter.WriteEndElement();
				}
				xmlTextWriter.WriteEndElement();
					
				xmlTextWriter.WriteStartElement("ModuleThresholds");
				foreach (ModuleThreshold moduleThreshold in _moduleThresholds)
				{
					xmlTextWriter.WriteStartElement("ModuleThreshold");
					xmlTextWriter.WriteAttributeString("moduleName", moduleThreshold.ModuleName);
					xmlTextWriter.WriteAttributeString("satisfactoryCoverage", XmlConvert.ToString(moduleThreshold.SatisfactoryCoverage));
					xmlTextWriter.WriteEndElement();
				}
				xmlTextWriter.WriteEndElement();

				xmlTextWriter.WriteEndElement(); // NCoverExplorer
				xmlTextWriter.WriteEndDocument();
				xmlTextWriter.Flush();

				fileStream.Close();
			}
		}

		#endregion Private Methods
	}
}
