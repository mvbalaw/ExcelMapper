using System.Reflection;

[assembly: AssemblyVersion("1.3.4.1705")]
[assembly: AssemblyCompany("Kiwi Development Ltd")]
[assembly: AssemblyCopyright("Copyright � 2006 Kiwi Development Ltd.")]
[assembly: AssemblyProduct("NCoverExplorer")]

/// <summary>
/// NCover code coverage exclusion attribute.
/// </summary>
internal class CoverageExcludeAttribute : System.Attribute {}